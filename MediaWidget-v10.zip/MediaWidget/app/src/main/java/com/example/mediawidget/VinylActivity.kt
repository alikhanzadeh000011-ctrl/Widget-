package com.example.mediawidget

import android.app.Activity
import android.content.ComponentName
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.media.AudioManager
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.KeyEvent
import android.view.View
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.view.WindowManager

/** صفحه‌ی اصلی اپ: فول‌اسکرین، دیسک وینیل. با هر پلیری کار می‌کنه (از MediaSession می‌خونه). */
class VinylActivity : Activity(), VinylView.Listener {

    private lateinit var vinyl: VinylView
    private var msm: MediaSessionManager? = null
    private var controllers: List<MediaController> = emptyList()
    private val component by lazy { ComponentName(this, MediaListenerService::class.java) }

    private val sessionsListener = MediaSessionManager.OnActiveSessionsChangedListener { list ->
        bind(list.orEmpty())
    }

    private val callback = object : MediaController.Callback() {
        override fun onMetadataChanged(metadata: MediaMetadata?) = reload()
        override fun onPlaybackStateChanged(state: PlaybackState?) = reload()
        override fun onSessionDestroyed() = reload()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setBackgroundDrawable(ColorDrawable(Color.BLACK))
        setupWindow()
        vinyl = VinylView(this)
        vinyl.listener = this
        setContentView(vinyl)
        enterImmersive()
    }

    override fun onResume() {
        super.onResume()
        enterImmersive()
        val m = getSystemService(MediaSessionManager::class.java)
        msm = m
        try {
            m.addOnActiveSessionsChangedListener(sessionsListener, component)
            bind(m.getActiveSessions(component))
        } catch (e: SecurityException) {
            controllers = emptyList()
            vinyl.update(MediaInfo(hasAccess = false))
        }
    }

    override fun onPause() {
        super.onPause()
        try {
            msm?.removeOnActiveSessionsChangedListener(sessionsListener)
        } catch (e: Exception) {
            // مهم نیست
        }
        controllers.forEach { it.unregisterCallback(callback) }
        controllers = emptyList()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) enterImmersive()
    }

    private fun bind(list: List<MediaController>) {
        controllers.forEach { it.unregisterCallback(callback) }
        controllers = list
        list.forEach { it.registerCallback(callback) }
        reload()
    }

    private fun reload() {
        vinyl.update(MediaReader.read(this))
    }

    // ------------------------------------------------------------ فول‌اسکرین

    private fun setupWindow() {
        if (Build.VERSION.SDK_INT >= 28) {
            val lp = window.attributes
            lp.layoutInDisplayCutoutMode = if (Build.VERSION.SDK_INT >= 30) {
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
            } else {
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
            window.attributes = lp
        }
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
    }

    @Suppress("DEPRECATION")
    private fun enterImmersive() {
        if (Build.VERSION.SDK_INT >= 30) {
            window.setDecorFitsSystemWindows(false)
            val ctl = window.insetsController
            if (ctl != null) {
                ctl.hide(WindowInsets.Type.systemBars())
                ctl.systemBarsBehavior = WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }
        } else {
            val flags = View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_FULLSCREEN or
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            window.decorView.systemUiVisibility = flags
        }
    }

    // ------------------------------------------------------------ دکمه‌ها

    private fun currentController(): MediaController? {
        return try {
            val list = MediaReader.controllers(this)
            if (list == null) null else MediaReader.pick(list)
        } catch (e: SecurityException) {
            null
        }
    }

    private fun sendKey(code: Int) {
        val am = getSystemService(AudioManager::class.java)
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
    }

    override fun onPlayPause() {
        val c = currentController()
        if (c != null) {
            if (c.playbackState?.state == PlaybackState.STATE_PLAYING) {
                c.transportControls.pause()
            } else {
                c.transportControls.play()
            }
        } else {
            sendKey(KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE)
        }
    }

    override fun onPrev() {
        val c = currentController()
        if (c != null) c.transportControls.skipToPrevious() else sendKey(KeyEvent.KEYCODE_MEDIA_PREVIOUS)
    }

    override fun onNext() {
        val c = currentController()
        if (c != null) c.transportControls.skipToNext() else sendKey(KeyEvent.KEYCODE_MEDIA_NEXT)
    }

    override fun onNeedleLift() {
        val c = currentController()
        if (c != null) c.transportControls.pause() else sendKey(KeyEvent.KEYCODE_MEDIA_PAUSE)
    }

    override fun onNeedleDrop(positionMs: Long) {
        val c = currentController()
        if (c != null) {
            if (positionMs >= 0L) c.transportControls.seekTo(positionMs)
            c.transportControls.play()
        } else {
            sendKey(KeyEvent.KEYCODE_MEDIA_PLAY)
        }
    }

    override fun onNeedAccess() {
        startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
    }

    /** نگه داشتن انگشت: صفحه‌ی تنظیمات قدیمی (دسترسی و پوشه‌های ویجت Library) */
    override fun onLongPress() {
        startActivity(Intent(this, MainActivity::class.java))
    }
}
