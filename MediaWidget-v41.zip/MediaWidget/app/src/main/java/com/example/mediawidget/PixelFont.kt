package com.example.mediawidget

import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF

/**
 * فونت پیکسلی ۵×۷ (مثل ویجت‌های MD) که با کد کشیده میشه؛ فقط ASCII.
 * برای متن‌های غیر ASCII (فارسی، چینی و...) باید از فونت معمولی استفاده بشه (supports()).
 */
object PixelFont {

    // ستونی: هر کاراکتر ۵ بایت، بیت ۰ = ردیف بالا؛ ASCII 32..126
    private val DATA = (
        "00 00 00 00 00|00 00 5F 00 00|00 07 00 07 00|14 7F 14 7F 14|24 2A 7F 2A 12|23 13 08 64 62|36 49 56 20 50|00 08 07 03 00|" +
        "00 1C 22 41 00|00 41 22 1C 00|2A 1C 7F 1C 2A|08 08 3E 08 08|00 80 70 30 00|08 08 08 08 08|00 00 60 60 00|20 10 08 04 02|" +
        "3E 51 49 45 3E|00 42 7F 40 00|72 49 49 49 46|21 41 49 4D 33|18 14 12 7F 10|27 45 45 45 39|3C 4A 49 49 31|41 21 11 09 07|" +
        "36 49 49 49 36|46 49 49 29 1E|00 00 14 00 00|00 40 34 00 00|00 08 14 22 41|14 14 14 14 14|00 41 22 14 08|02 01 59 09 06|" +
        "3E 41 5D 59 4E|7C 12 11 12 7C|7F 49 49 49 36|3E 41 41 41 22|7F 41 41 41 3E|7F 49 49 49 41|7F 09 09 09 01|3E 41 41 51 73|" +
        "7F 08 08 08 7F|00 41 7F 41 00|20 40 41 3F 01|7F 08 14 22 41|7F 40 40 40 40|7F 02 1C 02 7F|7F 04 08 10 7F|3E 41 41 41 3E|" +
        "7F 09 09 09 06|3E 41 51 21 5E|7F 09 19 29 46|26 49 49 49 32|03 01 7F 01 03|3F 40 40 40 3F|1F 20 40 20 1F|3F 40 38 40 3F|" +
        "63 14 08 14 63|03 04 78 04 03|61 59 49 4D 43|00 7F 41 41 41|02 04 08 10 20|00 41 41 41 7F|04 02 01 02 04|40 40 40 40 40|" +
        "00 03 07 08 00|20 54 54 78 40|7F 28 44 44 38|38 44 44 44 28|38 44 44 28 7F|38 54 54 54 18|00 08 7E 09 02|18 A4 A4 9C 78|" +
        "7F 08 04 04 78|00 44 7D 40 00|20 40 40 3D 00|7F 10 28 44 00|00 41 7F 40 00|7C 04 78 04 78|7C 08 04 04 78|38 44 44 44 38|" +
        "FC 18 24 24 18|18 24 24 18 FC|7C 08 04 04 08|48 54 54 54 24|04 04 3F 44 24|3C 40 40 20 7C|1C 20 40 20 1C|3C 40 30 40 3C|" +
        "44 28 10 28 44|4C 90 90 90 7C|44 64 54 4C 44|00 08 36 41 00|00 00 77 00 00|00 41 36 08 00|02 01 02 04 02"
        ).split("|").map { g -> g.trim().split(" ").map { it.toInt(16) }.toIntArray() }

    fun supports(s: String): Boolean = s.all { it.code in 32..126 }

    /** عرض متن به پیکسل (p = اندازه‌ی هر نقطه) */
    fun width(text: String, p: Float): Float = if (text.isEmpty()) 0f else text.length * 6f * p - p

    /** متن رو طوری کوتاه می‌کنه که تو عرض مجاز جا بشه (آخرش «..») */
    fun fit(text: String, p: Float, maxW: Float): String {
        if (width(text, p) <= maxW) return text
        var t = text
        while (t.length > 1 && width("$t..", p) > maxW) t = t.dropLast(1)
        return "$t.."
    }

    /** x = شروع متن، baseline = خط پایه‌ی حروف (پایین ردیف ۷ام)؛ حروف بدون دنباله روی همین خط میشینن */
    fun draw(c: Canvas, text: String, x: Float, baseline: Float, p: Float, paint: Paint) {
        val r = RectF()
        val top = baseline - 7f * p
        var cx = x
        val round = p * 0.14f
        for (ch in text) {
            val code = ch.code
            if (code in 32..126) {
                val g = DATA[code - 32]
                for (col in 0 until 5) {
                    val bits = g[col]
                    if (bits == 0) continue
                    for (row in 0 until 8) {
                        if ((bits shr row) and 1 == 1) {
                            r.set(cx + col * p, top + row * p, cx + (col + 1) * p, top + (row + 1) * p)
                            c.drawRoundRect(r, round, round, paint)
                        }
                    }
                }
            }
            cx += 6f * p
        }
    }
}
