package com.example.mediawidget

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.util.concurrent.Executors

/** صفحه‌ی آلبوم‌ها (یا پوشه‌ها): چیدمان ۳بعدی یا گالری؛ دیسک بالا-چپ، تغییر حالت بالا-راست */
class AlbumsActivity : Activity(), AlbumStackView.Listener {

    private lateinit var stack: AlbumStackView
    private lateinit var toggle: ToggleView
    private lateinit var discBtn: DiscView
    private lateinit var permPanel: LinearLayout
    private lateinit var emptyText: TextView
    private var loaded = false

    private fun perm(): String =
        if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE

    private fun hasPerm(): Boolean = checkSelfPermission(perm()) == PackageManager.PERMISSION_GRANTED

    private fun dp(v: Float) = DarkUi.dp(this, v)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        DarkUi.guard(this) { build() }
    }

    @Suppress("DEPRECATION")
    private fun enterImmersive() {
        if (Build.VERSION.SDK_INT >= 30) {
            window.setDecorFitsSystemWindows(false)
            window.insetsController?.let {
                it.systemBarsBehavior = WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                it.hide(WindowInsets.Type.systemBars())
            }
        } else {
            window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_FULLSCREEN or
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) enterImmersive()
    }

    @Suppress("DEPRECATION")
    private fun build() {
        DarkUi.setupWindow(this)
        if (Build.VERSION.SDK_INT >= 28) {
            val lp = window.attributes
            lp.layoutInDisplayCutoutMode = android.view.WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            window.attributes = lp
        }
        enterImmersive()

        val root = FrameLayout(this)
        root.setBackgroundColor(DarkUi.BG)

        stack = AlbumStackView(this)
        stack.listener = this
        root.addView(stack, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        // دکمه‌ی تغییر حالت (بالا-راست)
        toggle = ToggleView(this)
        toggle.setOnClickListener {
            stack.toggleMode()
            toggle.grid = stack.isGrid()
            toggle.invalidate()
        }
        root.addView(toggle, FrameLayout.LayoutParams(dp(52f), dp(52f), Gravity.TOP or Gravity.END))

        // دکمه‌ی دیسک (بالا-چپ): برگشت به صفحه‌ی وینیل
        discBtn = DiscView(this)
        discBtn.setOnClickListener { finish() }
        root.addView(discBtn, FrameLayout.LayoutParams(dp(52f), dp(52f), Gravity.TOP or Gravity.START))

        emptyText = TextView(this)
        emptyText.text = "Nothing to show here"
        emptyText.setTextColor(DarkUi.LABEL)
        emptyText.textSize = 18f
        emptyText.typeface = DarkUi.font(this)
        emptyText.gravity = Gravity.CENTER
        emptyText.visibility = View.GONE
        root.addView(emptyText, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        permPanel = LinearLayout(this)
        permPanel.orientation = LinearLayout.VERTICAL
        permPanel.gravity = Gravity.CENTER
        permPanel.setPadding(dp(32f), 0, dp(32f), 0)
        val msg = TextView(this)
        msg.text = "Allow access to your music files to show your albums."
        msg.setTextColor(Color.WHITE)
        msg.textSize = 18f
        msg.typeface = DarkUi.font(this)
        msg.gravity = Gravity.CENTER
        msg.setLineSpacing(0f, 1.2f)
        permPanel.addView(msg)
        val btn = DarkUi.pill(this, "Allow access") { requestPermissions(arrayOf(perm()), 7) }
        val blp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        blp.topMargin = dp(22f)
        permPanel.addView(btn, blp)
        permPanel.visibility = View.GONE
        root.addView(permPanel, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        root.setOnApplyWindowInsetsListener { _, ins ->
            var top = ins.systemWindowInsetTop
            var left = ins.systemWindowInsetLeft
            var right = ins.systemWindowInsetRight
            val bottom = ins.systemWindowInsetBottom
            if (Build.VERSION.SDK_INT >= 28) {
                val cut = ins.displayCutout
                if (cut != null) {
                    top = maxOf(top, cut.safeInsetTop)
                    left = maxOf(left, cut.safeInsetLeft)
                    right = maxOf(right, cut.safeInsetRight)
                }
            }
            stack.setInsets(top, bottom)
            val tl = toggle.layoutParams as FrameLayout.LayoutParams
            tl.topMargin = top + dp(14f)
            tl.rightMargin = right + dp(18f)
            toggle.layoutParams = tl
            val dl = discBtn.layoutParams as FrameLayout.LayoutParams
            dl.topMargin = top + dp(14f)
            dl.leftMargin = left + dp(18f)
            discBtn.layoutParams = dl
            ins
        }

        setContentView(root)
        root.requestApplyInsets()
        refreshState()
    }

    override fun onResume() {
        super.onResume()
        if (::stack.isInitialized) refreshState()
    }

    private fun refreshState() {
        if (hasPerm()) {
            permPanel.visibility = View.GONE
            if (!loaded) loadAlbums()
        } else {
            permPanel.visibility = View.VISIBLE
            stack.visibility = View.INVISIBLE
        }
    }

    private fun loadAlbums() {
        loaded = true
        val app = applicationContext
        val mode = LibraryPrefs.mode(app)
        Executors.newSingleThreadExecutor().execute {
            val list = AlbumRepo.loadVisible(app, mode)
            runOnUiThread {
                if (isDestroyed) return@runOnUiThread
                stack.visibility = View.VISIBLE
                stack.setAlbums(list)
                emptyText.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
            }
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        refreshState()
    }

    override fun onAlbumTap(album: Album, index: Int) {
        // مرحله‌ی بعد: صفحه‌ی آلبوم با لیست ترک‌ها
        Toast.makeText(this, album.title + " (" + album.tracks + ")", Toast.LENGTH_SHORT).show()
    }

    /** نگه داشتن انگشت روی یک کارت: پیشنهاد مخفی کردن */
    override fun onAlbumLongPress(album: Album, index: Int) {
        val mode = LibraryPrefs.mode(this)
        AlertDialog.Builder(this)
            .setTitle(album.title)
            .setMessage("Hide this " + (if (mode == LibraryPrefs.FOLDERS) "folder" else "album") + "? You can show it again from Settings > Hidden items.")
            .setPositiveButton("Hide") { _, _ ->
                LibraryPrefs.setHidden(this, mode, album.key, true)
                loaded = false
                loadAlbums()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    /** دکمه‌ی گرد بالا-راست: آیکن شبکه (حالت ۳بعدی) یا آیکن پشته (حالت گالری) */
    private class ToggleView(ctx: Activity) : View(ctx) {
        var grid = false
        private val p = Paint(Paint.ANTI_ALIAS_FLAG)
        private val r = RectF()

        override fun onDraw(c: Canvas) {
            val w = width.toFloat()
            val cx = w / 2f
            val cy = height / 2f
            p.style = Paint.Style.FILL
            p.color = Color.argb(110, 0, 0, 0)
            c.drawCircle(cx, cy, w / 2f, p)
            p.color = Color.WHITE
            val u = w / 52f
            if (!grid) {
                val s = 8f * u
                val g = 4f * u
                for (i in 0..1) for (j in 0..1) {
                    val x = cx - s - g / 2f + i * (s + g)
                    val y = cy - s - g / 2f + j * (s + g)
                    r.set(x, y, x + s, y + s)
                    c.drawRoundRect(r, 2f * u, 2f * u, p)
                }
            } else {
                for (i in 0..2) {
                    val y = cy - 9f * u + i * 9f * u
                    val inset = (2 - i) * 2.5f * u
                    r.set(cx - 12f * u + inset, y - 3f * u, cx + 12f * u - inset, y + 3f * u)
                    c.drawRoundRect(r, 1.5f * u, 1.5f * u, p)
                }
            }
        }
    }

    /** دکمه‌ی گرد بالا-چپ با لوگوی دیسک (برگشت به صفحه‌ی وینیل) */
    private class DiscView(ctx: Activity) : View(ctx) {
        private val p = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
        private val logo: Bitmap? = try {
            BitmapFactory.decodeResource(ctx.resources, R.drawable.ic_theme_logo)
        } catch (e: Exception) {
            null
        }
        private val r = RectF()

        override fun onDraw(c: Canvas) {
            val w = width.toFloat()
            val cx = w / 2f
            val cy = height / 2f
            p.style = Paint.Style.FILL
            p.color = Color.argb(110, 0, 0, 0)
            c.drawCircle(cx, cy, w / 2f, p)
            val lg = logo ?: return
            val h = w * 0.30f
            r.set(cx - h, cy - h, cx + h, cy + h)
            c.drawBitmap(lg, null, r, p)
        }
    }
}
