package com.example.mediawidget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.CornerPathEffect
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.util.TypedValue
import android.view.View
import android.widget.RemoteViews
import kotlin.math.min

/**
 * ویجت‌های وینیل: دیسک و بازو به‌صورت یک تصویر ثابت، و برچسب (کاور) جدا که می‌چرخه.
 * چرخش نرم با ViewFlipper و انیمیشن چرخش انجام میشه که خود لانچر اجرا می‌کنه.
 */
object VinylWidgets {

    private const val SPIN_MS = 12000L
    private const val DEG_PER_SEC = 360f / 12f
    private const val LABEL_RATIO = 0.69f   // قطر کاور نسبت به قطر دیسک (از ویدیوی مرجع)
    private const val CORNER_RATIO = 0.176f
    private const val CORNER_DP = 28.16f

    private class Geo(val cx: Float, val cy: Float, val r: Float)

    private val recCache = HashMap<String, Bitmap>()
    private val armCache = HashMap<Int, Bitmap>()

    private fun geo(kind: Kind, bw: Int, bh: Int): Geo = when (kind) {
        Kind.VDISC -> Geo(bw / 2f, bh / 2f, 0.389f * min(bw, bh))
        Kind.VHALF, Kind.VCTRL -> Geo(bw / 2f, 0.11f * bh, 0.386f * bw)
        Kind.VWIDE -> Geo(0.73f * bw, bh / 2f, min(0.40f * bh, 0.225f * bw))
        else -> Geo(bw / 2f, 0.44f * bh, 0.31f * min(bw, bh))
    }

    // ---------------------------------------------------------------- زاویه‌ی چرخش

    /** زاویه‌ی فعلی کاور؛ وقتی پخش میشه از زمان شروع حساب میشه و وقتی متوقفه ثابت می‌مونه */
    private fun spinAngle(ctx: Context, info: MediaInfo): Float {
        val p = ctx.getSharedPreferences("spin", Context.MODE_PRIVATE)
        val now = System.currentTimeMillis()
        var a0 = p.getFloat("a0", 0f)
        var t0 = p.getLong("t0", now)
        var was = p.getBoolean("playing", false)
        val key = p.getString("key", "") ?: ""
        val playing = info.hasMedia && info.playing
        if (key != info.key) {
            a0 = 0f
            t0 = now
            was = playing
        } else if (playing && !was) {
            t0 = now
        } else if (!playing && was) {
            a0 = (a0 + (now - t0) * DEG_PER_SEC / 1000f) % 360f
        }
        val cur = if (playing) (a0 + (now - t0) * DEG_PER_SEC / 1000f) % 360f else a0
        p.edit().putFloat("a0", a0).putLong("t0", t0).putBoolean("playing", playing).putString("key", info.key).apply()
        return cur
    }

    // ---------------------------------------------------------------- ساخت تصویرها

    private fun record(ctx: Context, s: Float): Bitmap {
        val custom = ThemeStore.selected(ctx, ThemeStore.DISC)
        val key = (custom?.name ?: "def") + "|" + (s * 1000f).toInt()
        recCache[key]?.let { return it }
        if (recCache.size > 6) recCache.clear()
        var made: Bitmap? = null
        if (custom != null) {
            val src = ThemeStore.decodeFile(custom, 1400)
            if (src != null) made = VinylArt.customRecord(src, s)
        }
        val rec = made ?: VinylArt.recordBitmap(s)
        recCache[key] = rec
        return rec
    }

    private fun arm(s: Float): Bitmap {
        val key = (s * 1000f).toInt()
        return armCache.getOrPut(key) {
            if (armCache.size > 6) armCache.clear()
            VinylArt.armBitmap(s)
        }
    }

    /** دیسک ثابت + جای بازو + بازو (بدون برچسب) */
    private fun scene(ctx: Context, bw: Int, bh: Int, g: Geo, playing: Boolean, radius: Float): Bitmap {
        val bmp = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val clip = Path()
        clip.addRoundRect(RectF(0f, 0f, bw.toFloat(), bh.toFloat()), radius, radius, Path.Direction.CW)
        c.clipPath(clip)

        val s = g.r / VinylArt.R
        val k = VinylArt.K
        fun px(ax: Float) = g.cx + (ax - VinylArt.CX) * s
        fun py(ay: Float) = g.cy + (ay - VinylArt.CY) * s

        // جای بازو
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        val box = RectF(px(780f), py(200f), px(780f + 412f * k), py(200f + 604f * k))
        val rad = 412f * k / 2f * s
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 1.6f * s * 1.4f
        paint.color = Color.argb(90, 0, 0, 0)
        c.drawRoundRect(box, rad, rad, paint)
        val pocket = Path()
        val pts = VinylArt.POCKET
        pocket.moveTo(px(780f + pts[0] * k), py(200f + pts[1] * k))
        var i = 2
        while (i < pts.size) {
            pocket.lineTo(px(780f + pts[i] * k), py(200f + pts[i + 1] * k))
            i += 2
        }
        pocket.close()
        paint.pathEffect = CornerPathEffect(10f * s)
        paint.style = Paint.Style.FILL
        paint.color = Color.argb(34, 0, 0, 0)
        c.drawPath(pocket, paint)
        paint.pathEffect = null

        // دیسک
        val rec = record(ctx, s)
        c.drawBitmap(rec, g.cx - rec.width / 2f, g.cy - rec.height / 2f, Paint(Paint.FILTER_BITMAP_FLAG))

        // بازو: روی دیسک وقتی پخش میشه، توی جاش وقتی متوقفه
        val angle = if (playing) VinylArt.ARM_OUTER + 0.35f * (VinylArt.ARM_INNER - VinylArt.ARM_OUTER) else VinylArt.ARM_REST
        val armBmp = arm(s)
        c.save()
        c.translate(px(VinylArt.PX), py(VinylArt.PY))
        c.rotate(angle)
        c.drawBitmap(armBmp, -VinylArt.ARM_OX * s, -VinylArt.ARM_OY * s, Paint(Paint.FILTER_BITMAP_FLAG))
        c.restore()
        return bmp
    }

    /** لایه‌ی برچسب (هم‌اندازه‌ی ویجت، شفاف) که با زاویه‌ی داده‌شده چرخیده */
    private fun labelLayer(art: Bitmap?, bw: Int, bh: Int, g: Geo, angle: Float, tf: Typeface?): Bitmap {
        val bmp = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val d = (2f * g.r * LABEL_RATIO).toInt().coerceAtLeast(8)
        val label = if (art != null) VinylArt.labelFromCover(art, d) else VinylArt.blankLabel(d, tf)
        c.save()
        c.rotate(angle, g.cx, g.cy)
        c.drawBitmap(label, g.cx - d / 2f, g.cy - d / 2f, Paint(Paint.FILTER_BITMAP_FLAG))
        c.restore()
        return bmp
    }

    /** فقط خود کاور (دایره) با زاویه‌ی داده‌شده */
    private fun rotatedLabel(art: Bitmap?, d: Int, angle: Float, tf: Typeface?): Bitmap {
        val bmp = Bitmap.createBitmap(d, d, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val label = if (art != null) VinylArt.labelFromCover(art, d) else VinylArt.blankLabel(d, tf)
        c.save()
        c.rotate(angle, d / 2f, d / 2f)
        c.drawBitmap(label, 0f, 0f, Paint(Paint.FILTER_BITMAP_FLAG))
        c.restore()
        return bmp
    }

    /** پس‌زمینه‌ی نرم اپ با گوشه‌های گرد ویجت */
    private fun background(art: Bitmap?, bw: Int, bh: Int, radius: Float): Bitmap {
        val src = if (art != null) VinylArt.coverBackground(art, bw, bh) else VinylArt.greyBackground(bw, bh)
        val out = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        val clip = Path()
        clip.addRoundRect(RectF(0f, 0f, bw.toFloat(), bh.toFloat()), radius, radius, Path.Direction.CW)
        c.clipPath(clip)
        c.drawBitmap(src, null, RectF(0f, 0f, bw.toFloat(), bh.toFloat()), Paint(Paint.FILTER_BITMAP_FLAG))
        return out
    }

    // ---------------------------------------------------------------- ساخت RemoteViews

    fun build(ctx: Context, mgr: AppWidgetManager?, id: Int, kind: Kind, info: MediaInfo, tint: Tint): RemoteViews {
        val layout = when (kind) {
            Kind.VDISC -> R.layout.vinyl_disc
            Kind.VHALF -> R.layout.vinyl_half
            Kind.VCTRL -> R.layout.vinyl_ctrl
            Kind.VWIDE -> R.layout.vinyl_wide
            else -> R.layout.vinyl_big
        }
        val rv = RemoteViews(ctx.packageName, layout)
        val d = ctx.resources.displayMetrics.density

        val opts = if (mgr != null) mgr.getAppWidgetOptions(id) else Bundle()
        var wDp = opts.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 0)
        var hDp = opts.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT, 0)
        if (wDp < 50) wDp = kind.defW
        if (hDp < 40) hDp = kind.defH
        wDp = wDp.coerceAtMost(700)
        hDp = hDp.coerceAtMost(500)
        val w = wDp * d
        val h = hDp * d
        val sc = minOf(1f, 460f / maxOf(w, h))
        val bw = (w * sc).toInt().coerceAtLeast(2)
        val bh = (h * sc).toInt().coerceAtLeast(2)
        val radius = when (kind) {
            Kind.VWIDE, Kind.VBIG -> CORNER_DP * d * sc
            else -> bw * CORNER_RATIO
        }

        val art = info.art
        val playing = info.hasMedia && info.playing
        val g = geo(kind, bw, bh)

        // پس‌زمینه: همون پس‌زمینه‌ی نرم داخل اپ (گوشه‌گرد)
        rv.setImageViewBitmap(R.id.bg, background(art, bw, bh, radius))
        rv.setImageViewBitmap(R.id.scene, scene(ctx, bw, bh, g, playing, radius))

        // برچسب: متوقف = ثابت با همون زاویه‌ی آخر، در حال پخش = چرخش نرم و بی‌وقفه
        val angle = spinAngle(ctx, info)
        val tf = try {
            ctx.resources.getFont(R.font.sf_pro_soft)
        } catch (e: Exception) {
            null
        }
        if (playing && Build.VERSION.SDK_INT >= 31) {
            // یک ویوی دایره‌ای فقط به اندازه‌ی کاور، دقیقاً روی مرکز دیسک (با اندازه و فاصله‌ی دقیق)؛ انیمیشن اون رو می‌چرخونه
            val dBmp = (2f * g.r * LABEL_RATIO).toInt().coerceAtLeast(8)
            val dDp = dBmp / bw.toFloat() * wDp
            val leftDp = g.cx / bw * wDp - dDp / 2f
            val topDp = g.cy / bh * hDp - dDp / 2f
            rv.setViewLayoutWidth(R.id.spin, dDp, TypedValue.COMPLEX_UNIT_DIP)
            rv.setViewLayoutHeight(R.id.spin, dDp, TypedValue.COMPLEX_UNIT_DIP)
            rv.setViewLayoutMargin(R.id.spin, RemoteViews.MARGIN_LEFT, leftDp, TypedValue.COMPLEX_UNIT_DIP)
            rv.setViewLayoutMargin(R.id.spin, RemoteViews.MARGIN_TOP, topDp, TypedValue.COMPLEX_UNIT_DIP)
            rv.setViewVisibility(R.id.spin, View.VISIBLE)
            rv.setViewVisibility(R.id.label_static, View.GONE)
            rv.setImageViewBitmap(R.id.spin_img, rotatedLabel(art, dBmp, angle, tf))
            rv.setDisplayedChild(R.id.spin, 0)   // شروع دوباره‌ی چرخش از زاویه‌ی همین تصویر
        } else {
            // متوقف (یا اندروید قدیمی‌تر از ۱۲): کاور ثابت با همون زاویه‌ی آخر
            rv.setViewVisibility(R.id.spin, View.GONE)
            rv.setViewVisibility(R.id.label_static, View.VISIBLE)
            rv.setImageViewBitmap(R.id.label_static, labelLayer(art, bw, bh, g, angle, tf))
        }

        // متن‌ها
        if (kind == Kind.VHALF || kind == Kind.VWIDE || kind == Kind.VBIG) {
            val title = when {
                !info.hasAccess -> "Tap to allow access"
                !info.hasMedia -> "Not playing"
                info.title.isEmpty() -> "Unknown"
                else -> info.title
            }
            rv.setTextViewText(R.id.title, title)
            rv.setTextViewText(R.id.artist, info.artist)
            rv.setTextColor(R.id.title, tint.primary)
            rv.setTextColor(R.id.artist, tint.secondary)
        }

        // لمس هر جا → باز شدن پلیر (یا صفحه‌ی دسترسی)
        val openApp = if (!info.hasAccess) {
            WidgetRenderer.activity(ctx, Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS), 1)
        } else {
            info.openIntent ?: WidgetRenderer.launchPlayer(ctx, info.pkg)
        }
        rv.setOnClickPendingIntent(android.R.id.background, openApp)

        // دکمه‌ها
        if (kind == Kind.VCTRL || kind == Kind.VWIDE || kind == Kind.VBIG) {
            for (vid in intArrayOf(R.id.prev, R.id.play, R.id.next)) {
                rv.setInt(vid, "setColorFilter", tint.primary)
            }
            rv.setImageViewResource(R.id.play, if (playing) R.drawable.ic_pause else R.drawable.ic_play)
            val base = 20 + kind.ordinal * 3
            rv.setOnClickPendingIntent(R.id.prev, WidgetRenderer.wideAction(ctx, BaseWidgetProvider.ACTION_PREV, base))
            rv.setOnClickPendingIntent(R.id.play, WidgetRenderer.wideAction(ctx, BaseWidgetProvider.ACTION_TOGGLE, base + 1))
            rv.setOnClickPendingIntent(R.id.next, WidgetRenderer.wideAction(ctx, BaseWidgetProvider.ACTION_NEXT, base + 2))
        }
        return rv
    }
}
