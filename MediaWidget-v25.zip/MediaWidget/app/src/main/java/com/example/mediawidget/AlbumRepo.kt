package com.example.mediawidget

import android.content.ContentUris
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Build
import android.provider.MediaStore
import android.util.Size

/** یک آیتم کتابخانه: آلبوم یا پوشه */
class Album(val id: Long, val title: String, var artist: String, var tracks: Int) {
    var key: String = ""
    var extra: String = ""
    var coverIds: MutableList<Long> = ArrayList()
    var color: Int = 0xFF5A5A64.toInt()
    var hasColor = false
    var noCover = false
}

/** خوندن آلبوم‌ها و پوشه‌ها و کاورها از MediaStore */
object AlbumRepo {

    fun loadVisible(ctx: Context, mode: Int): List<Album> {
        val hidden = LibraryPrefs.hidden(ctx, mode)
        return load(ctx, mode).filter { it.key !in hidden }
    }

    fun load(ctx: Context, mode: Int): List<Album> =
        if (mode == LibraryPrefs.FOLDERS) loadFolders(ctx) else loadAlbums(ctx)

    private fun loadAlbums(ctx: Context): List<Album> {
        val map = LinkedHashMap<Long, Album>()
        val multi = HashSet<Long>()
        val proj = arrayOf(
            MediaStore.Audio.Media.ALBUM_ID,
            MediaStore.Audio.Media.ALBUM,
            MediaStore.Audio.Media.ARTIST
        )
        try {
            ctx.contentResolver.query(
                MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, proj,
                MediaStore.Audio.Media.IS_MUSIC + " != 0", null,
                MediaStore.Audio.Media.ALBUM + " COLLATE NOCASE ASC"
            )?.use { c ->
                val iId = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM_ID)
                val iAl = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
                val iAr = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
                while (c.moveToNext()) {
                    val id = c.getLong(iId)
                    var title = c.getString(iAl) ?: ""
                    if (title.isBlank() || title == "<unknown>") title = "Unknown album"
                    var artist = c.getString(iAr) ?: ""
                    if (artist.isBlank() || artist == "<unknown>") artist = "Unknown artist"
                    val a = map[id]
                    if (a == null) {
                        map[id] = Album(id, title, artist, 1)
                    } else {
                        a.tracks++
                        if (a.artist != artist) multi.add(id)
                    }
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        for (id in multi) map[id]?.artist = "Various Artists"
        for (a in map.values) {
            a.key = "a:" + a.title + "|" + a.artist
            a.extra = a.artist
            a.coverIds.add(a.id)
        }
        return map.values.toList()
    }

    @Suppress("DEPRECATION")
    private fun loadFolders(ctx: Context): List<Album> {
        val map = LinkedHashMap<String, Album>()
        val proj = arrayOf(
            MediaStore.Audio.Media.ALBUM_ID,
            MediaStore.Audio.Media.DATA
        )
        try {
            ctx.contentResolver.query(
                MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, proj,
                MediaStore.Audio.Media.IS_MUSIC + " != 0", null,
                MediaStore.Audio.Media.DATA + " COLLATE NOCASE ASC"
            )?.use { c ->
                val iId = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM_ID)
                val iData = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DATA)
                while (c.moveToNext()) {
                    val data = c.getString(iData) ?: continue
                    val slash = data.lastIndexOf('/')
                    if (slash <= 0) continue
                    val parent = data.substring(0, slash)
                    val albumId = c.getLong(iId)
                    var a = map[parent]
                    if (a == null) {
                        val name = parent.substringAfterLast('/')
                        a = Album((parent.hashCode().toLong() and 0xFFFFFFFFL) or (1L shl 40), name, "", 0)
                        a.key = "f:" + parent
                        a.extra = parent.removePrefix("/storage/emulated/0/").removePrefix("/storage/")
                        map[parent] = a
                    }
                    a.tracks++
                    if (albumId != 0L && a.coverIds.size < 6 && albumId !in a.coverIds) a.coverIds.add(albumId)
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        val list = map.values.toList()
        for (a in list) a.artist = if (a.tracks == 1) "1 song" else a.tracks.toString() + " songs"
        return list.sortedBy { it.title.lowercase() }
    }

    /** کاور آلبوم به‌صورت مربع؛ null اگه کاوری نباشه */
    fun loadCover(ctx: Context, albumId: Long, size: Int): Bitmap? {
        val uri = ContentUris.withAppendedId(MediaStore.Audio.Albums.EXTERNAL_CONTENT_URI, albumId)
        if (Build.VERSION.SDK_INT >= 29) {
            try {
                return ctx.contentResolver.loadThumbnail(uri, Size(size, size), null)
            } catch (e: Exception) {
                // می‌ریم سراغ روش قدیمی
            }
        }
        return try {
            @Suppress("DEPRECATION")
            ctx.contentResolver.query(
                MediaStore.Audio.Albums.EXTERNAL_CONTENT_URI,
                arrayOf(MediaStore.Audio.Albums.ALBUM_ART),
                MediaStore.Audio.Albums._ID + "=?", arrayOf(albumId.toString()), null
            )?.use { c ->
                if (c.moveToFirst()) {
                    val path = c.getString(0)
                    if (path != null) {
                        val o = BitmapFactory.Options()
                        o.inSampleSize = 2
                        BitmapFactory.decodeFile(path, o)
                    } else null
                } else null
            }
        } catch (e: Exception) {
            null
        }
    }

    /** کاور یک آیتم: اولین کاوری که از بین آهنگ‌هاش پیدا بشه */
    fun loadItemCover(ctx: Context, a: Album, size: Int): Bitmap? {
        for (id in a.coverIds) {
            val b = loadCover(ctx, id, size)
            if (b != null) return b
        }
        return null
    }
}
