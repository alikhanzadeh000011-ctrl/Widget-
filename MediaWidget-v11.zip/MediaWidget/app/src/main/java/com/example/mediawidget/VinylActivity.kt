package com.example.mediawidget

import android.app.Activity
import android.app.PendingIntent
import android.content.ComponentName
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.media.AudioManager
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.KeyEvent
import android.view.View
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.view.WindowManager
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.Toast

/** صفحه‌ی اصلی اپ: فول‌اسکرین، دیسک وینیل. با هر پلیری کار می‌کنه (از MediaSession می‌خونه). */
class VinylActivity : Activity(), VinylView.Listener {

    private lateinit var vinyl: VinylView
    private lateinit var root: FrameLayout
    private var sheet: ThemeSheet? = null
    private var statusShown = false
    private var lastPkg = ""
    private var lastOpen: PendingIntent? = null
    private var msm: MediaSessionManager? = null
    private var controllers: List<MediaController> = emptyList()
    private val component by lazy { ComponentName(this, MediaListenerService::class.java) }

    private val sessionsListener = MediaSessionManager.OnActiveSessionsChangedListener { list ->
        bind(list.orEmpty())
    }

    private val callback = object : MediaController.Callback() {
        override fun onMetadataChanged(metadata: MediaMetadata?) = reload()
        override fun onPlaybackStateChanged(state: PlaybackState?) = reload()
        override fun onSessionDestroyed() = reload()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setBackgroundDrawable(ColorDrawable(Color.BLACK))
        setupWindow()
        vinyl = VinylView(this)
        vinyl.listener = this
        root = FrameLayout(this)
        root.addView(vinyl, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        setContentView(root)
        enterImmersive()
    }

    override fun onResume() {
        super.onResume()
        enterImmersive()
        val m = getSystemService(MediaSessionManager::class.java)
        msm = m
        try {
            m.addOnActiveSessionsChangedListener(sessionsListener, component)
            bind(m.getActiveSessions(component))
        } catch (e: SecurityException) {
            controllers = emptyList()
            vinyl.update(MediaInfo(hasAccess = false))
        }
    }

    override fun onPause() {
        super.onPause()
        try {
            msm?.removeOnActiveSessionsChangedListener(sessionsListener)
        } catch (e: Exception) {
            // مهم نیست
        }
        controllers.forEach { it.unregisterCallback(callback) }
        controllers = emptyList()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) enterImmersive()
    }

    private fun bind(list: List<MediaController>) {
        controllers.forEach { it.unregisterCallback(callback) }
        controllers = list
        list.forEach { it.registerCallback(callback) }
        reload()
    }

    private fun reload() {
        val info = MediaReader.read(this)
        if (info.pkg.isNotEmpty()) {
            lastPkg = info.pkg
            lastOpen = info.openIntent
        }
        vinyl.update(info)
    }

    // ------------------------------------------------------------ فول‌اسکرین

    private fun setupWindow() {
        if (Build.VERSION.SDK_INT >= 28) {
            val lp = window.attributes
            lp.layoutInDisplayCutoutMode = if (Build.VERSION.SDK_INT >= 30) {
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
            } else {
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
            window.attributes = lp
        }
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
    }

    @Suppress("DEPRECATION")
    private fun enterImmersive() {
        if (Build.VERSION.SDK_INT >= 30) {
            window.setDecorFitsSystemWindows(false)
            val ctl = window.insetsController
            if (ctl != null) {
                ctl.systemBarsBehavior = WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                ctl.hide(WindowInsets.Type.navigationBars())
                if (statusShown) ctl.show(WindowInsets.Type.statusBars()) else ctl.hide(WindowInsets.Type.statusBars())
            }
        } else {
            var flags = View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            if (!statusShown) flags = flags or View.SYSTEM_UI_FLAG_FULLSCREEN
            window.decorView.systemUiVisibility = flags
        }
    }

    // ------------------------------------------------------------ دکمه‌ها

    private fun currentController(): MediaController? {
        return try {
            val list = MediaReader.controllers(this)
            if (list == null) null else MediaReader.pick(list)
        } catch (e: SecurityException) {
            null
        }
    }

    private fun sendKey(code: Int) {
        val am = getSystemService(AudioManager::class.java)
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
    }

    override fun onPlayPause() {
        val c = currentController()
        if (c != null) {
            if (c.playbackState?.state == PlaybackState.STATE_PLAYING) {
                c.transportControls.pause()
            } else {
                c.transportControls.play()
            }
        } else {
            sendKey(KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE)
        }
    }

    override fun onPrev() {
        val c = currentController()
        if (c != null) c.transportControls.skipToPrevious() else sendKey(KeyEvent.KEYCODE_MEDIA_PREVIOUS)
    }

    override fun onNext() {
        val c = currentController()
        if (c != null) c.transportControls.skipToNext() else sendKey(KeyEvent.KEYCODE_MEDIA_NEXT)
    }

    override fun onNeedleLift() {
        val c = currentController()
        if (c != null) c.transportControls.pause() else sendKey(KeyEvent.KEYCODE_MEDIA_PAUSE)
    }

    override fun onNeedleDrop(positionMs: Long) {
        val c = currentController()
        if (c != null) {
            if (positionMs >= 0L) c.transportControls.seekTo(positionMs)
            c.transportControls.play()
        } else {
            sendKey(KeyEvent.KEYCODE_MEDIA_PLAY)
        }
    }

    override fun onNeedAccess() {
        startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
    }

    /** دکمه‌ی تنظیمات: صفحه‌ی قدیمی (دسترسی و پوشه‌های ویجت Library) */
    override fun onSettings() {
        startActivity(Intent(this, MainActivity::class.java))
    }

    /** دکمه‌ی پلیر: برنامه‌ی موزیک فعلی رو باز می‌کنه */
    override fun onPlayer() {
        val pi = lastOpen
        if (pi != null) {
            try {
                pi.send()
                return
            } catch (e: Exception) {
                // می‌ریم سراغ روش دوم
            }
        }
        if (lastPkg.isNotEmpty()) {
            val intent = packageManager.getLaunchIntentForPackage(lastPkg)
            if (intent != null) startActivity(intent)
        }
    }

    override fun onTheme() {
        if (sheet != null) return
        val sh = ThemeSheet(this, vinyl)
        sh.onDismissed = { sheet = null }
        sheet = sh
        root.addView(sh, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
    }

    override fun onOverlay(show: Boolean) {
        statusShown = show
        enterImmersive()
    }

    // ------------------------------------------------------------ انتخاب عکس از گالری

    fun pickImage(kind: String) {
        val i = Intent(Intent.ACTION_GET_CONTENT)
        i.type = "image/*"
        i.addCategory(Intent.CATEGORY_OPENABLE)
        startActivityForResult(i, if (kind == ThemeStore.BG) REQ_BG else REQ_DISC)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val uri = data?.data
        if (resultCode != RESULT_OK || uri == null) return
        if (requestCode != REQ_BG && requestCode != REQ_DISC) return
        val kind = if (requestCode == REQ_BG) ThemeStore.BG else ThemeStore.DISC
        Thread {
            val f = try {
                ThemeStore.import(this, kind, uri)
            } catch (e: Throwable) {
                null
            }
            runOnUiThread {
                if (f != null) {
                    ThemeStore.select(this, kind, f)
                    vinyl.reloadTheme()
                    sheet?.refresh()
                } else {
                    Toast.makeText(this, "Couldn't open this image", Toast.LENGTH_SHORT).show()
                }
            }
        }.start()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        val sh = sheet
        if (sh != null) sh.dismiss() else super.onBackPressed()
    }

    companion object {
        private const val REQ_BG = 11
        private const val REQ_DISC = 12
    }
}
