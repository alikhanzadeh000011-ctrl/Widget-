package com.example.mediawidget

import android.app.SearchManager
import android.content.Context
import android.content.Intent
import android.media.MediaMetadata
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.widget.Toast

/** پخش یه ترک تو Samsung Music؛ روش از تنظیمات انتخاب میشه */
object TrackPlayer {

    private const val SAMSUNG = "com.sec.android.app.music"
    private val handler = Handler(Looper.getMainLooper())
    private var token = 0

    fun play(ctx: Context, t: Track, album: Album?, folderMode: Boolean, list: List<Track>, index: Int) {
        when (LibraryPrefs.playMethod(ctx)) {
            LibraryPrefs.PLAY_OPEN -> openFile(ctx, t)
            LibraryPrefs.PLAY_ALBUM -> if (!viaAlbum(ctx, t, album, folderMode, list, index)) openFile(ctx, t)
            else -> if (!viaSearch(ctx, t, album, folderMode)) openFile(ctx, t)
        }
    }

    /** «باز کردن فایل» (Samsung Music پاپ‌آپ نشون میده) */
    private fun openFile(ctx: Context, t: Track) {
        val i = Intent(Intent.ACTION_VIEW)
        i.setDataAndType(t.uri, "audio/*")
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        i.setPackage(SAMSUNG)
        try {
            ctx.startActivity(i)
        } catch (e: Exception) {
            i.setPackage(null)
            try {
                ctx.startActivity(Intent.createChooser(i, "Play with"))
            } catch (e2: Exception) {
                Toast.makeText(ctx, "No music app found", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun artistOf(album: Album?, folderMode: Boolean): String? {
        if (album == null || folderMode) return null
        val a = album.artist
        return if (a.isNotBlank() && a != "Various Artists" && a != "Unknown artist") a else null
    }

    /** پخش از جستجو با اسم ترک، آلبوم و خواننده (یه ترک) */
    private fun viaSearch(ctx: Context, t: Track, album: Album?, folderMode: Boolean): Boolean {
        val i = Intent(MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH)
        i.setPackage(SAMSUNG)
        i.putExtra(MediaStore.EXTRA_MEDIA_FOCUS, MediaStore.Audio.Media.ENTRY_CONTENT_TYPE)
        i.putExtra(MediaStore.EXTRA_MEDIA_TITLE, t.title)
        i.putExtra(SearchManager.QUERY, t.title)
        if (album != null && !folderMode) i.putExtra(MediaStore.EXTRA_MEDIA_ALBUM, album.title)
        artistOf(album, folderMode)?.let { i.putExtra(MediaStore.EXTRA_MEDIA_ARTIST, it) }
        return try {
            ctx.startActivity(i)
            true
        } catch (e: Exception) {
            Toast.makeText(ctx, "Search play not supported, opening the file", Toast.LENGTH_SHORT).show()
            false
        }
    }

    /**
     * تست: کل آلبوم رو برای پخش میفرستیم (صف آلبوم)، بعد با «ترک بعدی» تا ترک انتخابی جلو میریم.
     * هر بار از روی اسم ترکِ در حال پخش چک میشه، پس ترتیب صف مهم نیست.
     */
    private fun viaAlbum(ctx: Context, t: Track, album: Album?, folderMode: Boolean, list: List<Track>, index: Int): Boolean {
        if (album == null || folderMode) return viaSearch(ctx, t, album, folderMode)
        val i = Intent(MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH)
        i.setPackage(SAMSUNG)
        i.putExtra(MediaStore.EXTRA_MEDIA_FOCUS, MediaStore.Audio.Albums.ENTRY_CONTENT_TYPE)
        i.putExtra(MediaStore.EXTRA_MEDIA_ALBUM, album.title)
        i.putExtra(SearchManager.QUERY, album.title)
        artistOf(album, folderMode)?.let { i.putExtra(MediaStore.EXTRA_MEDIA_ARTIST, it) }
        try {
            ctx.startActivity(i)
        } catch (e: Exception) {
            Toast.makeText(ctx, "Album play not supported, opening the file", Toast.LENGTH_SHORT).show()
            return false
        }
        if (index > 0) jumpTo(ctx.applicationContext, album.title, t.title, list.size + 2)
        return true
    }

    private fun norm(s: String?): String = (s ?: "").trim().lowercase()

    private fun jumpTo(app: Context, albumTitle: String, title: String, maxSteps: Int) {
        val my = ++token
        var steps = 0
        var waits = 0
        val wantTitle = norm(title)
        val wantAlbum = norm(albumTitle)

        fun fail(msg: String) {
            Toast.makeText(app, msg, Toast.LENGTH_SHORT).show()
        }

        fun tick() {
            if (my != token) return
            val c = MediaReader.controllers(app)?.firstOrNull { it.packageName == SAMSUNG }
            val md = c?.metadata
            val curTitle = norm(md?.getString(MediaMetadata.METADATA_KEY_TITLE))
            val curAlbum = norm(md?.getString(MediaMetadata.METADATA_KEY_ALBUM))
            // صبر تا آلبوم درخواستی واقعاً شروع بشه (ممکنه هنوز ترک قبلی باشه)
            if (c == null || curAlbum != wantAlbum) {
                waits++
                if (waits < 24) handler.postDelayed({ tick() }, 400L) else fail("Album did not start, stayed on the first track")
                return
            }
            if (curTitle == wantTitle) return
            if (steps >= maxSteps) {
                fail("Could not reach that track")
                return
            }
            steps++
            try {
                c.transportControls.skipToNext()
            } catch (e: Exception) {
                fail("Could not skip to the next track")
                return
            }
            handler.postDelayed({ tick() }, 800L)
        }
        handler.postDelayed({ tick() }, 1500L)
    }
}
