package com.example.mediawidget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.CornerPathEffect
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.util.TypedValue
import android.view.View
import android.widget.RemoteViews
import kotlin.math.min

/**
 * ویجت‌های وینیل: دیسک و بازو به‌صورت یک تصویر ثابت، و برچسب (کاور) جدا که می‌چرخه.
 * چرخش نرم با ViewFlipper و انیمیشن چرخش انجام میشه که خود لانچر اجرا می‌کنه.
 */
object VinylWidgets {

    private const val SPIN_MS = 12000L
    private const val DEG_PER_SEC = 360f / 12f
    // قطر کاور نسبت به قطر دیسک: دیسک مشکی پیش‌فرض ۰٫۷۰ (ویدیوی MD)، دیسک‌های رنگی/ساخته‌شده ۰٫۶۰
    private var labelRatio = 0.70f
    private const val ARM_SCALE = 0.88f    // بازوی MD نسبت به دیسک حدود ۱۲٪ کوچیک‌تر و کوتاه‌تره
    private const val PIV_X = 0.885f       // مرکز چرخش بازو (= مرکز دایره‌ی جای بازو) نسبت به مرکز دیسک، برحسب شعاع
    private const val PIV_Y = -0.79f
    private const val POCKET_R = 0.27f     // شعاع دایره‌ی جای بازو؛ کمی زیر دیسک میره
    private const val ARM_PLAY_DEG = 11.5f // کج شدن بازو موقع پخش (سوزن روی حدود ۰٫۷۵ شعاع)
    private const val PAUSE_SCALE = 0.90f  // موقع توقف دیسک کوچیک‌تر میشه تا جا برای بازو باز بشه
    private const val HEAD_U = 275.5f      // مرکز هد بازو توی تصویر arm_*.png (پیکسل تصویر)
    private const val HEAD_V = 140f
    private const val CORNER_RATIO = 0.176f
    private const val CORNER_DP = 28.16f

    private class Geo(val cx: Float, val cy: Float, val r: Float)

    private val recCache = HashMap<String, Bitmap>()
    private val armCache = HashMap<Int, Bitmap>()
    private val bgCache = HashMap<String, Bitmap>()

    private fun geo(kind: Kind, bw: Float, bh: Float, bare: Boolean = false): Geo = when (kind) {
        // دیسک دقیق وسط ویجت با قطر ۸۵٫۷٪ (مثل MD)
        Kind.VDISC -> Geo(bw / 2f, bh / 2f, 0.4285f * min(bw, bh))
        // نیم‌دیسک: قطر ۹۰٫۸٪ عرض، وسط افقی، مرکز ۱۰٫۷٪ پایین‌تر از لبه‌ی بالا
        Kind.VHALF -> Geo(bw / 2f, 0.107f * bh, 0.454f * bw)
        Kind.VWIDE -> Geo(0.73f * bw, bh / 2f, min(0.40f * bh, 0.225f * bw))
        else -> if (bare) {
            // بدون متن و دکمه: دیسک وسط ویجت (افقی و عمودی)
            val r = min(0.4285f * bw, 0.46f * bh)
            Geo(bw / 2f, bh / 2f, r)
        } else {
            // ویجت بزرگ: دیسک وسط افقی، جای بازو (۱٫۰۸ شعاع بالای مرکز) داخل ویجت و بالای ردیف متن
            val r = min(0.4285f * bw, 0.37f * bh)
            Geo(bw / 2f, 1.06f * r + 0.012f * bh, r)
        }
    }

    // ---------------------------------------------------------------- زاویه‌ی چرخش

    /** زاویه‌ی فعلی کاور؛ وقتی پخش میشه از زمان شروع حساب میشه و وقتی متوقفه ثابت می‌مونه */
    private fun spinAngle(ctx: Context, info: MediaInfo, id: Int): Float {
        val p = ctx.getSharedPreferences("spin$id", Context.MODE_PRIVATE)
        val now = System.currentTimeMillis()
        var a0 = p.getFloat("a0", 0f)
        var t0 = p.getLong("t0", now)
        var was = p.getBoolean("playing", false)
        val key = p.getString("key", "") ?: ""
        val playing = info.hasMedia && info.playing
        if (key != info.key) {
            a0 = 0f
            t0 = now
            was = playing
        } else if (playing && !was) {
            t0 = now
        } else if (!playing && was) {
            a0 = (a0 + (now - t0) * DEG_PER_SEC / 1000f) % 360f
        }
        val cur = if (playing) (a0 + (now - t0) * DEG_PER_SEC / 1000f) % 360f else a0
        p.edit().putFloat("a0", a0).putLong("t0", t0).putBoolean("playing", playing).putString("key", info.key).apply()
        return cur
    }

    // ---------------------------------------------------------------- ساخت تصویرها

    private val layerCache = HashMap<String, RecordLayers>()

    /** دیسک غیر مشکی (عکس گالری یا ساخته‌شده با ادیتور، با رنگ کاور آهنگ)؛ null یعنی دیسک مشکی پیش‌فرض */
    private fun customLayers(ctx: Context, s: Float, info: MediaInfo): RecordLayers? {
        val dsel = ThemeStore.widgetDisc(ctx)
        val custom = dsel.file
        var st: DiscStyle? = null
        if (custom == null) {
            val base = dsel.style ?: return null
            st = DiscStyles.withTint(base, Palette.discColorFor(info.art))
        }
        val sig = if (custom != null) custom.name else {
            val z = st!!
            "st" + z.color + "_" + z.opacity + "_" + z.effect + "_" + z.c1 + "_" + z.c2 + "_" + z.effOpacity
        }
        val key = sig + "|" + (s * 1000f).toInt()
        layerCache[key]?.let { return it }
        if (layerCache.size > 4) layerCache.clear()
        var made: RecordLayers? = null
        if (custom != null) {
            val src = ThemeStore.decodeFile(custom, 1400)
            if (src != null) made = VinylArt.customRecordLayers(src, s)
        } else if (st != null) {
            made = VinylArt.styledRecordLayers(s, st, DiscStyles.layers(ctx, st), DiscStyles.glass(ctx))
        }
        if (made != null) layerCache[key] = made
        return made
    }

    /** دیسک مشکی پیش‌فرض (ثابت) */
    private fun record(s: Float): Bitmap {
        val key = "def|" + (if (ThemeStore.iosDisc(App.ctx)) "ios|" else "") + (s * 1000f).toInt()
        recCache[key]?.let { return it }
        if (recCache.size > 6) recCache.clear()
        val rec = VinylArt.recordBitmap(s)
        recCache[key] = rec
        return rec
    }

    private fun arm(s: Float, style: Int): Bitmap {
        val key = (s * 1000f).toInt() * 10 + style
        return armCache.getOrPut(key) {
            if (armCache.size > 6) armCache.clear()
            VinylArt.armBitmap(s, style)
        }
    }

    private fun drawArm(c: Canvas, g: Geo, s: Float, angleDeg: Float, armStyle: Int) {
        // بازو دور مرکز هدش (= مرکز دایره‌ی جای بازو) میچرخه
        val armBmp = arm(s, armStyle)
        val kk = VinylArt.K
        val hx = (848f - 162f * kk - VinylArt.PX + VinylArt.ARM_OX + HEAD_U * kk) * s
        val hy = (288f - 96f * kk - VinylArt.PY + VinylArt.ARM_OY + HEAD_V * kk) * s
        c.save()
        c.translate(g.cx + PIV_X * g.r, g.cy + PIV_Y * g.r)
        c.rotate(angleDeg)
        c.scale(ARM_SCALE, ARM_SCALE)
        c.drawBitmap(armBmp, -hx, -hy, Paint(Paint.FILTER_BITMAP_FLAG))
        c.restore()
    }

    /**
     * دیسک + جای بازو + بازو (بدون برچسب).
     * mode ۰: دیسک ثابت | ۱: دیسک با چرخش واقعی، با زاویه‌ی آخر (ایستاده) | ۲: فقط سایه و جای بازو (دیسک و بازو لایه‌ی جدا دارن)
     */
    private fun scene(ctx: Context, bw: Int, bh: Int, g: Geo, playing: Boolean, radius: Float, card: RectF, info: MediaInfo, mode: Int, rl: RecordLayers?, angle: Float, armStyle: Int, kind: Kind, kd: Float, armDeg: Float): Bitmap {
        val bmp = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val clip = Path()
        clip.addRoundRect(card, radius, radius, Path.Direction.CW)
        c.clipPath(clip)

        val s = g.r / VinylArt.R
        val k = VinylArt.K
        fun px(ax: Float) = g.cx + (ax - VinylArt.CX) * s
        fun py(ay: Float) = g.cy + (ay - VinylArt.CY) * s

        // جای بازو (مثل MD): دایره‌ی نازک دور هد بازو، یه کم زیر دیسک (بخشی که زیر دیسکه دیده نمیشه)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        val pivX = g.cx + PIV_X * g.r
        val pivY = g.cy + PIV_Y * g.r
        val discPath = Path()
        discPath.addCircle(g.cx, g.cy, g.r * kd, Path.Direction.CW)
        c.save()
        c.clipOutPath(discPath)
        val pr = POCKET_R * g.r
        paint.style = Paint.Style.FILL
        paint.color = Color.argb(34, 0, 0, 0)
        c.drawCircle(pivX, pivY, pr, paint)
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = (2.2f * s).coerceAtLeast(1f)
        paint.color = Color.argb(70, 0, 0, 0)
        c.drawCircle(pivX, pivY, pr, paint)
        c.restore()

        // دیسک (موقع توقف کوچیک‌تر: بوم رو دور مرکز دیسک مقیاس میدیم تا همون تصویرهای کش‌شده استفاده بشن)
        val fp = Paint(Paint.FILTER_BITMAP_FLAG)
        c.save()
        c.scale(kd, kd, g.cx, g.cy)
        when (mode) {
            0 -> {
                val rec = if (rl != null) rl.composite() else record(s)
                c.drawBitmap(rec, g.cx - rec.width / 2f, g.cy - rec.height / 2f, fp)
            }
            else -> {
                val l = rl ?: return bmp
                c.drawBitmap(l.shadow, g.cx - l.shadow.width / 2f, g.cy - l.shadow.height / 2f, fp)
                if (mode == 1) {
                    c.save()
                    c.rotate(angle, g.cx, g.cy)
                    c.drawBitmap(l.body, g.cx - l.body.width / 2f, g.cy - l.body.height / 2f, fp)
                    c.restore()
                    l.sheen?.let {
                        val sp = Paint(Paint.FILTER_BITMAP_FLAG)
                        sp.color = Color.BLACK
                        c.drawBitmap(it, g.cx - it.width / 2f, g.cy - it.height / 2f, sp)
                    }
                }
            }
        }
        c.restore()

        if (mode != 2) drawArm(c, g, s, armDeg, armStyle)
        return bmp
    }

    /** لایه‌ی بالایی برای چرخش واقعی: براقی ثابت + بازو (روی دیسکِ چرخان) */
    private fun armLayer(bw: Int, bh: Int, g: Geo, kd: Float, armDeg: Float, radius: Float, card: RectF, rl: RecordLayers, armStyle: Int): Bitmap {
        val bmp = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val clip = Path()
        clip.addRoundRect(card, radius, radius, Path.Direction.CW)
        c.clipPath(clip)
        val s = g.r / VinylArt.R
        rl.sheen?.let {
            val sp = Paint(Paint.FILTER_BITMAP_FLAG)
            sp.color = Color.BLACK
            c.save()
            c.scale(kd, kd, g.cx, g.cy)
            c.drawBitmap(it, g.cx - it.width / 2f, g.cy - it.height / 2f, sp)
            c.restore()
        }
        drawArm(c, g, s, armDeg, armStyle)
        return bmp
    }

    /** بدنه‌ی دیسک + برچسب با هم، با زاویه‌ی داده‌شده (لایه‌ای که لانچر می‌چرخونه) */
    private fun spinDiscBitmap(rl: RecordLayers, art: Bitmap?, angle: Float, tf: Typeface?, g: Geo): Bitmap {
        val size = rl.body.width
        val bmp = Bitmap.createBitmap(size, rl.body.height, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val fp = Paint(Paint.FILTER_BITMAP_FLAG)
        c.save()
        c.rotate(angle, size / 2f, rl.body.height / 2f)
        c.drawBitmap(rl.body, 0f, 0f, fp)
        val d = (2f * g.r * labelRatio).toInt().coerceAtLeast(8)
        val label = if (art != null) VinylArt.labelFromCover(art, d) else VinylArt.blankLabel(d, tf)
        c.drawBitmap(label, (size - d) / 2f, (rl.body.height - d) / 2f, fp)
        c.restore()
        return bmp
    }

    /** لایه‌ی برچسب (هم‌اندازه‌ی ویجت، شفاف) که با زاویه‌ی داده‌شده چرخیده */
    private fun labelLayer(art: Bitmap?, bw: Int, bh: Int, g: Geo, angle: Float, tf: Typeface?, card: RectF): Bitmap {
        val bmp = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        c.clipRect(card)
        val d = (2f * g.r * labelRatio).toInt().coerceAtLeast(8)
        val label = if (art != null) VinylArt.labelFromCover(art, d) else VinylArt.blankLabel(d, tf)
        c.save()
        c.rotate(angle, g.cx, g.cy)
        c.drawBitmap(label, g.cx - d / 2f, g.cy - d / 2f, Paint(Paint.FILTER_BITMAP_FLAG))
        c.restore()
        return bmp
    }

    /** مثل labelLayer ولی برچسب، اسم آهنگ و خواننده‌ست (حالت کاور) */
    private fun labelLayerText(info: MediaInfo, bw: Int, bh: Int, g: Geo, angle: Float, tf: Typeface?, card: RectF): Bitmap {
        val bmp = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        c.clipRect(card)
        val d = (2f * g.r * labelRatio).toInt().coerceAtLeast(8)
        val label = spinLabel(info, d, tf)
        c.save()
        c.rotate(angle, g.cx, g.cy)
        c.drawBitmap(label, g.cx - d / 2f, g.cy - d / 2f, Paint(Paint.FILTER_BITMAP_FLAG))
        c.restore()
        return bmp
    }

    /** کارت کاور مربعی با گوشه‌ی تیز و سایه‌ی نرم، سمت چپ (مثل MD)، روی یک کپی از پس‌زمینه */
    private fun coverCardOnto(base: Bitmap?, bw: Int, bh: Int, card: RectF, art: Bitmap?): Bitmap {
        val out = if (base != null) base.copy(Bitmap.Config.ARGB_8888, true) else Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        val side = 0.795f * card.height()
        val left = card.left + 0.105f * card.height()
        val top = card.top + (card.height() - side) / 2f
        val r = RectF(left, top, left + side, top + side)
        val sp = Paint(Paint.ANTI_ALIAS_FLAG)
        sp.color = Color.argb(95, 0, 0, 0)
        sp.maskFilter = android.graphics.BlurMaskFilter(0.07f * side, android.graphics.BlurMaskFilter.Blur.NORMAL)
        c.drawRect(RectF(r.left, r.top + 0.035f * side, r.right, r.bottom + 0.035f * side), sp)
        if (art != null) {
            val m = min(art.width, art.height)
            val src = android.graphics.Rect((art.width - m) / 2, (art.height - m) / 2, (art.width + m) / 2, (art.height + m) / 2)
            c.drawBitmap(art, src, r, Paint(Paint.FILTER_BITMAP_FLAG))
        } else {
            val p = Paint()
            p.color = Color.argb(70, 0, 0, 0)
            c.drawRect(r, p)
        }
        return out
    }

    /** فقط خود کاور (دایره) با زاویه‌ی داده‌شده */
    private fun rotatedLabel(art: Bitmap?, d: Int, angle: Float, tf: Typeface?): Bitmap {
        val bmp = Bitmap.createBitmap(d, d, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val label = if (art != null) VinylArt.labelFromCover(art, d) else VinylArt.blankLabel(d, tf)
        c.save()
        c.rotate(angle, d / 2f, d / 2f)
        c.drawBitmap(label, 0f, 0f, Paint(Paint.FILTER_BITMAP_FLAG))
        c.restore()
        return bmp
    }

    /** پس‌زمینه‌ی نرم اپ با گوشه‌های گرد؛ فقط داخل کارت (برای ویجت‌های ۲×۲ یه مربع وسط ویجته) */
    private fun background(art: Bitmap?, bw: Int, bh: Int, radius: Float, card: RectF): Bitmap {
        val cw = card.width().toInt().coerceAtLeast(2)
        val ch = card.height().toInt().coerceAtLeast(2)
        val src = if (art != null) VinylArt.coverBackground(art, cw, ch) else VinylArt.greyBackground(cw, ch)
        val out = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        val clip = Path()
        clip.addRoundRect(card, radius, radius, Path.Direction.CW)
        c.clipPath(clip)
        c.drawBitmap(src, null, card, Paint(Paint.FILTER_BITMAP_FLAG))
        return out
    }

    /** پس‌زمینه‌ی تم‌های آماده (زرد، خاکستری، مشکی، سفید): گرادیان ملایم با گوشه‌های گرد */
    private fun presetBackground(p: ScreenTheme.Preset, bw: Int, bh: Int, radius: Float, card: RectF): Bitmap {
        val out = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        val clip = Path()
        clip.addRoundRect(card, radius, radius, Path.Direction.CW)
        c.clipPath(clip)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        paint.shader = android.graphics.LinearGradient(0f, card.top, 0f, card.bottom, p.bgTop, p.bgBottom, android.graphics.Shader.TileMode.CLAMP)
        c.drawRect(card, paint)
        return out
    }

    // ---------------------------------------------------------------- ساخت RemoteViews

    fun build(ctx: Context, mgr: AppWidgetManager?, id: Int, kind0: Kind, info: MediaInfo, coverTint: Tint, set0: VSettings.Data, anim: Float? = null): RemoteViews {
        // Disc 2x2 با روشن بودن «Show music info» یا «Show control» خودش به حالت نیم‌دیسک میره (Half Disc دیگه ویجت جدا نیست)
        val kind = if (kind0 == Kind.VDISC && (set0.info || set0.control)) Kind.VHALF else kind0
        // حالت کاور (فقط Wide): متن و دکمه‌ها خاموش، کاور کنار دیسک، اسم آهنگ و خواننده روی لیبل
        val cm = kind == Kind.VWIDE && set0.cover
        val set = if (cm) VSettings.Data(false, false, set0.theme, set0.players, set0.rect, set0.blur, true) else set0
        // شکل: مستطیل = کل ناحیه‌ی ویجت، مربع = کارت مربع وسط (بلر فقط روی مستطیل ممکنه)
        val shapeKind = VSettings.hasShape(kind0)
        val rect = !shapeKind || set.rect
        val theme = if (!rect && set.theme == VSettings.BLUR) VSettings.COVER else set.theme
        val blur = theme == VSettings.BLUR
        val tint = VSettings.tint(theme, coverTint)
        val layout = when (kind) {
            Kind.VDISC -> R.layout.vinyl_disc
            Kind.VHALF -> R.layout.vinyl_half
            Kind.VWIDE -> R.layout.vinyl_wide
            else -> R.layout.vinyl_big
        }
        val rv = RemoteViews(ctx.packageName, layout)
        val d = ctx.resources.displayMetrics.density

        val opts = if (mgr != null) mgr.getAppWidgetOptions(id) else Bundle()
        var wDp = opts.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 0)
        var hDp = opts.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT, 0)
        if (wDp < 50) wDp = kind.defW
        if (hDp < 40) hDp = kind.defH
        wDp = wDp.coerceAtMost(700)
        hDp = hDp.coerceAtMost(500)
        val w = wDp * d
        val h = hDp * d
        val square = shapeKind && !rect
        val playing = info.hasMedia && info.playing
        // دیسک غیر مشکی (گالری یا ساخته‌شده با ادیتور) + Real rotation روشن؟
        val dsel = ThemeStore.widgetDisc(ctx)
        val customDisc = dsel.file != null || dsel.style != null
        val rot = customDisc && ThemeStore.realRotation(ctx, dsel.rotKey)
        val spinDisc = rot && playing && Build.VERSION.SDK_INT >= 31
        // کیفیت کامل تا سقف حافظه‌ی RemoteViews (دیسک + پس‌زمینه + لایه‌ی برچسب؛ با چرخش واقعی لایه‌ی بازو هم اضافه میشه)
        val sc = WidgetRenderer.fitScale(ctx, w, h, if (spinDisc) 17f else 12.5f)
        val bw = (w * sc).toInt().coerceAtLeast(2)
        val bh = (h * sc).toInt().coerceAtLeast(2)
        // کارت: برای ویجت‌های ۲×۲ یه مربع دقیق وسط ویجت (تصویرها کشیده نمیشن)، برای بقیه کل ویجت
        val card = if (square) {
            val side = min(bw, bh).toFloat()
            val ox = (bw - side) / 2f
            val oy = (bh - side) / 2f
            RectF(ox, oy, ox + side, oy + side)
        } else RectF(0f, 0f, bw.toFloat(), bh.toFloat())
        val radius = when (kind) {
            Kind.VWIDE, Kind.VBIG -> CORNER_DP * d * sc
            else -> card.width() * CORNER_RATIO
        }

        val art = info.art
        val g0 = geo(kind, card.width(), card.height(), kind == Kind.VBIG && !set.info && !set.control)
        val g = Geo(g0.cx + card.left, g0.cy + card.top, g0.r)
        // پیشرفت انتقال توقف ↔ پخش: ۰ = متوقف (دیسک کوچیک‌تر، بازو عمودی)، ۱ = در حال پخش (دیسک کامل، بازو روی دیسک)
        val pp = (anim ?: (if (playing) 1f else 0f)).coerceIn(0f, 1f)
        val ease = pp * pp * (3f - 2f * pp)
        val kd = PAUSE_SCALE + (1f - PAUSE_SCALE) * ease
        val armDeg = ARM_PLAY_DEG * ease
        // دیسک و برچسب با شعاع کوچیک‌شده؛ بازو و جای بازو با شعاع کامل
        val gd = Geo(g.cx, g.cy, g.r * kd)
        labelRatio = if (customDisc) 0.60f else if (ThemeStore.iosDisc(ctx)) 0.515f else 0.70f

        // پس‌زمینه: همون پس‌زمینه‌ی نرم داخل اپ (گوشه‌گرد)
        if (blur) {
            // بلر واقعی One UI: پس‌زمینه یه رنگ نیمه‌شفاف روی ویوی ریشه‌ست و خود لانچر والپیپر رو بلر می‌کنه
            rv.setViewVisibility(R.id.bg, View.GONE)
            rv.setInt(android.R.id.background, "setBackgroundColor", Color.argb(VSettings.blurAlpha(set.blur), 0, 0, 0))
        } else {
            rv.setViewVisibility(R.id.bg, View.VISIBLE)
            rv.setInt(android.R.id.background, "setBackgroundColor", 0)
            val bgBmp = if (theme == VSettings.COVER) {
                val key = "${info.key}|$bw|$bh|${radius.toInt()}|${card.left.toInt()}|${card.top.toInt()}|${card.width().toInt()}"
                if (bgCache.size > 6) bgCache.clear()
                bgCache.getOrPut(key) { background(art, bw, bh, radius, card) }
            } else presetBackground(VSettings.preset(theme), bw, bh, radius, card)
            rv.setImageViewBitmap(R.id.bg, if (cm) coverCardOnto(bgBmp, bw, bh, card, art) else bgBmp)
        }
        if (cm && blur) {
            // بلر واقعی: پس‌زمینه‌ی لانچره؛ فقط کارت کاور روی یه لایه‌ی شفاف
            rv.setViewVisibility(R.id.bg, View.VISIBLE)
            rv.setImageViewBitmap(R.id.bg, coverCardOnto(null, bw, bh, card, art))
        }
        // برچسب: متوقف = ثابت با همون زاویه‌ی آخر، در حال پخش = چرخش نرم و بی‌وقفه
        val angle = spinAngle(ctx, info, id)
        val rs = g.r / VinylArt.R
        val rl = if (customDisc) customLayers(ctx, rs, info) else null
        // ۰: دیسک ثابت | ۱: چرخش واقعی، ایستاده | ۲: چرخش واقعی، در حال پخش (دیسک و بازو لایه‌ی جدا)
        val mode = if (rl == null || !rot) 0 else if (spinDisc) 2 else 1
        rv.setImageViewBitmap(R.id.scene, scene(ctx, bw, bh, g, playing, radius, card, info, mode, rl, angle, VSettings.armStyle(theme), kind, kd, armDeg))
        if (mode == 2 && rl != null) {
            rv.setImageViewBitmap(R.id.arm_img, armLayer(bw, bh, g, kd, armDeg, radius, card, rl, VSettings.armStyle(theme)))
            rv.setViewVisibility(R.id.arm_img, View.VISIBLE)
        } else {
            rv.setViewVisibility(R.id.arm_img, View.GONE)
        }
        val tf = try {
            ctx.resources.getFont(R.font.sf_pro_soft)
        } catch (e: Exception) {
            null
        }
        if (playing && Build.VERSION.SDK_INT >= 31) {
            // یک ویوی دایره‌ای فقط به اندازه‌ی کاور، دقیقاً روی مرکز دیسک (با اندازه و فاصله‌ی دقیق)؛ انیمیشن اون رو می‌چرخونه
            // با چرخش واقعی، لایه‌ی چرخان کل دیسک (بدنه + برچسب) ـه، نه فقط برچسب
            val dBmp = if (mode == 2 && rl != null) rl.body.width else (2f * gd.r * labelRatio).toInt().coerceAtLeast(8)
            val dpX = wDp / bw.toFloat()
            val dpY = hDp / bh.toFloat()
            val dDp = dBmp * dpX * (if (mode == 2 && rl != null) kd else 1f)
            // جعبه‌ی برش: هر چی از کاور بیرون از کارت بیفته بریده میشه (برای ویجت‌های نیم‌دیسک)
            if (square) {
                rv.setViewLayoutWidth(R.id.spin_box, card.width() * dpX, TypedValue.COMPLEX_UNIT_DIP)
                rv.setViewLayoutHeight(R.id.spin_box, card.height() * dpY, TypedValue.COMPLEX_UNIT_DIP)
                rv.setViewLayoutMargin(R.id.spin_box, RemoteViews.MARGIN_LEFT, card.left * dpX, TypedValue.COMPLEX_UNIT_DIP)
                rv.setViewLayoutMargin(R.id.spin_box, RemoteViews.MARGIN_TOP, card.top * dpY, TypedValue.COMPLEX_UNIT_DIP)
            } else {
                // بعد از تغییر تم، اندازه‌ی قبلی (مربع) نباید باقی بمونه؛ کل ویجت
                rv.setViewLayoutWidth(R.id.spin_box, android.view.ViewGroup.LayoutParams.MATCH_PARENT.toFloat(), TypedValue.COMPLEX_UNIT_PX)
                rv.setViewLayoutHeight(R.id.spin_box, android.view.ViewGroup.LayoutParams.MATCH_PARENT.toFloat(), TypedValue.COMPLEX_UNIT_PX)
                rv.setViewLayoutMargin(R.id.spin_box, RemoteViews.MARGIN_LEFT, 0f, TypedValue.COMPLEX_UNIT_DIP)
                rv.setViewLayoutMargin(R.id.spin_box, RemoteViews.MARGIN_TOP, 0f, TypedValue.COMPLEX_UNIT_DIP)
            }
            val leftDp = (g.cx - card.left) * dpX - dDp / 2f
            val topDp = (g.cy - card.top) * dpY - dDp / 2f
            rv.setViewLayoutWidth(R.id.spin, dDp, TypedValue.COMPLEX_UNIT_DIP)
            rv.setViewLayoutHeight(R.id.spin, dDp, TypedValue.COMPLEX_UNIT_DIP)
            rv.setViewLayoutMargin(R.id.spin, RemoteViews.MARGIN_LEFT, leftDp, TypedValue.COMPLEX_UNIT_DIP)
            rv.setViewLayoutMargin(R.id.spin, RemoteViews.MARGIN_TOP, topDp, TypedValue.COMPLEX_UNIT_DIP)
            rv.setViewVisibility(R.id.spin, View.VISIBLE)
            rv.setViewVisibility(R.id.label_static, View.GONE)
            rv.setImageViewBitmap(R.id.spin_img, if (mode == 2 && rl != null) {
                if (cm) spinDiscWithLabel(rl, spinLabel(info, (2f * g.r * labelRatio).toInt().coerceAtLeast(8), tf), angle) else spinDiscBitmap(rl, art, angle, tf, g)
            } else {
                if (cm) rotateBmp(spinLabel(info, dBmp, tf), angle) else rotatedLabel(art, dBmp, angle, tf)
            })
            rv.setDisplayedChild(R.id.spin, 0)   // شروع دوباره‌ی چرخش از زاویه‌ی همین تصویر
        } else {
            // متوقف (یا اندروید قدیمی‌تر از ۱۲): کاور ثابت با همون زاویه‌ی آخر
            rv.setViewVisibility(R.id.spin, View.GONE)
            rv.setViewVisibility(R.id.label_static, View.VISIBLE)
            rv.setImageViewBitmap(R.id.label_static, if (cm) labelLayerText(info, bw, bh, gd, angle, tf, card) else labelLayer(art, bw, bh, gd, angle, tf, card))
        }

        // متن‌ها
        if (kind == Kind.VHALF || kind == Kind.VWIDE || kind == Kind.VBIG) {
            val title = when {
                !info.hasAccess -> "Tap to allow access"
                !info.hasMedia -> "Not playing"
                info.title.isEmpty() -> "Unknown"
                else -> info.title
            }
            rv.setTextViewText(R.id.title, title)
            rv.setTextViewText(R.id.artist, info.artist)
            rv.setTextColor(R.id.title, tint.primary)
            rv.setTextColor(R.id.artist, tint.secondary)
            val tv = if (set.info) View.VISIBLE else View.GONE
            rv.setViewVisibility(R.id.title, tv)
            rv.setViewVisibility(R.id.artist, tv)
        }

        // کارت مربع: متن و دکمه‌ها باید داخل کارت بمونن، نه لبه‌ی ویجت؛ مستطیل: فاصله‌ی معمولی (مقدار قبلی ریست میشه)
        if (kind == Kind.VHALF || kind == Kind.VBIG) {
            val offX = if (square) card.left / sc else 0f
            val offY = if (square) card.top / sc else 0f
            val sidePad = if (kind == Kind.VHALF) 10f * d else 16f * d
            val botPad = if (kind == Kind.VHALF) 10f * d else 16f * d
            // نیم‌دیسک: متن و دکمه‌ها وسط فضای زیر دیسک (گرانش وسط توی چیدمان)
            val topPad = if (kind == Kind.VHALF) (g.cy + g.r) / sc + 4f * d else 0f
            rv.setViewPadding(R.id.overlay, (sidePad + offX).toInt(), topPad.toInt(), (sidePad + offX).toInt(), (botPad + offY).toInt())
            if (kind == Kind.VHALF) {
                // جای خالی زیر دیسک (dp): توی کارت مربع کم میشه؛ اگه جا برای متن + دکمه نبود فشرده‌شون می‌کنیم تا زیر لبه نرن
                val availDp = (card.bottom / sc - botPad - topPad) / d
                val both = set.info && set.control
                val tier = when {
                    !both -> 0
                    availDp >= 70f -> 0
                    availDp >= 54f -> 1
                    else -> 2
                }
                rv.setTextViewTextSize(R.id.title, TypedValue.COMPLEX_UNIT_SP, if (tier == 0) 15f else 13f)
                rv.setTextViewTextSize(R.id.artist, TypedValue.COMPLEX_UNIT_SP, if (tier == 0) 11f else 10f)
                val iconDp = if (tier == 0) 26f else 22f
                for (vid in intArrayOf(R.id.prev, R.id.play, R.id.next)) {
                    rv.setViewLayoutWidth(vid, iconDp, TypedValue.COMPLEX_UNIT_DIP)
                    rv.setViewLayoutHeight(vid, iconDp, TypedValue.COMPLEX_UNIT_DIP)
                }
                rv.setViewLayoutMargin(R.id.controls, RemoteViews.MARGIN_TOP, if (tier == 0) 6f else 3f, TypedValue.COMPLEX_UNIT_DIP)
                rv.setViewVisibility(R.id.artist, if (set.info && tier < 2) View.VISIBLE else View.GONE)
            }
        }

        // لمس هر جا → باز شدن پلیر (یا صفحه‌ی دسترسی)
        val openApp = if (!info.hasAccess) {
            WidgetRenderer.activity(ctx, Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS), 1)
        } else {
            WidgetRenderer.launchPlayer(ctx, "")   // لمس ویجت: باز شدن خود اپ (نه پلیر)
        }
        rv.setOnClickPendingIntent(android.R.id.background, openApp)

        // دکمه‌ها
        if (kind == Kind.VHALF || kind == Kind.VWIDE || kind == Kind.VBIG) {
            if (kind == Kind.VHALF) rv.setViewVisibility(R.id.controls, if (set.control) View.VISIBLE else View.GONE)
            for (vid in intArrayOf(R.id.prev, R.id.play, R.id.next)) {
                rv.setInt(vid, "setColorFilter", tint.primary)
                rv.setViewVisibility(vid, if (set.control) View.VISIBLE else View.GONE)
            }
            rv.setImageViewResource(R.id.play, if (playing) R.drawable.ic_pause else R.drawable.ic_play)
            val base = 20 + kind.ordinal * 3
            rv.setOnClickPendingIntent(R.id.prev, WidgetRenderer.wideAction(ctx, BaseWidgetProvider.ACTION_PREV, base))
            rv.setOnClickPendingIntent(R.id.play, WidgetRenderer.wideAction(ctx, BaseWidgetProvider.ACTION_TOGGLE, base + 1))
            rv.setOnClickPendingIntent(R.id.next, WidgetRenderer.wideAction(ctx, BaseWidgetProvider.ACTION_NEXT, base + 2))
        }
        return rv
    }

    // ---------------------------------------------------------------- Now Spinning
    // کاور کج‌شده زیر دیسک (برای دیسک‌های شیشه‌ای)، دیسک بزرگ که از لبه بیرون می‌زنه، لیبل با اسم آهنگ و خواننده، دکمه‌ها پایین

    private const val SP_TILT = 15f
    private const val SP_LABEL = 0.45f

    private fun spinGeo(kind: Kind, card: RectF): Geo =
        if (kind == Kind.SPIN42) {
            Geo(card.left + 0.768f * card.width(), card.top + 0.83f * card.height(), 0.76f * card.height())
        } else {
            // مربع یا مستطیل بلند: دیسک پایین‌راست، با اندازه‌ی ضلع کوتاه‌تر
            val u = min(card.width(), card.height())
            Geo(card.right - 0.27f * u, card.bottom - 0.045f * u, 0.62f * u)
        }

    /** پس‌زمینه (تم) + کارت کاور کج‌شده؛ کارت از لبه‌ها بیرون می‌زنه و زیر دیسک میره */
    private fun spinBackground(art: Bitmap?, kind: Kind, theme: Int, blur: Boolean, bw: Int, bh: Int, radius: Float, card: RectF, blank: Bitmap?): Bitmap {
        val out = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        val clip = Path()
        clip.addRoundRect(card, radius, radius, Path.Direction.CW)
        c.clipPath(clip)
        if (!blur) {
            if (theme == VSettings.COVER) {
                val cw = card.width().toInt().coerceAtLeast(2)
                val ch = card.height().toInt().coerceAtLeast(2)
                val src = if (art != null) VinylArt.coverBackground(art, cw, ch) else VinylArt.greyBackground(cw, ch)
                c.drawBitmap(src, null, card, Paint(Paint.FILTER_BITMAP_FLAG))
            } else {
                val pr = VSettings.preset(theme)
                val paint = Paint(Paint.ANTI_ALIAS_FLAG)
                paint.shader = android.graphics.LinearGradient(0f, card.top, 0f, card.bottom, pr.bgTop, pr.bgBottom, android.graphics.Shader.TileMode.CLAMP)
                c.drawRect(card, paint)
            }
        }
        val side: Float
        val cx: Float
        val cy: Float
        if (kind == Kind.SPIN42) {
            side = 1.25f * card.height()
            cx = card.left + 0.454f * card.height()
            cy = card.top + 0.442f * card.height()
        } else {
            // گوشه‌ی بالاراست کارت کج‌شده همیشه نزدیک گوشه‌ی بالاراست ویجته؛ برای مستطیل بلند کارت بزرگ‌تر میشه تا پایین ادامه داشته باشه
            val u = min(card.width(), card.height())
            side = Math.max(card.width(), card.height())
            val trx = card.right - 0.026f * u
            val tryy = card.top - 0.066f * u
            cx = trx - 0.6125f * side
            cy = tryy + 0.3535f * side
        }
        // بدون آهنگ: کاور گرد و غباری (تصویر کاربر)، توی همه‌ی تم‌ها (بلر هم)
        val a = art ?: blank ?: VinylArt.greyBackground(256, 256)
        val sq = min(a.width, a.height).toFloat()
        val sx = (a.width - sq) / 2f
        val sy = (a.height - sq) / 2f
        val half = side / 2f
        val sh = android.graphics.BitmapShader(a, android.graphics.Shader.TileMode.CLAMP, android.graphics.Shader.TileMode.CLAMP)
        val m = android.graphics.Matrix()
        m.setRectToRect(RectF(sx, sy, sx + sq, sy + sq), RectF(-half, -half, half, half), android.graphics.Matrix.ScaleToFit.FILL)
        sh.setLocalMatrix(m)
        val p = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
        p.shader = sh
        c.save()
        c.translate(cx, cy)
        c.rotate(SP_TILT)
        val cr = if (kind == Kind.SPIN42) 0f else side * 0.14f   // 4x2: گوشه‌ی تیز مثل کاور عادی
        c.drawRoundRect(RectF(-half, -half, half, half), cr, cr, p)
        c.restore()
        return out
    }

    /** دیسک (بدون بازو و بدون لیبل)؛ برای چرخش واقعی فقط سایه (و بدنه‌ی ایستاده) */
    private fun spinScene(bw: Int, bh: Int, g: Geo, radius: Float, card: RectF, mode: Int, rl: RecordLayers?, angle: Float): Bitmap {
        val bmp = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val clip = Path()
        clip.addRoundRect(card, radius, radius, Path.Direction.CW)
        c.clipPath(clip)
        val s = g.r / VinylArt.R
        val fp = Paint(Paint.FILTER_BITMAP_FLAG)
        if (mode == 0) {
            val rec = if (rl != null) rl.composite() else record(s)
            c.drawBitmap(rec, g.cx - rec.width / 2f, g.cy - rec.height / 2f, fp)
        } else {
            val l = rl ?: return bmp
            c.drawBitmap(l.shadow, g.cx - l.shadow.width / 2f, g.cy - l.shadow.height / 2f, fp)
            if (mode == 1) {
                c.save()
                c.rotate(angle, g.cx, g.cy)
                c.drawBitmap(l.body, g.cx - l.body.width / 2f, g.cy - l.body.height / 2f, fp)
                c.restore()
                l.sheen?.let {
                    val sp = Paint(Paint.FILTER_BITMAP_FLAG)
                    sp.color = Color.BLACK
                    c.drawBitmap(it, g.cx - it.width / 2f, g.cy - it.height / 2f, sp)
                }
            }
        }
        return bmp
    }

    /** براقی ثابت روی دیسکِ چرخان (فقط وقتی چرخش واقعی روشنه) */
    private fun sheenLayer(bw: Int, bh: Int, g: Geo, radius: Float, card: RectF, rl: RecordLayers): Bitmap {
        val bmp = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val clip = Path()
        clip.addRoundRect(card, radius, radius, Path.Direction.CW)
        c.clipPath(clip)
        rl.sheen?.let {
            val sp = Paint(Paint.FILTER_BITMAP_FLAG)
            sp.color = Color.BLACK
            c.drawBitmap(it, g.cx - it.width / 2f, g.cy - it.height / 2f, sp)
        }
        return bmp
    }

    /** لیبل دیسک: مثل حالت افقی اپ، اسم آهنگ و خواننده (نه کاور) */
    private fun spinLabel(info: MediaInfo, d: Int, tf: Typeface?): Bitmap {
        if (!info.hasMedia) return VinylArt.blankLabel(d, tf)
        val title = when {
            !info.hasAccess -> "Tap to allow access"
            info.title.isEmpty() -> "Unknown"
            else -> info.title
        }
        val art = info.art
        val base = if (art != null) VinylArt.labelColor(art) else Color.rgb(26, 26, 28)
        return VinylArt.landscapeLabel(d, base, title, info.artist, tf)
    }

    private fun rotateBmp(src: Bitmap, angle: Float): Bitmap {
        val out = Bitmap.createBitmap(src.width, src.height, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        c.rotate(angle, src.width / 2f, src.height / 2f)
        c.drawBitmap(src, 0f, 0f, Paint(Paint.FILTER_BITMAP_FLAG))
        return out
    }

    /** بدنه‌ی دیسک + لیبل با هم، با زاویه‌ی داده‌شده (لایه‌ای که لانچر می‌چرخونه) */
    private fun spinDiscWithLabel(rl: RecordLayers, label: Bitmap, angle: Float): Bitmap {
        val w = rl.body.width
        val h = rl.body.height
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        val fp = Paint(Paint.FILTER_BITMAP_FLAG)
        c.save()
        c.rotate(angle, w / 2f, h / 2f)
        c.drawBitmap(rl.body, 0f, 0f, fp)
        c.drawBitmap(label, (w - label.width) / 2f, (h - label.height) / 2f, fp)
        c.restore()
        return out
    }

    fun buildSpin(ctx: Context, mgr: AppWidgetManager?, id: Int, kind: Kind, info: MediaInfo, set: VSettings.Data): RemoteViews {
        // شکل: مستطیل = کل ناحیه‌ی ویجت (بلر ممکنه)، مربع = کارت مربع وسط (بلر نه)؛ 4x2 همیشه مستطیله
        val square = kind != Kind.SPIN42 && !set.rect
        val theme = if (square && set.theme == VSettings.BLUR) VSettings.COVER else set.theme
        val blur = theme == VSettings.BLUR
        val rv = RemoteViews(ctx.packageName, R.layout.spin_widget)
        val d = ctx.resources.displayMetrics.density

        val opts = if (mgr != null) mgr.getAppWidgetOptions(id) else Bundle()
        var wDp = opts.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 0)
        var hDp = opts.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT, 0)
        if (wDp < 50) wDp = kind.defW
        if (hDp < 40) hDp = kind.defH
        wDp = wDp.coerceAtMost(700)
        hDp = hDp.coerceAtMost(500)
        val w = wDp * d
        val h = hDp * d
        val playing = info.hasMedia && info.playing
        val dsel = ThemeStore.widgetDisc(ctx)
        val customDisc = dsel.file != null || dsel.style != null
        val rot = customDisc && ThemeStore.realRotation(ctx, dsel.rotKey)
        val spinDisc = rot && playing && Build.VERSION.SDK_INT >= 31
        val sc = WidgetRenderer.fitScale(ctx, w, h, if (spinDisc) 21f else 17f)
        val bw = (w * sc).toInt().coerceAtLeast(2)
        val bh = (h * sc).toInt().coerceAtLeast(2)
        val card = if (square) {
            val side = min(bw, bh).toFloat()
            val ox = (bw - side) / 2f
            val oy = (bh - side) / 2f
            RectF(ox, oy, ox + side, oy + side)
        } else RectF(0f, 0f, bw.toFloat(), bh.toFloat())
        val radius = CORNER_DP * d * sc
        val art = info.art
        val g = spinGeo(kind, card)

        // پس‌زمینه + کارت کاور (بلر واقعی لانچر برای تم بلر: فقط رنگ نیمه‌شفاف روی ویوی ریشه)
        if (blur) {
            rv.setInt(android.R.id.background, "setBackgroundColor", Color.argb(VSettings.blurAlpha(set.blur), 0, 0, 0))
        } else {
            rv.setInt(android.R.id.background, "setBackgroundColor", 0)
        }
        val bgKey = "spin|${kind.ordinal}|${info.key}|$theme|$square|$bw|$bh|${radius.toInt()}"
        if (bgCache.size > 6) bgCache.clear()
        rv.setViewVisibility(R.id.bg, View.VISIBLE)
        rv.setImageViewBitmap(R.id.bg, bgCache.getOrPut(bgKey) { spinBackground(art, kind, theme, blur, bw, bh, radius, card, WidgetRenderer.blankCover(ctx)) })

        // دیسک
        val angle = spinAngle(ctx, info, id)
        val rs = g.r / VinylArt.R
        val rl = if (customDisc) customLayers(ctx, rs, info) else null
        val mode = if (rl == null || !rot) 0 else if (spinDisc) 2 else 1
        rv.setImageViewBitmap(R.id.scene, spinScene(bw, bh, g, radius, card, mode, rl, angle))
        if (mode == 2 && rl != null) {
            rv.setImageViewBitmap(R.id.arm_img, sheenLayer(bw, bh, g, radius, card, rl))
            rv.setViewVisibility(R.id.arm_img, View.VISIBLE)
        } else {
            rv.setViewVisibility(R.id.arm_img, View.GONE)
        }

        // لیبل: اسم آهنگ و خواننده؛ موقع پخش میچرخه (چرخش نرم لانچر)، موقع توقف ثابت با همون زاویه‌ی آخر
        val tf = try {
            ctx.resources.getFont(R.font.sf_pro_soft)
        } catch (e: Exception) {
            null
        }
        val dLabel = (2f * g.r * SP_LABEL).toInt().coerceAtLeast(8)
        val label = spinLabel(info, dLabel, tf)
        if (playing && Build.VERSION.SDK_INT >= 31) {
            val dBmp = if (mode == 2 && rl != null) rl.body.width else dLabel
            val dpX = wDp / bw.toFloat()
            val dpY = hDp / bh.toFloat()
            val dDp = dBmp * dpX
            if (square) {
                rv.setViewLayoutWidth(R.id.spin_box, card.width() * dpX, TypedValue.COMPLEX_UNIT_DIP)
                rv.setViewLayoutHeight(R.id.spin_box, card.height() * dpY, TypedValue.COMPLEX_UNIT_DIP)
                rv.setViewLayoutMargin(R.id.spin_box, RemoteViews.MARGIN_LEFT, card.left * dpX, TypedValue.COMPLEX_UNIT_DIP)
                rv.setViewLayoutMargin(R.id.spin_box, RemoteViews.MARGIN_TOP, card.top * dpY, TypedValue.COMPLEX_UNIT_DIP)
            } else {
                rv.setViewLayoutWidth(R.id.spin_box, android.view.ViewGroup.LayoutParams.MATCH_PARENT.toFloat(), TypedValue.COMPLEX_UNIT_PX)
                rv.setViewLayoutHeight(R.id.spin_box, android.view.ViewGroup.LayoutParams.MATCH_PARENT.toFloat(), TypedValue.COMPLEX_UNIT_PX)
                rv.setViewLayoutMargin(R.id.spin_box, RemoteViews.MARGIN_LEFT, 0f, TypedValue.COMPLEX_UNIT_DIP)
                rv.setViewLayoutMargin(R.id.spin_box, RemoteViews.MARGIN_TOP, 0f, TypedValue.COMPLEX_UNIT_DIP)
            }
            val leftDp = (g.cx - card.left) * dpX - dDp / 2f
            val topDp = (g.cy - card.top) * dpY - dDp / 2f
            rv.setViewLayoutWidth(R.id.spin, dDp, TypedValue.COMPLEX_UNIT_DIP)
            rv.setViewLayoutHeight(R.id.spin, dDp, TypedValue.COMPLEX_UNIT_DIP)
            rv.setViewLayoutMargin(R.id.spin, RemoteViews.MARGIN_LEFT, leftDp, TypedValue.COMPLEX_UNIT_DIP)
            rv.setViewLayoutMargin(R.id.spin, RemoteViews.MARGIN_TOP, topDp, TypedValue.COMPLEX_UNIT_DIP)
            rv.setViewVisibility(R.id.spin, View.VISIBLE)
            rv.setViewVisibility(R.id.label_static, View.GONE)
            rv.setImageViewBitmap(R.id.spin_img, if (mode == 2 && rl != null) spinDiscWithLabel(rl, label, angle) else rotateBmp(label, angle))
            rv.setDisplayedChild(R.id.spin, 0)
        } else {
            rv.setViewVisibility(R.id.spin, View.GONE)
            rv.setViewVisibility(R.id.label_static, View.VISIBLE)
            val layer = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888)
            val lc = Canvas(layer)
            val lclip = Path()
            lclip.addRoundRect(card, radius, radius, Path.Direction.CW)
            lc.clipPath(lclip)
            lc.save()
            lc.rotate(angle, g.cx, g.cy)
            lc.drawBitmap(label, g.cx - label.width / 2f, g.cy - label.height / 2f, Paint(Paint.FILTER_BITMAP_FLAG))
            lc.restore()
            rv.setImageViewBitmap(R.id.label_static, layer)
        }

        // دکمه‌ها: قبلی / پخش / بعدی، سفید، پایین (روی کاور و دیسک)
        val cs = card.width() / sc / d   // عرض کارت (dp)
        val chDp = card.height() / sc / d
        val pitchDp: Float
        val firstCx: Float
        val cyDp: Float
        val iconDp: Float
        if (kind == Kind.SPIN42) {
            pitchDp = 0.24f * chDp
            firstCx = 0.16f * chDp
            cyDp = 0.86f * chDp
            iconDp = (0.10f * chDp).coerceIn(20f, 30f)
        } else {
            val u = min(cs, chDp)
            pitchDp = 0.23f * u
            firstCx = 0.27f * u
            cyDp = chDp - 0.11f * u
            iconDp = (0.085f * u).coerceIn(20f, 30f)
        }
        val slot = pitchDp.coerceAtLeast(iconDp + 12f)
        val padPx = ((slot - iconDp) / 2f * d).toInt()
        val offXDp = card.left / sc / d
        val offYDp = card.top / sc / d
        rv.setViewVisibility(R.id.controls, if (set.control) View.VISIBLE else View.GONE)
        if (Build.VERSION.SDK_INT >= 31) {
            rv.setViewLayoutMargin(R.id.controls, RemoteViews.MARGIN_LEFT, offXDp + firstCx - slot / 2f, TypedValue.COMPLEX_UNIT_DIP)
            rv.setViewLayoutMargin(R.id.controls, RemoteViews.MARGIN_TOP, offYDp + cyDp - slot / 2f, TypedValue.COMPLEX_UNIT_DIP)
            for (vid in intArrayOf(R.id.prev, R.id.play, R.id.next)) {
                rv.setViewLayoutWidth(vid, slot + (pitchDp - slot).coerceAtLeast(0f), TypedValue.COMPLEX_UNIT_DIP)
                rv.setViewLayoutHeight(vid, slot, TypedValue.COMPLEX_UNIT_DIP)
            }
        }
        for (vid in intArrayOf(R.id.prev, R.id.play, R.id.next)) {
            rv.setViewPadding(vid, padPx, padPx, padPx, padPx)
            rv.setInt(vid, "setColorFilter", Color.WHITE)
        }
        rv.setImageViewResource(R.id.play, if (playing) R.drawable.ic_pause else R.drawable.ic_play)

        // لمس هر جا → باز شدن اپ (یا صفحه‌ی دسترسی)
        val openApp = if (!info.hasAccess) {
            WidgetRenderer.activity(ctx, Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS), 1)
        } else {
            WidgetRenderer.launchPlayer(ctx, "")
        }
        rv.setOnClickPendingIntent(android.R.id.background, openApp)
        val base = 20 + kind.ordinal * 3
        rv.setOnClickPendingIntent(R.id.prev, WidgetRenderer.wideAction(ctx, BaseWidgetProvider.ACTION_PREV, base))
        rv.setOnClickPendingIntent(R.id.play, WidgetRenderer.wideAction(ctx, BaseWidgetProvider.ACTION_TOGGLE, base + 1))
        rv.setOnClickPendingIntent(R.id.next, WidgetRenderer.wideAction(ctx, BaseWidgetProvider.ACTION_NEXT, base + 2))
        return rv
    }
}
