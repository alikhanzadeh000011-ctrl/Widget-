package com.example.mediawidget

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.drawable.Icon
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.MediaMetadata
import android.media.MediaMetadataRetriever
import android.media.MediaPlayer
import android.media.session.MediaSession
import android.media.session.PlaybackState
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.util.Size

/** صف پخش که از صفحه‌ی آلبوم‌ها به سرویس داده میشه (هر دو تو یه پروسه‌ان) */
object PlayerQueue {
    @Volatile var tracks: List<Track> = emptyList()
    @Volatile var start: Int = 0
    /** ترک فعلیِ صف و فعال بودن پلیر داخلی (برای صفحه‌ی صف و رنگ ترک در حال پخش) */
    @Volatile var index: Int = 0
    @Volatile var currentId: Long = -1L
    @Volatile var active: Boolean = false
}

/**
 * پلیر داخلی کوچیک: MediaPlayer + MediaSession + اعلان پخش.
 * چون سشن رسانه‌ی سیستمیه، ویجت‌ها و صفحه‌ی وینیل اپ خودکار نشونش میدن و کنترلش می‌کنن.
 */
class PlayerService : Service() {

    companion object {
        const val ACTION_START = "com.example.mediawidget.PLAYER_START"
        const val ACTION_TOGGLE = "com.example.mediawidget.PLAYER_TOGGLE"
        const val ACTION_NEXT = "com.example.mediawidget.PLAYER_NEXT"
        const val ACTION_PREV = "com.example.mediawidget.PLAYER_PREV"
        const val ACTION_STOP = "com.example.mediawidget.PLAYER_STOP"
        const val ACTION_JUMP = "com.example.mediawidget.PLAYER_JUMP"
        private const val CHANNEL = "player"
        private const val NOTIF_ID = 4242

        /** پرش به ترک index از صف جاری */
        fun jump(ctx: Context, index: Int) {
            val i = Intent(ctx, PlayerService::class.java)
            i.action = ACTION_JUMP
            i.putExtra("index", index)
            ctx.startService(i)
        }

        /** پخش یه صف از ترک‌ها، شروع از ترک index */
        fun start(ctx: Context, list: List<Track>, index: Int) {
            if (list.isEmpty()) return
            PlayerQueue.tracks = list
            PlayerQueue.start = index.coerceIn(0, list.size - 1)
            val i = Intent(ctx, PlayerService::class.java)
            i.action = ACTION_START
            ctx.startForegroundService(i)
        }
    }

    private lateinit var session: MediaSession
    private lateinit var am: AudioManager
    private var player: MediaPlayer? = null
    private var prepared = false
    private var wantPlay = false
    private var queue: List<Track> = emptyList()
    private var index = 0
    private var art: Bitmap? = null
    private var errorStreak = 0
    private var resumeOnGain = false
    private var focusReq: AudioFocusRequest? = null
    private val handler = Handler(Looper.getMainLooper())
    private var noisyRegistered = false

    private val attrs: AudioAttributes = AudioAttributes.Builder()
        .setUsage(AudioAttributes.USAGE_MEDIA)
        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
        .build()

    private val noisy = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            if (i.action == AudioManager.ACTION_AUDIO_BECOMING_NOISY) pause()
        }
    }

    private val focusListener = AudioManager.OnAudioFocusChangeListener { change ->
        when (change) {
            AudioManager.AUDIOFOCUS_LOSS -> {
                resumeOnGain = false
                pause()
            }
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT -> {
                if (player?.isPlaying == true) {
                    resumeOnGain = true
                    pause()
                }
            }
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK -> player?.setVolume(0.25f, 0.25f)
            AudioManager.AUDIOFOCUS_GAIN -> {
                player?.setVolume(1f, 1f)
                if (resumeOnGain) {
                    resumeOnGain = false
                    play()
                }
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "Playback", NotificationManager.IMPORTANCE_LOW))
        session = MediaSession(this, "MediaWidgetPlayer")
        session.setCallback(object : MediaSession.Callback() {
            override fun onPlay() = play()
            override fun onPause() = pause()
            override fun onSkipToNext() = next()
            override fun onSkipToPrevious() = prev()
            override fun onStop() = stopPlayback()
            override fun onSeekTo(pos: Long) {
                if (prepared) player?.seekTo(pos.toInt())
                updateState()
            }
        })
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                queue = PlayerQueue.tracks
                if (queue.isEmpty()) {
                    stopSelf()
                    return START_NOT_STICKY
                }
                errorStreak = 0
                goForeground(buildNotification())
                playIndex(PlayerQueue.start.coerceIn(0, queue.size - 1))
            }
            ACTION_TOGGLE -> if (player?.isPlaying == true) pause() else play()
            ACTION_NEXT -> next()
            ACTION_PREV -> prev()
            ACTION_STOP -> stopPlayback()
            ACTION_JUMP -> if (queue.isNotEmpty()) playIndex(intent.getIntExtra("index", 0))
        }
        return START_NOT_STICKY
    }

    // ---------------------------------------------------------------- پخش

    private fun playIndex(i: Int) {
        if (queue.isEmpty() || i !in queue.indices) {
            stopPlayback()
            return
        }
        index = i
        val t = queue[i]
        PlayerQueue.index = i
        PlayerQueue.currentId = t.id
        PlayerQueue.active = true
        releasePlayer()
        art = null
        val mp = MediaPlayer()
        mp.setAudioAttributes(attrs)
        mp.setWakeMode(this, PowerManager.PARTIAL_WAKE_LOCK)
        mp.setOnPreparedListener {
            prepared = true
            errorStreak = 0
            if (wantPlay && requestFocus()) {
                it.start()
                registerNoisy()
            }
            updateState()
            refreshNotification()
        }
        mp.setOnCompletionListener { next() }
        mp.setOnErrorListener { _, _, _ ->
            handler.post { onTrackError() }
            true
        }
        player = mp
        prepared = false
        wantPlay = true
        session.isActive = true
        setMetadata(t)
        updateState()
        refreshNotification()
        try {
            mp.setDataSource(this, t.uri)
            mp.prepareAsync()
        } catch (e: Exception) {
            handler.post { onTrackError() }
        }
        loadArtAsync(t)
    }

    private fun onTrackError() {
        errorStreak++
        if (errorStreak > 5 || index + 1 >= queue.size) stopPlayback() else playIndex(index + 1)
    }

    private fun play() {
        val mp = player ?: return
        wantPlay = true
        if (!prepared) return
        if (!mp.isPlaying && requestFocus()) {
            mp.start()
            registerNoisy()
        }
        updateState()
        refreshNotification()
    }

    private fun pause() {
        val mp = player
        wantPlay = false
        if (mp != null && prepared && mp.isPlaying) mp.pause()
        unregisterNoisy()
        updateState()
        refreshNotification()
    }

    private fun next() {
        if (index + 1 < queue.size) playIndex(index + 1) else stopPlayback()
    }

    private fun prev() {
        val mp = player
        if (mp != null && prepared && mp.currentPosition > 3000) {
            mp.seekTo(0)
            updateState()
        } else if (index > 0) {
            playIndex(index - 1)
        } else if (mp != null && prepared) {
            mp.seekTo(0)
            updateState()
        }
    }

    private fun stopPlayback() {
        PlayerQueue.active = false
        PlayerQueue.currentId = -1L
        releasePlayer()
        wantPlay = false
        unregisterNoisy()
        focusReq?.let { am.abandonAudioFocusRequest(it) }
        session.setPlaybackState(
            PlaybackState.Builder().setState(PlaybackState.STATE_STOPPED, 0, 0f).build()
        )
        session.isActive = false
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun releasePlayer() {
        player?.let {
            try {
                it.setOnCompletionListener(null)
                it.setOnErrorListener(null)
                it.release()
            } catch (e: Exception) {
            }
        }
        player = null
        prepared = false
    }

    private fun requestFocus(): Boolean {
        val req = focusReq ?: AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
            .setAudioAttributes(attrs)
            .setOnAudioFocusChangeListener(focusListener)
            .build().also { focusReq = it }
        return am.requestAudioFocus(req) == AudioManager.AUDIOFOCUS_REQUEST_GRANTED
    }

    private fun registerNoisy() {
        if (noisyRegistered) return
        registerReceiver(noisy, IntentFilter(AudioManager.ACTION_AUDIO_BECOMING_NOISY))
        noisyRegistered = true
    }

    private fun unregisterNoisy() {
        if (!noisyRegistered) return
        try {
            unregisterReceiver(noisy)
        } catch (e: Exception) {
        }
        noisyRegistered = false
    }

    // ---------------------------------------------------------------- سشن و اعلان

    private fun setMetadata(t: Track) {
        val b = MediaMetadata.Builder()
            .putString(MediaMetadata.METADATA_KEY_TITLE, t.title)
            .putString(MediaMetadata.METADATA_KEY_ARTIST, t.artist)
            .putString(MediaMetadata.METADATA_KEY_ALBUM, t.album)
            .putLong(MediaMetadata.METADATA_KEY_DURATION, t.durationMs)
        art?.let {
            b.putBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART, it)
            b.putBitmap(MediaMetadata.METADATA_KEY_ART, it)
        }
        session.setMetadata(b.build())
    }

    private fun updateState() {
        val mp = player
        val st = when {
            mp == null -> PlaybackState.STATE_STOPPED
            !prepared -> PlaybackState.STATE_BUFFERING
            mp.isPlaying -> PlaybackState.STATE_PLAYING
            else -> PlaybackState.STATE_PAUSED
        }
        val pos = if (mp != null && prepared) mp.currentPosition.toLong() else 0L
        val actions = PlaybackState.ACTION_PLAY or PlaybackState.ACTION_PAUSE or PlaybackState.ACTION_PLAY_PAUSE or
            PlaybackState.ACTION_SKIP_TO_NEXT or PlaybackState.ACTION_SKIP_TO_PREVIOUS or
            PlaybackState.ACTION_SEEK_TO or PlaybackState.ACTION_STOP
        session.setPlaybackState(
            PlaybackState.Builder()
                .setActions(actions)
                .setState(st, pos, if (st == PlaybackState.STATE_PLAYING) 1f else 0f, SystemClock.elapsedRealtime())
                .build()
        )
    }

    private fun pi(action: String, code: Int): PendingIntent {
        val i = Intent(this, PlayerService::class.java)
        i.action = action
        return PendingIntent.getService(this, code, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
    }

    private fun buildNotification(): Notification {
        val t = queue.getOrNull(index)
        val playing = player?.isPlaying == true
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, VinylActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val b = Notification.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_notif)
            .setContentTitle(t?.title ?: "Playing")
            .setContentText(t?.artist ?: "")
            .setContentIntent(open)
            .setOnlyAlertOnce(true)
            .setOngoing(true)
            .setVisibility(Notification.VISIBILITY_PUBLIC)
        art?.let { b.setLargeIcon(it) }
        b.addAction(Notification.Action.Builder(Icon.createWithResource(this, R.drawable.ic_prev), "Previous", pi(ACTION_PREV, 1)).build())
        b.addAction(
            Notification.Action.Builder(
                Icon.createWithResource(this, if (playing) R.drawable.ic_pause else R.drawable.ic_play),
                if (playing) "Pause" else "Play", pi(ACTION_TOGGLE, 2)
            ).build()
        )
        b.addAction(Notification.Action.Builder(Icon.createWithResource(this, R.drawable.ic_next), "Next", pi(ACTION_NEXT, 3)).build())
        b.setStyle(
            Notification.MediaStyle()
                .setMediaSession(session.sessionToken)
                .setShowActionsInCompactView(0, 1, 2)
        )
        return b.build()
    }

    private fun goForeground(n: Notification) {
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    private fun refreshNotification() {
        if (queue.isEmpty()) return
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(NOTIF_ID, buildNotification())
    }

    // ---------------------------------------------------------------- کاور

    private fun loadArtAsync(t: Track) {
        val app = applicationContext
        Thread {
            val b = loadArt(app, t)
            handler.post {
                if (queue.getOrNull(index)?.id == t.id && b != null) {
                    art = b
                    setMetadata(t)
                    refreshNotification()
                }
            }
        }.start()
    }

    private fun loadArt(ctx: Context, t: Track): Bitmap? {
        try {
            val r = MediaMetadataRetriever()
            try {
                r.setDataSource(ctx, t.uri)
                val bytes = r.embeddedPicture
                if (bytes != null) {
                    val o = BitmapFactory.Options()
                    o.inJustDecodeBounds = true
                    BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o)
                    var sample = 1
                    while (o.outWidth / sample > 1024) sample *= 2
                    val o2 = BitmapFactory.Options()
                    o2.inSampleSize = sample
                    val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o2)
                    if (bmp != null) return bmp
                }
            } finally {
                r.release()
            }
        } catch (e: Exception) {
        }
        if (Build.VERSION.SDK_INT >= 29) {
            try {
                return ctx.contentResolver.loadThumbnail(t.uri, Size(600, 600), null)
            } catch (e: Exception) {
            }
        }
        return null
    }

    override fun onDestroy() {
        unregisterNoisy()
        releasePlayer()
        try {
            session.release()
        } catch (e: Exception) {
        }
        super.onDestroy()
    }
}
