package com.example.mediawidget

import android.app.Activity
import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/** پیام کوتاه سبک MD: کارت تیره‌ی گرد با متن پررنگ که چند ثانیه می‌مونه و محو میشه */
object MdToast {
    private var current: View? = null

    fun show(ctx: Context, text: String) {
        val act = ctx as? Activity
        val decor = act?.window?.decorView as? FrameLayout
        if (act == null || decor == null) {
            Toast.makeText(ctx, text, Toast.LENGTH_SHORT).show()
            return
        }
        val d = ctx.resources.displayMetrics.density
        current?.let { old -> (old.parent as? ViewGroup)?.removeView(old) }

        val tv = TextView(act)
        tv.text = text
        tv.setTextColor(Color.WHITE)
        tv.textSize = 17f
        tv.typeface = Typeface.create(DarkUi.font(act), Typeface.BOLD)
        tv.gravity = Gravity.CENTER
        val bg = GradientDrawable()
        bg.setColor(Color.rgb(43, 44, 51))
        bg.cornerRadius = 26f * d
        tv.background = bg
        tv.setPadding((26f * d).toInt(), (18f * d).toInt(), (26f * d).toInt(), (18f * d).toInt())
        tv.elevation = 12f * d
        val maxW = (ctx.resources.displayMetrics.widthPixels * 0.86f).toInt().coerceAtMost((420f * d).toInt())
        tv.maxWidth = maxW
        val lp = FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL)
        lp.bottomMargin = (96f * d).toInt()
        decor.addView(tv, lp)
        current = tv
        tv.alpha = 0f
        tv.scaleX = 0.92f
        tv.scaleY = 0.92f
        tv.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(180L).start()
        tv.postDelayed({
            tv.animate().alpha(0f).setDuration(260L).withEndAction {
                (tv.parent as? ViewGroup)?.removeView(tv)
                if (current === tv) current = null
            }.start()
        }, 2200L)
    }
}

/** دیالوگ سبک MD: کارت تیره‌ی گرد، متن پررنگ و دکمه‌ی بنفش بزرگ */
class MdDialog(private val ctx: Context) {

    private val d = ctx.resources.displayMetrics.density
    private var titleText: String? = null
    private var messageText: String? = null
    private val bodyViews = ArrayList<View>()
    private class Btn(val text: String, val style: Int, val action: (() -> Unit)?)
    private val buttons = ArrayList<Btn>()
    private var dialog: Dialog? = null

    private fun dp(v: Float) = (v * d).toInt()

    fun title(t: String): MdDialog { titleText = t; return this }
    fun message(m: String): MdDialog { messageText = m; return this }
    fun addView(v: View): MdDialog { bodyViews.add(v); return this }
    fun primary(text: String, action: (() -> Unit)? = null): MdDialog { buttons.add(Btn(text, 0, action)); return this }
    fun secondary(text: String, action: (() -> Unit)? = null): MdDialog { buttons.add(Btn(text, 1, action)); return this }
    fun danger(text: String, action: (() -> Unit)? = null): MdDialog { buttons.add(Btn(text, 2, action)); return this }

    fun dismiss() {
        dialog?.dismiss()
    }

    private fun pill(b: Btn): TextView {
        val tv = TextView(ctx)
        tv.text = b.text
        tv.gravity = Gravity.CENTER
        tv.textSize = 19f
        tv.typeface = Typeface.create(DarkUi.font(ctx), Typeface.BOLD)
        tv.setTextColor(Color.WHITE)
        val g = GradientDrawable()
        g.cornerRadius = dp(30f).toFloat()
        when (b.style) {
            0 -> {
                g.orientation = GradientDrawable.Orientation.LEFT_RIGHT
                g.colors = intArrayOf(Color.rgb(139, 72, 234), Color.rgb(108, 70, 222))
                g.setStroke(dp(2f), Color.rgb(96, 64, 186))
            }
            2 -> {
                g.setColor(Color.rgb(214, 60, 70))
                g.setStroke(dp(2f), Color.rgb(170, 44, 52))
            }
            else -> {
                g.setColor(Color.rgb(58, 59, 68))
                g.setStroke(dp(2f), Color.rgb(74, 75, 86))
            }
        }
        tv.background = g
        tv.setOnClickListener {
            dismiss()
            b.action?.invoke()
        }
        return tv
    }

    fun show(): Dialog {
        val dlg = Dialog(ctx)
        dlg.requestWindowFeature(Window.FEATURE_NO_TITLE)
        val card = LinearLayout(ctx)
        card.orientation = LinearLayout.VERTICAL
        val bg = GradientDrawable()
        bg.setColor(Color.rgb(43, 44, 51))
        bg.cornerRadius = dp(32f).toFloat()
        card.background = bg
        card.setPadding(dp(26f), dp(28f), dp(26f), dp(24f))

        titleText?.let {
            val t = TextView(ctx)
            t.text = it
            t.setTextColor(Color.WHITE)
            t.textSize = 22f
            t.typeface = Typeface.create(DarkUi.font(ctx), Typeface.BOLD)
            card.addView(t, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).also { lp -> lp.bottomMargin = dp(10f) })
        }
        messageText?.let {
            val t = TextView(ctx)
            t.text = it
            t.setTextColor(Color.WHITE)
            t.textSize = 20f
            t.setLineSpacing(0f, 1.18f)
            t.typeface = Typeface.create(DarkUi.font(ctx), Typeface.BOLD)
            card.addView(t, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).also { lp -> lp.bottomMargin = dp(8f) })
        }
        for (v in bodyViews) {
            card.addView(v, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }
        for ((i, b) in buttons.withIndex()) {
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(58f))
            lp.topMargin = if (i == 0) dp(20f) else dp(10f)
            card.addView(pill(b), lp)
        }

        val scroll = ScrollView(ctx)
        scroll.isVerticalScrollBarEnabled = false
        scroll.addView(card, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        val w = (ctx.resources.displayMetrics.widthPixels * 0.88f).toInt().coerceAtMost(dp(420f))
        val root = FrameLayout(ctx)
        root.addView(scroll, FrameLayout.LayoutParams(w, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER))
        dlg.setContentView(root)
        dlg.window?.let {
            it.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            it.setDimAmount(0.6f)
            it.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        }
        dlg.setCanceledOnTouchOutside(true)
        dialog = dlg
        dlg.show()
        return dlg
    }

    companion object {
        /** پیام ساده با یه دکمه‌ی OK */
        fun info(ctx: Context, message: String, ok: String = "OK") {
            MdDialog(ctx).message(message).primary(ok).show()
        }

        fun confirm(ctx: Context, title: String?, message: String, yes: String, danger: Boolean = false, onYes: () -> Unit) {
            val dlg = MdDialog(ctx)
            title?.let { dlg.title(it) }
            dlg.message(message)
            if (danger) dlg.danger(yes) { onYes() } else dlg.primary(yes) { onYes() }
            dlg.secondary("Cancel").show()
        }

        /** انتخاب از بین چند گزینه (جای setSingleChoiceItems) */
        fun choose(ctx: Context, title: String, items: Array<String>, checked: Int, onPick: (Int) -> Unit) {
            val dlg = MdDialog(ctx).title(title)
            val d = ctx.resources.displayMetrics.density
            val list = LinearLayout(ctx)
            list.orientation = LinearLayout.VERTICAL
            for ((i, name) in items.withIndex()) {
                val row = LinearLayout(ctx)
                row.orientation = LinearLayout.HORIZONTAL
                row.gravity = Gravity.CENTER_VERTICAL
                row.setPadding(0, (14f * d).toInt(), 0, (14f * d).toInt())
                val t = TextView(ctx)
                t.text = name
                t.textSize = 18f
                t.setTextColor(Color.WHITE)
                t.typeface = DarkUi.font(ctx)
                row.addView(t, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
                val dot = View(ctx)
                val g = GradientDrawable()
                g.shape = GradientDrawable.OVAL
                if (i == checked) {
                    g.setColor(DarkUi.PURPLE)
                } else {
                    g.setColor(Color.TRANSPARENT)
                    g.setStroke((2f * d).toInt(), Color.rgb(98, 99, 110))
                }
                dot.background = g
                row.addView(dot, LinearLayout.LayoutParams((22f * d).toInt(), (22f * d).toInt()))
                row.setOnClickListener {
                    dlg.dismiss()
                    onPick(i)
                }
                list.addView(row)
            }
            dlg.addView(list)
            dlg.show()
        }

        /** یه ردیف با کلید روشن/خاموش (برای منوی نگه‌داشتن) */
        fun toggleRow(ctx: Context, label: String, desc: String, on: Boolean, onChange: (Boolean) -> Unit): View {
            val d = ctx.resources.displayMetrics.density
            val row = LinearLayout(ctx)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.setPadding(0, (8f * d).toInt(), 0, (8f * d).toInt())
            val col = LinearLayout(ctx)
            col.orientation = LinearLayout.VERTICAL
            val t = TextView(ctx)
            t.text = label
            t.textSize = 18f
            t.setTextColor(Color.WHITE)
            t.typeface = Typeface.create(DarkUi.font(ctx), Typeface.BOLD)
            col.addView(t)
            val s = TextView(ctx)
            s.text = desc
            s.textSize = 13.5f
            s.setTextColor(Color.rgb(150, 151, 162))
            s.typeface = DarkUi.font(ctx)
            col.addView(s)
            row.addView(col, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

            var state = on
            val track = View(ctx)
            val knob = View(ctx)
            val holder = FrameLayout(ctx)
            fun apply(animate: Boolean) {
                val g = GradientDrawable()
                g.cornerRadius = 16f * d
                g.setColor(if (state) DarkUi.PURPLE else Color.rgb(70, 71, 82))
                track.background = g
                val x = if (state) 22f * d else 0f
                if (animate) knob.animate().translationX(x).setDuration(140L).start() else knob.translationX = x
            }
            val kg = GradientDrawable()
            kg.shape = GradientDrawable.OVAL
            kg.setColor(Color.WHITE)
            knob.background = kg
            holder.addView(track, FrameLayout.LayoutParams((50f * d).toInt(), (30f * d).toInt()))
            holder.addView(knob, FrameLayout.LayoutParams((24f * d).toInt(), (24f * d).toInt()).also {
                it.leftMargin = (3f * d).toInt()
                it.topMargin = (3f * d).toInt()
            })
            apply(false)
            holder.setOnClickListener {
                state = !state
                apply(true)
                onChange(state)
            }
            row.addView(holder, LinearLayout.LayoutParams((50f * d).toInt(), (30f * d).toInt()).also { it.leftMargin = (14f * d).toInt() })
            return row
        }
    }
}
