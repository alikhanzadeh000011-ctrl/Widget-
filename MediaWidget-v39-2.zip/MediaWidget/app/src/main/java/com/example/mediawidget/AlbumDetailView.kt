package com.example.mediawidget

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.RenderEffect
import android.graphics.Shader
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/** رنگ‌های صفحه‌ی آلبوم: گرادینت از رنگ کاور + رنگ متن */
class AlbumTheme(val top: Int, val bottom: Int, val dark: Boolean) {
    val text: Int get() = if (dark) Color.WHITE else Color.rgb(22, 22, 26)

    companion object {
        fun from(bmp: Bitmap?, fallback: Int): AlbumTheme {
            val n = 24
            val px = IntArray(n * n)
            if (bmp != null) {
                Bitmap.createScaledBitmap(bmp, n, n, true).getPixels(px, 0, n, 0, 0, n, n)
            } else {
                px.fill(fallback)
            }
            var sr = 0.0
            var sg = 0.0
            var sb = 0.0
            var sw = 0.0
            var lum = 0.0
            val hsv = FloatArray(3)
            for (p in px) {
                Color.colorToHSV(p, hsv)
                // رنگ‌های زنده وزن بیشتری دارن تا میانگین خاکستری و کدر نشه
                val w = 0.05 + hsv[1] * hsv[2]
                sr += Color.red(p) * w
                sg += Color.green(p) * w
                sb += Color.blue(p) * w
                sw += w
                lum += (0.299 * Color.red(p) + 0.587 * Color.green(p) + 0.114 * Color.blue(p)) / 255.0
            }
            val avg = Color.rgb((sr / sw).toInt(), (sg / sw).toInt(), (sb / sw).toInt())
            val avgLum = lum / px.size
            Color.colorToHSV(avg, hsv)
            val h = hsv[0]
            var s = hsv[1]
            // کاور خاکستری خاکستری می‌مونه؛ کاور رنگی کمی زنده‌تر میشه
            if (s > 0.10f) s = (s * 1.15f).coerceIn(0.22f, 0.85f)
            val light = avgLum > 0.5
            val top: Int
            val bottom: Int
            if (light) {
                top = Color.HSVToColor(floatArrayOf(h, s * 0.55f, 0.94f))
                bottom = Color.HSVToColor(floatArrayOf(h, s * 0.80f, 0.80f))
            } else {
                top = Color.HSVToColor(floatArrayOf(h, s * 0.90f, 0.52f))
                bottom = Color.HSVToColor(floatArrayOf(h, s, 0.20f))
            }
            return AlbumTheme(top, bottom, !light)
        }
    }
}

/**
 * صفحه‌ی یک آلبوم: کاور (بعد از فرود)، اسم، خواننده، دکمه‌های Play و Shuffle و لیست ترک‌ها.
 * پس‌زمینه شفافه؛ گرادینت و کاور در حال پرواز رو خود AlbumStackView زیرش می‌کشه.
 */
class AlbumDetailView(ctx: Context) : FrameLayout(ctx) {

    interface Host {
        fun onBack()
        fun onTrack(list: List<Track>, index: Int)
        fun onPlayAll(list: List<Track>, shuffle: Boolean)
    }

    var host: Host? = null

    private val d = ctx.resources.displayMetrics.density
    private val scroll = ScrollView(ctx)
    private val col = LinearLayout(ctx)
    private val slot = FrameLayout(ctx)
    val coverView = ImageView(ctx)
    private val head = LinearLayout(ctx)
    private val tracksBox = LinearLayout(ctx)
    private val back = BackView(ctx)
    private val titleV = TextView(ctx)
    private val artistV = TextView(ctx)
    private val infoV = TextView(ctx)
    private val playBtn = TextView(ctx)
    private val shuffleBtn = TextView(ctx)

    private var insetTop = 0
    private var insetBottom = 0
    private var insetLeft = 0
    private var side = 0
    private var theme = AlbumTheme(Color.GRAY, Color.DKGRAY, true)
    private var tracks: List<Track> = emptyList()
    private var infoBase = ""
    private var revealed = false
    private var folderMode = false
    private var playTint = Color.WHITE
    private var playingIdx = -1
    private val titleViews = ArrayList<TextView>()

    private fun dp(v: Float) = (v * d).toInt()

    init {
        isClickable = true
        clipChildren = false
        val font = DarkUi.font(ctx)

        scroll.isVerticalScrollBarEnabled = false
        scroll.overScrollMode = OVER_SCROLL_NEVER
        scroll.clipChildren = false
        scroll.clipToPadding = false
        addView(scroll, LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        col.orientation = LinearLayout.VERTICAL
        col.clipChildren = false
        scroll.addView(col, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        slot.clipChildren = false
        coverView.scaleType = ImageView.ScaleType.FIT_XY
        coverView.outlineProvider = ViewOutlineProvider.BOUNDS
        coverView.elevation = dp(10f).toFloat()
        coverView.visibility = INVISIBLE
        slot.addView(coverView, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        col.addView(slot, LinearLayout.LayoutParams(dp(200f), dp(200f)))

        head.orientation = LinearLayout.VERTICAL
        head.gravity = Gravity.CENTER_HORIZONTAL
        head.alpha = 0f

        titleV.typeface = Typeface_bold(font)
        titleV.textSize = 23f
        titleV.gravity = Gravity.CENTER
        titleV.maxLines = 2
        titleV.ellipsize = android.text.TextUtils.TruncateAt.END
        head.addView(titleV, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).also {
            it.topMargin = dp(26f)
        })

        artistV.typeface = font
        artistV.textSize = 17f
        artistV.gravity = Gravity.CENTER
        artistV.maxLines = 1
        artistV.ellipsize = android.text.TextUtils.TruncateAt.END
        head.addView(artistV, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).also {
            it.topMargin = dp(8f)
        })

        infoV.typeface = font
        infoV.textSize = 14f
        infoV.gravity = Gravity.CENTER
        head.addView(infoV, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).also {
            it.topMargin = dp(8f)
        })

        val btnRow = LinearLayout(ctx)
        btnRow.orientation = LinearLayout.HORIZONTAL
        for ((i, b) in listOf(playBtn, shuffleBtn).withIndex()) {
            b.typeface = Typeface_bold(font)
            b.textSize = 16f
            b.gravity = Gravity.CENTER
            val lp = LinearLayout.LayoutParams(0, dp(52f), 1f)
            if (i == 0) lp.rightMargin = dp(8f) else lp.leftMargin = dp(8f)
            btnRow.addView(b, lp)
        }
        playBtn.text = "Play"
        shuffleBtn.text = "Shuffle"
        playBtn.setOnClickListener { if (tracks.isNotEmpty()) host?.onPlayAll(tracks, false) }
        shuffleBtn.setOnClickListener { if (tracks.isNotEmpty()) host?.onPlayAll(tracks, true) }
        head.addView(btnRow, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).also {
            it.topMargin = dp(28f)
        })
        col.addView(head, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).also {
            it.leftMargin = dp(24f)
            it.rightMargin = dp(24f)
        })

        tracksBox.orientation = LinearLayout.VERTICAL
        tracksBox.alpha = 0f
        col.addView(tracksBox, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).also {
            it.leftMargin = dp(24f)
            it.rightMargin = dp(24f)
            it.topMargin = dp(30f)
        })

        back.setOnClickListener { host?.onBack() }
        addView(back, LayoutParams(dp(48f), dp(48f), Gravity.TOP or Gravity.START))
        back.alpha = 0f
    }

    @Suppress("FunctionName")
    private fun Typeface_bold(base: android.graphics.Typeface): android.graphics.Typeface =
        android.graphics.Typeface.create(base, android.graphics.Typeface.BOLD)

    fun setInsets(top: Int, bottom: Int, left: Int) {
        insetTop = top
        insetBottom = bottom
        insetLeft = left
        val lp = back.layoutParams as LayoutParams
        lp.topMargin = top + dp(10f)
        lp.leftMargin = left + dp(10f)
        back.layoutParams = lp
        col.setPadding(0, 0, 0, bottom + dp(56f))
        relayoutCover()
    }

    /** مستطیل نهایی کاور (در مختصات همین صفحه) وقتی اسکرول صفره */
    fun coverRect(w: Int): RectF {
        side = (w * 0.76f).toInt()
        val left = (w - side) / 2f
        val top = (insetTop + dp(78f)).toFloat()
        return RectF(left, top, left + side, top + side)
    }

    private fun relayoutCover() {
        if (side <= 0) return
        val lp = slot.layoutParams as LinearLayout.LayoutParams
        lp.width = side
        lp.height = side
        lp.gravity = Gravity.CENTER_HORIZONTAL
        lp.topMargin = insetTop + dp(78f)
        slot.layoutParams = lp
    }

    /** آماده‌سازی برای یک آلبوم: متن‌ها، رنگ‌ها و کاور */
    fun bind(album: Album, th: AlbumTheme, w: Int, cover: Bitmap, folderMode: Boolean) {
        theme = th
        tracks = emptyList()
        revealed = false
        side = (w * 0.76f).toInt()
        relayoutCover()
        scroll.scrollTo(0, 0)
        titleV.text = album.title
        titleV.setTextColor(th.text)
        this.folderMode = folderMode
        artistV.text = if (folderMode) folderArtistGuess(album.extra) else album.artist
        playTint = adaptTint(Palette.tintFor(cover).primary, th.dark, th.text)
        playingIdx = -1
        titleViews.clear()
        artistV.setTextColor(withAlpha(th.text, 190))
        infoBase = if (album.tracks == 1) "1 song" else album.tracks.toString() + " songs"
        infoV.text = infoBase
        infoV.setTextColor(withAlpha(th.text, 140))
        styleButton(playBtn)
        styleButton(shuffleBtn)
        back.color = th.text
        back.invalidate()
        coverView.setImageBitmap(cover)
        coverView.visibility = INVISIBLE
        coverView.elevation = 0f
        head.alpha = 0f
        tracksBox.alpha = 0f
        back.alpha = 0f
        clearEffect(head)
        clearEffect(tracksBox)
        tracksBox.removeAllViews()
    }

    /** تو حالت پوشه، قبل از لود ترک‌ها: اسم پوشه‌ی بالاتر (معمولاً خواننده) به‌جای کل مسیر */
    private fun folderArtistGuess(extra: String): String {
        val segs = extra.split('/').filter { it.isNotBlank() }
        return if (segs.size >= 2) segs[segs.size - 2] else (segs.lastOrNull() ?: "")
    }

    /** رنگ ترک در حال پخش: تینت کاور، متناسب با روشنایی صفحه */
    private fun adaptTint(c: Int, dark: Boolean, textColor: Int): Int {
        val hsv = FloatArray(3)
        Color.colorToHSV(c, hsv)
        if (hsv[1] < 0.03f) return textColor   // کاور خاکستری: بدون رنگ
        if (dark) {
            hsv[2] = maxOf(hsv[2], 0.9f)
        } else {
            hsv[1] = (hsv[1] * 4f).coerceIn(0.55f, 0.95f)
            hsv[2] = 0.42f
        }
        return Color.HSVToColor(hsv)
    }

    fun trackList(): List<Track> = tracks

    /** ترک در حال پخش (اندیس) با رنگ آلبوم؛ -1 = هیچ‌کدوم */
    fun markPlaying(idx: Int) {
        playingIdx = idx
        for ((i, tv) in titleViews.withIndex()) tv.setTextColor(if (i == idx) playTint else theme.text)
    }

    fun setCoverBitmap(b: Bitmap) {
        coverView.setImageBitmap(b)
    }

    private fun styleButton(b: TextView) {
        val g = GradientDrawable()
        g.cornerRadius = dp(26f).toFloat()
        g.setStroke(dp(1.5f), withAlpha(theme.text, 110))
        g.setColor(Color.TRANSPARENT)
        b.background = g
        b.setTextColor(theme.text)
    }

    private fun withAlpha(c: Int, a: Int) = Color.argb(a, Color.red(c), Color.green(c), Color.blue(c))

    fun setTracks(list: List<Track>) {
        tracks = list
        tracksBox.removeAllViews()
        titleViews.clear()
        val font = DarkUi.font(context)
        var year = 0
        for (t in list) if (t.year > year) year = t.year
        infoV.text = if (year > 0) "$infoBase · $year" else infoBase
        if (folderMode) {
            val counts = HashMap<String, Int>()
            for (t in list) if (t.artist.isNotBlank()) counts[t.artist] = (counts[t.artist] ?: 0) + 1
            val best = counts.maxByOrNull { it.value }?.key
            if (best != null) artistV.text = best
        }
        for ((i, t) in list.withIndex()) {
            val row = LinearLayout(context)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.setPadding(0, dp(15f), 0, dp(15f))
            row.isClickable = true
            row.setOnClickListener { host?.onTrack(list, i) }

            val no = TextView(context)
            no.typeface = font
            no.textSize = 15f
            no.setTextColor(withAlpha(theme.text, 130))
            val num = if (t.no > 0) t.no else i + 1
            no.text = if (num < 10) "0$num" else num.toString()
            row.addView(no, LinearLayout.LayoutParams(dp(42f), ViewGroup.LayoutParams.WRAP_CONTENT))

            val title = TextView(context)
            title.typeface = Typeface_bold(font)
            title.textSize = 16f
            title.setTextColor(theme.text)
            title.text = t.title
            title.maxLines = 2
            title.ellipsize = android.text.TextUtils.TruncateAt.END
            row.addView(title, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            titleViews.add(title)

            val dur = TextView(context)
            dur.typeface = font
            dur.textSize = 14f
            dur.setTextColor(withAlpha(theme.text, 130))
            val sec = (t.durationMs / 1000).toInt()
            dur.text = (sec / 60).toString() + "'" + (if (sec % 60 < 10) "0" else "") + (sec % 60).toString() + "\""
            val dlp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            dlp.leftMargin = dp(12f)
            row.addView(dur, dlp)

            tracksBox.addView(row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            if (i < list.size - 1) {
                val line = View(context)
                line.setBackgroundColor(withAlpha(theme.text, 28))
                tracksBox.addView(line, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 1))
            }
        }
        markPlaying(playingIdx)
    }

    // ---------------------------------------------------------------- انیمیشن‌ها

    /** بعد از فرود کاور: کاور واقعی نشون داده میشه و متن‌ها از حالت تار واضح میشن */
    fun reveal() {
        revealed = true
        coverView.visibility = VISIBLE
        coverView.elevation = dp(10f).toFloat()
        fadeBlurIn(head, 0L)
        fadeBlurIn(tracksBox, 140L)
        back.animate().alpha(1f).setDuration(260L).start()
    }

    private fun fadeBlurIn(v: View, delay: Long) {
        v.alpha = 0f
        val a = ValueAnimator.ofFloat(0f, 1f)
        a.duration = 440L
        a.startDelay = delay
        a.addUpdateListener {
            val f = it.animatedValue as Float
            v.alpha = f
            applyBlur(v, 16f * (1f - f))
        }
        a.addListener(object : AnimatorListenerAdapter() {
            override fun onAnimationEnd(animation: Animator) {
                clearEffect(v)
            }
        })
        a.start()
    }

    /** قبل از برگشت: اگه صفحه اسکرول شده، نرم به بالا برمی‌گرده تا کاور تو جای اصلیش باشه */
    fun scrollToTop(done: () -> Unit) {
        val y = scroll.scrollY
        if (y <= 2) {
            done()
            return
        }
        scroll.smoothScrollTo(0, 0)
        postDelayed({ done() }, (140 + y / 6).coerceAtMost(380).toLong())
    }

    /** قبل از برگشت: متن‌ها و دکمه‌ی عقب محو میشن و کاور واقعی جاش رو به کاور در حال پرواز میده */
    fun hideContent(done: () -> Unit) {
        coverView.visibility = INVISIBLE
        back.animate().alpha(0f).setDuration(160L).start()
        head.animate().alpha(0f).setDuration(180L).start()
        tracksBox.animate().alpha(0f).setDuration(180L).withEndAction { done() }.start()
    }

    private fun applyBlur(v: View, r: Float) {
        if (Build.VERSION.SDK_INT >= 31) {
            if (r > 0.5f) v.setRenderEffect(RenderEffect.createBlurEffect(r, r, Shader.TileMode.CLAMP))
            else v.setRenderEffect(null)
        }
    }

    private fun clearEffect(v: View) {
        if (Build.VERSION.SDK_INT >= 31) v.setRenderEffect(null)
    }

    /** دکمه‌ی عقب: فلش < */
    class BackView(ctx: Context) : View(ctx) {
        var color: Int = Color.WHITE
        private val p = Paint(Paint.ANTI_ALIAS_FLAG)
        private val path = Path()

        override fun onDraw(c: Canvas) {
            val u = resources.displayMetrics.density
            p.style = Paint.Style.STROKE
            p.strokeWidth = 2.4f * u
            p.strokeCap = Paint.Cap.ROUND
            p.strokeJoin = Paint.Join.ROUND
            p.color = color
            val cx = width / 2f
            val cy = height / 2f
            path.reset()
            path.moveTo(cx + 5f * u, cy - 11f * u)
            path.lineTo(cx - 5f * u, cy)
            path.lineTo(cx + 5f * u, cy + 11f * u)
            c.drawPath(path, p)
        }
    }
}
