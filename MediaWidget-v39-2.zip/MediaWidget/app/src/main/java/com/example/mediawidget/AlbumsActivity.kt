package com.example.mediawidget

import android.Manifest
import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.media.MediaMetadata
import android.graphics.Path
import android.graphics.RectF
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.util.concurrent.Executors

/** صفحه‌ی آلبوم‌ها (یا پوشه‌ها): چیدمان ۳بعدی یا گالری؛ دیسک بالا-چپ، تغییر حالت بالا-راست */
class AlbumsActivity : Activity(), AlbumStackView.Listener {

    private lateinit var stack: AlbumStackView
    private lateinit var toggle: ToggleView
    private lateinit var discBtn: DiscView
    private lateinit var queueBtn: QueueBtn
    private lateinit var queueView: QueueView
    private var queueOpen = false
    @Volatile private var lastBackdrop: Bitmap? = null
    private var playTint: Int = Color.WHITE
    private val queuePoll = object : Runnable {
        override fun run() {
            if (!queueOpen) return
            refreshQueue(false)
            handler.postDelayed(this, 1000L)
        }
    }
    private val playPoll = object : Runnable {
        override fun run() {
            if (!detailOpen) return
            refreshPlaying()
            handler.postDelayed(this, 1000L)
        }
    }
    private lateinit var permPanel: LinearLayout
    private lateinit var emptyText: TextView
    private var loaded = false
    private lateinit var detail: AlbumDetailView
    private var detailOpen = false
    private var animating = false
    private var openAlbum: Album? = null
    private var theme: AlbumTheme? = null
    private val handler = Handler(Looper.getMainLooper())
    private val bgExec = Executors.newSingleThreadExecutor()
    @Volatile private var bgKey = "?"
    private var insTop = 0
    private var insBottom = 0
    private var insLeft = 0
    private val bgPoll = object : Runnable {
        override fun run() {
            pollBackdrop()
            handler.postDelayed(this, 3000L)
        }
    }

    private fun perm(): String =
        if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE

    private fun hasPerm(): Boolean = checkSelfPermission(perm()) == PackageManager.PERMISSION_GRANTED

    private fun dp(v: Float) = DarkUi.dp(this, v)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        DarkUi.guard(this) { build() }
    }

    @Suppress("DEPRECATION")
    private fun enterImmersive() {
        if (Build.VERSION.SDK_INT >= 30) {
            window.setDecorFitsSystemWindows(false)
            window.insetsController?.let {
                it.systemBarsBehavior = WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                it.hide(WindowInsets.Type.systemBars())
            }
        } else {
            window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_FULLSCREEN or
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) enterImmersive()
    }

    @Suppress("DEPRECATION")
    private fun build() {
        DarkUi.setupWindow(this)
        if (Build.VERSION.SDK_INT >= 28) {
            val lp = window.attributes
            lp.layoutInDisplayCutoutMode = android.view.WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            window.attributes = lp
        }
        enterImmersive()

        val root = FrameLayout(this)
        root.setBackgroundColor(DarkUi.BG)

        stack = AlbumStackView(this)
        stack.listener = this
        root.addView(stack, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        // دکمه‌ی تغییر حالت (بالا-راست)
        toggle = ToggleView(this)
        toggle.setOnClickListener {
            stack.toggleMode()
            toggle.grid = stack.isGrid()
            toggle.invalidate()
        }
        root.addView(toggle, FrameLayout.LayoutParams(dp(52f), dp(52f), Gravity.TOP or Gravity.END))

        // دکمه‌ی دیسک (بالا-چپ): برگشت به صفحه‌ی وینیل
        discBtn = DiscView(this)
        discBtn.setOnClickListener { finish() }
        root.addView(discBtn, FrameLayout.LayoutParams(dp(52f), dp(52f), Gravity.TOP or Gravity.START))

        // دکمه‌ی صف پخش (وسط بالا)
        queueBtn = QueueBtn(this)
        queueBtn.setOnClickListener { openQueue() }
        root.addView(queueBtn, FrameLayout.LayoutParams(dp(52f), dp(52f), Gravity.TOP or Gravity.CENTER_HORIZONTAL))

        emptyText = TextView(this)
        emptyText.text = "Nothing to show here"
        emptyText.setTextColor(DarkUi.LABEL)
        emptyText.textSize = 18f
        emptyText.typeface = DarkUi.font(this)
        emptyText.gravity = Gravity.CENTER
        emptyText.visibility = View.GONE
        root.addView(emptyText, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        permPanel = LinearLayout(this)
        permPanel.orientation = LinearLayout.VERTICAL
        permPanel.gravity = Gravity.CENTER
        permPanel.setPadding(dp(32f), 0, dp(32f), 0)
        val msg = TextView(this)
        msg.text = "Allow access to your music files to show your albums."
        msg.setTextColor(Color.WHITE)
        msg.textSize = 18f
        msg.typeface = DarkUi.font(this)
        msg.gravity = Gravity.CENTER
        msg.setLineSpacing(0f, 1.2f)
        permPanel.addView(msg)
        val btn = DarkUi.pill(this, "Allow access") { requestPermissions(arrayOf(perm()), 7) }
        val blp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        blp.topMargin = dp(22f)
        permPanel.addView(btn, blp)
        permPanel.visibility = View.GONE
        root.addView(permPanel, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        // صفحه‌ی صف پخش (بالای دکمه‌ها)
        queueView = QueueView(this)
        queueView.visibility = View.GONE
        queueView.host = object : QueueView.Host {
            override fun onClose() = closeQueue()
            override fun onJump(entry: QueueEntry, index: Int) = jumpQueue(entry, index)
        }
        root.addView(queueView, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        // صفحه‌ی آلبوم (بالای همه؛ فقط وقتی یه آلبوم باز شده)
        detail = AlbumDetailView(this)
        detail.visibility = View.GONE
        detail.host = object : AlbumDetailView.Host {
            override fun onBack() = closeDetail()
            override fun onTrack(list: List<Track>, index: Int) {
                askNotifPermission()
                TrackPlayer.play(this@AlbumsActivity, list, index, openAlbum, LibraryPrefs.mode(this@AlbumsActivity) == LibraryPrefs.FOLDERS)
            }
            override fun onPlayAll(list: List<Track>, shuffle: Boolean) {
                askNotifPermission()
                TrackPlayer.playAll(this@AlbumsActivity, list, shuffle, openAlbum, LibraryPrefs.mode(this@AlbumsActivity) == LibraryPrefs.FOLDERS)
            }
        }
        root.addView(detail, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        root.setOnApplyWindowInsetsListener { _, ins ->
            var top = ins.systemWindowInsetTop
            var left = ins.systemWindowInsetLeft
            var right = ins.systemWindowInsetRight
            val bottom = ins.systemWindowInsetBottom
            if (Build.VERSION.SDK_INT >= 28) {
                val cut = ins.displayCutout
                if (cut != null) {
                    top = maxOf(top, cut.safeInsetTop)
                    left = maxOf(left, cut.safeInsetLeft)
                    right = maxOf(right, cut.safeInsetRight)
                }
            }
            stack.setInsets(top, bottom)
            insTop = top
            insBottom = bottom
            insLeft = left
            detail.setInsets(top, bottom, left)
            queueView.setInsets(top, bottom, left)
            val ql = queueBtn.layoutParams as FrameLayout.LayoutParams
            ql.topMargin = top + dp(14f)
            queueBtn.layoutParams = ql
            val tl = toggle.layoutParams as FrameLayout.LayoutParams
            tl.topMargin = top + dp(14f)
            tl.rightMargin = right + dp(18f)
            toggle.layoutParams = tl
            val dl = discBtn.layoutParams as FrameLayout.LayoutParams
            dl.topMargin = top + dp(14f)
            dl.leftMargin = left + dp(18f)
            discBtn.layoutParams = dl
            ins
        }

        setContentView(root)
        root.requestApplyInsets()
        refreshState()
    }

    override fun onResume() {
        super.onResume()
        if (::stack.isInitialized) {
            refreshState()
            handler.removeCallbacks(bgPoll)
            handler.postDelayed(bgPoll, 300L)
        }
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(bgPoll)
        handler.removeCallbacks(playPoll)
        handler.removeCallbacks(queuePoll)
    }

    /** پس‌زمینه‌ی پشته: همون بلرِ کاورِ آهنگ در حال پخش که تو صفحه‌ی وینیل هست */
    private fun pollBackdrop() {
        if (!::stack.isInitialized) return
        val w = stack.width
        val h = stack.height
        if (w <= 0 || h <= 0) return
        val app = applicationContext
        bgExec.execute {
            val info = try { MediaReader.read(app) } catch (e: Throwable) { null }
            val art = info?.art
            val key = if (art != null && info != null) info.key else ""
            if (key == bgKey) return@execute
            val bmp = if (art != null) {
                try { VinylArt.coverBackground(art, w, h) } catch (e: Throwable) { null }
            } else null
            val tintC = if (art != null) Palette.tintFor(art).primary else Color.WHITE
            runOnUiThread {
                if (!isDestroyed) {
                    bgKey = key
                    lastBackdrop = bmp
                    playTint = lightTint(tintC)
                    stack.setBackdrop(bmp)
                    if (queueOpen) {
                        queueView.setBackdrop(bmp)
                        queueView.setTint(playTint)
                    }
                }
            }
        }
    }

    private fun refreshState() {
        if (hasPerm()) {
            permPanel.visibility = View.GONE
            if (!loaded) loadAlbums()
        } else {
            permPanel.visibility = View.VISIBLE
            stack.visibility = View.INVISIBLE
        }
    }

    private fun loadAlbums() {
        loaded = true
        val app = applicationContext
        val mode = LibraryPrefs.mode(app)
        Executors.newSingleThreadExecutor().execute {
            val list = AlbumRepo.loadVisible(app, mode)
            runOnUiThread {
                if (isDestroyed) return@runOnUiThread
                stack.visibility = View.VISIBLE
                stack.setAlbums(list)
                emptyText.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
            }
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        refreshState()
    }

    override fun onAlbumTap(album: Album, index: Int) {
        if (animating || detailOpen) return
        val w = stack.width
        if (w <= 0) return
        animating = true
        val mode = LibraryPrefs.mode(this)
        val cover = stack.bitmapFor(index)
        val th = AlbumTheme.from(if (stack.hasCover(index)) cover else null, album.color)
        theme = th
        openAlbum = album
        detail.bind(album, th, w, cover, mode == LibraryPrefs.FOLDERS)
        detail.visibility = View.VISIBLE
        stack.setFinalRect(detail.coverRect(w))
        stack.setFocusBitmap(null)
        stack.beginFocus(index)
        toggle.animate().alpha(0f).setDuration(200L).start()
        discBtn.animate().alpha(0f).setDuration(200L).start()
        queueBtn.animate().alpha(0f).setDuration(200L).start()

        // کاور بزرگ و ترک‌ها تو پس‌زمینه
        val app = applicationContext
        Executors.newSingleThreadExecutor().execute {
            val big = AlbumRepo.loadItemCover(app, album, 1000)
            val list = AlbumRepo.loadTracks(app, album, mode)
            runOnUiThread {
                if (isDestroyed || openAlbum !== album) return@runOnUiThread
                if (big != null) {
                    stack.setFocusBitmap(big)
                    detail.setCoverBitmap(big)
                }
                detail.setTracks(list)
            }
        }

        val anim = ValueAnimator.ofFloat(0f, 1f)
        anim.duration = 650L
        anim.addUpdateListener {
            val e = it.animatedValue as Float
            stack.setFocusProgress(e)
            stack.setGradient(th.top, th.bottom, (e * 1.4f).coerceIn(0f, 1f))
        }
        anim.addListener(object : AnimatorListenerAdapter() {
            override fun onAnimationEnd(animation: Animator) {
                animating = false
                detailOpen = true
                detail.reveal()
                // کاور واقعی نشون داده شد؛ پشته دیگه کاور پروازی رو نکشه
                handler.postDelayed({ if (detailOpen) stack.setFocusHold(true) }, 90L)
                handler.post(playPoll)
            }
        })
        anim.start()
    }

    /** برگشت از صفحه‌ی آلبوم: انیمیشن باز شدن برعکس */
    private fun closeDetail() {
        if (animating || !detailOpen) return
        val th = theme ?: return
        animating = true
        handler.removeCallbacks(playPoll)
        detail.scrollToTop {
          stack.setFocusHold(false)
          detail.hideContent {
            val anim = ValueAnimator.ofFloat(1f, 0f)
            anim.duration = 520L
            anim.addUpdateListener {
                val e = it.animatedValue as Float
                stack.setFocusProgress(e)
                stack.setGradient(th.top, th.bottom, (e * 1.4f).coerceIn(0f, 1f))
            }
            anim.addListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: Animator) {
                    stack.endFocus()
                    detail.visibility = View.GONE
                    detailOpen = false
                    animating = false
                    openAlbum = null
                    toggle.animate().alpha(1f).setDuration(200L).start()
                    discBtn.animate().alpha(1f).setDuration(200L).start()
                    queueBtn.animate().alpha(1f).setDuration(200L).start()
                }
            })
            anim.start()
          }
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (animating) return
        if (queueOpen) {
            closeQueue()
            return
        }
        if (detailOpen) {
            closeDetail()
            return
        }
        @Suppress("DEPRECATION")
        super.onBackPressed()
    }

    private fun norm(x: String?): String = (x ?: "").trim().lowercase()

    /** تینت روشن برای پس‌زمینه‌های تیره */
    private fun lightTint(c: Int): Int {
        val hsv = FloatArray(3)
        Color.colorToHSV(c, hsv)
        if (hsv[1] < 0.03f) return Color.WHITE
        hsv[2] = maxOf(hsv[2], 0.92f)
        return Color.HSVToColor(hsv)
    }

    /** ترک در حال پخش تو لیست آلبوم: از پلیر داخلی یا از سشن پلیر دیگه */
    private fun refreshPlaying() {
        if (!detailOpen) return
        val list = detail.trackList()
        if (list.isEmpty()) return
        var idx = -1
        if (PlayerQueue.active && PlayerQueue.currentId >= 0) {
            idx = list.indexOfFirst { it.id == PlayerQueue.currentId }
        }
        if (idx < 0) {
            val c = MediaReader.controllers(this)?.let { MediaReader.pick(it) }
            val md = c?.metadata
            val title = norm(md?.getString(MediaMetadata.METADATA_KEY_TITLE))
            val alb = norm(md?.getString(MediaMetadata.METADATA_KEY_ALBUM))
            if (title.isNotEmpty()) {
                idx = list.indexOfFirst {
                    norm(it.title) == title && (alb.isEmpty() || norm(it.album).isEmpty() || norm(it.album) == alb)
                }
            }
        }
        detail.markPlaying(idx)
    }

    // ---------------------------------------------------------------- صف پخش

    private fun buildQueue(): Pair<List<QueueEntry>, Int> {
        if (PlayerQueue.active && PlayerQueue.tracks.isNotEmpty()) {
            val list = PlayerQueue.tracks.mapIndexed { i, t ->
                QueueEntry("t:" + t.id, t.title, t.artist, t, i.toLong(), null, null)
            }
            return Pair(list, PlayerQueue.index)
        }
        val c = MediaReader.controllers(this)?.let { MediaReader.pick(it) }
        val q = c?.queue
        if (c != null && q != null && q.isNotEmpty()) {
            val activeId = c.playbackState?.activeQueueItemId ?: -1L
            val list = q.map { item ->
                val dsc = item.description
                QueueEntry(
                    "q:" + c.packageName + ":" + item.queueId,
                    dsc.title?.toString() ?: "", dsc.subtitle?.toString() ?: "",
                    null, item.queueId, dsc.iconBitmap, dsc.iconUri
                )
            }
            var cur = q.indexOfFirst { it.queueId == activeId }
            if (cur < 0) {
                val t = norm(c.metadata?.getString(MediaMetadata.METADATA_KEY_TITLE))
                cur = list.indexOfFirst { norm(it.title) == t }
            }
            return Pair(list, cur)
        }
        return Pair(emptyList(), -1)
    }

    private fun refreshQueue(initial: Boolean) {
        val (list, cur) = buildQueue()
        queueView.setData(list, cur, initial)
    }

    private fun openQueue() {
        if (animating || detailOpen || queueOpen) return
        queueOpen = true
        queueView.setBackdrop(lastBackdrop)
        queueView.setTint(playTint)
        refreshQueue(true)
        queueView.visibility = View.VISIBLE
        queueView.alpha = 0f
        queueView.translationY = dp(24f).toFloat()
        queueView.animate().alpha(1f).translationY(0f).setDuration(240L).start()
        toggle.animate().alpha(0f).setDuration(160L).start()
        discBtn.animate().alpha(0f).setDuration(160L).start()
        queueBtn.animate().alpha(0f).setDuration(160L).start()
        handler.removeCallbacks(queuePoll)
        handler.postDelayed(queuePoll, 1000L)
    }

    private fun closeQueue() {
        if (!queueOpen) return
        queueOpen = false
        handler.removeCallbacks(queuePoll)
        queueView.animate().alpha(0f).translationY(dp(24f).toFloat()).setDuration(200L).withEndAction {
            queueView.visibility = View.GONE
        }.start()
        toggle.animate().alpha(1f).setDuration(220L).start()
        discBtn.animate().alpha(1f).setDuration(220L).start()
        queueBtn.animate().alpha(1f).setDuration(220L).start()
    }

    private fun jumpQueue(entry: QueueEntry, index: Int) {
        if (entry.track != null && PlayerQueue.active) {
            PlayerService.jump(this, index)
        } else {
            val c = MediaReader.controllers(this)?.let { MediaReader.pick(it) }
            try {
                c?.transportControls?.skipToQueueItem(entry.queueId)
            } catch (e: Exception) {
                MdToast.show(this, "This player can't jump in its queue")
            }
        }
        handler.postDelayed({ if (queueOpen) refreshQueue(false) }, 500L)
    }

    /** اندروید ۱۳ به بالا: برای اعلان پخش یه بار مجوز اعلان‌ها رو می‌پرسیم (پخش بدون اون هم کار می‌کنه) */
    private fun askNotifPermission() {
        if (Build.VERSION.SDK_INT < 33) return
        if (LibraryPrefs.askedNotifPermission(this)) return
        if (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) return
        LibraryPrefs.setAskedNotifPermission(this)
        requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 77)
    }

    /** نگه داشتن انگشت روی یک کارت: پیشنهاد مخفی کردن */
    override fun onAlbumLongPress(album: Album, index: Int) {
        val mode = LibraryPrefs.mode(this)
        MdDialog.confirm(
            this, album.title,
            "Hide this " + (if (mode == LibraryPrefs.FOLDERS) "folder" else "album") + "? You can show it again from Settings > Hidden items.",
            "Hide"
        ) {
            LibraryPrefs.setHidden(this, mode, album.key, true)
            loaded = false
            loadAlbums()
        }
    }

    /** دکمه‌ی گرد بالا-راست: آیکن شبکه (حالت ۳بعدی) یا آیکن پشته (حالت گالری) */
    private class ToggleView(ctx: Activity) : View(ctx) {
        var grid = false
        private val p = Paint(Paint.ANTI_ALIAS_FLAG)
        private val r = RectF()

        override fun onDraw(c: Canvas) {
            val w = width.toFloat()
            val cx = w / 2f
            val cy = height / 2f
            p.style = Paint.Style.FILL
            p.color = Color.argb(110, 0, 0, 0)
            c.drawCircle(cx, cy, w / 2f, p)
            p.color = Color.WHITE
            val u = w / 52f
            if (!grid) {
                val s = 8f * u
                val g = 4f * u
                for (i in 0..1) for (j in 0..1) {
                    val x = cx - s - g / 2f + i * (s + g)
                    val y = cy - s - g / 2f + j * (s + g)
                    r.set(x, y, x + s, y + s)
                    c.drawRoundRect(r, 2f * u, 2f * u, p)
                }
            } else {
                for (i in 0..2) {
                    val y = cy - 9f * u + i * 9f * u
                    val inset = (2 - i) * 2.5f * u
                    r.set(cx - 12f * u + inset, y - 3f * u, cx + 12f * u - inset, y + 3f * u)
                    c.drawRoundRect(r, 1.5f * u, 1.5f * u, p)
                }
            }
        }
    }

    /** دکمه‌ی گرد بالا-چپ با لوگوی دیسک (برگشت به صفحه‌ی وینیل) */
    private class DiscView(ctx: Activity) : View(ctx) {
        private val p = Paint(Paint.ANTI_ALIAS_FLAG)
        private val oval = RectF()

        override fun onDraw(c: Canvas) {
            val w = width.toFloat()
            val cx = w / 2f
            val cy = height / 2f
            p.style = Paint.Style.FILL
            p.color = Color.argb(110, 0, 0, 0)
            c.drawCircle(cx, cy, w / 2f, p)
            // لوگوی دیسک (سفید): حلقه‌ی بیرونی، دو کمان سر‌گرد، حلقه‌ی داخلی و نقطه‌ی وسط
            val r = w * 0.31f
            p.color = Color.WHITE
            p.style = Paint.Style.STROKE
            p.strokeCap = Paint.Cap.BUTT
            p.strokeWidth = r * 0.126f
            c.drawCircle(cx, cy, r * 0.937f, p)
            p.strokeWidth = r * 0.119f
            p.strokeCap = Paint.Cap.ROUND
            val ra = r * 0.618f
            oval.set(cx - ra, cy - ra, cx + ra, cy + ra)
            c.drawArc(oval, 183.5f, 83f, false, p)
            c.drawArc(oval, 3.5f, 83f, false, p)
            p.strokeCap = Paint.Cap.BUTT
            p.strokeWidth = r * 0.133f
            c.drawCircle(cx, cy, r * 0.2755f, p)
            p.style = Paint.Style.FILL
            c.drawCircle(cx, cy, r * 0.084f, p)
        }
    }

    /** دکمه‌ی صف پخش: لوگوی سفید (سه خط و نت) */
    private class QueueBtn(ctx: Activity) : View(ctx) {
        private val p = Paint(Paint.ANTI_ALIAS_FLAG)
        private val ip = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
        private val dst = RectF()
        private val logo: Bitmap? = BitmapFactory.decodeResource(ctx.resources, R.drawable.ic_queue_logo)

        override fun onDraw(c: Canvas) {
            val w = width.toFloat()
            val cx = w / 2f
            val cy = height / 2f
            p.style = Paint.Style.FILL
            p.color = Color.argb(110, 0, 0, 0)
            c.drawCircle(cx, cy, w / 2f, p)
            val l = logo ?: return
            val half = w * 0.24f
            dst.set(cx - half, cy - half, cx + half, cy + half)
            c.drawBitmap(l, null, dst, ip)
        }
    }
}
