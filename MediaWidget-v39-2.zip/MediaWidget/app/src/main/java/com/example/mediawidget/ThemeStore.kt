package com.example.mediawidget

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.Uri
import java.io.File
import java.io.FileOutputStream
import kotlin.math.max

/** ذخیره‌ی عکس‌های سفارشی پس‌زمینه و دیسک (داخل حافظه‌ی اپ) و انتخاب فعلی */
object ThemeStore {
    const val BG = "bg"
    const val DISC = "disc"

    private fun dir(ctx: Context): File {
        val d = File(ctx.filesDir, "themes")
        d.mkdirs()
        return d
    }

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("theme", Context.MODE_PRIVATE)

    /** چرخش واقعی (۳۳⅓ دور در دقیقه و چرخش کل دیسک) برای هر دیسک؛ key = اسم فایل یا default */
    fun realRotation(ctx: Context, key: String): Boolean = prefs(ctx).getBoolean("real_" + key, false)

    fun setRealRotation(ctx: Context, key: String, v: Boolean) {
        prefs(ctx).edit().putBoolean("real_" + key, v).apply()
    }

    fun list(ctx: Context, kind: String): List<File> {
        val files = dir(ctx).listFiles { f -> f.name.startsWith(kind + "_") } ?: return emptyList()
        return files.sortedBy { it.lastModified() }
    }

    fun selected(ctx: Context, kind: String): File? {
        val name = prefs(ctx).getString(kind, "").orEmpty()
        if (name.isEmpty()) return null
        val f = File(dir(ctx), name)
        return if (f.exists()) f else null
    }

    fun select(ctx: Context, kind: String, file: File?) {
        prefs(ctx).edit().putString(kind, file?.name ?: "").apply()
        WidgetRenderer.updateAll(ctx)
    }

    fun delete(ctx: Context, kind: String, file: File) {
        if (selected(ctx, kind)?.name == file.name) select(ctx, kind, null)
        file.delete()
    }

    /** عکس انتخاب‌شده از گالری رو کوچیک و ذخیره می‌کنه */
    fun import(ctx: Context, kind: String, uri: Uri): File? {
        val maxSide = if (kind == BG) 2400 else 1400
        val bmp = decodeUri(ctx, uri, maxSide) ?: return null
        val ext = if (kind == BG) "jpg" else "png"
        val f = File(dir(ctx), kind + "_" + System.currentTimeMillis() + "." + ext)
        FileOutputStream(f).use {
            if (kind == BG) bmp.compress(Bitmap.CompressFormat.JPEG, 92, it)
            else bmp.compress(Bitmap.CompressFormat.PNG, 100, it)
        }
        bmp.recycle()
        return f
    }

    private fun decodeUri(ctx: Context, uri: Uri, maxSide: Int): Bitmap? {
        val cr = ctx.contentResolver
        val bounds = BitmapFactory.Options()
        bounds.inJustDecodeBounds = true
        cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
        var sample = 1
        while (max(bounds.outWidth, bounds.outHeight) / (sample * 2) >= maxSide) sample *= 2
        val opts = BitmapFactory.Options()
        opts.inSampleSize = sample
        var bmp = cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) } ?: return null

        val orient = try {
            cr.openInputStream(uri)?.use {
                ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
            } ?: ExifInterface.ORIENTATION_NORMAL
        } catch (e: Exception) {
            ExifInterface.ORIENTATION_NORMAL
        }
        val deg = when (orient) {
            ExifInterface.ORIENTATION_ROTATE_90 -> 90f
            ExifInterface.ORIENTATION_ROTATE_180 -> 180f
            ExifInterface.ORIENTATION_ROTATE_270 -> 270f
            else -> 0f
        }
        if (deg != 0f) {
            val m = Matrix()
            m.postRotate(deg)
            bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
        }
        val big = max(bmp.width, bmp.height)
        if (big > maxSide) {
            val k = maxSide / big.toFloat()
            bmp = Bitmap.createScaledBitmap(bmp, (bmp.width * k).toInt().coerceAtLeast(1), (bmp.height * k).toInt().coerceAtLeast(1), true)
        }
        return bmp
    }

    /** خوندن فایل ذخیره‌شده؛ بزرگ‌ترین ضلع حداقل minSide میشه (برای رندر یا بندانگشتی) */
    fun decodeFile(f: File, minSide: Int): Bitmap? {
        val b = BitmapFactory.Options()
        b.inJustDecodeBounds = true
        BitmapFactory.decodeFile(f.path, b)
        if (b.outWidth <= 0 || b.outHeight <= 0) return null
        var sample = 1
        while (max(b.outWidth, b.outHeight) / (sample * 2) >= minSide) sample *= 2
        val o = BitmapFactory.Options()
        o.inSampleSize = sample
        return BitmapFactory.decodeFile(f.path, o)
    }
}
