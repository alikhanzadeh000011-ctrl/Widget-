package com.example.mediawidget

import android.content.Context

/** تنظیمات کتابخانه‌ی موزیک: حالت نمایش (آلبوم یا پوشه) و مخفی‌ها */
object LibraryPrefs {
    const val ALBUMS = 0
    const val FOLDERS = 1

    private fun p(ctx: Context) = ctx.getSharedPreferences("library", Context.MODE_PRIVATE)

    fun mode(ctx: Context): Int = p(ctx).getInt("mode", ALBUMS)

    fun setMode(ctx: Context, mode: Int) {
        p(ctx).edit().putInt("mode", mode).apply()
    }

    fun hidden(ctx: Context, mode: Int): Set<String> =
        HashSet(p(ctx).getStringSet("hidden_$mode", emptySet()) ?: emptySet())

    fun setHidden(ctx: Context, mode: Int, key: String, hide: Boolean) {
        val s = HashSet(hidden(ctx, mode))
        if (hide) s.add(key) else s.remove(key)
        p(ctx).edit().putStringSet("hidden_$mode", s).apply()
    }

    /** روش پخش یه ترک: ۰ = پخش از جستجو (پیش‌فرض)، ۱ = باز کردن فایل (پاپ‌آپ Samsung Music) */
    const val PLAY_SEARCH = 0
    const val PLAY_OPEN = 1

    /** پلیر: ۰ = پلیر داخلی (پیش‌فرض)، ۱ = Samsung Music */
    const val PLAYER_BUILTIN = 0
    const val PLAYER_SAMSUNG = 1

    fun playerType(ctx: Context): Int = p(ctx).getInt("player_type", PLAYER_BUILTIN)

    fun setPlayerType(ctx: Context, v: Int) {
        p(ctx).edit().putInt("player_type", v).apply()
    }

    fun askedNotifPermission(ctx: Context): Boolean = p(ctx).getBoolean("asked_notif", false)

    fun setAskedNotifPermission(ctx: Context) {
        p(ctx).edit().putBoolean("asked_notif", true).apply()
    }

    fun playMethod(ctx: Context): Int = p(ctx).getInt("play_method2", PLAY_SEARCH)

    fun setPlayMethod(ctx: Context, m: Int) {
        p(ctx).edit().putInt("play_method2", m).apply()
    }

    fun clearHidden(ctx: Context) {
        p(ctx).edit().remove("hidden_$ALBUMS").remove("hidden_$FOLDERS").apply()
    }
}
