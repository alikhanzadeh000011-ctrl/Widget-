package com.example.mediawidget

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.Switch
import android.widget.TextView
import android.content.res.ColorStateList
import android.graphics.Color

/** صفحه‌ی تنظیمات: ظاهر تیره و فول‌اسکرین (فقط گزینه‌های خود اپ) */
class MainActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        DarkUi.guard(this) { build() }
    }

    private fun build() {
        val screen = DarkUi.Screen(this, "Settings")
        val prefs = getSharedPreferences("ui", MODE_PRIVATE)

        screen.body.addView(DarkUi.sectionLabel(this, "General"))
        val general = DarkUi.card(this)
        DarkUi.addRow(general, "Permissions", null, DarkUi.glyph(this, GlyphView.CHEVRON, 28f)) {
            startActivity(Intent(this, PermissionsActivity::class.java))
        }
        DarkUi.addRow(general, "Library folders", null, DarkUi.glyph(this, GlyphView.CHEVRON, 28f)) {
            startActivity(Intent(this, TilesActivity::class.java))
        }

        screen.body.addView(general)

        screen.body.addView(DarkUi.sectionLabel(this, "Music library"))
        val lib = DarkUi.card(this)
        val modeText = TextView(this)
        modeText.text = if (LibraryPrefs.mode(this) == LibraryPrefs.FOLDERS) "Folders" else "Albums"
        modeText.setTextColor(DarkUi.LABEL)
        modeText.textSize = 17f
        modeText.typeface = DarkUi.font(this)
        DarkUi.addRow(lib, "Show music by", "Group the 3D view by albums or folders", modeText) {
            val items = arrayOf("Albums", "Folders")
            MdDialog.choose(this, "Show music by", items, LibraryPrefs.mode(this)) { which ->
                LibraryPrefs.setMode(this, which)
                modeText.text = items[which]
            }
        }
        val playerText = TextView(this)
        val playerNames = arrayOf("Built-in", "Samsung Music")
        playerText.text = playerNames[LibraryPrefs.playerType(this).coerceIn(0, 1)]
        playerText.setTextColor(DarkUi.LABEL)
        playerText.textSize = 17f
        playerText.typeface = DarkUi.font(this)
        DarkUi.addRow(lib, "Player", "What plays tracks you start from the album screens", playerText) {
            MdDialog.choose(this, "Player", arrayOf("Built-in player", "Samsung Music"), LibraryPrefs.playerType(this).coerceIn(0, 1)) { which ->
                LibraryPrefs.setPlayerType(this, which)
                playerText.text = playerNames[which]
            }
        }
        val playText = TextView(this)
        val playNames = arrayOf("Search", "Popup")
        playText.text = playNames[LibraryPrefs.playMethod(this).coerceIn(0, 1)]
        playText.setTextColor(DarkUi.LABEL)
        playText.textSize = 17f
        playText.typeface = DarkUi.font(this)
        DarkUi.addRow(lib, "Playback method", "Samsung Music only: how tapping a track starts it", playText) {
            val items = arrayOf(
                "Play from search (one track)",
                "Open file (popup player)"
            )
            MdDialog.choose(this, "Playback method", items, LibraryPrefs.playMethod(this).coerceIn(0, 1)) { which ->
                LibraryPrefs.setPlayMethod(this, which)
                playText.text = playNames[which]
            }
        }
        DarkUi.addRow(lib, "Hidden items", "Choose albums or folders to hide", DarkUi.glyph(this, GlyphView.CHEVRON, 28f)) {
            startActivity(Intent(this, HiddenActivity::class.java))
        }
        screen.body.addView(lib)
        screen.body.addView(DarkUi.sectionLabel(this, "Display"))
        val display = DarkUi.card(this)
        val sw = Switch(this)
        sw.isChecked = !prefs.getBoolean("hide_text", false)
        sw.thumbTintList = ColorStateList.valueOf(Color.WHITE)
        sw.trackTintList = ColorStateList(
            arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()),
            intArrayOf(DarkUi.PURPLE, Color.rgb(85, 86, 98))
        )
        sw.setOnCheckedChangeListener { _, on -> prefs.edit().putBoolean("hide_text", !on).apply() }
        DarkUi.addRow(display, "Song title and artist", "Show them under the vinyl", sw) { sw.toggle() }
        screen.body.addView(display)

        val spacer = View(this)
        screen.body.addView(spacer, LinearLayout.LayoutParams(1, 0, 1f))
        val foot = TextView(this)
        foot.text = "Media Widget"
        foot.setTextColor(DarkUi.LABEL)
        foot.textSize = 15f
        foot.typeface = DarkUi.font(this)
        foot.gravity = Gravity.CENTER
        foot.setPadding(0, DarkUi.dp(this, 36f), 0, 0)
        screen.body.addView(foot)

        screen.show()
    }
}
