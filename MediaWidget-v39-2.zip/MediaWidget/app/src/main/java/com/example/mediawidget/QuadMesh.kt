package com.example.mediawidget

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Matrix
import android.graphics.Paint
import kotlin.math.abs

/** نگاشت پرسپکتیو‌صحیح یه مربع واحد به یه چهارضلعی دلخواه، به شکل مش برای drawBitmapMesh */
object QuadMesh {
    /** کشیدن تصویر روی یه چهارضلعی با تبدیل پرسپکتیو دقیق (لبه‌ی نرم با paint مناسب) */
    fun draw(c: Canvas, bmp: Bitmap, q: FloatArray, paint: Paint, m: Matrix, src: FloatArray): Boolean {
        val bw = bmp.width.toFloat()
        val bh = bmp.height.toFloat()
        src[0] = 0f; src[1] = 0f
        src[2] = bw; src[3] = 0f
        src[4] = bw; src[5] = bh
        src[6] = 0f; src[7] = bh
        if (!m.setPolyToPoly(src, 0, q, 0, 4)) return false
        c.drawBitmap(bmp, m, paint)
        return true
    }

    /** q: بالا‌چپ، بالا‌راست، پایین‌راست، پایین‌چپ؛ out: (n+1)*(n+1)*2 عدد */
    fun build(q: FloatArray, out: FloatArray, n: Int) {
        val x0 = q[0]; val y0 = q[1]
        val x1 = q[2]; val y1 = q[3]
        val x2 = q[4]; val y2 = q[5]
        val x3 = q[6]; val y3 = q[7]
        val dx1 = x1 - x2; val dx2 = x3 - x2; val dx3 = x0 - x1 + x2 - x3
        val dy1 = y1 - y2; val dy2 = y3 - y2; val dy3 = y0 - y1 + y2 - y3
        val det = dx1 * dy2 - dx2 * dy1
        var g = 0f
        var h = 0f
        if (abs(det) > 1e-3f && (abs(dx3) > 1e-4f || abs(dy3) > 1e-4f)) {
            g = (dx3 * dy2 - dx2 * dy3) / det
            h = (dx1 * dy3 - dx3 * dy1) / det
        }
        val a = x1 - x0 + g * x1
        val b = x3 - x0 + h * x3
        val dd = y1 - y0 + g * y1
        val e = y3 - y0 + h * y3
        var k = 0
        for (r in 0..n) {
            val v = r.toFloat() / n
            for (c in 0..n) {
                val u = c.toFloat() / n
                val den = g * u + h * v + 1f
                out[k++] = (a * u + b * v + x0) / den
                out[k++] = (dd * u + e * v + y0) / den
            }
        }
    }
}
