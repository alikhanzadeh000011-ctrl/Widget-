package com.example.mediawidget

import android.app.Activity
import android.appwidget.AppWidgetManager
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.Shader
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import kotlin.math.min

/**
 * صفحه‌ی تنظیمات ویجت‌های وینیل (مثل MD Vinyl): پیش‌نمایش زنده، نمایش اطلاعات، تم، دکمه‌ها،
 * انتخاب پلیر و دکمه‌ی Save. هر ویجت تنظیمات خودش رو داره.
 */
class VWidgetConfigActivity : Activity() {

    private var widgetId = AppWidgetManager.INVALID_APPWIDGET_ID
    private lateinit var kind: Kind
    private var showInfo = true
    private var showControl = true
    private var theme = VSettings.COVER
    private var players: Set<String> = emptySet()

    private lateinit var previewBox: FrameLayout
    private lateinit var playersSummary: TextView
    private val dots = ArrayList<Dot>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setResult(RESULT_CANCELED)
        widgetId = intent?.extras?.getInt(AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID)
            ?: AppWidgetManager.INVALID_APPWIDGET_ID
        if (widgetId == AppWidgetManager.INVALID_APPWIDGET_ID) {
            finish()
            return
        }
        val cn = AppWidgetManager.getInstance(this).getAppWidgetInfo(widgetId)?.provider?.className
        val k = Kind.values().firstOrNull { it.vinyl && it.provider.name == cn }
        if (k == null) {
            finish()
            return
        }
        kind = k
        val cur = VSettings.load(this, widgetId)
        showInfo = cur.info
        showControl = cur.control
        theme = cur.theme
        players = cur.players
        DarkUi.guard(this) { build() }
    }

    private fun current() = VSettings.Data(showInfo, showControl, theme, players)

    private fun dp(v: Float) = DarkUi.dp(this, v)

    // ------------------------------------------------------------------ ساخت صفحه

    @Suppress("DEPRECATION")
    private fun build() {
        DarkUi.setupWindow(this)
        val root = FrameLayout(this)
        root.setBackgroundColor(DarkUi.BG)

        val body = LinearLayout(this)
        body.orientation = LinearLayout.VERTICAL

        // دکمه‌ی بستن
        val close = CloseView(this)
        close.isClickable = true
        close.setOnClickListener { finish() }
        val clp = LinearLayout.LayoutParams(dp(48f), dp(48f))
        clp.setMargins(dp(20f), dp(14f), 0, 0)
        body.addView(close, clp)

        // پیش‌نمایش زنده
        previewBox = FrameLayout(this)
        val plp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        plp.setMargins(dp(20f), dp(26f), dp(20f), dp(26f))
        body.addView(previewBox, plp)
        refreshPreview()

        // کارت تنظیمات
        val card = DarkUi.card(this)
        if (VSettings.hasInfo(kind)) {
            val sw = DarkUi.styledSwitch(this, showInfo)
            sw.setOnCheckedChangeListener { _, v -> showInfo = v; refreshPreview() }
            DarkUi.addRow(card, "Show music info", null, sw, null)
        }
        DarkUi.addRow(card, "Theme", null, themeDots(), null)
        if (VSettings.hasControl(kind)) {
            val sw = DarkUi.styledSwitch(this, showControl)
            sw.setOnCheckedChangeListener { _, v -> showControl = v; refreshPreview() }
            DarkUi.addRow(card, "Show control", null, sw, null)
        }
        body.addView(card)

        // انتخاب پلیر
        val pick = LinearLayout(this)
        pick.orientation = LinearLayout.HORIZONTAL
        pick.gravity = Gravity.CENTER_VERTICAL
        pick.setPadding(dp(30f), dp(34f), dp(30f), dp(10f))
        pick.addView(DarkUi.glyph(this, GlyphView.PLUS, 42f))
        val pt = TextView(this)
        pt.text = "Select music player"
        pt.setTextColor(Color.rgb(160, 110, 255))
        pt.textSize = 24f
        pt.typeface = DarkUi.font(this)
        pt.setPadding(dp(14f), 0, 0, 0)
        pick.addView(pt)
        pick.isClickable = true
        pick.setOnClickListener { choosePlayers() }
        body.addView(pick)

        playersSummary = TextView(this)
        playersSummary.setTextColor(Color.WHITE)
        playersSummary.textSize = 17f
        playersSummary.typeface = DarkUi.font(this)
        playersSummary.setPadding(dp(32f), dp(4f), dp(32f), dp(6f))
        body.addView(playersSummary)
        updateSummary()

        val d1 = TextView(this)
        d1.text = "Display the latest music from the players you choose."
        val d2 = TextView(this)
        d2.text = "If no specific players are selected, your most recent listening music from all players will be shown in this widget."
        for ((i, t) in listOf(d1, d2).withIndex()) {
            t.setTextColor(DarkUi.LABEL)
            t.textSize = 19f
            t.typeface = DarkUi.font(this)
            t.setLineSpacing(0f, 1.2f)
            t.setPadding(dp(32f), dp(if (i == 0) 8f else 22f), dp(32f), 0)
            body.addView(t)
        }
        // جا برای دکمه‌ی Save
        body.addView(View(this), LinearLayout.LayoutParams(1, dp(130f)))

        val scroll = ScrollView(this)
        scroll.isFillViewport = true
        scroll.addView(body)
        root.addView(scroll, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))

        // دکمه‌ی Save
        val saveBtn = TextView(this)
        saveBtn.text = "Save Widget Settings"
        saveBtn.setTextColor(Color.WHITE)
        saveBtn.textSize = 22f
        saveBtn.typeface = DarkUi.font(this)
        saveBtn.paint.isFakeBoldText = true
        saveBtn.gravity = Gravity.CENTER
        val sg = GradientDrawable()
        sg.setColor(Color.rgb(125, 68, 226))
        sg.cornerRadius = dp(40f).toFloat()
        saveBtn.background = sg
        saveBtn.setOnClickListener { save() }
        val slp = FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, dp(66f), Gravity.BOTTOM)
        slp.setMargins(dp(28f), 0, dp(28f), dp(24f))
        root.addView(saveBtn, slp)

        root.setOnApplyWindowInsetsListener { _, ins ->
            body.setPadding(0, ins.systemWindowInsetTop, 0, 0)
            slp.bottomMargin = dp(24f) + ins.systemWindowInsetBottom
            saveBtn.layoutParams = slp
            ins
        }
        setContentView(root)
        root.requestApplyInsets()
    }

    // ------------------------------------------------------------------ پیش‌نمایش

    private fun refreshPreview() {
        val metrics = resources.displayMetrics
        val availDp = metrics.widthPixels / metrics.density - 40f
        val k = min(1.15f, availDp / kind.defW)
        val wDp = kind.defW * k
        val hDp = kind.defH * k

        // پشت پیش‌نمایش بلر، یه پس‌زمینه‌ی رنگی میذاریم تا شفافیت دیده بشه (بلر واقعی فقط روی صفحه‌ی اصلی گوشی دیده میشه)
        if (theme == VSettings.BLUR) {
            val g = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(Color.rgb(112, 78, 190), Color.rgb(46, 150, 170)))
            g.cornerRadius = dp(28f).toFloat()
            previewBox.background = g
        } else {
            previewBox.background = null
        }
        previewBox.setPadding(0, dp(if (theme == VSettings.BLUR) 14f else 0f), 0, dp(if (theme == VSettings.BLUR) 14f else 0f))

        WidgetRenderer.preview(this, kind, current()) { rv ->
            if (isDestroyed) return@preview
            try {
                val inner = object : FrameLayout(this) {
                    override fun onInterceptTouchEvent(ev: MotionEvent?): Boolean = true
                }
                inner.clipChildren = false
                val v = rv.apply(this, inner)
                inner.addView(v, FrameLayout.LayoutParams(dp(kind.defW.toFloat()), dp(kind.defH.toFloat())))
                v.pivotX = 0f
                v.pivotY = 0f
                v.scaleX = k
                v.scaleY = k
                previewBox.removeAllViews()
                previewBox.addView(inner, FrameLayout.LayoutParams(dp(wDp), dp(hDp), Gravity.CENTER_HORIZONTAL))
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    // ------------------------------------------------------------------ تم

    private fun themeDots(): View {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        val availDp = resources.displayMetrics.widthPixels / resources.displayMetrics.density - 40f - 44f - 90f
        val size = min(36f, availDp / 6f - 4f)
        for (t in intArrayOf(VSettings.WHITE, VSettings.YELLOW, VSettings.GRAY, VSettings.COVER, VSettings.BLACK, VSettings.BLUR)) {
            val dot = Dot(this, t)
            dot.sel = t == theme
            dot.setOnClickListener {
                theme = t
                for (d in dots) {
                    d.sel = d.theme == theme
                    d.invalidate()
                }
                refreshPreview()
            }
            dots.add(dot)
            val lp = LinearLayout.LayoutParams(dp(size), dp(size))
            lp.leftMargin = dp(4f)
            row.addView(dot, lp)
        }
        return row
    }

    // ------------------------------------------------------------------ پلیرها

    private fun updateSummary() {
        if (players.isEmpty()) {
            playersSummary.visibility = View.GONE
            return
        }
        val names = VSettings.players(this).filter { it.first in players }.map { it.second }
        playersSummary.text = if (names.isEmpty()) "${players.size} selected" else names.joinToString(", ")
        playersSummary.visibility = View.VISIBLE
    }

    private fun choosePlayers() {
        val list = VSettings.players(this)
        val chosen = HashSet(players)
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        if (list.isEmpty()) {
            val t = TextView(this)
            t.text = "No music players found yet. Play something in your music app first."
            t.setTextColor(DarkUi.LABEL)
            t.textSize = 16f
            t.typeface = DarkUi.font(this)
            box.addView(t)
        }
        for ((pkg, label) in list) {
            box.addView(MdDialog.toggleRow(this, label, pkg, pkg in chosen) { on ->
                if (on) chosen.add(pkg) else chosen.remove(pkg)
            })
        }
        MdDialog(this)
            .title("Select music player")
            .addView(box)
            .primary("OK") {
                players = chosen
                updateSummary()
                refreshPreview()
            }
            .secondary("Cancel")
            .show()
    }

    // ------------------------------------------------------------------ ذخیره

    private fun save() {
        VSettings.save(this, widgetId, current())
        setResult(RESULT_OK, Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId))
        WidgetRenderer.updateAll(this)
        finish()
    }

    // ------------------------------------------------------------------ ویوهای کوچیک

    /** دایره‌ی انتخاب تم */
    private class Dot(ctx: android.content.Context, val theme: Int) : View(ctx) {
        var sel = false
        private val p = Paint(Paint.ANTI_ALIAS_FLAG)

        override fun onDraw(c: Canvas) {
            val w = width.toFloat()
            val cx = w / 2f
            val cy = height / 2f
            val ring = w * 0.07f
            val r = w / 2f - ring * 2.2f
            if (sel) {
                p.shader = null
                p.style = Paint.Style.STROKE
                p.strokeWidth = ring * 1.6f
                p.color = Color.rgb(140, 92, 240)
                c.drawCircle(cx, cy, w / 2f - ring, p)
            }
            p.style = Paint.Style.FILL
            when (theme) {
                VSettings.COVER -> {
                    p.shader = RadialGradient(cx - r * 0.35f, cy - r * 0.35f, r * 1.5f,
                        intArrayOf(Color.rgb(210, 210, 214), Color.rgb(110, 110, 118), Color.rgb(48, 48, 54)),
                        floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP)
                    c.drawCircle(cx, cy, r, p)
                }
                VSettings.BLUR -> {
                    val clip = Path()
                    clip.addCircle(cx, cy, r, Path.Direction.CW)
                    c.save()
                    c.clipPath(clip)
                    p.shader = null
                    val n = 4
                    val cell = 2f * r / n
                    for (i in 0 until n) for (j in 0 until n) {
                        p.color = if ((i + j) % 2 == 0) Color.rgb(112, 112, 120) else Color.rgb(64, 64, 72)
                        c.drawRect(cx - r + i * cell, cy - r + j * cell, cx - r + (i + 1) * cell, cy - r + (j + 1) * cell, p)
                    }
                    c.restore()
                }
                else -> {
                    p.shader = null
                    p.color = when (theme) {
                        VSettings.WHITE -> Color.rgb(244, 242, 236)
                        VSettings.YELLOW -> Color.rgb(255, 160, 10)
                        VSettings.GRAY -> Color.rgb(48, 48, 52)
                        else -> Color.rgb(10, 10, 10)
                    }
                    c.drawCircle(cx, cy, r, p)
                }
            }
            p.shader = null
        }
    }

    /** دایره‌ی تیره با ضربدر (بستن) */
    private class CloseView(ctx: android.content.Context) : View(ctx) {
        private val p = Paint(Paint.ANTI_ALIAS_FLAG)

        override fun onDraw(c: Canvas) {
            val w = width.toFloat()
            p.style = Paint.Style.FILL
            p.color = Color.rgb(52, 53, 62)
            c.drawCircle(w / 2f, height / 2f, w / 2f, p)
            p.style = Paint.Style.STROKE
            p.color = Color.WHITE
            p.strokeWidth = w * 0.065f
            p.strokeCap = Paint.Cap.ROUND
            val a = w * 0.32f
            c.drawLine(a, a, w - a, w - a, p)
            c.drawLine(w - a, a, a, w - a, p)
        }
    }
}
