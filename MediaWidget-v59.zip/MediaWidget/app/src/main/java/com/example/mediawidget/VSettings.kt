package com.example.mediawidget

import android.content.Context
import android.content.Intent
import android.graphics.Color

/**
 * تنظیمات هر ویجت وینیل (جدا برای هر ویجت): نمایش اطلاعات آهنگ، دکمه‌ها، تم و پلیرهای انتخابی.
 * ترتیب تم‌ها مثل دایره‌های صفحه‌ی تنظیمات: سفید، زرد، خاکستری، کاور (پیش‌فرض)، مشکی، شفاف (بلر One UI)
 */
object VSettings {
    const val WHITE = 0
    const val YELLOW = 1
    const val GRAY = 2
    const val COVER = 3
    const val BLACK = 4
    const val BLUR = 5

    /** شفافیت رنگ روی بلر والپیپر (۱ تا ۲۵۴؛ بیشتر = تیره‌تر) */
    const val BLUR_ALPHA = 96

    class Data(val info: Boolean, val control: Boolean, val theme: Int, val players: Set<String>)

    fun defaults() = Data(true, true, COVER, emptySet())

    fun hasInfo(kind: Kind) = kind == Kind.VHALF || kind == Kind.VWIDE || kind == Kind.VBIG
    fun hasControl(kind: Kind) = kind == Kind.VCTRL || kind == Kind.VWIDE || kind == Kind.VBIG

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("vwidget", Context.MODE_PRIVATE)

    fun has(ctx: Context, id: Int): Boolean = prefs(ctx).contains("theme_$id")

    fun load(ctx: Context, id: Int): Data {
        val p = prefs(ctx)
        if (!p.contains("theme_$id")) return defaults()
        return Data(
            p.getBoolean("info_$id", true),
            p.getBoolean("control_$id", true),
            p.getInt("theme_$id", COVER).coerceIn(0, 5),
            p.getStringSet("players_$id", emptySet())?.toSet() ?: emptySet()
        )
    }

    fun save(ctx: Context, id: Int, d: Data) {
        prefs(ctx).edit()
            .putBoolean("info_$id", d.info)
            .putBoolean("control_$id", d.control)
            .putInt("theme_$id", d.theme)
            .putStringSet("players_$id", HashSet(d.players))
            .apply()
    }

    fun remove(ctx: Context, ids: IntArray) {
        val e = prefs(ctx).edit()
        for (id in ids) {
            e.remove("info_$id").remove("control_$id").remove("theme_$id").remove("players_$id")
        }
        e.apply()
    }

    fun preset(theme: Int): ScreenTheme.Preset = when (theme) {
        WHITE -> ScreenTheme.WHITE_P
        YELLOW -> ScreenTheme.YELLOW_P
        GRAY -> ScreenTheme.GRAY_P
        BLACK -> ScreenTheme.BLACK_P
        else -> ScreenTheme.DEFAULT_P
    }

    /** رنگ متن و دکمه‌ها: کاور = از خود کاور، بلر = سفید روی تینت تیره، بقیه از تم آماده */
    fun tint(theme: Int, cover: Tint): Tint = when (theme) {
        COVER -> cover
        BLUR -> Tint(Color.WHITE, Color.argb(215, 255, 255, 255))
        else -> preset(theme).let { Tint(it.title, it.artist) }
    }

    /** لیست پلیرهای شناخته‌شده: اپ‌های دارای MediaBrowserService، سشن‌های فعال و پلیرهایی که قبلاً دیده شدن */
    fun players(ctx: Context): List<Pair<String, String>> {
        val pm = ctx.packageManager
        val pkgs = LinkedHashSet<String>()
        try {
            for (ri in pm.queryIntentServices(Intent("android.media.browse.MediaBrowserService"), 0)) {
                ri.serviceInfo?.packageName?.let { pkgs.add(it) }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        try {
            MediaReader.controllers(ctx)?.forEach { pkgs.add(it.packageName) }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        pkgs.addAll(AppPrefs.seen(ctx))
        val last = AppPrefs.lastPlayer(ctx)
        if (last.isNotEmpty()) pkgs.add(last)
        val out = ArrayList<Pair<String, String>>()
        for (pkg in pkgs) {
            try {
                val label = pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
                out.add(Pair(pkg, label))
            } catch (e: Exception) {
                // برنامه‌ی حذف‌شده
            }
        }
        out.sortBy { it.second.lowercase() }
        return out
    }
}
