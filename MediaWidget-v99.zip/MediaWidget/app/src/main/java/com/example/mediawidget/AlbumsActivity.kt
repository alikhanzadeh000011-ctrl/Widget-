package com.example.mediawidget

import android.Manifest
import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.media.MediaMetadata
import android.graphics.Path
import android.graphics.RectF
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.util.concurrent.Executors

/** صفحه‌ی آلبوم‌ها (یا پوشه‌ها): چیدمان ۳بعدی یا گالری؛ دیسک بالا-چپ، تغییر حالت بالا-راست */
class AlbumsActivity : Activity(), AlbumStackView.Listener {

    private lateinit var stack: AlbumStackView
    private lateinit var toggle: ToggleView
    private lateinit var discBtn: DiscView
    private lateinit var queueBtn: QueueBtn
    private lateinit var queueView: QueueView
    private var queueOpen = false
    @Volatile private var lastBackdrop: Bitmap? = null
    private var playTint: Int = Color.WHITE
    private val queuePoll = object : Runnable {
        override fun run() {
            if (!queueOpen) return
            refreshQueue(false)
            handler.postDelayed(this, 1000L)
        }
    }
    private val playPoll = object : Runnable {
        override fun run() {
            if (!detailOpen) return
            refreshPlaying()
            handler.postDelayed(this, 1000L)
        }
    }
    private lateinit var permPanel: LinearLayout
    private lateinit var emptyText: TextView
    private var loaded = false
    private lateinit var detail: AlbumDetailView
    private var detailOpen = false
    private var animating = false
    private var openAlbum: Album? = null
    private var theme: AlbumTheme? = null
    private val handler = Handler(Looper.getMainLooper())
    private val bgExec = Executors.newSingleThreadExecutor()
    @Volatile private var bgKey = "?"
    private var insTop = 0
    private var insBottom = 0
    private var insLeft = 0
    private val bgPoll = object : Runnable {
        override fun run() {
            pollBackdrop()
            handler.postDelayed(this, 3000L)
        }
    }

    private fun perm(): String =
        if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE

    private fun hasPerm(): Boolean = checkSelfPermission(perm()) == PackageManager.PERMISSION_GRANTED

    private fun dp(v: Float) = DarkUi.dp(this, v)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        DarkUi.guard(this) { build() }
    }

    @Suppress("DEPRECATION")
    private fun enterImmersive() {
        if (Build.VERSION.SDK_INT >= 30) {
            window.setDecorFitsSystemWindows(false)
            window.insetsController?.let {
                it.systemBarsBehavior = WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                it.hide(WindowInsets.Type.systemBars())
            }
        } else {
            window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_FULLSCREEN or
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) enterImmersive()
    }

    @Suppress("DEPRECATION")
    private fun build() {
        DarkUi.setupWindow(this)
        if (Build.VERSION.SDK_INT >= 28) {
            val lp = window.attributes
            lp.layoutInDisplayCutoutMode = android.view.WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            window.attributes = lp
        }
        enterImmersive()

        val root = FrameLayout(this)
        root.setBackgroundColor(DarkUi.BG)

        stack = AlbumStackView(this)
        stack.listener = this
        stack.onScrollDir = { hide -> setBarsHidden(hide) }
        root.addView(stack, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        // دکمه‌ی تغییر حالت (بالا-راست)
        toggle = ToggleView(this)
        toggle.setOnClickListener {
            stack.toggleMode()
            setBarsHidden(false)
            toggle.grid = stack.isGrid()
            toggle.invalidate()
        }
        toggle.glassSrc = stack
        root.addView(toggle, FrameLayout.LayoutParams(dp(52f), dp(52f), Gravity.TOP or Gravity.END))

        // دکمه‌ی دیسک (بالا-چپ): برگشت به صفحه‌ی وینیل
        discBtn = DiscView(this)
        discBtn.setOnClickListener { finish() }
        discBtn.glassSrc = stack
        root.addView(discBtn, FrameLayout.LayoutParams(dp(52f), dp(52f), Gravity.TOP or Gravity.START))

        // دکمه‌ی صف پخش (وسط بالا)
        queueBtn = QueueBtn(this)
        queueBtn.setOnClickListener { openQueue() }
        queueBtn.glassSrc = stack
        root.addView(queueBtn, FrameLayout.LayoutParams(dp(52f), dp(52f), Gravity.TOP or Gravity.CENTER_HORIZONTAL))

        emptyText = TextView(this)
        emptyText.text = "Nothing to show here"
        emptyText.setTextColor(DarkUi.LABEL)
        emptyText.textSize = 18f
        emptyText.typeface = DarkUi.font(this)
        emptyText.gravity = Gravity.CENTER
        emptyText.visibility = View.GONE
        root.addView(emptyText, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        permPanel = LinearLayout(this)
        permPanel.orientation = LinearLayout.VERTICAL
        permPanel.gravity = Gravity.CENTER
        permPanel.setPadding(dp(32f), 0, dp(32f), 0)
        val msg = TextView(this)
        msg.text = "Allow access to your music files to show your albums."
        msg.setTextColor(Color.WHITE)
        msg.textSize = 18f
        msg.typeface = DarkUi.font(this)
        msg.gravity = Gravity.CENTER
        msg.setLineSpacing(0f, 1.2f)
        permPanel.addView(msg)
        val btn = DarkUi.pill(this, "Allow access") { requestPermissions(arrayOf(perm()), 7) }
        val blp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        blp.topMargin = dp(22f)
        permPanel.addView(btn, blp)
        permPanel.visibility = View.GONE
        root.addView(permPanel, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        // صفحه‌ی صف پخش (بالای دکمه‌ها)
        queueView = QueueView(this)
        queueView.visibility = View.GONE
        queueView.host = object : QueueView.Host {
            override fun onClose() = closeQueue()
            override fun onJump(entry: QueueEntry, index: Int) = jumpQueue(entry, index)
        }
        root.addView(queueView, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        // صفحه‌ی آلبوم (بالای همه؛ فقط وقتی یه آلبوم باز شده)
        detail = AlbumDetailView(this)
        detail.visibility = View.GONE
        detail.host = object : AlbumDetailView.Host {
            override fun onBack() = closeDetail()
            override fun onTrack(list: List<Track>, index: Int) {
                askNotifPermission()
                TrackPlayer.play(this@AlbumsActivity, list, index, openAlbum, LibraryPrefs.mode(this@AlbumsActivity) == LibraryPrefs.FOLDERS)
            }
            override fun onPlayAll(list: List<Track>, shuffle: Boolean) {
                askNotifPermission()
                TrackPlayer.playAll(this@AlbumsActivity, list, shuffle, openAlbum, LibraryPrefs.mode(this@AlbumsActivity) == LibraryPrefs.FOLDERS)
            }
        }
        root.addView(detail, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        root.setOnApplyWindowInsetsListener { _, ins ->
            var top = ins.systemWindowInsetTop
            var left = ins.systemWindowInsetLeft
            var right = ins.systemWindowInsetRight
            val bottom = ins.systemWindowInsetBottom
            if (Build.VERSION.SDK_INT >= 28) {
                val cut = ins.displayCutout
                if (cut != null) {
                    top = maxOf(top, cut.safeInsetTop)
                    left = maxOf(left, cut.safeInsetLeft)
                    right = maxOf(right, cut.safeInsetRight)
                }
            }
            stack.setInsets(top, bottom)
            insTop = top
            insBottom = bottom
            insLeft = left
            detail.setInsets(top, bottom, left)
            queueView.setInsets(top, bottom, left)
            val landscape = resources.configuration.orientation == android.content.res.Configuration.ORIENTATION_LANDSCAPE
            val ql = queueBtn.layoutParams as FrameLayout.LayoutParams
            val tl = toggle.layoutParams as FrameLayout.LayoutParams
            val dl = discBtn.layoutParams as FrameLayout.LayoutParams
            if (landscape) {
                // لندسکیپ: سه دکمه‌ی زیر هم سمت چپ، با همون ترتیب حالت عمودی: دیسک، صف، آلبوم‌ها
                // (تو FrameLayout با CENTER_VERTICAL جابه‌جایی = topMargin - bottomMargin)؛ فاصله‌ی مرکز تا مرکز ۹۶dp (مثل حالت عمودی)
                val stepY = dp(96f)
                for ((lp, k) in listOf(Pair(dl, -1), Pair(ql, 0), Pair(tl, 1))) {
                    lp.gravity = Gravity.START or Gravity.CENTER_VERTICAL
                    lp.leftMargin = left + dp(22f)
                    lp.rightMargin = 0
                    lp.topMargin = k * stepY
                    lp.bottomMargin = 0
                }
            } else {
                // عمودی: همه‌ی حاشیه‌ها از نو (وگرنه حاشیه‌ی حالت افقی می‌مونه و دکمه‌ی صف به چپ میره)
                ql.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
                ql.topMargin = top + dp(14f)
                ql.leftMargin = 0
                ql.rightMargin = 0
                ql.bottomMargin = 0
                // دو دکمه‌ی کناری نزدیک دکمه‌ی وسط: فاصله‌ی مرکز تا مرکز ۹۶dp، قرینه
                // (تو FrameLayout با CENTER_HORIZONTAL جابه‌جایی = leftMargin - rightMargin)
                tl.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
                tl.topMargin = top + dp(14f)
                tl.leftMargin = dp(96f)
                tl.rightMargin = 0
                tl.bottomMargin = 0
                dl.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
                dl.topMargin = top + dp(14f)
                dl.leftMargin = 0
                dl.rightMargin = dp(96f)
                dl.bottomMargin = 0
            }
            queueBtn.layoutParams = ql
            toggle.layoutParams = tl
            discBtn.layoutParams = dl
            ins
        }

        setContentView(root)
        root.requestApplyInsets()
        refreshState()
    }

    override fun onResume() {
        super.onResume()
        if (::stack.isInitialized) {
            refreshState()
            handler.removeCallbacks(bgPoll)
            handler.postDelayed(bgPoll, 300L)
        }
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(bgPoll)
        handler.removeCallbacks(playPoll)
        handler.removeCallbacks(queuePoll)
    }

    /** پس‌زمینه‌ی پشته: همون بلرِ کاورِ آهنگ در حال پخش که تو صفحه‌ی وینیل هست */
    private fun pollBackdrop() {
        if (!::stack.isInitialized) return
        val w = stack.width
        val h = stack.height
        if (w <= 0 || h <= 0) return
        val app = applicationContext
        bgExec.execute {
            val info = try { MediaReader.read(app) } catch (e: Throwable) { null }
            val art = info?.art
            val key = if (art != null && info != null) info.key else ""
            if (key == bgKey) return@execute
            val bmp = if (art != null) {
                try { VinylArt.coverBackground(art, w, h) } catch (e: Throwable) { null }
            } else null
            val tintC = if (art != null) Palette.tintFor(art).primary else Color.WHITE
            runOnUiThread {
                if (!isDestroyed) {
                    bgKey = key
                    lastBackdrop = bmp
                    playTint = lightTint(tintC)
                    stack.setBackdrop(bmp)
                    if (queueOpen) {
                        queueView.setBackdrop(bmp)
                        queueView.setTint(playTint)
                    }
                }
            }
        }
    }

    private fun refreshState() {
        if (hasPerm()) {
            permPanel.visibility = View.GONE
            if (!loaded) loadAlbums()
        } else {
            permPanel.visibility = View.VISIBLE
            stack.visibility = View.INVISIBLE
        }
    }

    private fun loadAlbums() {
        loaded = true
        val app = applicationContext
        val mode = LibraryPrefs.mode(app)
        Executors.newSingleThreadExecutor().execute {
            val list = AlbumRepo.loadVisible(app, mode)
            runOnUiThread {
                if (isDestroyed) return@runOnUiThread
                stack.visibility = View.VISIBLE
                stack.setAlbums(list)
                emptyText.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
            }
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        refreshState()
    }

    override fun onAlbumTap(album: Album, index: Int) {
        if (animating || detailOpen) return
        val w = stack.width
        if (w <= 0) return
        animating = true
        val mode = LibraryPrefs.mode(this)
        val cover = stack.bitmapFor(index)
        val th = AlbumTheme.from(if (stack.hasCover(index)) cover else null, album.color)
        theme = th
        openAlbum = album
        detail.bind(album, th, w, stack.height, cover, mode == LibraryPrefs.FOLDERS)
        detail.visibility = View.VISIBLE
        stack.setFinalRect(detail.coverRect(w, stack.height))
        stack.setFocusBitmap(null)
        stack.engine3d = getSharedPreferences("ui", MODE_PRIVATE).getBoolean("engine3d", false)
        stack.beginFocus(index)
        toggle.animate().alpha(0f).setDuration(200L).start()
        discBtn.animate().alpha(0f).setDuration(200L).start()
        queueBtn.animate().alpha(0f).setDuration(200L).start()

        // کاور بزرگ و ترک‌ها تو پس‌زمینه
        val app = applicationContext
        Executors.newSingleThreadExecutor().execute {
            val big = AlbumRepo.loadItemCover(app, album, 1000)
            val list = AlbumRepo.loadTracks(app, album, mode)
            runOnUiThread {
                if (isDestroyed || openAlbum !== album) return@runOnUiThread
                if (big != null) {
                    stack.setFocusBitmap(big)
                    detail.setCoverBitmap(big)
                }
                detail.setTracks(list)
            }
        }

        val anim = ValueAnimator.ofFloat(0f, 1f)
        anim.duration = 650L
        anim.addUpdateListener {
            val e = it.animatedValue as Float
            stack.setFocusProgress(e)
            stack.setGradient(th.top, th.bottom, (e * 1.4f).coerceIn(0f, 1f))
        }
        anim.addListener(object : AnimatorListenerAdapter() {
            override fun onAnimationEnd(animation: Animator) {
                animating = false
                detailOpen = true
                detail.reveal()
                // کاور واقعی نشون داده شد؛ پشته دیگه کاور پروازی رو نکشه
                handler.postDelayed({ if (detailOpen) stack.setFocusHold(true) }, 90L)
                handler.post(playPoll)
            }
        })
        anim.start()
    }

    /** برگشت از صفحه‌ی آلبوم: انیمیشن باز شدن برعکس */
    private fun closeDetail() {
        if (animating || !detailOpen) return
        val th = theme ?: return
        animating = true
        handler.removeCallbacks(playPoll)
        detail.scrollToTop {
          stack.setFocusHold(false)
          detail.hideContent {
            val anim = ValueAnimator.ofFloat(1f, 0f)
            anim.duration = 520L
            anim.addUpdateListener {
                val e = it.animatedValue as Float
                stack.setFocusProgress(e)
                stack.setGradient(th.top, th.bottom, (e * 1.4f).coerceIn(0f, 1f))
            }
            anim.addListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: Animator) {
                    stack.endFocus()
                    detail.visibility = View.GONE
                    detailOpen = false
                    animating = false
                    openAlbum = null
                    setBarsHidden(false)
                    toggle.animate().alpha(1f).setDuration(200L).start()
                    discBtn.animate().alpha(1f).setDuration(200L).start()
                    queueBtn.animate().alpha(1f).setDuration(200L).start()
                }
            })
            anim.start()
          }
        }
    }

    override fun onConfigurationChanged(newConfig: android.content.res.Configuration) {
        super.onConfigurationChanged(newConfig)
        // چرخش صفحه: دکمه‌ها و چیدمان‌ها از نو
        window.decorView.requestApplyInsets()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (animating) return
        if (queueOpen) {
            closeQueue()
            return
        }
        if (detailOpen) {
            closeDetail()
            return
        }
        @Suppress("DEPRECATION")
        super.onBackPressed()
    }

    private fun norm(x: String?): String = (x ?: "").trim().lowercase()

    /** تینت روشن برای پس‌زمینه‌های تیره */
    private fun lightTint(c: Int): Int {
        val hsv = FloatArray(3)
        Color.colorToHSV(c, hsv)
        if (hsv[1] < 0.03f) return Color.WHITE
        hsv[2] = maxOf(hsv[2], 0.92f)
        return Color.HSVToColor(hsv)
    }

    /** ترک در حال پخش تو لیست آلبوم: از پلیر داخلی یا از سشن پلیر دیگه */
    private fun refreshPlaying() {
        if (!detailOpen) return
        val list = detail.trackList()
        if (list.isEmpty()) return
        var idx = -1
        if (PlayerQueue.active && PlayerQueue.currentId >= 0) {
            idx = list.indexOfFirst { it.id == PlayerQueue.currentId }
        }
        if (idx < 0) {
            val c = MediaReader.controllers(this)?.let { MediaReader.pick(it) }
            val md = c?.metadata
            val title = norm(md?.getString(MediaMetadata.METADATA_KEY_TITLE))
            val alb = norm(md?.getString(MediaMetadata.METADATA_KEY_ALBUM))
            if (title.isNotEmpty()) {
                idx = list.indexOfFirst {
                    norm(it.title) == title && (alb.isEmpty() || norm(it.album).isEmpty() || norm(it.album) == alb)
                }
            }
        }
        detail.markPlaying(idx)
    }

    // ---------------------------------------------------------------- صف پخش

    private fun buildQueue(): Pair<List<QueueEntry>, Int> {
        if (PlayerQueue.active && PlayerQueue.tracks.isNotEmpty()) {
            val list = PlayerQueue.tracks.mapIndexed { i, t ->
                QueueEntry("t:" + t.id, t.title, t.artist, t, i.toLong(), null, null)
            }
            return Pair(list, PlayerQueue.index)
        }
        val c = MediaReader.controllers(this)?.let { MediaReader.pick(it) }
        val q = c?.queue
        if (c != null && q != null && q.isNotEmpty()) {
            val activeId = c.playbackState?.activeQueueItemId ?: -1L
            val list = q.map { item ->
                val dsc = item.description
                QueueEntry(
                    "q:" + c.packageName + ":" + item.queueId,
                    dsc.title?.toString() ?: "", dsc.subtitle?.toString() ?: "",
                    null, item.queueId, dsc.iconBitmap, dsc.iconUri
                )
            }
            var cur = q.indexOfFirst { it.queueId == activeId }
            if (cur < 0) {
                val t = norm(c.metadata?.getString(MediaMetadata.METADATA_KEY_TITLE))
                cur = list.indexOfFirst { norm(it.title) == t }
            }
            return Pair(list, cur)
        }
        return Pair(emptyList(), -1)
    }

    private fun refreshQueue(initial: Boolean) {
        val (list, cur) = buildQueue()
        queueView.setData(list, cur, initial)
    }

    private fun openQueue() {
        if (animating || detailOpen || queueOpen) return
        queueOpen = true
        queueView.setBackdrop(lastBackdrop)
        queueView.setTint(playTint)
        refreshQueue(true)
        queueView.visibility = View.VISIBLE
        queueView.alpha = 0f
        queueView.translationY = dp(24f).toFloat()
        queueView.animate().alpha(1f).translationY(0f).setDuration(240L).start()
        toggle.animate().alpha(0f).setDuration(160L).start()
        discBtn.animate().alpha(0f).setDuration(160L).start()
        queueBtn.animate().alpha(0f).setDuration(160L).start()
        handler.removeCallbacks(queuePoll)
        handler.postDelayed(queuePoll, 1000L)
    }

    private var barsHidden = false

    /** سه دکمه‌ی بالا (دیسک، صف، آلبوم‌ها) موقع اسکرول به پایین از صفحه بیرون میرن و با اسکرول به بالا برمی‌گردن */
    private fun setBarsHidden(h: Boolean) {
        if (barsHidden == h) return
        barsHidden = h
        val landscape = resources.configuration.orientation == android.content.res.Configuration.ORIENTATION_LANDSCAPE
        for (v in listOf(toggle, discBtn, queueBtn)) {
            val lp = v.layoutParams as FrameLayout.LayoutParams
            val a = v.animate().setDuration(220L)
            if (landscape) {
                a.translationX(if (h) -(v.width + lp.leftMargin + dp(24f)).toFloat() else 0f)
            } else {
                a.translationY(if (h) -(v.height + lp.topMargin + dp(24f)).toFloat() else 0f)
            }
            a.start()
        }
    }

    private fun closeQueue() {
        if (!queueOpen) return
        queueOpen = false
        handler.removeCallbacks(queuePoll)
        queueView.animate().alpha(0f).translationY(dp(24f).toFloat()).setDuration(200L).withEndAction {
            queueView.visibility = View.GONE
        }.start()
        setBarsHidden(false)
        toggle.animate().alpha(1f).setDuration(220L).start()
        discBtn.animate().alpha(1f).setDuration(220L).start()
        queueBtn.animate().alpha(1f).setDuration(220L).start()
    }

    private fun jumpQueue(entry: QueueEntry, index: Int) {
        if (entry.track != null && PlayerQueue.active) {
            PlayerService.jump(this, index)
        } else {
            val c = MediaReader.controllers(this)?.let { MediaReader.pick(it) }
            try {
                c?.transportControls?.skipToQueueItem(entry.queueId)
            } catch (e: Exception) {
                MdToast.show(this, "This player can't jump in its queue")
            }
        }
        handler.postDelayed({ if (queueOpen) refreshQueue(false) }, 500L)
    }

    /** اندروید ۱۳ به بالا: برای اعلان پخش یه بار مجوز اعلان‌ها رو می‌پرسیم (پخش بدون اون هم کار می‌کنه) */
    private fun askNotifPermission() {
        if (Build.VERSION.SDK_INT < 33) return
        if (LibraryPrefs.askedNotifPermission(this)) return
        if (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) return
        LibraryPrefs.setAskedNotifPermission(this)
        requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 77)
    }

    /** نگه داشتن انگشت روی یک کارت: پیشنهاد مخفی کردن */
    override fun onAlbumLongPress(album: Album, index: Int) {
        val mode = LibraryPrefs.mode(this)
        MdDialog.confirm(
            this, album.title,
            "Hide this " + (if (mode == LibraryPrefs.FOLDERS) "folder" else "album") + "? You can show it again from Settings > Hidden items.",
            "Hide"
        ) {
            LibraryPrefs.setHidden(this, mode, album.key, true)
            loaded = false
            loadAlbums()
        }
    }

    /** دکمه‌ی گرد بالا-راست: آیکن شبکه (حالت ۳بعدی) یا آیکن پشته (حالت گالری) */
    /** دکمه‌ی گرد تیره با آیکن سفید (آیکن‌ها از فایل‌های خودت) */
    private abstract class IconBase(ctx: Activity, res: Int, private val byMass: Boolean = false) : View(ctx) {
        /** پشت‌زمینه‌ی بلر: همون صفحه‌ی گرید/پشته؛ دایره‌ی دکمه محتوای زیرش رو محو میکنه (اندروید ۱۲ به بالا) */
        var glassSrc: AlbumStackView? = null
        private var glassNode: Any? = null
        private val gPath = android.graphics.Path()
        private val gRing = Paint(Paint.ANTI_ALIAS_FLAG)
        private val p = Paint(Paint.ANTI_ALIAS_FLAG)
        private val ip = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
        private val dst = RectF()
        private val icon: Bitmap? = BitmapFactory.decodeResource(ctx.resources, res)
        // جابه‌جایی آیکن (نسبت به اندازه‌ی خودش) تا مرکز «جرم» لوگو دقیقاً وسط دایره بیفته
        private var offX = 0f
        private var offY = 0f

        init {
            val ic = icon
            if (byMass && ic != null) {
                val n = 64
                val sm = Bitmap.createScaledBitmap(ic, n, n, true)
                var sx = 0.0
                var sy = 0.0
                var sa = 0.0
                for (yy in 0 until n) for (xx in 0 until n) {
                    val a = Color.alpha(sm.getPixel(xx, yy)) / 255.0
                    sx += xx * a
                    sy += yy * a
                    sa += a
                }
                if (sa > 0) {
                    offX = (0.5 - (sx / sa + 0.5) / n).toFloat()
                    offY = (0.5 - (sy / sa + 0.5) / n).toFloat()
                }
            }
        }

        /** دایره‌ی شیشه‌ای: بلر زنده‌ی صفحه‌ی پشت دکمه + رنگ تقریباً شفاف #01FFFFFF + لبه‌ی نازک */
        private fun drawGlass(c: Canvas, cx: Float, cy: Float, r: Float): Boolean {
            if (android.os.Build.VERSION.SDK_INT < 31 || !c.isHardwareAccelerated || !ThemeStore.buttonBlur(context)) return false
            val src = glassSrc?.sceneNode ?: return false
            return glassDraw(c, cx, cy, r, src)
        }

        @android.annotation.TargetApi(31)
        private fun glassDraw(c: Canvas, cx: Float, cy: Float, r: Float, src: Any): Boolean {
            val srcNode = src as android.graphics.RenderNode
            val d = resources.displayMetrics.density
            val m = 28f * d
            val size = (2f * r + 2f * m).toInt()
            var node = glassNode as android.graphics.RenderNode?
            if (node == null) {
                node = android.graphics.RenderNode("btnGlass")
                node.setRenderEffect(android.graphics.RenderEffect.createBlurEffect(14f * d, 14f * d, android.graphics.Shader.TileMode.CLAMP))
                glassNode = node
            }
            node.setPosition(0, 0, size, size)
            val rc = node.beginRecording()
            // مختصات صفحه‌ی پشت = مختصات این دکمه + (left, top)؛ مرکز دایره میره وسط نود
            rc.translate(m - (left + cx - r), m - (top + cy - r))
            rc.drawRenderNode(srcNode)
            node.endRecording()
            c.save()
            gPath.reset()
            gPath.addCircle(cx, cy, r, android.graphics.Path.Direction.CW)
            c.clipPath(gPath)
            c.translate(cx - r - m, cy - r - m)
            c.drawRenderNode(node)
            c.restore()
            p.color = Color.argb(1, 255, 255, 255)
            c.drawCircle(cx, cy, r, p)
            gRing.style = Paint.Style.STROKE
            gRing.strokeWidth = 1.2f * d
            gRing.color = Color.argb(46, 255, 255, 255)
            c.drawCircle(cx, cy, r - 0.6f * d, gRing)
            return true
        }

        override fun onDraw(c: Canvas) {
            val w = width.toFloat()
            val cx = w / 2f
            val cy = height / 2f
            p.style = Paint.Style.FILL
            if (!drawGlass(c, cx, cy, w / 2f)) {
                p.color = Color.argb(110, 0, 0, 0)
                c.drawCircle(cx, cy, w / 2f, p)
            }
            val ic = icon ?: return
            val half = w * 0.25f
            val sz = half * 2f
            dst.set(cx - half + offX * sz, cy - half + offY * sz, cx + half + offX * sz, cy + half + offY * sz)
            c.drawBitmap(ic, null, dst, ip)
        }
    }

    /** گرید و پشته */
    private class ToggleView(ctx: Activity) : IconBase(ctx, R.drawable.ic_btn_albums) {
        var grid = false
    }

    /** برگشت به صفحه‌ی وینیل */
    private class DiscView(ctx: Activity) : IconBase(ctx, R.drawable.ic_btn_disc)

    /** صف پخش */
    private class QueueBtn(ctx: Activity) : IconBase(ctx, R.drawable.ic_btn_queue, true)
}
