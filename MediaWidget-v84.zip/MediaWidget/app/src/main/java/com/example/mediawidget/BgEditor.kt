package com.example.mediawidget

import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.TextView
import java.io.File

/**
 * ویرایشگر پس‌زمینه (مثل MD): پنل پایین با تب‌های Color و Effect، ✕ برای برگشت و ✓ برای تأیید.
 * Color = رنگ پس‌زمینه، Effect = گرادیانت دو رنگ. تغییرها همون لحظه پشت پنل دیده میشن
 * و با ✓ تو ردیف Theme ذخیره میشن. فقط صفحه‌ی وینیل رو عوض می‌کنه، ویجت‌ها نه.
 */
class BgEditor(
    private val act: VinylActivity,
    private val vinyl: VinylView,
    private val editFile: File?,       // پس‌زمینه‌ای که ویرایش میشه؛ null یعنی جدید
    start: BgStyle
) : FrameLayout(act) {

    var onClosed: (() -> Unit)? = null

    private val d = resources.displayMetrics.density
    private val tf: Typeface = try {
        resources.getFont(R.font.sf_pro_soft)
    } catch (e: Exception) {
        Typeface.DEFAULT
    }
    private val compact = resources.displayMetrics.heightPixels < (520f * d)

    private val st = start.copy()
    private var touched = false
    private var tab = 0
    private var closing = false

    private val panel = LinearLayout(act)
    private val content = LinearLayout(act)
    private val tabs = ArrayList<TextView>()

    private val palette = intArrayOf(
        Color.rgb(16, 16, 18), Color.rgb(72, 72, 78), Color.rgb(150, 150, 158), Color.WHITE,
        Color.rgb(226, 58, 66), Color.rgb(244, 108, 150), Color.rgb(255, 128, 40), Color.rgb(255, 196, 32),
        Color.rgb(120, 198, 70), Color.rgb(28, 170, 130), Color.rgb(32, 150, 226), Color.rgb(60, 80, 220),
        Color.rgb(122, 76, 226), Color.rgb(176, 72, 214)
    )

    private fun dp(v: Float) = (v * d).toInt()

    private val applyRun = Runnable {
        ThemeStore.previewBg = st.copy()
        vinyl.reloadTheme(true)
    }

    private fun changed() {
        touched = true
        removeCallbacks(applyRun)
        postDelayed(applyRun, 70)
    }

    init {
        panel.orientation = LinearLayout.VERTICAL
        val r = 28f * d
        val bg = GradientDrawable()
        bg.setColor(Color.rgb(28, 27, 32))
        bg.cornerRadii = floatArrayOf(r, r, r, r, 0f, 0f, 0f, 0f)
        panel.background = bg
        panel.isClickable = true
        panel.setPadding(0, 0, 0, if (compact) dp(10f) else dp(26f))

        // بالا: ✕  Color  Effect  ✓
        val head = LinearLayout(act)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        val close = EditorGlyph(act, false)
        close.setOnClickListener { cancel() }
        head.addView(close, LinearLayout.LayoutParams(dp(56f), dp(52f)))
        head.addView(View(act), LinearLayout.LayoutParams(0, 1, 1f))
        for ((i, name) in listOf("Color", "Effect").withIndex()) {
            val t = TextView(act)
            t.text = name
            t.textSize = 17f
            t.typeface = tf
            t.gravity = Gravity.CENTER
            t.setPadding(dp(14f), 0, dp(14f), 0)
            t.setOnClickListener {
                tab = i
                build()
            }
            tabs.add(t)
            head.addView(t, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(52f)))
        }
        head.addView(View(act), LinearLayout.LayoutParams(0, 1, 1f))
        val ok = EditorGlyph(act, true)
        ok.setOnClickListener { confirm() }
        head.addView(ok, LinearLayout.LayoutParams(dp(56f), dp(52f)))
        panel.addView(head, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        content.orientation = LinearLayout.VERTICAL
        content.setPadding(dp(18f), 0, dp(18f), 0)
        panel.addView(content, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        addView(panel, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT, Gravity.BOTTOM))
        build()

        panel.alpha = 0f
        panel.post {
            panel.translationY = panel.height.toFloat()
            panel.alpha = 1f
            panel.animate().translationY(0f).setDuration(240).setInterpolator(DecelerateInterpolator()).start()
        }
        // پیش‌نمایش از همون اول (برای ویرایش یا پس‌زمینه‌ی تازه)
        ThemeStore.previewBg = st.copy()
        vinyl.reloadTheme(true)
    }

    private fun label(text: String): TextView {
        val t = TextView(act)
        t.text = text
        t.setTextColor(Color.WHITE)
        t.textSize = 15f
        t.typeface = tf
        return t
    }

    private fun rowBox(): LinearLayout {
        val r = LinearLayout(act)
        r.orientation = LinearLayout.HORIZONTAL
        r.gravity = Gravity.CENTER_VERTICAL
        r.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(if (compact) 40f else 46f))
        return r
    }

    /** ردیف رنگ: نوار رنگ‌های آماده (قابل اسکرول) + انتخابگر رنگ دلخواه ثابت آخر ردیف */
    private fun colorRow(name: String, get: () -> Int, set: (Int) -> Unit): LinearLayout {
        val row = rowBox()
        row.addView(label(name), LinearLayout.LayoutParams(dp(72f), ViewGroup.LayoutParams.WRAP_CONTENT))
        val cur = get()
        var matched = false
        val strip = LinearLayout(act)
        strip.orientation = LinearLayout.HORIZONTAL
        strip.gravity = Gravity.CENTER_VERTICAL
        for (col in palette) {
            val sw = SwatchView(act, col, false)
            sw.chosen = cur == col
            if (sw.chosen) matched = true
            sw.setOnClickListener {
                set(col)
                changed()
                build()
            }
            strip.addView(sw, LinearLayout.LayoutParams(dp(40f), dp(40f)))
        }
        if (!matched) {
            val custom = SwatchView(act, cur, false)
            custom.chosen = true
            strip.addView(custom, 0, LinearLayout.LayoutParams(dp(40f), dp(40f)))
        }
        val scroll = HorizontalScrollView(act)
        scroll.isHorizontalScrollBarEnabled = false
        scroll.overScrollMode = View.OVER_SCROLL_NEVER
        scroll.addView(strip, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT))
        row.addView(scroll, LinearLayout.LayoutParams(0, dp(40f), 1f))
        val pick = SwatchView(act, Color.WHITE, true)
        pick.setOnClickListener {
            ColorPickerView.show(act, get(), name) { col ->
                set(col)
                changed()
                build()
            }
        }
        row.addView(pick, LinearLayout.LayoutParams(dp(40f), dp(40f)))
        return row
    }

    private fun chip(text: String, on: Boolean, click: () -> Unit): TextView {
        val t = TextView(act)
        t.text = text
        t.textSize = 15f
        t.typeface = tf
        t.gravity = Gravity.CENTER
        t.setTextColor(Color.WHITE)
        val g = GradientDrawable()
        g.cornerRadius = dp(18f).toFloat()
        g.setColor(if (on) Color.rgb(108, 70, 222) else Color.rgb(52, 52, 60))
        t.background = g
        t.setOnClickListener { click() }
        return t
    }

    private fun chipRow(items: List<Pair<String, Boolean>>, click: (Int) -> Unit): LinearLayout {
        val chips = LinearLayout(act)
        chips.orientation = LinearLayout.HORIZONTAL
        chips.gravity = Gravity.CENTER_VERTICAL
        for ((k, it) in items.withIndex()) {
            val c = chip(it.first, it.second) { click(k) }
            val lp = LinearLayout.LayoutParams(0, dp(34f), 1f)
            if (k > 0) lp.marginStart = dp(8f)
            chips.addView(c, lp)
        }
        chips.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(if (compact) 38f else 44f))
        return chips
    }

    private fun build() {
        for ((i, t) in tabs.withIndex()) {
            t.setTextColor(if (i == tab) Color.WHITE else Color.rgb(142, 140, 147))
            t.typeface = if (i == tab) Typeface.create(tf, Typeface.BOLD) else tf
        }
        content.removeAllViews()
        if (tab == 0) {
            content.addView(colorRow("Color", { st.c1 }) { st.c1 = it })
        } else {
            content.addView(chipRow(listOf("None" to !st.gradient, "Gradient" to st.gradient)) { k ->
                val g = k == 1
                if (st.gradient != g) {
                    st.gradient = g
                    if (g) {
                        // رنگ دوم پیشنهادی: همون رنگ با رنگمایه‌ی جابه‌جا شده
                        val hsv = FloatArray(3)
                        Color.colorToHSV(st.c1, hsv)
                        hsv[0] = (hsv[0] + 40f) % 360f
                        if (hsv[1] < 0.15f) hsv[1] = 0.5f
                        st.c2 = Color.HSVToColor(hsv)
                    }
                    changed()
                    build()
                }
            })
            if (st.gradient) {
                content.addView(colorRow("Color 1", { st.c1 }) { st.c1 = it })
                content.addView(colorRow("Color 2", { st.c2 }) { st.c2 = it })
                content.addView(chipRow(listOf("Vertical" to (st.dir == 0), "Horizontal" to (st.dir == 1), "Diagonal" to (st.dir == 2))) { k ->
                    if (st.dir != k) {
                        st.dir = k
                        changed()
                        build()
                    }
                })
            }
        }
    }

    /** ✓: پس‌زمینه تو ردیف Theme ذخیره میشه (جدید یا جایگزین قبلی) و فعال میشه */
    private fun confirm() {
        if (closing) return
        removeCallbacks(applyRun)
        if (touched || editFile == null) {
            val f = ThemeStore.saveBg(act, editFile, st)
            ThemeStore.select(act, ThemeStore.BG, f)
        }
        ThemeStore.previewBg = null
        vinyl.reloadTheme()
        close()
    }

    /** ✕ یا دکمه‌ی برگشت: هرچی بوده برمیگرده */
    fun cancel() {
        if (closing) return
        removeCallbacks(applyRun)
        ThemeStore.previewBg = null
        vinyl.reloadTheme()
        close()
    }

    private fun close() {
        closing = true
        panel.animate().translationY(panel.height.toFloat()).setDuration(200).withEndAction {
            (parent as? ViewGroup)?.removeView(this)
            onClosed?.invoke()
        }.start()
    }
}
