package com.example.mediawidget

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Shader

/**
 * پس‌زمینه‌ی ساخته‌شده با Background editor: رنگ ساده یا گرادیانت دو رنگ.
 * فقط برای صفحه‌ی وینیل استفاده میشه (ویجت‌ها دست نمی‌خورن).
 */
class BgStyle(
    var gradient: Boolean = false,
    var c1: Int = Color.rgb(122, 76, 226),
    var c2: Int = Color.rgb(226, 76, 168),
    var dir: Int = 0                     // ۰ عمودی، ۱ افقی، ۲ مورب
) {
    fun copy() = BgStyle(gradient, c1, c2, dir)

    fun encode() = "$gradient,$c1,$c2,$dir"

    /** روشنایی میانگین (۰..۱) برای انتخاب متن و دکمه‌های تیره یا روشن */
    fun luminance(): Float {
        fun l(c: Int) = (0.299f * Color.red(c) + 0.587f * Color.green(c) + 0.114f * Color.blue(c)) / 255f
        return if (gradient) (l(c1) + l(c2)) / 2f else l(c1)
    }

    fun isLight() = luminance() > 0.6f

    companion object {
        fun parse(s: String): BgStyle? = try {
            val p = s.trim().split(",")
            BgStyle(p[0].toBoolean(), p[1].toInt(), p[2].toInt(), p[3].toInt())
        } catch (e: Exception) {
            null
        }

        fun render(st: BgStyle, w: Int, h: Int): Bitmap {
            val out = Bitmap.createBitmap(w.coerceAtLeast(1), h.coerceAtLeast(1), Bitmap.Config.ARGB_8888)
            val c = Canvas(out)
            val p = Paint(Paint.DITHER_FLAG)
            if (!st.gradient) {
                c.drawColor(st.c1)
            } else {
                val wf = w.toFloat()
                val hf = h.toFloat()
                p.shader = when (st.dir) {
                    1 -> LinearGradient(0f, 0f, wf, 0f, st.c1, st.c2, Shader.TileMode.CLAMP)
                    2 -> LinearGradient(0f, 0f, wf, hf, st.c1, st.c2, Shader.TileMode.CLAMP)
                    else -> LinearGradient(0f, 0f, 0f, hf, st.c1, st.c2, Shader.TileMode.CLAMP)
                }
                c.drawRect(0f, 0f, wf, hf, p)
            }
            return out
        }
    }
}
