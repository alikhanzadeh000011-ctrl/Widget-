package com.example.mediawidget

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Typeface

/**
 * فونت پیکسلی ویجت‌های Now Playing: Pixel Operator 8 (فایل ttf واقعی، مثل ویجت‌های MD).
 * p = اندازه‌ی هر «نقطه»ی پیکسلی؛ اندازه‌ی متن = ۸ برابر p و ارتفاع حروف بزرگ = ۷ نقطه.
 * فقط حروف لاتین؛ برای فارسی و چینی و... supports() false میده و باید فونت معمولی استفاده بشه.
 */
object PixelFont {

    @Volatile private var tf: Typeface? = null

    fun ensure(ctx: Context) {
        if (tf != null) return
        try {
            tf = ctx.applicationContext.resources.getFont(R.font.pixel_operator8)
        } catch (e: Throwable) {
            tf = Typeface.MONOSPACE
        }
    }

    private fun paintFor(p: Float, src: Paint?): Paint {
        val pt = Paint(Paint.ANTI_ALIAS_FLAG)
        pt.typeface = tf ?: Typeface.MONOSPACE
        pt.textSize = 8f * p
        if (src != null) {
            pt.color = src.color
            pt.alpha = src.alpha
        }
        return pt
    }

    private fun covered(code: Int): Boolean =
        code in 32..126 || code in 0xBF..0xFF || code == 0x2013 || code == 0x2014 ||
            code in 0x2018..0x201A || code in 0x201C..0x201E || code == 0x2026

    fun supports(s: String): Boolean = s.all { covered(it.code) }

    /** عرض متن به پیکسل (p = اندازه‌ی هر نقطه) */
    fun width(text: String, p: Float): Float =
        if (text.isEmpty()) 0f else paintFor(p, null).measureText(text) - p

    /** متن رو طوری کوتاه می‌کنه که تو عرض مجاز جا بشه (آخرش «..») */
    fun fit(text: String, p: Float, maxW: Float): String {
        if (width(text, p) <= maxW) return text
        var t = text
        while (t.length > 1 && width("$t..", p) > maxW) t = t.dropLast(1)
        return "$t.."
    }

    /** x = شروع متن، baseline = خط پایه‌ی حروف (پایین حروف بزرگ) */
    fun draw(c: Canvas, text: String, x: Float, baseline: Float, p: Float, paint: Paint) {
        if (text.isEmpty()) return
        c.drawText(text, x - p, baseline, paintFor(p, paint))
    }
}
