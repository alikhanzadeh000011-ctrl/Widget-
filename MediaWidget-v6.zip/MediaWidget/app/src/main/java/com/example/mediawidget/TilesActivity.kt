package com.example.mediawidget

import android.app.Activity
import android.content.Intent
import android.graphics.BitmapFactory
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.util.concurrent.Executors

/** صفحه‌ی انتخاب ۵ پوشه‌ی آلبوم برای ویجت Library */
class TilesActivity : Activity() {

    private val executor = Executors.newSingleThreadExecutor()
    private val handler = Handler(Looper.getMainLooper())
    private val thumbs = arrayOfNulls<ImageView>(TileStore.COUNT)
    private val labels = arrayOfNulls<TextView>(TileStore.COUNT)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val d = resources.displayMetrics.density
        val pad = (16 * d).toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }

        val hint = TextView(this).apply {
            text = "Choose up to 5 album folders. The cover of the first song in each folder " +
                "(or cover.jpg / folder.jpg) is shown on the Library widget. " +
                "Tapping a cover opens your music player."
            textSize = 14f
            setPadding(0, 0, 0, pad)
        }
        root.addView(hint)

        for (i in 0 until TileStore.COUNT) {
            root.addView(buildRow(i, d))
        }

        val refreshButton = Button(this).apply {
            text = "Refresh all covers"
            setOnClickListener { refreshAll() }
        }
        root.addView(refreshButton)

        setContentView(ScrollView(this).apply { addView(root) })
        updateRows()
    }

    private fun buildRow(i: Int, d: Float): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, (6 * d).toInt(), 0, (6 * d).toInt())
        }

        val thumb = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            setBackgroundColor(0x22888888)
            layoutParams = LinearLayout.LayoutParams((64 * d).toInt(), (64 * d).toInt())
        }
        thumbs[i] = thumb
        row.addView(thumb)

        val column = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            setPadding((12 * d).toInt(), 0, 0, 0)
        }

        val label = TextView(this).apply { textSize = 15f }
        labels[i] = label
        column.addView(label)

        val buttons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val chooseButton = Button(this).apply {
            text = "Choose folder"
            setOnClickListener { pickFolder(i) }
        }
        val clearButton = Button(this).apply {
            text = "Clear"
            setOnClickListener {
                TileStore.clear(this@TilesActivity, i)
                updateRows()
                WidgetRenderer.updateAll(this@TilesActivity)
            }
        }
        buttons.addView(chooseButton)
        buttons.addView(clearButton)
        column.addView(buttons)

        row.addView(column)
        return row
    }

    private fun pickFolder(slot: Int) {
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT_TREE), REQ_BASE + slot)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val slot = requestCode - REQ_BASE
        if (resultCode != RESULT_OK || slot < 0 || slot >= TileStore.COUNT) return
        val uri = data?.data ?: return
        try {
            contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (e: Exception) {
            // بعضی دستگاه‌ها اجازه‌ی دائمی نمیدن؛ همین الان کافیه
        }
        TileStore.setFolder(this, slot, uri)
        labels[slot]?.text = "Slot ${slot + 1}: reading..."
        executor.execute {
            val ok = TileStore.loadCover(this, slot)
            handler.post {
                updateRows()
                WidgetRenderer.updateAll(this)
                if (!ok) {
                    Toast.makeText(this, "No cover found in this folder", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun refreshAll() {
        Toast.makeText(this, "Refreshing...", Toast.LENGTH_SHORT).show()
        executor.execute {
            for (i in 0 until TileStore.COUNT) {
                if (TileStore.folderUri(this, i) != null) TileStore.loadCover(this, i)
            }
            handler.post {
                updateRows()
                WidgetRenderer.updateAll(this)
            }
        }
    }

    private fun updateRows() {
        for (i in 0 until TileStore.COUNT) {
            val name = TileStore.folderName(this, i)
            val f = TileStore.file(this, i)
            val text = when {
                name == null -> "Slot ${i + 1}: empty"
                f.exists() -> "Slot ${i + 1}: $name"
                else -> "Slot ${i + 1}: $name (no cover found)"
            }
            labels[i]?.text = text
            val img = thumbs[i]
            if (f.exists()) {
                img?.setImageBitmap(BitmapFactory.decodeFile(f.absolutePath))
            } else {
                img?.setImageDrawable(null)
            }
        }
    }

    companion object {
        private const val REQ_BASE = 4100
    }
}
