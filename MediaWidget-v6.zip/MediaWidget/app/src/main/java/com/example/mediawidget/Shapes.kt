package com.example.mediawidget

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RectF
import android.graphics.Shader

/** ساخت بیت‌مپ‌های ویجت: کاور گرد، پس‌زمینه‌ی بلر و گوشه‌گرد */
object Shapes {

    fun centerCrop(src: Bitmap, w: Int, h: Int): Bitmap {
        val target = w.toFloat() / h
        val cur = src.width.toFloat() / src.height
        return if (cur > target) {
            val nw = (src.height * target).toInt().coerceIn(1, src.width)
            Bitmap.createBitmap(src, (src.width - nw) / 2, 0, nw, src.height)
        } else {
            val nh = (src.width / target).toInt().coerceIn(1, src.height)
            Bitmap.createBitmap(src, 0, (src.height - nh) / 2, src.width, nh)
        }
    }

    fun rounded(src: Bitmap, radius: Float): Bitmap {
        val out = Bitmap.createBitmap(src.width, src.height, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        c.drawRoundRect(RectF(0f, 0f, src.width.toFloat(), src.height.toFloat()), radius, radius, p)
        p.xfermode = PorterDuffXfermode(PorterDuff.Mode.SRC_IN)
        c.drawBitmap(src, 0f, 0f, p)
        return out
    }

    /** کاور مربعی (یا گرد، با radiusFrac = 0.5) */
    fun cover(src: Bitmap, size: Int, radiusFrac: Float): Bitmap {
        val sq = centerCrop(src, 1, 1)
        val scaled = Bitmap.createScaledBitmap(sq, size, size, true)
        return rounded(scaled, size * radiusFrac)
    }

    /** پس‌زمینه: بلر خودِ کاور + لایه‌ی تیره‌ی تدریجی (بالا کم، پایین زیاد) */
    fun blurBackground(src: Bitmap, w: Int, h: Int, radius: Float, topAlpha: Int, bottomAlpha: Int): Bitmap {
        val cropped = centerCrop(src, w, h)
        val smallW = 40
        val smallH = (smallW * h / w.toFloat()).toInt().coerceAtLeast(8)
        val small = Bitmap.createScaledBitmap(cropped, smallW, smallH, true)
        val blurred = boxBlur(small, 3, 3)
        val big = Bitmap.createScaledBitmap(blurred, w, h, true)
        val work = big.copy(Bitmap.Config.ARGB_8888, true)
        val c = Canvas(work)
        val p = Paint()
        p.shader = LinearGradient(
            0f, 0f, 0f, h.toFloat(),
            Color.argb(topAlpha, 0, 0, 0), Color.argb(bottomAlpha, 0, 0, 0),
            Shader.TileMode.CLAMP
        )
        c.drawRect(0f, 0f, w.toFloat(), h.toFloat(), p)
        return rounded(work, radius)
    }

    /** وقتی آهنگی نیست */
    fun defaultBackground(w: Int, h: Int, radius: Float): Bitmap {
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val p = Paint()
        p.shader = LinearGradient(
            0f, 0f, 0f, h.toFloat(),
            Color.parseColor("#55657A"), Color.parseColor("#141B27"),
            Shader.TileMode.CLAMP
        )
        c.drawRect(0f, 0f, w.toFloat(), h.toFloat(), p)
        return rounded(bmp, radius)
    }

    /** پس‌زمینه‌ی تک‌رنگ (ویجت Library) با یه نوار کمی تیره‌تر پایین برای کاشی‌ها */
    fun solidBackground(w: Int, h: Int, radius: Float, color: Int, stripFrac: Float): Bitmap {
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val p = Paint()
        p.color = color
        c.drawRect(0f, 0f, w.toFloat(), h.toFloat(), p)
        p.color = Color.argb(40, 0, 0, 0)
        c.drawRect(0f, h * stripFrac, w.toFloat(), h.toFloat(), p)
        return rounded(bmp, radius)
    }

    /** نوار پیشرفت آهنگ: مسیر کم‌رنگ + بخش پرشده با رنگ آیکون‌ها */
    fun progress(w: Int, h: Int, frac: Float, fillColor: Int): Bitmap {
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        val r = h / 2f
        p.color = Color.argb(60, 255, 255, 255)
        c.drawRoundRect(RectF(0f, 0f, w.toFloat(), h.toFloat()), r, r, p)
        if (frac > 0f) {
            p.color = fillColor
            val fw = maxOf(h.toFloat(), w * frac)
            c.drawRoundRect(RectF(0f, 0f, fw, h.toFloat()), r, r, p)
        }
        return bmp
    }

    private fun boxBlur(bmp: Bitmap, r: Int, passes: Int): Bitmap {
        val w = bmp.width
        val h = bmp.height
        val a = IntArray(w * h)
        val b = IntArray(w * h)
        bmp.getPixels(a, 0, w, 0, 0, w, h)
        repeat(passes) {
            blurPass(a, b, w, h, r, true)
            blurPass(b, a, w, h, r, false)
        }
        return Bitmap.createBitmap(a, w, h, Bitmap.Config.ARGB_8888)
    }

    private fun blurPass(src: IntArray, dst: IntArray, w: Int, h: Int, r: Int, horizontal: Boolean) {
        val n = 2 * r + 1
        for (y in 0 until h) {
            for (x in 0 until w) {
                var sr = 0
                var sg = 0
                var sb = 0
                for (k in -r..r) {
                    val xx = if (horizontal) (x + k).coerceIn(0, w - 1) else x
                    val yy = if (horizontal) y else (y + k).coerceIn(0, h - 1)
                    val c = src[yy * w + xx]
                    sr += (c shr 16) and 0xFF
                    sg += (c shr 8) and 0xFF
                    sb += c and 0xFF
                }
                dst[y * w + x] = (0xFF shl 24) or ((sr / n) shl 16) or ((sg / n) shl 8) or (sb / n)
            }
        }
    }
}
