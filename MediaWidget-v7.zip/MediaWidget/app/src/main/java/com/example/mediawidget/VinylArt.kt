package com.example.mediawidget

import android.graphics.Bitmap
import android.graphics.BlurMaskFilter
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.CornerPathEffect
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.SweepGradient
import android.graphics.Typeface

/**
 * رسم قطعه‌های ثابت صفحه‌ی وینیل (با کد، بدون هیچ فایل تصویر).
 * همه‌ی مختصات روی بوم مرجع ۱۰۸۰×۲۳۴۰ هستن و با ضریب s به اندازه‌ی صفحه‌ی گوشی تبدیل میشن.
 * اندازه‌ها از روی اسکرین‌شات‌های مرجع اندازه‌گیری شده.
 */
object VinylArt {

    const val REF_W = 1080f
    const val REF_H = 2340f

    // دیسک و برچسب (کاور)
    const val CX = 296f
    const val CY = 842.5f
    const val R = 654f
    const val LR = 294.5f

    // محور چرخش بازو و زاویه‌ها (درجه، ساعت‌گرد مثبت)
    const val PX = 875f
    const val PY = 338f
    const val ARM_REST = 0f
    const val ARM_OUTER = 18f
    const val ARM_INNER = 41f

    // محدوده‌ی بیت‌مپ بازو نسبت به محور
    const val ARM_OX = 80f
    const val ARM_OY = 140f
    const val ARM_W = 300f
    const val ARM_H = 1270f

    // دکمه‌ها
    const val BTN_W = 206f
    const val BTN_H = 105f
    const val BTN_PAD = 30f

    /** بدنه‌ی دیسک: شیارها، حلقه‌ها، برق نور و سایه. (خودِ دیسک نمی‌چرخه) */
    fun recordBitmap(s: Float): Bitmap {
        val pad = 0.12f * R
        val size = ((2f * R + 2f * pad) * s).toInt()
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val mid = size / 2f
        val r = R * s
        val p = Paint(Paint.ANTI_ALIAS_FLAG)

        // سایه‌ی زیر دیسک
        p.color = Color.argb(100, 0, 0, 0)
        p.maskFilter = BlurMaskFilter(26f * s, BlurMaskFilter.Blur.NORMAL)
        c.drawCircle(mid, mid + 14f * s, r, p)
        p.maskFilter = null

        // بدنه
        p.shader = RadialGradient(
            mid, mid, r,
            intArrayOf(Color.rgb(14, 14, 14), Color.rgb(26, 26, 26), Color.rgb(11, 11, 11)),
            floatArrayOf(0f, 0.72f, 1f),
            Shader.TileMode.CLAMP
        )
        c.drawCircle(mid, mid, r, p)
        p.shader = null

        // شیارها
        val rnd = java.util.Random(3)
        p.style = Paint.Style.STROKE
        p.strokeWidth = 1.3f * s
        var rr = 0.52f * R
        while (rr < 0.955f * R) {
            p.color = Color.argb(rnd.nextInt(18), 255, 255, 255)
            c.drawCircle(mid, mid, rr * s, p)
            rr += 2.6f
        }

        // فاصله‌ی بین ترک‌ها (حلقه‌های صاف و تیره)
        p.strokeWidth = 6f * s
        p.color = Color.argb(120, 0, 0, 0)
        for (g in floatArrayOf(0.60f, 0.69f, 0.79f, 0.89f)) {
            c.drawCircle(mid, mid, g * R * s, p)
        }

        // حاشیه‌ی بیرونی صاف
        p.strokeWidth = 0.03f * R * s
        p.color = Color.argb(70, 0, 0, 0)
        c.drawCircle(mid, mid, 0.97f * R * s, p)

        // برق نور (دو ناحیه‌ی روشن، ثابت)
        val none = Color.argb(0, 255, 255, 255)
        val hi = Color.argb(70, 255, 255, 255)
        p.shader = SweepGradient(
            mid, mid,
            intArrayOf(none, none, hi, none, none, hi, none, none),
            floatArrayOf(0f, 0.0722f, 0.1667f, 0.2611f, 0.5722f, 0.6667f, 0.7611f, 1f)
        )
        p.strokeWidth = 0.485f * R * s
        c.drawCircle(mid, mid, 0.7425f * R * s, p)
        p.shader = null

        // ناحیه‌ی صاف دور برچسب
        p.style = Paint.Style.FILL
        p.color = Color.rgb(8, 8, 8)
        c.drawCircle(mid, mid, 0.52f * R * s, p)

        // لبه‌ی براق
        p.style = Paint.Style.STROKE
        p.strokeWidth = 3f * s
        p.color = Color.argb(45, 255, 255, 255)
        c.drawCircle(mid, mid, 0.992f * R * s, p)
        return bmp
    }

    /** بازوی سوزن در حالت عمودی (استراحت)؛ موقع نمایش حول محور PX,PY می‌چرخه */
    fun armBitmap(s: Float): Bitmap {
        val bmp = Bitmap.createBitmap((ARM_W * s).toInt(), (ARM_H * s).toInt(), Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)

        fun px(x: Float): Float = (x - PX + ARM_OX) * s
        fun py(y: Float): Float = (y - PY + ARM_OY) * s

        fun poly(pts: FloatArray, dx: Float, dy: Float): Path {
            val path = Path()
            path.moveTo(px(pts[0] + dx), py(pts[1] + dy))
            var i = 2
            while (i < pts.size) {
                path.lineTo(px(pts[i] + dx), py(pts[i + 1] + dy))
                i += 2
            }
            path.close()
            return path
        }

        val headshell = floatArrayOf(954f, 1192f, 1031f, 1233f, 984f, 1344f, 897f, 1323f)
        val stylus = floatArrayOf(962f, 1338f, 1006f, 1342f, 1004f, 1372f, 962f, 1370f)

        // پاس اول: سایه، پاس دوم: خود بازو
        for (pass in 0..1) {
            val shadow = pass == 0
            val dx = if (shadow) 8f else 0f
            val dy = if (shadow) 14f else 0f
            p.shader = null
            p.pathEffect = null
            p.maskFilter = if (shadow) BlurMaskFilter(10f * s, BlurMaskFilter.Blur.NORMAL) else null

            fun rr(l: Float, t: Float, r: Float, b: Float, rad: Float, color: Int) {
                p.color = if (shadow) Color.argb(115, 0, 0, 0) else color
                c.drawRoundRect(RectF(px(l + dx), py(t + dy), px(r + dx), py(b + dy)), rad * s, rad * s, p)
            }

            rr(857f, 258f, 943f, 292f, 8f, Color.rgb(26, 26, 26))
            // بلوک بزرگ بالا (با گرادیان ملایم)
            if (!shadow) {
                p.shader = LinearGradient(
                    0f, py(288f), 0f, py(395f),
                    Color.rgb(46, 46, 46), Color.rgb(28, 28, 28), Shader.TileMode.CLAMP
                )
                p.color = Color.rgb(34, 34, 34)
                c.drawRoundRect(RectF(px(848f), py(288f), px(1012f), py(395f)), 14f * s, 14f * s, p)
                p.shader = null
            } else {
                rr(848f, 288f, 1012f, 395f, 14f, Color.BLACK)
            }
            rr(962f, 390f, 1004f, 475f, 6f, Color.rgb(30, 30, 30))

            // میله‌ی نقره‌ای
            if (shadow) {
                rr(966f, 470f, 1000f, 1136f, 3f, Color.BLACK)
            } else {
                p.shader = LinearGradient(
                    px(966f), 0f, px(1000f), 0f,
                    intArrayOf(
                        Color.rgb(74, 74, 74), Color.rgb(181, 181, 181), Color.rgb(222, 222, 222),
                        Color.rgb(160, 160, 160), Color.rgb(92, 92, 92)
                    ),
                    floatArrayOf(0f, 0.25f, 0.5f, 0.75f, 1f),
                    Shader.TileMode.CLAMP
                )
                c.drawRect(RectF(px(966f), py(470f), px(1000f), py(1136f)), p)
                p.shader = null
            }

            rr(960f, 1132f, 1005f, 1215f, 6f, Color.rgb(28, 28, 28))

            // هد و سوزن
            p.pathEffect = CornerPathEffect(10f * s)
            p.color = if (shadow) Color.argb(115, 0, 0, 0) else Color.rgb(36, 36, 36)
            c.drawPath(poly(headshell, dx, dy), p)
            p.pathEffect = null
            p.color = if (shadow) Color.argb(115, 0, 0, 0) else Color.rgb(28, 28, 28)
            c.drawPath(poly(stylus, dx, dy), p)
        }
        p.maskFilter = null
        return bmp
    }

    /** دکمه‌ی قرصی تیره با سایه (PLAY، قبلی، بعدی) */
    fun buttonBitmap(s: Float): Bitmap {
        val w = BTN_W
        val h = BTN_H
        val pad = BTN_PAD
        val bmp = Bitmap.createBitmap(((w + 2f * pad) * s).toInt(), ((h + 2f * pad) * s).toInt(), Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)

        // سایه
        p.color = Color.argb(110, 0, 0, 0)
        p.maskFilter = BlurMaskFilter(14f * s, BlurMaskFilter.Blur.NORMAL)
        c.drawRoundRect(RectF(pad * s, (pad + 10f) * s, (pad + w) * s, (pad + h + 10f) * s), h * s / 2f, h * s / 2f, p)
        p.maskFilter = null

        // حلقه‌ی بیرونی تیره
        p.color = Color.argb(55, 0, 0, 0)
        c.drawRoundRect(RectF(pad * s, pad * s, (pad + w) * s, (pad + h) * s), h * s / 2f, h * s / 2f, p)

        // قرص داخلی
        val i = 11f
        val rect = RectF((pad + i) * s, (pad + i) * s, (pad + w - i) * s, (pad + h - i) * s)
        p.shader = LinearGradient(
            0f, rect.top, 0f, rect.bottom,
            Color.rgb(44, 44, 44), Color.rgb(24, 24, 24), Shader.TileMode.CLAMP
        )
        c.drawRoundRect(rect, rect.height() / 2f, rect.height() / 2f, p)
        p.shader = null

        p.style = Paint.Style.STROKE
        p.strokeWidth = 2f * s
        p.color = Color.argb(150, 0, 0, 0)
        c.drawRoundRect(rect, rect.height() / 2f, rect.height() / 2f, p)
        return bmp
    }

    /** پس‌زمینه‌ی خاکستری وقتی هیچ آهنگی نیست (بیت‌مپ کوچک، موقع رسم بزرگ و نرم میشه) */
    fun greyBackground(w: Int, h: Int): Bitmap {
        val bw = (w / 4).coerceAtLeast(8)
        val bh = (h / 4).coerceAtLeast(8)
        val bmp = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val p = Paint()
        p.shader = LinearGradient(
            0f, 0f, 0f, bh.toFloat(),
            intArrayOf(
                Color.rgb(206, 206, 206), Color.rgb(185, 185, 185), Color.rgb(128, 128, 128),
                Color.rgb(92, 92, 92), Color.rgb(162, 162, 162), Color.rgb(110, 110, 110)
            ),
            floatArrayOf(0f, 0.30f, 0.55f, 0.70f, 0.84f, 1f),
            Shader.TileMode.CLAMP
        )
        c.drawRect(0f, 0f, bw.toFloat(), bh.toFloat(), p)
        return bmp
    }

    /**
     * پس‌زمینه‌ی نرم از روی کاور: خیلی بلر، با رنگ میانگین کاور مخلوط (کم‌کنتراست)
     * و یه لایه‌ی تیره‌ی ملایم، مثل اپ مرجع.
     */
    fun coverBackground(art: Bitmap, w: Int, h: Int): Bitmap {
        val bw = (w / 4).coerceAtLeast(8)
        val bh = (h / 4).coerceAtLeast(8)
        val cropped = Shapes.centerCrop(art, bw, bh)
        val sw = 12
        val sh = (sw * bh / bw.toFloat()).toInt().coerceAtLeast(8)
        val small = Bitmap.createScaledBitmap(cropped, sw, sh, true)
        val avg = Bitmap.createScaledBitmap(cropped, 1, 1, true).getPixel(0, 0)
        val px = IntArray(sw * sh)
        small.getPixels(px, 0, sw, 0, 0, sw, sh)
        val ar = Color.red(avg)
        val ag = Color.green(avg)
        val ab = Color.blue(avg)
        for (i in px.indices) {
            val q = px[i]
            px[i] = Color.rgb(
                (Color.red(q) * 0.30f + ar * 0.70f).toInt(),
                (Color.green(q) * 0.30f + ag * 0.70f).toInt(),
                (Color.blue(q) * 0.30f + ab * 0.70f).toInt()
            )
        }
        val mixed = Bitmap.createBitmap(px, sw, sh, Bitmap.Config.ARGB_8888)
        val big = Bitmap.createScaledBitmap(mixed, bw, bh, true)
        val blurred = Shapes.boxBlur(big, 14, 2)
        val out = blurred.copy(Bitmap.Config.ARGB_8888, true)
        val c = Canvas(out)
        val p = Paint()
        p.shader = LinearGradient(
            0f, 0f, 0f, bh.toFloat(),
            Color.argb(70, 0, 0, 0), Color.argb(120, 0, 0, 0), Shader.TileMode.CLAMP
        )
        c.drawRect(0f, 0f, bw.toFloat(), bh.toFloat(), p)
        return out
    }

    /** برچسب گرد از روی کاور آهنگ */
    fun labelFromCover(art: Bitmap, d: Int): Bitmap {
        val label = Shapes.cover(art, d, 0.5f)
        val c = Canvas(label)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.style = Paint.Style.STROKE
        p.strokeWidth = 0.012f * d
        p.color = Color.argb(110, 0, 0, 0)
        c.drawCircle(d / 2f, d / 2f, d / 2f - p.strokeWidth / 2f, p)
        return label
    }

    /** برچسب تیره وقتی آهنگی نیست */
    fun blankLabel(d: Int, tf: Typeface?): Bitmap {
        val bmp = Bitmap.createBitmap(d, d, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val m = d / 2f
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.color = Color.rgb(40, 40, 40)
        c.drawCircle(m, m, m, p)

        p.style = Paint.Style.STROKE
        p.strokeWidth = 0.02f * d
        p.color = Color.rgb(56, 56, 56)
        c.drawCircle(m, m, m * 0.93f, p)

        p.style = Paint.Style.FILL
        p.color = Color.rgb(32, 32, 32)
        c.drawCircle(m, m, m * 0.16f, p)
        p.color = Color.rgb(150, 150, 150)
        c.drawCircle(m, m, m * 0.04f, p)

        val tp = Paint(Paint.ANTI_ALIAS_FLAG)
        if (tf != null) tp.typeface = tf
        tp.color = Color.rgb(150, 138, 120)
        tp.textAlign = Paint.Align.CENTER
        tp.textSize = 0.095f * d
        c.drawText("VINYL", m, m - 0.15f * d, tp)
        tp.textSize = 0.065f * d
        c.drawText("33 1/3 RPM", m, m + 0.21f * d, tp)
        return bmp
    }
}
