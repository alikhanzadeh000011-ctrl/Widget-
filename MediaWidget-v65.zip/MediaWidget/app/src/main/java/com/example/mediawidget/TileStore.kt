package com.example.mediawidget

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.DocumentsContract
import java.io.File
import java.io.FileOutputStream

/** تنظیمات کوچیک اپ: آخرین پلیری که آهنگ پخش کرده (برای باز کردنش با لمس کاشی‌ها) */
object AppPrefs {
    fun lastPlayer(ctx: Context): String =
        ctx.getSharedPreferences("state", Context.MODE_PRIVATE).getString("last_pkg", "") ?: ""

    fun setLastPlayer(ctx: Context, pkg: String) {
        ctx.getSharedPreferences("state", Context.MODE_PRIVATE).edit().putString("last_pkg", pkg).apply()
    }

    /** همه‌ی پلیرهایی که تا حالا آهنگ پخش کردن (برای لیست انتخاب پلیر در تنظیمات ویجت) */
    fun seen(ctx: Context): Set<String> =
        ctx.getSharedPreferences("state", Context.MODE_PRIVATE).getStringSet("seen_pkgs", emptySet())?.toSet() ?: emptySet()

    fun addSeen(ctx: Context, pkg: String) {
        val p = ctx.getSharedPreferences("state", Context.MODE_PRIVATE)
        val cur = p.getStringSet("seen_pkgs", emptySet()) ?: emptySet()
        if (pkg in cur) return
        p.edit().putStringSet("seen_pkgs", HashSet(cur).also { it.add(pkg) }).apply()
    }
}

/**
 * ۵ کاشی ویجت Library: هر کدوم یه پوشه‌ی آلبوم (انتخاب‌شده با انتخابگر پوشه‌ی اندروید).
 * کاور اولین آهنگ پوشه یک بار خونده میشه و داخل حافظه‌ی خود اپ ذخیره میشه؛
 * ویجت فقط همون فایل کوچیک رو نشون میده.
 */
object TileStore {
    const val COUNT = 5

    private val COVER_NAMES = setOf("cover", "folder", "front", "album", "albumart", "albumartsmall", "artwork", "thumb")
    private val AUDIO_EXT = setOf("mp3", "m4a", "flac", "ogg", "opus", "wav", "aac", "wma", "m4b")
    private val IMAGE_EXT = setOf("jpg", "jpeg", "png", "webp")

    private class Entry(val docId: String, val name: String, val mime: String)

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("tiles", Context.MODE_PRIVATE)

    fun file(ctx: Context, slot: Int): File = File(ctx.filesDir, "tile_$slot.jpg")

    fun folderName(ctx: Context, slot: Int): String? = prefs(ctx).getString("name_$slot", null)

    fun folderUri(ctx: Context, slot: Int): Uri? =
        prefs(ctx).getString("uri_$slot", null)?.let { Uri.parse(it) }

    fun setFolder(ctx: Context, slot: Int, tree: Uri) {
        var name = ""
        try {
            val docUri = DocumentsContract.buildDocumentUriUsingTree(tree, DocumentsContract.getTreeDocumentId(tree))
            ctx.contentResolver.query(
                docUri, arrayOf(DocumentsContract.Document.COLUMN_DISPLAY_NAME), null, null, null
            )?.use { c ->
                if (c.moveToFirst()) name = c.getString(0) ?: ""
            }
        } catch (e: Exception) {
            // اسم پوشه نگرفتیم؛ عیبی نداره
        }
        prefs(ctx).edit()
            .putString("uri_$slot", tree.toString())
            .putString("name_$slot", name.ifEmpty { "Folder ${slot + 1}" })
            .apply()
        file(ctx, slot).delete()
    }

    fun clear(ctx: Context, slot: Int) {
        prefs(ctx).edit().remove("uri_$slot").remove("name_$slot").apply()
        file(ctx, slot).delete()
    }

    /** کاور پوشه رو پیدا و ذخیره می‌کنه. اگه پیدا نشد false */
    fun loadCover(ctx: Context, slot: Int): Boolean {
        val tree = folderUri(ctx, slot) ?: return false
        val f = file(ctx, slot)
        val bmp = try {
            findCover(ctx, tree, DocumentsContract.getTreeDocumentId(tree), 0)
        } catch (e: Exception) {
            null
        }
        if (bmp == null) {
            f.delete()
            return false
        }
        val sq = Shapes.centerCrop(bmp, 1, 1)
        val scaled = Bitmap.createScaledBitmap(sq, 256, 256, true)
        FileOutputStream(f).use { stream -> scaled.compress(Bitmap.CompressFormat.JPEG, 92, stream) }
        return true
    }

    private fun children(ctx: Context, tree: Uri, docId: String): List<Entry> {
        val uri = DocumentsContract.buildChildDocumentsUriUsingTree(tree, docId)
        val list = ArrayList<Entry>()
        ctx.contentResolver.query(
            uri,
            arrayOf(
                DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                DocumentsContract.Document.COLUMN_MIME_TYPE
            ),
            null, null, null
        )?.use { c ->
            while (c.moveToNext()) {
                list.add(Entry(c.getString(0) ?: "", c.getString(1) ?: "", c.getString(2) ?: ""))
            }
        }
        return list
    }

    private fun ext(e: Entry): String = e.name.substringAfterLast('.', "").lowercase()

    private fun isAudio(e: Entry): Boolean = e.mime.startsWith("audio/") || ext(e) in AUDIO_EXT

    private fun isImage(e: Entry): Boolean = e.mime.startsWith("image/") || ext(e) in IMAGE_EXT

    private fun findCover(ctx: Context, tree: Uri, docId: String, depth: Int): Bitmap? {
        val items = children(ctx, tree, docId).sortedBy { it.name.lowercase() }

        // ۱) کاور داخل فایل اولین آهنگ‌ها (اگه اولی نداشت، بعدی)
        for (a in items.filter { isAudio(it) }.take(3)) {
            val r = MediaMetadataRetriever()
            try {
                r.setDataSource(ctx, DocumentsContract.buildDocumentUriUsingTree(tree, a.docId))
                val pic = r.embeddedPicture
                if (pic != null) {
                    val bmp = decode(pic)
                    if (bmp != null) return bmp
                }
            } catch (e: Exception) {
                // این فایل کاور نداشت یا خونده نشد
            } finally {
                try {
                    r.release()
                } catch (e: Exception) {
                    // مهم نیست
                }
            }
        }

        // ۲) عکس کاور کنار آهنگ‌ها (cover.jpg / folder.jpg ...)، وگرنه اولین عکس پوشه
        val images = items.filter { isImage(it) }
        val chosen = images.firstOrNull { it.name.substringBeforeLast('.').lowercase() in COVER_NAMES }
            ?: images.firstOrNull()
        if (chosen != null) {
            val uri = DocumentsContract.buildDocumentUriUsingTree(tree, chosen.docId)
            val bytes = ctx.contentResolver.openInputStream(uri)?.use { it.readBytes() }
            if (bytes != null) {
                val bmp = decode(bytes)
                if (bmp != null) return bmp
            }
        }

        // ۳) یک سطح پایین‌تر (اگه آهنگ‌ها داخل زیرپوشه بودن)
        if (depth == 0) {
            for (sub in items.filter { it.mime == DocumentsContract.Document.MIME_TYPE_DIR }) {
                val bmp = findCover(ctx, tree, sub.docId, 1)
                if (bmp != null) return bmp
            }
        }
        return null
    }

    private fun decode(bytes: ByteArray): Bitmap? {
        val o = BitmapFactory.Options()
        o.inJustDecodeBounds = true
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o)
        var sample = 1
        while (o.outWidth / sample > 800 || o.outHeight / sample > 800) sample *= 2
        val o2 = BitmapFactory.Options()
        o2.inSampleSize = sample
        return BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o2)
    }
}
