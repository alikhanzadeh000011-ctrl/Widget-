package com.example.mediawidget

import android.app.AlertDialog
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.TextView
import java.io.File
import kotlin.math.min

/** بندانگشتی گرد یا چهارگوش (گزینه‌ی پیش‌فرض، عکس سفارشی یا دکمه‌ی +) */
class ThumbView(act: VinylActivity, private val circle: Boolean) : View(act) {
    var bmp: Bitmap? = null
    var plus = false
    var tune = false     // آیکن ویرایش (سه خط با دسته)
    var chosen = false

    private val d = resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val path = Path()
    private val src = Rect()
    private val box = RectF()

    override fun onDraw(c: Canvas) {
        val m = 5f * d
        box.set(m, m, width - m, height - m)
        path.reset()
        if (circle) path.addOval(box, Path.Direction.CW) else path.addRoundRect(box, 13f * d, 13f * d, Path.Direction.CW)
        c.save()
        c.clipPath(path)
        p.style = Paint.Style.FILL
        p.color = Color.rgb(44, 43, 48)
        c.drawRect(box, p)
        val b = bmp
        if (b != null) {
            val side = min(b.width, b.height)
            val sx = (b.width - side) / 2
            val sy = ((b.height - side) * 0.35f).toInt()
            src.set(sx, sy, sx + side, sy + side)
            c.drawBitmap(b, src, box, p)
        } else if (tune) {
            p.style = Paint.Style.STROKE
            p.strokeWidth = 2.2f * d
            p.strokeCap = Paint.Cap.ROUND
            p.color = Color.WHITE
            val cx = width / 2f
            val cy = height / 2f
            val l = 10f * d
            val knobs = floatArrayOf(-4f, 5f, -2f)
            for (i in 0 until 3) {
                val y = cy + (i - 1) * 8.5f * d
                c.drawLine(cx - l, y, cx + l, y, p)
                p.style = Paint.Style.FILL
                c.drawCircle(cx + knobs[i] * d, y, 3.2f * d, p)
                p.style = Paint.Style.STROKE
            }
        } else if (plus) {
            p.style = Paint.Style.STROKE
            p.strokeWidth = 2.4f * d
            p.strokeCap = Paint.Cap.ROUND
            p.color = Color.WHITE
            val cx = width / 2f
            val cy = height / 2f
            val l = 9f * d
            c.drawLine(cx - l, cy, cx + l, cy, p)
            c.drawLine(cx, cy - l, cx, cy + l, p)
        }
        c.restore()
        if (chosen) {
            p.style = Paint.Style.STROKE
            p.strokeWidth = 2.4f * d
            p.color = Color.WHITE
            box.inset(-3.5f * d, -3.5f * d)
            if (circle) c.drawOval(box, p) else c.drawRoundRect(box, 16.5f * d, 16.5f * d, p)
        }
    }
}

/** دایره‌ی رنگ برای چراغ سوزن (رنگ ساده یا حلقه‌ی رنگین‌کمان برای انتخابگر) */
class SwatchView(act: VinylActivity, private val color: Int, private val rainbow: Boolean) : View(act) {
    var chosen = false
    var dim = false
    var ring = false      // دایره‌ی رنگ فعلی با حلقه‌ی رنگین‌کمان دورش (انتخابگر چراغ سوزن)
    var off = false       // دایره‌ی «خاموش» (خط مورب روی زمینه‌ی تیره)
    private val d = resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onDraw(c: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val r = min(width, height) / 2f - 6f * d
        p.alpha = if (dim) 110 else 255
        p.style = Paint.Style.FILL
        if (off) {
            p.color = Color.rgb(44, 44, 52)
            c.drawCircle(cx, cy, r, p)
            p.style = Paint.Style.STROKE
            p.strokeWidth = 2f * d
            p.color = Color.rgb(200, 200, 208)
            val k = r * 0.55f
            c.drawLine(cx - k, cy + k, cx + k, cy - k, p)
            p.style = Paint.Style.FILL
        } else if (ring) {
            val cols = IntArray(7) { Color.HSVToColor(floatArrayOf(it * 60f, 0.9f, 1f)) }
            p.shader = android.graphics.SweepGradient(cx, cy, cols, null)
            c.drawCircle(cx, cy, r, p)
            p.shader = null
            p.color = Color.rgb(28, 27, 32)
            c.drawCircle(cx, cy, r * 0.82f, p)
            p.color = color
            c.drawCircle(cx, cy, r * 0.66f, p)
        } else if (rainbow) {
            val cols = IntArray(7) { Color.HSVToColor(floatArrayOf(it * 60f, 0.9f, 1f)) }
            p.shader = android.graphics.SweepGradient(cx, cy, cols, null)
            c.drawCircle(cx, cy, r, p)
            p.shader = null
            p.color = Color.rgb(28, 27, 32)
            c.drawCircle(cx, cy, r * 0.42f, p)
        } else {
            p.color = color
            c.drawCircle(cx, cy, r, p)
        }
        if (chosen) {
            p.style = Paint.Style.STROKE
            p.strokeWidth = 2.2f * d
            p.color = Color.WHITE
            c.drawCircle(cx, cy, r + 3.5f * d, p)
        }
    }
}

/** چیدمان ردیفی که وقتی جا تموم شد میره خط بعد (برای کشوی Theme توی لندسکیپ) */
class FlowLayout(ctx: Context) : ViewGroup(ctx) {
    private val d = resources.displayMetrics.density

    override fun checkLayoutParams(p: LayoutParams?): Boolean = p is MarginLayoutParams

    override fun generateDefaultLayoutParams(): LayoutParams =
        MarginLayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT)

    override fun generateLayoutParams(attrs: android.util.AttributeSet?): LayoutParams = MarginLayoutParams(context, attrs)

    override fun generateLayoutParams(p: LayoutParams?): LayoutParams =
        if (p is MarginLayoutParams) MarginLayoutParams(p) else MarginLayoutParams(p!!)

    private fun gap() = (8f * d).toInt()

    override fun onMeasure(wSpec: Int, hSpec: Int) {
        val maxW = MeasureSpec.getSize(wSpec) - paddingLeft - paddingRight
        var x = 0
        var y = 0
        var rowH = 0
        for (i in 0 until childCount) {
            val c = getChildAt(i)
            if (c.visibility == GONE) continue
            measureChildWithMargins(c, wSpec, 0, hSpec, 0)
            val lp = c.layoutParams as MarginLayoutParams
            val cw = c.measuredWidth + lp.marginStart + lp.marginEnd
            val ch = c.measuredHeight + lp.topMargin + lp.bottomMargin
            if (x + cw > maxW && x > 0) {
                x = 0
                y += rowH + gap()
                rowH = 0
            }
            x += cw
            rowH = maxOf(rowH, ch)
        }
        setMeasuredDimension(MeasureSpec.getSize(wSpec), y + rowH + paddingTop + paddingBottom)
    }

    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
        val maxW = (r - l) - paddingLeft - paddingRight
        var x = 0
        var y = 0
        var rowH = 0
        for (i in 0 until childCount) {
            val c = getChildAt(i)
            if (c.visibility == GONE) continue
            val lp = c.layoutParams as MarginLayoutParams
            val cw = c.measuredWidth + lp.marginStart + lp.marginEnd
            val ch = c.measuredHeight + lp.topMargin + lp.bottomMargin
            if (x + cw > maxW && x > 0) {
                x = 0
                y += rowH + gap()
                rowH = 0
            }
            val left = paddingLeft + x + lp.marginStart
            val top = paddingTop + y + lp.topMargin
            c.layout(left, top, left + c.measuredWidth, top + c.measuredHeight)
            x += cw
            rowH = maxOf(rowH, ch)
        }
    }
}

/** صفحه‌ی تم (کشوی پایین)، مثل عکس مرجع: ردیف Theme برای پس‌زمینه و ردیف Vinyl برای دیسک */
class ThemeSheet(private val act: VinylActivity, private val vinyl: VinylView) : FrameLayout(act) {

    var onDismissed: (() -> Unit)? = null

    private val d = resources.displayMetrics.density
    private val land = resources.configuration.orientation == android.content.res.Configuration.ORIENTATION_LANDSCAPE
    private val panel = LinearLayout(act)
    private val card = FrameLayout(act)          // لندسکیپ: کارت سمت چپ (مثل MD) که پنل داخلش اسکرول میشه
    private val bgRow: ViewGroup = if (land) FlowLayout(act) else LinearLayout(act)
    private val discRow: ViewGroup = if (land) FlowLayout(act) else LinearLayout(act)
    private val needleRow: ViewGroup = if (land) FlowLayout(act) else LinearLayout(act)
    /** چیزی که موقع ورود و خروج میلغزه */
    private val mover: View get() = if (land) card else panel
    private val tf: Typeface = try {
        resources.getFont(R.font.sf_pro_soft)
    } catch (e: Exception) {
        Typeface.DEFAULT
    }
    private val defBg: Bitmap? = vinyl.defaultBackgroundPreview()
    private val thumbCache = HashMap<Int, Bitmap>()
    private var dismissing = false
    private var dragging = false
    private var dragStartY = 0f

    private fun dp(v: Float) = (v * d).toInt()

    // لندسکیپ (ارتفاع کم): همه‌چیز کمی فشرده‌تر تا کشو از صفحه بیرون نزنه
    private val compact = resources.displayMetrics.heightPixels < dp(520f)

    private fun title(label: String, topPad: Int): TextView {
        val t = TextView(act)
        t.text = label
        t.setTextColor(Color.WHITE)
        t.textSize = if (compact) 16f else 20f
        t.typeface = tf
        t.setPadding(dp(28f), if (compact) topPad / 2 else topPad, 0, if (compact) dp(4f) else dp(8f))
        return t
    }

    private fun scroller(row: ViewGroup): View {
        if (land) {
            // لندسکیپ: دایره‌ها زیر هم می‌شکنن، اسکرول افقی نداریم
            val box = FrameLayout(act)
            box.setPadding(dp(23f), 0, dp(23f), 0)
            box.addView(row, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            return box
        }
        val sv = HorizontalScrollView(act)
        sv.isHorizontalScrollBarEnabled = false
        sv.overScrollMode = View.OVER_SCROLL_NEVER
        sv.setPadding(dp(23f), 0, dp(23f), 0)
        sv.clipToPadding = false
        (row as LinearLayout).orientation = LinearLayout.HORIZONTAL
        sv.addView(row, ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        return sv
    }

    init {
        isClickable = true
        setOnClickListener { dismiss() }

        panel.orientation = LinearLayout.VERTICAL
        val r = 30f * d
        val bgd = GradientDrawable()
        bgd.setColor(Color.rgb(28, 27, 32))
        bgd.cornerRadii = floatArrayOf(r, r, r, r, 0f, 0f, 0f, 0f)
        if (land) card.background = bgd else panel.background = bgd
        panel.isClickable = true
        card.isClickable = true
        panel.setPadding(0, 0, 0, if (compact) dp(14f) else dp(34f))

        val handle = View(act)
        val hd = GradientDrawable()
        hd.setColor(Color.rgb(142, 140, 147))
        hd.cornerRadius = 4f * d
        handle.background = hd
        val hlp = LinearLayout.LayoutParams(dp(36f), dp(4f))
        hlp.gravity = Gravity.CENTER_HORIZONTAL
        hlp.topMargin = if (compact) dp(8f) else dp(14f)
        hlp.bottomMargin = if (compact) dp(8f) else dp(20f)
        panel.addView(handle, hlp)

        panel.addView(title("Theme", 0))
        panel.addView(scroller(bgRow))
        panel.addView(title("Vinyl", dp(12f)))
        panel.addView(scroller(discRow))
        panel.addView(title("Needle light", dp(12f)))
        panel.addView(scroller(needleRow))

        if (!land) panel.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    if (e.y < dp(56f)) {
                        dragging = true
                        dragStartY = e.rawY
                    }
                    dragging
                }
                MotionEvent.ACTION_MOVE -> {
                    if (dragging) panel.translationY = (e.rawY - dragStartY).coerceAtLeast(0f)
                    dragging
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    val was = dragging
                    dragging = false
                    if (was) {
                        if (panel.translationY > dp(90f)) dismiss()
                        else panel.animate().translationY(0f).setDuration(160).start()
                    }
                    was
                }
                else -> false
            }
        }

        if (land) {
            // کارت سمت چپ: حدود ۴۳٪ عرض و ۸۰٪ ارتفاع، چسبیده به پایین؛ محتوا داخلش اسکرول میشه
            val sw = resources.displayMetrics.widthPixels
            val sh = resources.displayMetrics.heightPixels
            val sv = android.widget.ScrollView(act)
            sv.isVerticalScrollBarEnabled = false
            sv.overScrollMode = View.OVER_SCROLL_NEVER
            sv.addView(panel, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            card.addView(sv, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
            val lp = LayoutParams((0.43f * sw).toInt(), (0.82f * sh).toInt(), Gravity.BOTTOM or Gravity.START)
            lp.leftMargin = (0.08f * sw).toInt()
            addView(card, lp)
        } else {
            addView(panel, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT, Gravity.BOTTOM))
        }
        refresh()

        mover.alpha = 0f
        mover.post {
            mover.translationY = mover.height.toFloat()
            mover.alpha = 1f
            mover.animate().translationY(0f).setDuration(260).setInterpolator(DecelerateInterpolator()).start()
        }
    }

    fun dismiss(then: (() -> Unit)? = null) {
        if (dismissing) return
        dismissing = true
        mover.animate().translationY(mover.height.toFloat()).setDuration(200).withEndAction {
            (parent as? ViewGroup)?.removeView(this)
            onDismissed?.invoke()
            then?.invoke()
        }.start()
    }

    fun refresh() {
        fillTheme()
        fillDisc()
        fillNeedle()
    }

    /** ردیف Theme: تم‌های آماده (پیش‌فرض، زرد، خاکستری، مشکی) + پس‌زمینه‌های گالری + دکمه‌ی + */
    private fun fillTheme() {
        bgRow.removeAllViews()
        val selFile = ThemeStore.selected(act, ThemeStore.BG)
        val cur = ScreenTheme.current(act)
        for (pr in ScreenTheme.ALL) {
            val v = item(false)
            v.bmp = if (pr.id == ScreenTheme.DEFAULT) defBg else ScreenTheme.swatch(pr, 200)
            v.chosen = selFile == null && cur.id == pr.id
            v.setOnClickListener {
                ThemeStore.select(act, ThemeStore.BG, null)
                ScreenTheme.select(act, pr.id)
                vinyl.reloadTheme()
                refresh()
            }
            bgRow.addView(v)
        }
        for (f in ThemeStore.list(act, ThemeStore.BG)) {
            val v = item(false)
            v.bmp = ThemeStore.decodeFile(f, 200)
            v.chosen = selFile != null && selFile.name == f.name
            v.setOnClickListener {
                ThemeStore.select(act, ThemeStore.BG, f)
                vinyl.reloadTheme()
                refresh()
            }
            v.setOnLongClickListener {
                if (ThemeStore.bgStyle(act, f) != null) {
                    MdDialog(act).title("Background")
                        .primary("Edit") { dismiss { act.openBgEditor(f) } }
                        .danger("Delete") { confirmDelete(ThemeStore.BG, f) }
                        .secondary("Close")
                        .show()
                } else {
                    confirmDelete(ThemeStore.BG, f)
                }
                true
            }
            bgRow.addView(v)
        }
        val add = item(false)
        add.plus = true
        add.setOnClickListener {
            MdDialog(act).title("Add background")
                .primary("Background editor") { dismiss { act.openBgEditor(null) } }
                .secondary("From gallery") { act.pickImage(ThemeStore.BG) }
                .show()
        }
        bgRow.addView(add)
    }

    /** ردیف چراغ سوزن: روشن/خاموش، Auto (رنگ از کاور هر آهنگ) و یه دایره‌ی رنگی برای رنگ ثابت */
    private fun fillNeedle() {
        needleRow.removeAllViews()
        val on = ScreenTheme.needleOn(act)
        val auto = ScreenTheme.needleAuto(act)
        val curColor = ScreenTheme.needleColor(act)

        fun pill(text: String, active: Boolean): TextView {
            val t = TextView(act)
            t.text = text
            t.setTextColor(Color.WHITE)
            t.textSize = 16f
            t.typeface = tf
            t.gravity = Gravity.CENTER
            val g = GradientDrawable()
            g.cornerRadius = dp(22f).toFloat()
            g.setColor(if (active) Color.rgb(108, 70, 222) else Color.rgb(58, 59, 68))
            t.background = g
            return t
        }

        val tog = pill(if (on) "On" else "Off", on)
        val tlp = LinearLayout.LayoutParams(dp(84f), dp(44f))
        tlp.marginEnd = dp(10f)
        tlp.topMargin = dp(2f)
        needleRow.addView(tog, tlp)
        tog.setOnClickListener {
            ScreenTheme.setNeedleOn(act, !on)
            vinyl.reloadTheme()
            refresh()
        }

        val autoBtn = pill("Auto", auto && on)
        val alp = LinearLayout.LayoutParams(dp(84f), dp(44f))
        alp.marginEnd = dp(14f)
        alp.topMargin = dp(2f)
        needleRow.addView(autoBtn, alp)
        autoBtn.setOnClickListener {
            ScreenTheme.setNeedleAuto(act, !auto)
            ScreenTheme.setNeedleOn(act, true)
            vinyl.reloadTheme()
            refresh()
        }

        val pick = DropletButton(act)
        pick.chosen = !auto && on
        pick.dim = !on
        needleRow.addView(pick, LinearLayout.LayoutParams(dp(44f), dp(44f)))
        pick.setOnClickListener {
            ColorPickerView.show(act, curColor ?: Color.rgb(253, 103, 58), "Needle light") { col ->
                ScreenTheme.setNeedleColor(act, col)
                ScreenTheme.setNeedleAuto(act, false)
                ScreenTheme.setNeedleOn(act, true)
                vinyl.reloadTheme()
                refresh()
            }
        }
    }

    private fun item(circle: Boolean): ThumbView {
        val v = ThumbView(act, circle)
        val sz = if (compact) 50f else 62f
        val lp = LinearLayout.LayoutParams(dp(sz), dp(sz))
        lp.marginEnd = dp(14f)
        v.layoutParams = lp
        return v
    }

    /** ردیف Vinyl: دیسک پیش‌فرض، سه دیسک آماده (Clear، Splatter، Marble)، دیسک‌های ساخته‌شده با ادیتور، دیسک‌های گالری و + */
    private fun fillDisc() {
        discRow.removeAllViews()
        val sel = ThemeStore.selected(act, ThemeStore.DISC)
        val styleOn = sel == null && DiscStyles.isOn(act)
        val cur = DiscStyles.load(act)
        val savedIdx = DiscStyles.savedIndex(act)

        val def = item(true)
        def.bmp = vinyl.defaultRecordPreview()
        def.chosen = sel == null && !styleOn
        def.setOnClickListener {
            ThemeStore.select(act, ThemeStore.DISC, null)
            DiscStyles.setOn(act, false)
            vinyl.reloadTheme()
            refresh()
        }
        def.setOnLongClickListener {
            discMenu("default", null)
            true
        }
        discRow.addView(def)

        for ((eff, _) in DiscStyles.EFFECTS) {
            val v = item(true)
            val pre = vinyl.resolveStyle(DiscStyles.preset(eff))
            v.bmp = thumbCache.getOrPut(pre.color * 8 + eff) { DiscStyles.thumb(act, pre, 200) }
            v.chosen = styleOn && savedIdx < 0 && cur.effect == eff
            v.setOnClickListener {
                ThemeStore.select(act, ThemeStore.DISC, null)
                DiscStyles.save(act, if (styleOn && savedIdx < 0 && cur.effect == eff) cur else pre)
                DiscStyles.setSavedIndex(act, -1)
                DiscStyles.setOn(act, true)
                vinyl.reloadTheme()
                refresh()
            }
            v.setOnLongClickListener {
                discMenu("fx$eff", null)
                true
            }
            discRow.addView(v)
        }

        // دیسک‌هایی که کاربر با ادیتور ساخته (نگه داشتن: ویرایش یا حذف)
        for ((i, st) in DiscStyles.listSaved(act).withIndex()) {
            val v = item(true)
            v.bmp = DiscStyles.thumb(act, st, 200)
            v.chosen = styleOn && savedIdx == i
            v.setOnClickListener {
                ThemeStore.select(act, ThemeStore.DISC, null)
                DiscStyles.save(act, st)
                DiscStyles.setSavedIndex(act, i)
                DiscStyles.setOn(act, true)
                vinyl.reloadTheme()
                refresh()
            }
            v.setOnLongClickListener {
                savedMenu(i)
                true
            }
            discRow.addView(v)
        }

        for (f in ThemeStore.list(act, ThemeStore.DISC)) {
            val v = item(true)
            v.bmp = ThemeStore.decodeFile(f, 200)
            v.chosen = sel != null && sel.name == f.name
            v.setOnClickListener {
                ThemeStore.select(act, ThemeStore.DISC, f)
                DiscStyles.setOn(act, false)
                vinyl.reloadTheme()
                refresh()
            }
            v.setOnLongClickListener {
                discMenu(f.name, f)
                true
            }
            discRow.addView(v)
        }

        val add = item(true)
        add.plus = true
        add.setOnClickListener {
            MdDialog(act).title("Add vinyl")
                .primary("Disc editor") { dismiss { act.openDiscEditor(-1) } }
                .secondary("From gallery") { act.pickImage(ThemeStore.DISC) }
                .show()
        }
        discRow.addView(add)
    }

    /** منوی دیسک ساخته‌شده با ادیتور: ویرایش یا حذف */
    private fun savedMenu(i: Int) {
        val dlg0 = MdDialog(act).title("Vinyl")
        dlg0.addView(
            MdDialog.toggleRow(act, "Real rotation", "The whole disc spins, not only the label", ThemeStore.realRotation(act, "saved$i")) { on ->
                ThemeStore.setRealRotation(act, "saved$i", on)
                vinyl.refreshSpinMode()
            }
        )
        dlg0.addView(pinRow("saved$i"))
        dlg0
            .primary("Edit") { dismiss { act.openDiscEditor(i) } }
            .danger("Delete") {
                MdDialog.confirm(act, null, "Delete this vinyl?", "Delete", true) {
                    val wasActive = DiscStyles.isOn(act) && DiscStyles.savedIndex(act) == i
                    DiscStyles.deleteSaved(act, i)
                    ThemeStore.onSavedDiscDeleted(act, i)
                    if (wasActive) DiscStyles.setOn(act, false)
                    vinyl.reloadTheme()
                    refresh()
                }
            }
            .secondary("Close")
            .show()
    }

    /** «Apply to widgets»: با روشن شدنش ویجت‌ها همیشه همین دیسک رو نشون میدن، حتی اگه دیسک اپ عوض شه */
    private fun pinRow(key: String) = MdDialog.toggleRow(
        act, "Apply to widgets", "Widgets always use this disc, even if you change the disc in the app",
        ThemeStore.widgetPinKey(act) == key
    ) { on ->
        if (on) ThemeStore.setWidgetPin(act, key)
        else if (ThemeStore.widgetPinKey(act) == key) ThemeStore.clearWidgetPin(act)
    }

    /** سویچ نسخه‌ی دیسک پیش‌فرض: Android (دیسک فعلی) یا iOS؛ روی خود اپ و ویجت‌ها اعمال میشه */
    private fun discVersionRow(): View {
        val box = LinearLayout(act)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(0, dp(8f), 0, dp(8f))
        val t = TextView(act)
        t.text = "Disc version"
        t.textSize = 18f
        t.setTextColor(Color.WHITE)
        t.typeface = Typeface.create(DarkUi.font(act), Typeface.BOLD)
        box.addView(t)
        val d = TextView(act)
        d.text = "Android or iOS look of the default disc"
        d.textSize = 13.5f
        d.setTextColor(Color.rgb(150, 151, 162))
        d.typeface = DarkUi.font(act)
        box.addView(d)
        val row = LinearLayout(act)
        row.orientation = LinearLayout.HORIZONTAL
        val lp0 = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp0.topMargin = dp(10f)
        box.addView(row, lp0)
        val names = arrayOf("Android", "iOS")
        val pills = ArrayList<TextView>()
        fun paint() {
            val ios = ThemeStore.iosDisc(act)
            for (i in pills.indices) {
                val active = (i == 1) == ios
                val g = GradientDrawable()
                g.cornerRadius = dp(22f).toFloat()
                g.setColor(if (active) Color.rgb(108, 70, 222) else Color.rgb(58, 59, 68))
                pills[i].background = g
            }
        }
        for (i in names.indices) {
            val p = TextView(act)
            p.text = names[i]
            p.setTextColor(Color.WHITE)
            p.textSize = 16f
            p.typeface = tf
            p.gravity = Gravity.CENTER
            val lp = LinearLayout.LayoutParams(0, dp(44f), 1f)
            if (i == 0) lp.marginEnd = dp(10f)
            row.addView(p, lp)
            pills.add(p)
            p.setOnClickListener {
                ThemeStore.setIosDisc(act, i == 1)
                vinyl.refreshDefaultDisc()
                paint()
                box.postDelayed({ refresh() }, 700L)
            }
        }
        paint()
        return box
    }

    /** نگه داشتن انگشت روی یه دیسک: چرخش واقعی، ثابت کردن روی ویجت‌ها (و حذف برای دیسک‌های شخصی) */
    private fun discMenu(key: String, file: File?) {
        val dlg = MdDialog(act).title("Vinyl")
        dlg.addView(
            MdDialog.toggleRow(act, "Real rotation", "The whole disc spins, not only the label", ThemeStore.realRotation(act, key)) { on ->
                ThemeStore.setRealRotation(act, key, on)
                vinyl.refreshSpinMode()
            }
        )
        dlg.addView(pinRow(key))
        if (key == "default") dlg.addView(discVersionRow())
        if (file != null) dlg.danger("Delete") { confirmDelete(ThemeStore.DISC, file) }
        dlg.secondary("Close")
        dlg.show()
    }

    private fun confirmDelete(kind: String, f: File) {
        MdDialog.confirm(act, null, "Delete this image?", "Delete", true) {
            ThemeStore.delete(act, kind, f)
            vinyl.reloadTheme()
            refresh()
        }
    }
}


/** دکمه‌ی انتخاب رنگ چراغ سوزن: دایره‌ی شیشه‌ای (مثل بقیه‌ی دکمه‌ها) با لوگوی قطره‌ی سفید با اندازه‌ی متوسط */
class DropletButton(act: VinylActivity) : View(act) {
    var chosen = false
    var dim = false
    private val d = resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ip = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val icon: Bitmap? = android.graphics.BitmapFactory.decodeResource(resources, R.drawable.ic_droplet)
    private val dst = RectF()

    override fun onDraw(c: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val r = min(width, height) / 2f
        p.style = Paint.Style.FILL
        // مثل دکمه‌های صفحه‌ی اصلی: کمی تیره‌تر از کپسول‌ها (وقتی Button blur روشنه)
        val glass = ThemeStore.buttonBlur(context)
        p.color = if (chosen) Color.rgb(108, 70, 222) else if (glass) Color.rgb(44, 45, 53) else Color.rgb(58, 59, 68)
        c.drawCircle(cx, cy, r, p)
        if (!chosen) {
            p.style = Paint.Style.STROKE
            p.strokeWidth = 1.2f * d
            p.color = Color.argb(46, 255, 255, 255)
            c.drawCircle(cx, cy, r - 0.6f * d, p)
        }
        val ic = icon ?: return
        val h = r * 1.0f          // قطره‌ی متوسط: حدود نصف ارتفاع دایره
        val w = h * ic.width / ic.height
        dst.set(cx - w / 2f, cy - h / 2f, cx + w / 2f, cy + h / 2f)
        ip.alpha = if (dim) 120 else 255
        c.drawBitmap(ic, null, dst, ip)
    }
}
