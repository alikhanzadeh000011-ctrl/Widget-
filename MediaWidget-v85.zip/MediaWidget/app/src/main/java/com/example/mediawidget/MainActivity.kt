package com.example.mediawidget

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.Switch
import android.widget.TextView
import android.content.res.ColorStateList
import android.graphics.Color

/** صفحه‌ی تنظیمات: ظاهر تیره و فول‌اسکرین (فقط گزینه‌های خود اپ) */
class MainActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        DarkUi.guard(this) { build() }
    }

    private fun build() {
        val screen = DarkUi.Screen(this, "Settings")
        val prefs = getSharedPreferences("ui", MODE_PRIVATE)

        screen.body.addView(DarkUi.sectionLabel(this, "General"))
        val general = DarkUi.card(this)
        DarkUi.addRow(general, "Permissions", null, DarkUi.glyph(this, GlyphView.CHEVRON, 28f)) {
            startActivity(Intent(this, PermissionsActivity::class.java))
        }

        screen.body.addView(general)

        screen.body.addView(DarkUi.sectionLabel(this, "Music library"))
        val lib = DarkUi.card(this)
        val modeText = TextView(this)
        modeText.text = if (LibraryPrefs.mode(this) == LibraryPrefs.FOLDERS) "Folders" else "Albums"
        modeText.setTextColor(DarkUi.LABEL)
        modeText.textSize = 17f
        modeText.typeface = DarkUi.font(this)
        DarkUi.addRow(lib, "Show music by", "Group the 3D view by albums or folders", modeText) {
            val items = arrayOf("Albums", "Folders")
            MdDialog.choose(this, "Show music by", items, LibraryPrefs.mode(this)) { which ->
                LibraryPrefs.setMode(this, which)
                modeText.text = items[which]
            }
        }
        DarkUi.addRow(lib, "Hidden items", "Choose albums or folders to hide", DarkUi.glyph(this, GlyphView.CHEVRON, 28f)) {
            startActivity(Intent(this, HiddenActivity::class.java))
        }
        screen.body.addView(lib)
        screen.body.addView(DarkUi.sectionLabel(this, "Display"))
        val display = DarkUi.card(this)
        val sw = Switch(this)
        sw.isChecked = !prefs.getBoolean("hide_text", false)
        sw.thumbTintList = ColorStateList.valueOf(Color.WHITE)
        sw.trackTintList = ColorStateList(
            arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()),
            intArrayOf(DarkUi.PURPLE, Color.rgb(85, 86, 98))
        )
        sw.setOnCheckedChangeListener { _, on -> prefs.edit().putBoolean("hide_text", !on).apply() }
        DarkUi.addRow(display, "Song title and artist", "Show them under the vinyl", sw) { sw.toggle() }

        val blurSw = Switch(this)
        blurSw.isChecked = prefs.getBoolean("btn_blur", true)
        blurSw.thumbTintList = ColorStateList.valueOf(Color.WHITE)
        blurSw.trackTintList = ColorStateList(
            arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()),
            intArrayOf(DarkUi.PURPLE, Color.rgb(85, 86, 98))
        )
        blurSw.setOnCheckedChangeListener { _, on -> prefs.edit().putBoolean("btn_blur", on).apply() }
        DarkUi.addRow(display, "Button blur", "Glass blur behind the buttons (Android 12+)", blurSw) { blurSw.toggle() }

        // شدت چراغ سوزن: ۰ تا ۱۰۰ درصد
        val pctText = TextView(this)
        pctText.setTextColor(Color.WHITE)
        pctText.textSize = 16f
        pctText.typeface = DarkUi.font(this)
        pctText.text = ScreenTheme.needlePct(this).toString() + "%"
        val seek = android.widget.SeekBar(this)
        seek.max = 100
        seek.progress = ScreenTheme.needlePct(this)
        seek.progressTintList = ColorStateList.valueOf(DarkUi.PURPLE)
        seek.thumbTintList = ColorStateList.valueOf(Color.WHITE)
        seek.setOnSeekBarChangeListener(object : android.widget.SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: android.widget.SeekBar?, p: Int, fromUser: Boolean) {
                pctText.text = "$p%"
                if (fromUser) ScreenTheme.setNeedlePct(this@MainActivity, p)
            }

            override fun onStartTrackingTouch(sb: android.widget.SeekBar?) {}
            override fun onStopTrackingTouch(sb: android.widget.SeekBar?) {}
        })
        DarkUi.addRow(display, "Needle light intensity", "How bright the light at the needle tip is", pctText, null)
        val seekBox = LinearLayout(this)
        seekBox.setPadding(DarkUi.dp(this, 14f), 0, DarkUi.dp(this, 14f), DarkUi.dp(this, 12f))
        seekBox.addView(seek, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        display.addView(seekBox)
        screen.body.addView(display)

        val spacer = View(this)
        screen.body.addView(spacer, LinearLayout.LayoutParams(1, 0, 1f))
        val foot = TextView(this)
        foot.text = "Vinyl+"
        foot.setTextColor(DarkUi.LABEL)
        foot.textSize = 15f
        foot.typeface = DarkUi.font(this)
        foot.gravity = Gravity.CENTER
        foot.setPadding(0, DarkUi.dp(this, 36f), 0, 0)
        screen.body.addView(foot)

        screen.show()
    }
}
