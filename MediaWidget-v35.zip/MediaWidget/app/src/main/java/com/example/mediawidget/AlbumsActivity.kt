package com.example.mediawidget

import android.Manifest
import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.util.concurrent.Executors

/** صفحه‌ی آلبوم‌ها (یا پوشه‌ها): چیدمان ۳بعدی یا گالری؛ دیسک بالا-چپ، تغییر حالت بالا-راست */
class AlbumsActivity : Activity(), AlbumStackView.Listener {

    private lateinit var stack: AlbumStackView
    private lateinit var toggle: ToggleView
    private lateinit var discBtn: DiscView
    private lateinit var permPanel: LinearLayout
    private lateinit var emptyText: TextView
    private var loaded = false
    private lateinit var detail: AlbumDetailView
    private var detailOpen = false
    private var animating = false
    private var openAlbum: Album? = null
    private var theme: AlbumTheme? = null
    private val handler = Handler(Looper.getMainLooper())
    private val bgExec = Executors.newSingleThreadExecutor()
    @Volatile private var bgKey = "?"
    private var insTop = 0
    private var insBottom = 0
    private var insLeft = 0
    private val bgPoll = object : Runnable {
        override fun run() {
            pollBackdrop()
            handler.postDelayed(this, 3000L)
        }
    }

    private fun perm(): String =
        if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE

    private fun hasPerm(): Boolean = checkSelfPermission(perm()) == PackageManager.PERMISSION_GRANTED

    private fun dp(v: Float) = DarkUi.dp(this, v)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        DarkUi.guard(this) { build() }
    }

    @Suppress("DEPRECATION")
    private fun enterImmersive() {
        if (Build.VERSION.SDK_INT >= 30) {
            window.setDecorFitsSystemWindows(false)
            window.insetsController?.let {
                it.systemBarsBehavior = WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                it.hide(WindowInsets.Type.systemBars())
            }
        } else {
            window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_FULLSCREEN or
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) enterImmersive()
    }

    @Suppress("DEPRECATION")
    private fun build() {
        DarkUi.setupWindow(this)
        if (Build.VERSION.SDK_INT >= 28) {
            val lp = window.attributes
            lp.layoutInDisplayCutoutMode = android.view.WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            window.attributes = lp
        }
        enterImmersive()

        val root = FrameLayout(this)
        root.setBackgroundColor(DarkUi.BG)

        stack = AlbumStackView(this)
        stack.listener = this
        root.addView(stack, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        // دکمه‌ی تغییر حالت (بالا-راست)
        toggle = ToggleView(this)
        toggle.setOnClickListener {
            stack.toggleMode()
            toggle.grid = stack.isGrid()
            toggle.invalidate()
        }
        root.addView(toggle, FrameLayout.LayoutParams(dp(52f), dp(52f), Gravity.TOP or Gravity.END))

        // دکمه‌ی دیسک (بالا-چپ): برگشت به صفحه‌ی وینیل
        discBtn = DiscView(this)
        discBtn.setOnClickListener { finish() }
        root.addView(discBtn, FrameLayout.LayoutParams(dp(52f), dp(52f), Gravity.TOP or Gravity.START))

        emptyText = TextView(this)
        emptyText.text = "Nothing to show here"
        emptyText.setTextColor(DarkUi.LABEL)
        emptyText.textSize = 18f
        emptyText.typeface = DarkUi.font(this)
        emptyText.gravity = Gravity.CENTER
        emptyText.visibility = View.GONE
        root.addView(emptyText, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        permPanel = LinearLayout(this)
        permPanel.orientation = LinearLayout.VERTICAL
        permPanel.gravity = Gravity.CENTER
        permPanel.setPadding(dp(32f), 0, dp(32f), 0)
        val msg = TextView(this)
        msg.text = "Allow access to your music files to show your albums."
        msg.setTextColor(Color.WHITE)
        msg.textSize = 18f
        msg.typeface = DarkUi.font(this)
        msg.gravity = Gravity.CENTER
        msg.setLineSpacing(0f, 1.2f)
        permPanel.addView(msg)
        val btn = DarkUi.pill(this, "Allow access") { requestPermissions(arrayOf(perm()), 7) }
        val blp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        blp.topMargin = dp(22f)
        permPanel.addView(btn, blp)
        permPanel.visibility = View.GONE
        root.addView(permPanel, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        // صفحه‌ی آلبوم (بالای همه؛ فقط وقتی یه آلبوم باز شده)
        detail = AlbumDetailView(this)
        detail.visibility = View.GONE
        detail.host = object : AlbumDetailView.Host {
            override fun onBack() = closeDetail()
            override fun onTrack(list: List<Track>, index: Int) {
                askNotifPermission()
                TrackPlayer.play(this@AlbumsActivity, list, index, openAlbum, LibraryPrefs.mode(this@AlbumsActivity) == LibraryPrefs.FOLDERS)
            }
            override fun onPlayAll(list: List<Track>, shuffle: Boolean) {
                askNotifPermission()
                TrackPlayer.playAll(this@AlbumsActivity, list, shuffle, openAlbum, LibraryPrefs.mode(this@AlbumsActivity) == LibraryPrefs.FOLDERS)
            }
        }
        root.addView(detail, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        root.setOnApplyWindowInsetsListener { _, ins ->
            var top = ins.systemWindowInsetTop
            var left = ins.systemWindowInsetLeft
            var right = ins.systemWindowInsetRight
            val bottom = ins.systemWindowInsetBottom
            if (Build.VERSION.SDK_INT >= 28) {
                val cut = ins.displayCutout
                if (cut != null) {
                    top = maxOf(top, cut.safeInsetTop)
                    left = maxOf(left, cut.safeInsetLeft)
                    right = maxOf(right, cut.safeInsetRight)
                }
            }
            stack.setInsets(top, bottom)
            insTop = top
            insBottom = bottom
            insLeft = left
            detail.setInsets(top, bottom, left)
            val tl = toggle.layoutParams as FrameLayout.LayoutParams
            tl.topMargin = top + dp(14f)
            tl.rightMargin = right + dp(18f)
            toggle.layoutParams = tl
            val dl = discBtn.layoutParams as FrameLayout.LayoutParams
            dl.topMargin = top + dp(14f)
            dl.leftMargin = left + dp(18f)
            discBtn.layoutParams = dl
            ins
        }

        setContentView(root)
        root.requestApplyInsets()
        refreshState()
    }

    override fun onResume() {
        super.onResume()
        if (::stack.isInitialized) {
            refreshState()
            handler.removeCallbacks(bgPoll)
            handler.postDelayed(bgPoll, 300L)
        }
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(bgPoll)
    }

    /** پس‌زمینه‌ی پشته: همون بلرِ کاورِ آهنگ در حال پخش که تو صفحه‌ی وینیل هست */
    private fun pollBackdrop() {
        if (!::stack.isInitialized) return
        val w = stack.width
        val h = stack.height
        if (w <= 0 || h <= 0) return
        val app = applicationContext
        bgExec.execute {
            val info = try { MediaReader.read(app) } catch (e: Throwable) { null }
            val art = info?.art
            val key = if (art != null && info != null) info.key else ""
            if (key == bgKey) return@execute
            val bmp = if (art != null) {
                try { VinylArt.coverBackground(art, w, h) } catch (e: Throwable) { null }
            } else null
            runOnUiThread {
                if (!isDestroyed) {
                    bgKey = key
                    stack.setBackdrop(bmp)
                }
            }
        }
    }

    private fun refreshState() {
        if (hasPerm()) {
            permPanel.visibility = View.GONE
            if (!loaded) loadAlbums()
        } else {
            permPanel.visibility = View.VISIBLE
            stack.visibility = View.INVISIBLE
        }
    }

    private fun loadAlbums() {
        loaded = true
        val app = applicationContext
        val mode = LibraryPrefs.mode(app)
        Executors.newSingleThreadExecutor().execute {
            val list = AlbumRepo.loadVisible(app, mode)
            runOnUiThread {
                if (isDestroyed) return@runOnUiThread
                stack.visibility = View.VISIBLE
                stack.setAlbums(list)
                emptyText.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
            }
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        refreshState()
    }

    override fun onAlbumTap(album: Album, index: Int) {
        if (animating || detailOpen) return
        val w = stack.width
        if (w <= 0) return
        animating = true
        val mode = LibraryPrefs.mode(this)
        val cover = stack.bitmapFor(index)
        val th = AlbumTheme.from(if (stack.hasCover(index)) cover else null, album.color)
        theme = th
        openAlbum = album
        detail.bind(album, th, w, cover, mode == LibraryPrefs.FOLDERS)
        detail.visibility = View.VISIBLE
        stack.setFinalRect(detail.coverRect(w))
        stack.setFocusBitmap(null)
        stack.beginFocus(index)
        toggle.animate().alpha(0f).setDuration(200L).start()
        discBtn.animate().alpha(0f).setDuration(200L).start()

        // کاور بزرگ و ترک‌ها تو پس‌زمینه
        val app = applicationContext
        Executors.newSingleThreadExecutor().execute {
            val big = AlbumRepo.loadItemCover(app, album, 1000)
            val list = AlbumRepo.loadTracks(app, album, mode)
            runOnUiThread {
                if (isDestroyed || openAlbum !== album) return@runOnUiThread
                if (big != null) {
                    stack.setFocusBitmap(big)
                    detail.setCoverBitmap(big)
                }
                detail.setTracks(list)
            }
        }

        val anim = ValueAnimator.ofFloat(0f, 1f)
        anim.duration = 650L
        anim.addUpdateListener {
            val e = it.animatedValue as Float
            stack.setFocusProgress(e)
            stack.setGradient(th.top, th.bottom, (e * 1.4f).coerceIn(0f, 1f))
        }
        anim.addListener(object : AnimatorListenerAdapter() {
            override fun onAnimationEnd(animation: Animator) {
                animating = false
                detailOpen = true
                detail.reveal()
                // کاور واقعی نشون داده شد؛ پشته دیگه کاور پروازی رو نکشه
                handler.postDelayed({ if (detailOpen) stack.setFocusHold(true) }, 90L)
            }
        })
        anim.start()
    }

    /** برگشت از صفحه‌ی آلبوم: انیمیشن باز شدن برعکس */
    private fun closeDetail() {
        if (animating || !detailOpen) return
        val th = theme ?: return
        animating = true
        detail.scrollToTop {
          stack.setFocusHold(false)
          detail.hideContent {
            val anim = ValueAnimator.ofFloat(1f, 0f)
            anim.duration = 520L
            anim.addUpdateListener {
                val e = it.animatedValue as Float
                stack.setFocusProgress(e)
                stack.setGradient(th.top, th.bottom, (e * 1.4f).coerceIn(0f, 1f))
            }
            anim.addListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: Animator) {
                    stack.endFocus()
                    detail.visibility = View.GONE
                    detailOpen = false
                    animating = false
                    openAlbum = null
                    toggle.animate().alpha(1f).setDuration(200L).start()
                    discBtn.animate().alpha(1f).setDuration(200L).start()
                }
            })
            anim.start()
          }
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (animating) return
        if (detailOpen) {
            closeDetail()
            return
        }
        @Suppress("DEPRECATION")
        super.onBackPressed()
    }

    /** اندروید ۱۳ به بالا: برای اعلان پخش یه بار مجوز اعلان‌ها رو می‌پرسیم (پخش بدون اون هم کار می‌کنه) */
    private fun askNotifPermission() {
        if (Build.VERSION.SDK_INT < 33) return
        if (LibraryPrefs.askedNotifPermission(this)) return
        if (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) return
        LibraryPrefs.setAskedNotifPermission(this)
        requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 77)
    }

    /** نگه داشتن انگشت روی یک کارت: پیشنهاد مخفی کردن */
    override fun onAlbumLongPress(album: Album, index: Int) {
        val mode = LibraryPrefs.mode(this)
        AlertDialog.Builder(this)
            .setTitle(album.title)
            .setMessage("Hide this " + (if (mode == LibraryPrefs.FOLDERS) "folder" else "album") + "? You can show it again from Settings > Hidden items.")
            .setPositiveButton("Hide") { _, _ ->
                LibraryPrefs.setHidden(this, mode, album.key, true)
                loaded = false
                loadAlbums()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    /** دکمه‌ی گرد بالا-راست: آیکن شبکه (حالت ۳بعدی) یا آیکن پشته (حالت گالری) */
    private class ToggleView(ctx: Activity) : View(ctx) {
        var grid = false
        private val p = Paint(Paint.ANTI_ALIAS_FLAG)
        private val r = RectF()

        override fun onDraw(c: Canvas) {
            val w = width.toFloat()
            val cx = w / 2f
            val cy = height / 2f
            p.style = Paint.Style.FILL
            p.color = Color.argb(110, 0, 0, 0)
            c.drawCircle(cx, cy, w / 2f, p)
            p.color = Color.WHITE
            val u = w / 52f
            if (!grid) {
                val s = 8f * u
                val g = 4f * u
                for (i in 0..1) for (j in 0..1) {
                    val x = cx - s - g / 2f + i * (s + g)
                    val y = cy - s - g / 2f + j * (s + g)
                    r.set(x, y, x + s, y + s)
                    c.drawRoundRect(r, 2f * u, 2f * u, p)
                }
            } else {
                for (i in 0..2) {
                    val y = cy - 9f * u + i * 9f * u
                    val inset = (2 - i) * 2.5f * u
                    r.set(cx - 12f * u + inset, y - 3f * u, cx + 12f * u - inset, y + 3f * u)
                    c.drawRoundRect(r, 1.5f * u, 1.5f * u, p)
                }
            }
        }
    }

    /** دکمه‌ی گرد بالا-چپ با لوگوی دیسک (برگشت به صفحه‌ی وینیل) */
    private class DiscView(ctx: Activity) : View(ctx) {
        private val p = Paint(Paint.ANTI_ALIAS_FLAG)

        override fun onDraw(c: Canvas) {
            val w = width.toFloat()
            val cx = w / 2f
            val cy = height / 2f
            p.style = Paint.Style.FILL
            p.color = Color.argb(110, 0, 0, 0)
            c.drawCircle(cx, cy, w / 2f, p)
            // لوگوی دیسک: حلقه‌ی بیرونی کامل، حلقه‌ی داخلی کامل و نقطه‌ی وسط (سفید)
            p.color = Color.WHITE
            p.style = Paint.Style.STROKE
            p.strokeWidth = w * 0.05f
            c.drawCircle(cx, cy, w * 0.27f, p)
            p.strokeWidth = w * 0.04f
            c.drawCircle(cx, cy, w * 0.155f, p)
            p.style = Paint.Style.FILL
            c.drawCircle(cx, cy, w * 0.045f, p)
        }
    }
}
