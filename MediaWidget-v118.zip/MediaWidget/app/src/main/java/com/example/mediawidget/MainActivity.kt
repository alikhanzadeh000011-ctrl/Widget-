package com.example.mediawidget

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.Switch
import android.widget.TextView
import android.content.res.ColorStateList
import android.graphics.Color

/** صفحه‌ی تنظیمات: ظاهر تیره و فول‌اسکرین (فقط گزینه‌های خود اپ) */
class MainActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        DarkUi.guard(this) { build() }
    }

    private fun openSection(name: String) {
        startActivity(Intent(this, SettingsSectionActivity::class.java).putExtra("section", name))
    }

    private fun build() {
        val screen = DarkUi.Screen(this, "Settings")

        val chev = { DarkUi.glyph(this, GlyphView.CHEVRON, 28f) }
        val general = DarkUi.card(this)
        DarkUi.addRow(general, "Permissions", null, chev()) {
            startActivity(Intent(this, PermissionsActivity::class.java))
        }
        DarkUi.addRow(general, "Players", "Choose which music players the app works with", chev()) {
            startActivity(Intent(this, PlayersActivity::class.java))
        }
        DarkUi.addRow(general, "Music library", "Show music by, hidden items", chev()) { openSection("library") }
        DarkUi.addRow(general, "Display", "Title, button blur, needle light", chev()) { openSection("display") }
        DarkUi.addRow(general, "Album gyro", "Tilt, sensitivity, direction", chev()) { openSection("gyro") }
        val top = android.widget.Space(this)
        screen.body.addView(top, LinearLayout.LayoutParams(1, DarkUi.dp(this, 6f)))
        screen.body.addView(general)

        val spacer = View(this)
        screen.body.addView(spacer, LinearLayout.LayoutParams(1, 0, 1f))
        val foot = TextView(this)
        foot.text = "Vinyl+"
        foot.setTextColor(DarkUi.LABEL)
        foot.textSize = 15f
        foot.typeface = DarkUi.font(this)
        foot.gravity = Gravity.CENTER
        foot.setPadding(0, DarkUi.dp(this, 36f), 0, 0)
        screen.body.addView(foot)

        screen.show()
    }
}
