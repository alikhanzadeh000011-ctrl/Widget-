package com.example.mediawidget

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.os.SystemClock
import android.view.View

/**
 * پوشش نرم موقع چرخش صفحه: رنگ‌های محو پس‌زمینه‌ی قبلی (بدون دیسک و بدون جزئیات) تمام‌صفحه نشون داده میشه
 * تا چیدمان جدید زیرش ساخته بشه؛ بعد نرم محو میشه و چیدمان جدید کامل دیده میشه. هیچ صفحه‌ی سیاهی دیده نمیشه.
 */
class FadeCoverView(ctx: Context, private var tiny: Bitmap?, private var snap: Bitmap? = null, private val sign: Float = 1f) : View(ctx) {

    /** پیشرفت انیمیشن چرخش (۰ تا ۱) وقتی عکس صحنه‌ی قبلی (snap) داریم */
    var prog = 0f
        set(v) {
            field = v
            invalidate()
        }
    val hasSnap: Boolean get() = snap != null

    private val p = Paint(Paint.FILTER_BITMAP_FLAG)
    private val dst = Rect()
    private var fadeStart = 0L
    private var done = false
    var onDone: (() -> Unit)? = null

    fun fadeOut() {
        if (fadeStart != 0L || done) return
        fadeStart = SystemClock.uptimeMillis()
        postInvalidateOnAnimation()
    }

    fun release() {
        onDone = null
        done = true
        tiny?.recycle()
        tiny = null
        snap?.recycle()
        snap = null
    }

    override fun onDraw(canvas: Canvas) {
        if (done) return
        val sb = snap
        if (sb != null && !sb.isRecycled) {
            // صحنه‌ی قبلی: اول ۹۰ درجه چرخیده (همون که روی صفحه‌ی چرخیده دیده میشد)، بعد صاف میشه، کوچیک و محو میشه
            val w = width.toFloat()
            val h = height.toFloat()
            val bw = sb.width.toFloat()
            val bh = sb.height.toFloat()
            val e = prog
            val s0 = minOf(w / bh, h / bw)
            val s1 = minOf(w / bw, h / bh)
            val sc = s0 + (s1 - s0) * e
            // محو شدن سریع‌تر: تا نصفه‌ی انیمیشن کامل محو میشه
            val fo = (e / FADE_OUT_AT).coerceIn(0f, 1f)
            p.alpha = (255f * (1f - fo * fo * (3f - 2f * fo))).toInt()
            canvas.save()
            canvas.translate(w / 2f, h / 2f)
            canvas.rotate(-90f * sign * (1f - e))
            canvas.scale(sc, sc)
            canvas.drawBitmap(sb, -bw / 2f, -bh / 2f, p)
            canvas.restore()
            return
        }
        var a = 1f
        if (fadeStart != 0L) {
            val t = ((SystemClock.uptimeMillis() - fadeStart) / FADE_MS.toFloat()).coerceIn(0f, 1f)
            a = 1f - t * t * (3f - 2f * t)
        }
        val b = tiny
        if (b != null && !b.isRecycled) {
            dst.set(0, 0, width, height)
            p.alpha = (255f * a).toInt()
            canvas.drawBitmap(b, null, dst, p)
        } else {
            canvas.drawColor(Color.argb((255f * a).toInt(), 34, 34, 40))
        }
        if (fadeStart != 0L) {
            if (a <= 0f) {
                done = true
                val cb = onDone
                post { cb?.invoke() }
            } else {
                postInvalidateOnAnimation()
            }
        }
    }

    companion object {
        const val FADE_MS = 90L
        /** نقطه‌ای از انیمیشن چرخش (۰ تا ۱) که صحنه‌ی قبلی کامل محو شده */
        const val FADE_OUT_AT = 0.5f
    }
}
