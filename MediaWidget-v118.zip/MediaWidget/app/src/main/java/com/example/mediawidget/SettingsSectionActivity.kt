package com.example.mediawidget

import android.app.Activity
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.os.Bundle
import android.widget.LinearLayout
import android.widget.Switch
import android.widget.TextView

/** صفحه‌ی یک دسته از تنظیمات: library / display / gyro (از صفحه‌ی اصلی تنظیمات باز میشه) */
class SettingsSectionActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        DarkUi.guard(this) { build() }
    }

    private fun build() {
        val section = intent.getStringExtra("section") ?: "display"
        val title = when (section) {
            "library" -> "Music library"
            "gyro" -> "Album gyro"
            else -> "Display"
        }
        val screen = DarkUi.Screen(this, title)
        val prefs = getSharedPreferences("ui", MODE_PRIVATE)
        when (section) {
            "library" -> {
        val lib = DarkUi.card(this)
        val modeText = TextView(this)
        modeText.text = if (LibraryPrefs.mode(this) == LibraryPrefs.FOLDERS) "Folders" else "Albums"
        modeText.setTextColor(DarkUi.LABEL)
        modeText.textSize = 17f
        modeText.typeface = DarkUi.font(this)
        DarkUi.addRow(lib, "Show music by", "Group the 3D view by albums or folders", modeText) {
            val items = arrayOf("Albums", "Folders")
            MdDialog.choose(this, "Show music by", items, LibraryPrefs.mode(this)) { which ->
                LibraryPrefs.setMode(this, which)
                modeText.text = items[which]
            }
        }
        DarkUi.addRow(lib, "Hidden items", "Choose albums or folders to hide", DarkUi.glyph(this, GlyphView.CHEVRON, 28f)) {
            startActivity(Intent(this, HiddenActivity::class.java))
        }
        screen.body.addView(lib)
            }
            "gyro" -> {
        val gyro = DarkUi.card(this)
        val gyOn = DarkUi.styledSwitch(this, prefs.getBoolean("gyro_on", true))
        gyOn.setOnCheckedChangeListener { _, on -> prefs.edit().putBoolean("gyro_on", on).apply() }
        DarkUi.addRow(gyro, "Gyro", "Tilt the phone to move the albums", gyOn) { gyOn.toggle() }


        val gyText = TextView(this)
        gyText.setTextColor(Color.WHITE)
        gyText.textSize = 16f
        gyText.typeface = DarkUi.font(this)
        val gyNow = prefs.getInt("gyro_sens", 50)
        gyText.text = if (gyNow == 0) "Off" else "$gyNow%"
        val gySeek = android.widget.SeekBar(this)
        gySeek.max = 100
        gySeek.progress = gyNow
        gySeek.progressTintList = ColorStateList.valueOf(DarkUi.PURPLE)
        gySeek.thumbTintList = ColorStateList.valueOf(Color.WHITE)
        gySeek.setOnSeekBarChangeListener(object : android.widget.SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: android.widget.SeekBar?, p: Int, fromUser: Boolean) {
                gyText.text = if (p == 0) "Off" else "$p%"
                if (fromUser) prefs.edit().putInt("gyro_sens", p).apply()
            }

            override fun onStartTrackingTouch(sb: android.widget.SeekBar?) {}
            override fun onStopTrackingTouch(sb: android.widget.SeekBar?) {}
        })
        DarkUi.addRow(gyro, "Sensitivity", "How strongly the albums follow the tilt", gyText, null)
        val gyBox = LinearLayout(this)
        gyBox.setPadding(DarkUi.dp(this, 14f), 0, DarkUi.dp(this, 14f), DarkUi.dp(this, 12f))
        gyBox.addView(gySeek, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        gyro.addView(gyBox)
        val gyInv = DarkUi.styledSwitch(this, prefs.getBoolean("gyro_inv", false))
        gyInv.setOnCheckedChangeListener { _, on -> prefs.edit().putBoolean("gyro_inv", on).apply() }
        DarkUi.addRow(gyro, "Invert direction", "Flip the tilt direction if it feels reversed", gyInv) { gyInv.toggle() }
        screen.body.addView(gyro)
            }
            else -> {
        val display = DarkUi.card(this)
        val sw = Switch(this)
        sw.isChecked = !prefs.getBoolean("hide_text", false)
        sw.thumbTintList = ColorStateList.valueOf(Color.WHITE)
        sw.trackTintList = ColorStateList(
            arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()),
            intArrayOf(DarkUi.PURPLE, Color.rgb(85, 86, 98))
        )
        sw.setOnCheckedChangeListener { _, on -> prefs.edit().putBoolean("hide_text", !on).apply() }
        DarkUi.addRow(display, "Song title and artist", "Show them under the vinyl", sw) { sw.toggle() }

        val blurSw = Switch(this)
        blurSw.isChecked = prefs.getBoolean("btn_blur", true)
        blurSw.thumbTintList = ColorStateList.valueOf(Color.WHITE)
        blurSw.trackTintList = ColorStateList(
            arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()),
            intArrayOf(DarkUi.PURPLE, Color.rgb(85, 86, 98))
        )
        blurSw.setOnCheckedChangeListener { _, on -> prefs.edit().putBoolean("btn_blur", on).apply() }
        DarkUi.addRow(display, "Button blur", "Glass blur behind the buttons (Android 12+)", blurSw) { blurSw.toggle() }

        // شدت چراغ سوزن: ۰ تا ۱۰۰ درصد
        val pctText = TextView(this)
        pctText.setTextColor(Color.WHITE)
        pctText.textSize = 16f
        pctText.typeface = DarkUi.font(this)
        pctText.text = ScreenTheme.needlePct(this).toString() + "%"
        val seek = android.widget.SeekBar(this)
        seek.max = 100
        seek.progress = ScreenTheme.needlePct(this)
        seek.progressTintList = ColorStateList.valueOf(DarkUi.PURPLE)
        seek.thumbTintList = ColorStateList.valueOf(Color.WHITE)
        seek.setOnSeekBarChangeListener(object : android.widget.SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: android.widget.SeekBar?, p: Int, fromUser: Boolean) {
                pctText.text = "$p%"
                if (fromUser) ScreenTheme.setNeedlePct(this@SettingsSectionActivity, p)
            }

            override fun onStartTrackingTouch(sb: android.widget.SeekBar?) {}
            override fun onStopTrackingTouch(sb: android.widget.SeekBar?) {}
        })
        DarkUi.addRow(display, "Needle light intensity", "How bright the light at the needle tip is", pctText, null)
        val seekBox = LinearLayout(this)
        seekBox.setPadding(DarkUi.dp(this, 14f), 0, DarkUi.dp(this, 14f), DarkUi.dp(this, 12f))
        seekBox.addView(seek, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        display.addView(seekBox)
        screen.body.addView(display)
            }
        }
        screen.show()
    }
}
