package com.example.mediawidget

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.Switch
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (24 * resources.displayMetrics.density).toInt()

        val message = TextView(this).apply {
            text = "1) Allow Notification access for Media Widget.\n" +
                "2) Home screen: long press > Widgets > Media Widget.\n" +
                "3) For the Library widget: choose your album folders below."
            textSize = 16f
            setPadding(0, 0, 0, pad)
        }
        val accessButton = Button(this).apply {
            text = "Open access settings"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
            }
        }
        val tilesButton = Button(this).apply {
            text = "Library widget: choose folders"
            setOnClickListener {
                startActivity(Intent(this@MainActivity, TilesActivity::class.java))
            }
        }

        val prefs = getSharedPreferences("ui", MODE_PRIVATE)
        val hideSwitch = Switch(this).apply {
            text = "Hide song title and artist on the vinyl screen"
            isChecked = prefs.getBoolean("hide_text", false)
            setPadding(0, pad, 0, 0)
            setOnCheckedChangeListener { _, on -> prefs.edit().putBoolean("hide_text", on).apply() }
        }

        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(pad, pad, pad, pad)
            addView(message)
            addView(accessButton)
            addView(tilesButton)
            addView(hideSwitch)
        })
    }
}
