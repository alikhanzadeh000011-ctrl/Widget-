package com.example.mediawidget

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.os.SystemClock
import android.view.View

/**
 * پوشش نرم موقع چرخش صفحه: رنگ‌های محو پس‌زمینه‌ی قبلی (بدون دیسک و بدون جزئیات) تمام‌صفحه نشون داده میشه
 * تا چیدمان جدید زیرش ساخته بشه؛ بعد نرم محو میشه و چیدمان جدید کامل دیده میشه. هیچ صفحه‌ی سیاهی دیده نمیشه.
 */
class FadeCoverView(ctx: Context, private var tiny: Bitmap?) : View(ctx) {

    private val p = Paint(Paint.FILTER_BITMAP_FLAG)
    private val dst = Rect()
    private var fadeStart = 0L
    private var done = false
    var onDone: (() -> Unit)? = null

    fun fadeOut() {
        if (fadeStart != 0L || done) return
        fadeStart = SystemClock.uptimeMillis()
        postInvalidateOnAnimation()
    }

    fun release() {
        onDone = null
        done = true
        tiny?.recycle()
        tiny = null
    }

    override fun onDraw(canvas: Canvas) {
        if (done) return
        var a = 1f
        if (fadeStart != 0L) {
            val t = ((SystemClock.uptimeMillis() - fadeStart) / FADE_MS.toFloat()).coerceIn(0f, 1f)
            a = 1f - t * t * (3f - 2f * t)
        }
        val b = tiny
        if (b != null && !b.isRecycled) {
            dst.set(0, 0, width, height)
            p.alpha = (255f * a).toInt()
            canvas.drawBitmap(b, null, dst, p)
        } else {
            canvas.drawColor(Color.argb((255f * a).toInt(), 34, 34, 40))
        }
        if (fadeStart != 0L) {
            if (a <= 0f) {
                done = true
                val cb = onDone
                post { cb?.invoke() }
            } else {
                postInvalidateOnAnimation()
            }
        }
    }

    companion object {
        const val FADE_MS = 320L
    }
}
