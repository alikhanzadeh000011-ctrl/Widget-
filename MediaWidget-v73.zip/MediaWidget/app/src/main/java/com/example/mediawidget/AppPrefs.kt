package com.example.mediawidget

import android.content.Context

/** تنظیمات کوچیک اپ: آخرین پلیری که آهنگ پخش کرده (برای باز کردنش با لمس ویجت) */
object AppPrefs {
    fun lastPlayer(ctx: Context): String =
        ctx.getSharedPreferences("state", Context.MODE_PRIVATE).getString("last_pkg", "") ?: ""

    fun setLastPlayer(ctx: Context, pkg: String) {
        ctx.getSharedPreferences("state", Context.MODE_PRIVATE).edit().putString("last_pkg", pkg).apply()
    }

    /** همه‌ی پلیرهایی که تا حالا آهنگ پخش کردن (برای لیست انتخاب پلیر در تنظیمات ویجت) */
    fun seen(ctx: Context): Set<String> =
        ctx.getSharedPreferences("state", Context.MODE_PRIVATE).getStringSet("seen_pkgs", emptySet())?.toSet() ?: emptySet()

    fun addSeen(ctx: Context, pkg: String) {
        val p = ctx.getSharedPreferences("state", Context.MODE_PRIVATE)
        val cur = p.getStringSet("seen_pkgs", emptySet()) ?: emptySet()
        if (pkg in cur) return
        p.edit().putStringSet("seen_pkgs", HashSet(cur).also { it.add(pkg) }).apply()
    }
}
