package com.example.mediawidget

import android.content.ComponentName
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.service.notification.NotificationListenerService

/**
 * این سرویس برای گرفتن اجازه‌ی دسترسی به MediaSessionها وجود داره
 * (کاربر باید توی Settings > Notification access فعالش کنه)
 * و با هر تغییر آهنگ یا وضعیت پخش ویجت‌ها رو آپدیت می‌کنه.
 */
class MediaListenerService : NotificationListenerService() {

    private var msm: MediaSessionManager? = null
    private var controllers: List<MediaController> = emptyList()
    private val component by lazy { ComponentName(this, MediaListenerService::class.java) }
    private val handler = Handler(Looper.getMainLooper())

    private val sessionsListener = MediaSessionManager.OnActiveSessionsChangedListener { list ->
        bind(list.orEmpty())
    }

    private val callback = object : MediaController.Callback() {
        override fun onMetadataChanged(metadata: MediaMetadata?) = refresh()
        override fun onPlaybackStateChanged(state: PlaybackState?) = refresh()
        override fun onSessionDestroyed() = refresh()
    }

    private fun refresh() = WidgetRenderer.updateAll(this)

    override fun onListenerConnected() {
        val m = getSystemService(MediaSessionManager::class.java)
        msm = m
        m.addOnActiveSessionsChangedListener(sessionsListener, component)
        bind(m.getActiveSessions(component))
    }

    override fun onListenerDisconnected() {
        msm?.removeOnActiveSessionsChangedListener(sessionsListener)
        controllers.forEach { it.unregisterCallback(callback) }
        controllers = emptyList()
    }

    override fun onDestroy() {
        super.onDestroy()
    }

    private fun bind(list: List<MediaController>) {
        controllers.forEach { it.unregisterCallback(callback) }
        controllers = list
        list.forEach { it.registerCallback(callback) }
        refresh()
    }

}
