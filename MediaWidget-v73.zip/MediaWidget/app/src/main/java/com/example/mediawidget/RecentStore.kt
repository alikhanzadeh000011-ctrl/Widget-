package com.example.mediawidget

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream

/** آخرین آهنگ‌های پخش‌شده (اسم، خواننده و کاور کوچیک) برای ویجت Now Playing بزرگ */
object RecentStore {

    class Item(val key: String, val title: String, val artist: String)

    private const val PREF = "recent"
    private const val MAX = 12

    private fun prefs(ctx: Context) = ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE)

    private fun file(ctx: Context, key: String) = File(ctx.filesDir, "recent_" + Integer.toHexString(key.hashCode()) + ".jpg")

    private fun load(ctx: Context): MutableList<Item> {
        val out = ArrayList<Item>()
        try {
            val arr = JSONArray(prefs(ctx).getString("items", "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(Item(o.getString("k"), o.getString("t"), o.getString("a")))
            }
        } catch (e: Exception) {
        }
        return out
    }

    private fun store(ctx: Context, list: List<Item>) {
        val arr = JSONArray()
        for (it in list) {
            val o = JSONObject()
            o.put("k", it.key)
            o.put("t", it.title)
            o.put("a", it.artist)
            arr.put(o)
        }
        prefs(ctx).edit().putString("items", arr.toString()).apply()
    }

    fun keyOf(info: MediaInfo): String = info.title + "|" + info.artist

    /** وقتی آهنگ عوض شد، به لیست آخرین‌ها اضافه‌ش می‌کنه */
    @Synchronized
    fun record(ctx: Context, info: MediaInfo) {
        if (!info.hasMedia || info.title.isBlank()) return
        val k = keyOf(info)
        val list = load(ctx)
        if (list.firstOrNull()?.key == k) return
        val art = info.art
        if (art != null) {
            try {
                val side = 360
                val m = minOf(art.width, art.height)
                val sq = Bitmap.createBitmap(art, (art.width - m) / 2, (art.height - m) / 2, m, m)
                val small = Bitmap.createScaledBitmap(sq, side, side, true)
                FileOutputStream(file(ctx, k)).use { small.compress(Bitmap.CompressFormat.JPEG, 86, it) }
            } catch (e: Exception) {
            }
        }
        list.removeAll { it.key == k }
        list.add(0, Item(k, info.title, info.artist))
        while (list.size > MAX) {
            val r = list.removeAt(list.size - 1)
            file(ctx, r.key).delete()
        }
        store(ctx, list)
    }

    /** n آهنگ آخر (به‌جز آهنگ فعلی) با کاورشون */
    @Synchronized
    fun recent(ctx: Context, excludeKey: String, n: Int): List<Pair<Item, Bitmap?>> {
        val out = ArrayList<Pair<Item, Bitmap?>>()
        for (it in load(ctx)) {
            if (it.key == excludeKey) continue
            val f = file(ctx, it.key)
            val b = if (f.exists()) BitmapFactory.decodeFile(f.path) else null
            out.add(Pair(it, b))
            if (out.size >= n) break
        }
        return out
    }
}

/** آهنگ‌های لایک‌شده (فقط داخل خود اپ) */
object Favorites {
    private fun prefs(ctx: Context) = ctx.getSharedPreferences("favorites", Context.MODE_PRIVATE)

    fun isLiked(ctx: Context, key: String): Boolean = prefs(ctx).getStringSet("set", emptySet())?.contains(key) == true

    fun toggle(ctx: Context, key: String): Boolean {
        val cur = HashSet(prefs(ctx).getStringSet("set", emptySet()) ?: emptySet())
        val now = if (cur.contains(key)) { cur.remove(key); false } else { cur.add(key); true }
        prefs(ctx).edit().putStringSet("set", cur).apply()
        return now
    }
}
