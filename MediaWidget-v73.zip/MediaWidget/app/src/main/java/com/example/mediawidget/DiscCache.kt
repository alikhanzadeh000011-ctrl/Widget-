package com.example.mediawidget

import android.content.Context
import android.graphics.Bitmap
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.nio.ByteBuffer

/**
 * کش دیسک‌های ساخته‌شده با Disc editor (بدنه‌ی دیسک، پیکسل خام): ساختنشون (حلقه‌ی روی ~۱.۷ میلیون پیکسل + الگوها)
 * چند صد میلی‌ثانیه طول میکشه، ولی خوندن فایل خام چند ده میلی‌ثانیه است. کلید = همه‌ی تنظیمات دیسک + اندازه.
 */
object DiscCache {
    private const val VER = 1
    private const val KEEP = 4

    private fun dir(ctx: Context): File = File(ctx.cacheDir, "disc").also { it.mkdirs() }

    private fun fileFor(ctx: Context, st: DiscStyle, size: Int): File =
        File(dir(ctx), "d${VER}_${st.color}_${st.opacity}_${st.effect}_${st.c1}_${st.c2}_${st.effOpacity}_$size.raw")

    fun load(ctx: Context, st: DiscStyle, size: Int): Bitmap? {
        return try {
            val f = fileFor(ctx, st, size)
            if (!f.exists() || f.length() != size.toLong() * size * 4L) return null
            val buf = ByteBuffer.allocate(size * size * 4)
            FileInputStream(f).use { fin ->
                val ch = fin.channel
                while (buf.hasRemaining()) {
                    if (ch.read(buf) < 0) break
                }
            }
            if (buf.hasRemaining()) return null
            buf.rewind()
            val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
            bmp.copyPixelsFromBuffer(buf)
            f.setLastModified(System.currentTimeMillis())
            bmp
        } catch (e: Throwable) {
            null
        }
    }

    fun save(ctx: Context, st: DiscStyle, body: Bitmap) {
        try {
            if (body.config != Bitmap.Config.ARGB_8888 || body.width != body.height) return
            val f = fileFor(ctx, st, body.width)
            val buf = ByteBuffer.allocate(body.width * body.height * 4)
            body.copyPixelsToBuffer(buf)
            buf.rewind()
            val tmp = File(f.parentFile, f.name + ".tmp")
            FileOutputStream(tmp).use { fo ->
                val ch = fo.channel
                while (buf.hasRemaining()) ch.write(buf)
            }
            tmp.renameTo(f)
            // فقط چند فایل آخر نگه داشته میشه
            dir(ctx).listFiles { x -> x.name.endsWith(".raw") }
                ?.sortedByDescending { it.lastModified() }
                ?.drop(KEEP)
                ?.forEach { it.delete() }
        } catch (e: Throwable) {
            e.printStackTrace()
        }
    }
}
