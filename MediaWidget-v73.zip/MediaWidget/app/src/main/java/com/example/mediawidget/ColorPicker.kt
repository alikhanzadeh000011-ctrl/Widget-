package com.example.mediawidget

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ComposeShader
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout

/** انتخابگر رنگ: مربع اشباع/روشنی + نوار رنگ (Hue)، مثل پنل Color ویدیوی MD */
class ColorPickerView(ctx: Context, initial: Int, private val onChange: (Int) -> Unit) : LinearLayout(ctx) {

    private val d = resources.displayMetrics.density
    private val hsv = FloatArray(3)

    private val sv = object : View(ctx) {
        private val p = Paint(Paint.ANTI_ALIAS_FLAG)
        private val ring = Paint(Paint.ANTI_ALIAS_FLAG)
        private val rect = RectF()

        override fun onDraw(c: Canvas) {
            rect.set(0f, 0f, width.toFloat(), height.toFloat())
            val hue = Color.HSVToColor(floatArrayOf(hsv[0], 1f, 1f))
            val sat = LinearGradient(0f, 0f, width.toFloat(), 0f, Color.WHITE, hue, Shader.TileMode.CLAMP)
            val dark = LinearGradient(0f, 0f, 0f, height.toFloat(), Color.TRANSPARENT, Color.BLACK, Shader.TileMode.CLAMP)
            p.shader = ComposeShader(sat, dark, PorterDuff.Mode.SRC_OVER)
            c.drawRoundRect(rect, 10f * d, 10f * d, p)
            p.shader = null
            val x = hsv[1] * width
            val y = (1f - hsv[2]) * height
            ring.style = Paint.Style.STROKE
            ring.strokeWidth = 3f * d
            ring.color = Color.WHITE
            c.drawCircle(x, y, 11f * d, ring)
            ring.strokeWidth = 1.2f * d
            ring.color = Color.argb(120, 0, 0, 0)
            c.drawCircle(x, y, 13f * d, ring)
        }

        override fun onTouchEvent(e: MotionEvent): Boolean {
            parent.requestDisallowInterceptTouchEvent(true)
            hsv[1] = (e.x / width).coerceIn(0f, 1f)
            hsv[2] = 1f - (e.y / height).coerceIn(0f, 1f)
            invalidate()
            fire()
            return true
        }
    }

    private val hue = object : View(ctx) {
        private val p = Paint(Paint.ANTI_ALIAS_FLAG)
        private val rect = RectF()
        private val ring = Paint(Paint.ANTI_ALIAS_FLAG)

        override fun onDraw(c: Canvas) {
            rect.set(0f, 0f, width.toFloat(), height.toFloat())
            val cols = IntArray(7) { Color.HSVToColor(floatArrayOf(it * 60f, 1f, 1f)) }
            p.shader = LinearGradient(0f, 0f, width.toFloat(), 0f, cols, null, Shader.TileMode.CLAMP)
            c.drawRoundRect(rect, height / 2f, height / 2f, p)
            p.shader = null
            val x = (hsv[0] / 360f * width).coerceIn(height / 2f, width - height / 2f)
            ring.style = Paint.Style.FILL
            ring.color = Color.WHITE
            c.drawCircle(x, height / 2f, height / 2f + 2f * d, ring)
            ring.color = Color.HSVToColor(floatArrayOf(hsv[0], 1f, 1f))
            c.drawCircle(x, height / 2f, height / 2f - 3f * d, ring)
        }

        override fun onTouchEvent(e: MotionEvent): Boolean {
            parent.requestDisallowInterceptTouchEvent(true)
            hsv[0] = (e.x / width).coerceIn(0f, 1f) * 360f
            if (hsv[0] >= 360f) hsv[0] = 359.9f
            sv.invalidate()
            invalidate()
            fire()
            return true
        }
    }

    private val preview = View(ctx)

    init {
        orientation = VERTICAL
        Color.colorToHSV(initial, hsv)
        addView(sv, LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, (210f * d).toInt()))
        val lp = LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, (26f * d).toInt())
        lp.topMargin = (18f * d).toInt()
        addView(hue, lp)
        val plp = LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, (34f * d).toInt())
        plp.topMargin = (16f * d).toInt()
        addView(preview, plp)
        updatePreview()
    }

    fun color(): Int = Color.HSVToColor(hsv)

    private fun updatePreview() {
        val g = GradientDrawable()
        g.cornerRadius = 17f * d
        g.setColor(color())
        preview.background = g
    }

    private fun fire() {
        updatePreview()
        onChange(color())
    }

    companion object {
        /** دیالوگ انتخاب رنگ سبک MD؛ با «Done» رنگ برمی‌گرده */
        fun show(ctx: Context, initial: Int, title: String = "Color", onDone: (Int) -> Unit) {
            var cur = initial
            val view = ColorPickerView(ctx, initial) { cur = it }
            MdDialog(ctx).title(title).addView(view).primary("Done") { onDone(cur) }.secondary("Cancel").show()
        }
    }
}
