package com.example.mediawidget

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.drawable.ColorDrawable
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.text.TextUtils
import android.util.LruCache
import android.util.Size
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.content.res.Configuration
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import java.util.concurrent.Executors
import kotlin.math.cos
import kotlin.math.sin

/** یه ردیف از صف پخش (از پلیر داخلی یا از صف سشن یه پلیر دیگه) */
class QueueEntry(
    val key: String,
    val title: String,
    val artist: String,
    val track: Track?,
    val queueId: Long,
    val iconBitmap: Bitmap?,
    val iconUri: Uri?
)

/** کش کاور کوچیک ردیف‌ها؛ لود تو پس‌زمینه */
object ThumbCache {
    private val cache = object : LruCache<String, Bitmap>(28 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }
    private val pending = HashSet<String>()
    private val failed = HashSet<String>()
    private val exec = Executors.newFixedThreadPool(2)
    private val handler = Handler(Looper.getMainLooper())

    fun get(key: String): Bitmap? = cache.get(key)

    /** کاور رو مستقیم تحویل میده (کارت خودش نگهش میداره؛ پس بیرون افتادن از کش اثری نداره) */
    fun requestWith(ctx: Context, e: QueueEntry, onBitmap: (Bitmap) -> Unit) {
        val cached = cache.get(e.key)
        if (cached != null) {
            onBitmap(cached)
            return
        }
        val app = ctx.applicationContext
        exec.execute {
            val b = try { load(app, e) } catch (x: Throwable) { null }
            if (b != null) {
                cache.put(e.key, b)
                handler.post { onBitmap(b) }
            }
        }
    }

    fun request(ctx: Context, e: QueueEntry, done: () -> Unit) {
        synchronized(pending) {
            if (cache.get(e.key) != null || failed.contains(e.key) || !pending.add(e.key)) return
        }
        val app = ctx.applicationContext
        exec.execute {
            val b = try { load(app, e) } catch (x: Throwable) { null }
            synchronized(pending) {
                pending.remove(e.key)
                if (b == null) failed.add(e.key)
            }
            if (b != null) {
                cache.put(e.key, b)
                handler.post(done)
            }
        }
    }

    private fun decode(bytes: ByteArray): Bitmap? {
        val o = BitmapFactory.Options()
        o.inJustDecodeBounds = true
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o)
        var sample = 1
        while (o.outWidth / (sample * 2) >= 400) sample *= 2
        val o2 = BitmapFactory.Options()
        o2.inSampleSize = sample
        return BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o2)
    }

    private fun load(ctx: Context, e: QueueEntry): Bitmap? {
        e.iconBitmap?.let { return shrink(it) }
        e.iconUri?.let { u ->
            try {
                ctx.contentResolver.openInputStream(u)?.use { s ->
                    val bytes = s.readBytes()
                    decode(bytes)?.let { return it }
                }
            } catch (x: Exception) {
            }
        }
        val t = e.track ?: return null
        try {
            val r = MediaMetadataRetriever()
            try {
                r.setDataSource(ctx, t.uri)
                r.embeddedPicture?.let { bytes -> decode(bytes)?.let { return it } }
            } finally {
                r.release()
            }
        } catch (x: Exception) {
        }
        if (Build.VERSION.SDK_INT >= 29) {
            try {
                return ctx.contentResolver.loadThumbnail(t.uri, Size(400, 400), null)
            } catch (x: Exception) {
            }
        }
        return null
    }

    private fun shrink(b: Bitmap): Bitmap {
        val m = maxOf(b.width, b.height)
        if (m <= 400) return b
        val f = 400f / m
        return Bitmap.createScaledBitmap(b, (b.width * f).toInt().coerceAtLeast(1), (b.height * f).toInt().coerceAtLeast(1), true)
    }
}

/** کارت صف در حالت لندسکیپ (مثل MD): کاور کمی کج، زیرش اسم ترک و خواننده */
class QueueCard(ctx: Context, private val font: android.graphics.Typeface?) : View(ctx) {
    private val d = ctx.resources.displayMetrics.density
    private val titlePaint = TextPaint(Paint.ANTI_ALIAS_FLAG)
    private val artistPaint = TextPaint(Paint.ANTI_ALIAS_FLAG)
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val bp = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val rect = RectF()
    private val clip = Path()
    private val src = android.graphics.Rect()
    var entry: QueueEntry? = null
    var index = 0
    var current = false
    var tint = Color.WHITE
    var thumb: Bitmap? = null
    var side = 0f       // اندازه‌ی ضلع کاور؛ از عرض کارت بزرگ‌تره تا کاورها کمی روی هم بیفتن (مثل MD)

    init {
        titlePaint.typeface = font
        artistPaint.typeface = font
        titlePaint.textSize = 15f * d
        artistPaint.textSize = 12.5f * d
        titlePaint.isFakeBoldText = true
    }

    override fun onDraw(c: Canvas) {
        val e = entry ?: return
        val s = if (side > 0f) side else width * 0.95f
        val left = 4f * d
        val offs = floatArrayOf(0f, -9f, 7f, -4f, 10f, -7f)
        val angles = floatArrayOf(-2.4f, 2.0f, -1.4f, 3.0f, -2.0f, 1.4f)
        val top = 4f * d + offs[index % offs.size] * d
        c.save()
        c.rotate(angles[index % angles.size], left + s / 2f, top + s / 2f)
        rect.set(left, top, left + s, top + s)
        // سایه‌ی نرم زیر کاور
        for (i in 3 downTo 1) {
            p.color = Color.argb(26, 0, 0, 0)
            c.drawRoundRect(left - i * 2f * d, top + i * 3f * d, left + s + i * 2f * d, top + s + i * 4f * d, 10f * d, 10f * d, p)
        }
        clip.reset()
        clip.addRoundRect(rect, 8f * d, 8f * d, Path.Direction.CW)
        c.save()
        c.clipPath(clip)
        val b = thumb
        if (b != null) {
            val sd = minOf(b.width, b.height)
            src.set((b.width - sd) / 2, (b.height - sd) / 2, (b.width + sd) / 2, (b.height + sd) / 2)
            c.drawBitmap(b, src, rect, bp)
        } else {
            p.color = Color.argb(70, 255, 255, 255)
            c.drawRect(rect, p)
        }
        c.restore()
        c.restore()
        // اسم ترک و خواننده: از چپِ کاور (مثل MD)
        val tw = (s * 0.95f).toInt()
        titlePaint.color = if (current) tint else Color.WHITE
        val ty = 4f * d + s + 26f * d
        val tl = StaticLayout.Builder.obtain(e.title, 0, e.title.length, titlePaint, tw)
            .setMaxLines(1).setEllipsize(TextUtils.TruncateAt.END).build()
        c.save()
        c.translate(left + 2f * d, ty)
        tl.draw(c)
        c.restore()
        artistPaint.color = Color.argb(170, 255, 255, 255)
        val al = StaticLayout.Builder.obtain(e.artist, 0, e.artist.length, artistPaint, tw)
            .setMaxLines(1).setEllipsize(TextUtils.TruncateAt.END).build()
        c.save()
        c.translate(left + 2f * d, ty + tl.height + 2f * d)
        al.draw(c)
        c.restore()
    }
}

/** ردیف صف: کاور کج‌شده‌ی نیمه‌بیرون از لبه‌ی چپ، اسم ترک و خواننده */
class QueueRow(ctx: Context) : View(ctx) {
    private val d = ctx.resources.displayMetrics.density
    private val sd = ctx.resources.displayMetrics.scaledDensity
    private val titlePaint = TextPaint(Paint.ANTI_ALIAS_FLAG)
    private val artistPaint = TextPaint(Paint.ANTI_ALIAS_FLAG)
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val thumbPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val mtx = Matrix()
    private val srcPts = FloatArray(8)
    private val path = Path()
    private val quad = FloatArray(8)
    private var entry: QueueEntry? = null
    private var pos = 0
    private var unit = 0f
    private var current = false
    private var tint = Color.WHITE
    private var thumb: Bitmap? = null
    private var titleLayout: StaticLayout? = null
    private var layoutKey = ""
    private var artistText = ""

    init {
        val font = DarkUi.font(ctx)
        titlePaint.typeface = android.graphics.Typeface.create(font, android.graphics.Typeface.BOLD)
        titlePaint.textSize = 16f * sd
        artistPaint.typeface = font
        artistPaint.textSize = 12.5f * sd
        artistPaint.color = Color.argb(160, 255, 255, 255)
    }

    fun bind(e: QueueEntry, isCurrent: Boolean, tintColor: Int, th: Bitmap?, position: Int) {
        entry = e
        val firstChanged = (pos == 0) != (position == 0)
        pos = position
        if (firstChanged) requestLayout()
        current = isCurrent
        tint = tintColor
        thumb = th
        layoutKey = ""
        invalidate()
    }

    override fun onMeasure(w: Int, h: Int) {
        val ww = MeasureSpec.getSize(w)
        unit = minOf(ww, resources.displayMetrics.heightPixels).toFloat()
        setMeasuredDimension(ww, (0.28f * unit + topExtra()).toInt())
    }

    private fun buildText(e: QueueEntry, textW: Int) {
        val key = e.key + "|" + textW + "|" + current
        if (key == layoutKey) return
        layoutKey = key
        titlePaint.color = if (current) tint else Color.WHITE
        titleLayout = StaticLayout.Builder.obtain(e.title, 0, e.title.length, titlePaint, textW)
            .setMaxLines(2)
            .setEllipsize(TextUtils.TruncateAt.END)
            .setAlignment(Layout.Alignment.ALIGN_NORMAL)
            .build()
        artistText = TextUtils.ellipsize(e.artist, artistPaint, textW.toFloat(), TextUtils.TruncateAt.END).toString()
    }

    // ردیف اول کمی بلندتره تا بالای کاورش (که روی ردیف بالاتر میفته) بریده نشه؛ محتوا همون جای قبلی می‌مونه
    private fun topExtra(): Float = if (pos == 0) 0.10f * unit else 0f

    override fun onDraw(c: Canvas) {
        val ex = topExtra()
        c.save()
        c.translate(0f, ex)
        drawContent(c, width.toFloat(), height - ex)
        c.restore()
    }

    private fun drawContent(c: Canvas, w: Float, h: Float) {
        val e = entry ?: return

        // کاور: بزرگ و نامنظم؛ زاویه، اندازه و جای هر ردیف از روی اسمش ثابت و تصادفیه (مثل MD)
        val hs = e.key.hashCode() * -1640531535
        fun rnd(n: Int): Float = ((hs ushr (n * 5)) and 0x1F) / 31f
        val s = unit * (0.37f + 0.05f * rnd(1))
        val cx = unit * (0.12f + 0.08f * rnd(2))
        val cy = h * (0.5f + (rnd(3) - 0.5f) * 0.10f)
        // زیگ‌زاگ: یکی در میان به چپ و راست کج میشه، با مقدار نامنظم
        val a = (if (pos % 2 == 0) 1f else -1f) * (0.06f + 0.14f * rnd(0))
        val sq = 0.90f + 0.08f * rnd(4)
        val kl = if (rnd(5) > 0.5f) sq else 1f
        val kr = if (rnd(5) > 0.5f) 1f else sq
        val xs = floatArrayOf(-s / 2f, s / 2f, s / 2f, -s / 2f)
        val ys = floatArrayOf(-s / 2f * kl, -s / 2f * kr, s / 2f * kr, s / 2f * kl)
        val ca = cos(a)
        val sa = sin(a)
        for (i in 0..3) {
            quad[i * 2] = cx + xs[i] * ca - ys[i] * sa
            quad[i * 2 + 1] = cy + xs[i] * sa + ys[i] * ca
        }
        // بالای کاور آزاده و میفته روی کاور ردیف بالاتر؛ پایینش زیر خط جداکننده‌ی همین ردیف قایم میشه
        c.save()
        c.clipRect(0f, -h * 3f, w, h)
        val th = thumb
        if (th == null || !QuadMesh.draw(c, th, quad, thumbPaint, mtx, srcPts)) {
            path.reset()
            path.moveTo(quad[0], quad[1])
            path.lineTo(quad[2], quad[3])
            path.lineTo(quad[4], quad[5])
            path.lineTo(quad[6], quad[7])
            path.close()
            p.style = Paint.Style.FILL
            p.color = Color.argb(110, 40, 40, 44)
            c.drawPath(path, p)
        }
        c.restore()

        // متن
        val x0 = 0.455f * unit
        val textW = (w - x0 - 18f * d).toInt().coerceAtLeast(40)
        buildText(e, textW)
        val tl = titleLayout ?: return
        val gap = 3f * d
        val artistH = if (artistText.isEmpty()) 0f else artistPaint.fontMetrics.let { it.descent - it.ascent }
        val block = tl.height + (if (artistH > 0f) gap + artistH else 0f)
        val top = (h - block) / 2f
        c.save()
        c.translate(x0, top)
        tl.draw(c)
        c.restore()
        if (artistH > 0f) {
            c.drawText(artistText, x0, top + tl.height + gap - artistPaint.fontMetrics.ascent, artistPaint)
        }

        // نشونه‌ی ترک در حال پخش (سه میله)
        if (current) {
            p.style = Paint.Style.FILL
            p.color = tint
            val bx = x0 - 15f * d
            val by = top + titlePaint.textSize * 0.95f
            val bw = 2.6f * d
            val hs = floatArrayOf(7f * d, 11f * d, 5f * d)
            for (i in 0..2) {
                val l = bx + i * (bw + 1.6f * d)
                c.drawRoundRect(RectF(l, by - hs[i], l + bw, by), 1f * d, 1f * d, p)
            }
        }

        // خط جداکننده‌ی پایین ردیف: بخشی از خود ردیفه، پس همیشه با آهنگ و کاورش هماهنگ حرکت می‌کنه
        p.style = Paint.Style.FILL
        p.color = Color.argb(46, 255, 255, 255)
        c.drawRect(0f, h - 1.5f, w, h, p)
    }
}

/**
 * صفحه‌ی صف پخش: پس‌زمینه‌ی بلر کاور، عنوان Queue، دکمه‌ی عقب و لیست ردیف‌ها.
 */
class QueueView(ctx: Context) : FrameLayout(ctx) {

    interface Host {
        fun onClose()
        fun onJump(entry: QueueEntry, index: Int)
    }

    var host: Host? = null

    private val d = ctx.resources.displayMetrics.density
    private val list = ListView(ctx)
    private val titleV = TextView(ctx)
    private val back = AlbumDetailView.BackView(ctx)
    private val header = FrameLayout(ctx)   // عنوان و دکمه‌ی back جزو خود لیستن و با اسکرول بالا میرن
    private var headerH = 0
    private val cardsScroll = HorizontalScrollView(ctx)   // لندسکیپ: ردیف افقی کارت‌ها
    private val cardsRow = LinearLayout(ctx)
    private var land = false
    private var insetLeft = 0
    private val cardFont = DarkUi.font(ctx)
    private val emptyV = TextView(ctx)
    private val adapter = Ad()
    private val bgPaint = Paint(Paint.FILTER_BITMAP_FLAG)
    private val dstRect = RectF()
    private var backdrop: Bitmap? = null
    private var grey: Bitmap? = null
    private var entries: List<QueueEntry> = emptyList()
    private var current = -1
    private var tint = Color.WHITE
    private var thumbPosted = false
    private var insetTop = 0
    private var insetBottom = 0

    init {
        setWillNotDraw(false)
        isClickable = true
        val font = DarkUi.font(ctx)

        list.divider = null
        list.dividerHeight = 0
        list.selector = ColorDrawable(Color.TRANSPARENT)
        list.cacheColorHint = Color.TRANSPARENT
        list.isVerticalScrollBarEnabled = false
        list.overScrollMode = OVER_SCROLL_NEVER
        list.clipChildren = false
        // بدون برش پایین و بالا: ردیف‌ها تا لبه‌ی صفحه اسکرول میشن (فاصله‌ی انتها فقط برای دیده شدن ردیف آخره)
        list.clipToPadding = false

        header.addView(titleV, LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.CENTER_HORIZONTAL))
        header.addView(back, LayoutParams((48f * d).toInt(), (48f * d).toInt(), Gravity.TOP or Gravity.START))
        headerH = (72f * d).toInt()
        header.layoutParams = android.widget.AbsListView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, headerH)
        list.addHeaderView(header, null, false)
        list.adapter = adapter
        list.setOnItemClickListener { _, _, p, _ ->
            val i = p - list.headerViewsCount
            if (i in entries.indices) host?.onJump(entries[i], i)
        }
        addView(list, LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        titleV.text = "Queue"
        titleV.setTextColor(Color.WHITE)
        titleV.textSize = 17f
        titleV.typeface = android.graphics.Typeface.create(font, android.graphics.Typeface.BOLD)
        titleV.gravity = Gravity.CENTER

        emptyV.text = "No queue available for this player"
        emptyV.setTextColor(Color.argb(170, 255, 255, 255))
        emptyV.textSize = 15f
        emptyV.typeface = font
        emptyV.gravity = Gravity.CENTER
        emptyV.visibility = GONE
        addView(emptyV, LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER))

        back.color = Color.WHITE
        back.setOnClickListener { host?.onClose() }

        // لندسکیپ: به‌جای لیست عمودی، ردیف افقی کاورها (مثل MD)
        cardsScroll.isHorizontalScrollBarEnabled = false
        cardsScroll.overScrollMode = OVER_SCROLL_NEVER
        cardsScroll.clipToPadding = false
        cardsScroll.clipChildren = false
        cardsRow.orientation = LinearLayout.HORIZONTAL
        cardsRow.clipChildren = false
        cardsScroll.addView(cardsRow, LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT))
        addView(cardsScroll, LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        cardsScroll.visibility = GONE
        land = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
        if (land) applyMode()
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        val nl = newConfig.orientation == Configuration.ORIENTATION_LANDSCAPE
        if (nl != land) {
            land = nl
            applyMode()
        }
    }

    /** ارتفاع صفحه‌ی لندسکیپ (ضلع کوتاه) */
    private fun shortSide(): Int = minOf(resources.displayMetrics.widthPixels, resources.displayMetrics.heightPixels)

    private fun coverSide(): Float = 0.40f * shortSide()

    /** فاصله‌ی شروع کارت‌ها: کمی کمتر از اندازه‌ی کاور، تا هر کاور کمی روی قبلی بیفته */
    private fun cardW(): Int = (coverSide() * 0.97f).toInt()

    /** عنوان و دکمه‌ی back: تو لندسکیپ جزو خود صفحه (ثابت)، تو عمودی جزو هدر لیست (با اسکرول) */
    private fun applyMode() {
        list.visibility = if (land) GONE else VISIBLE
        cardsScroll.visibility = if (land) VISIBLE else GONE
        header.removeAllViews()
        removeView(titleV)
        removeView(back)
        val tp = LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.CENTER_HORIZONTAL)
        val bp = LayoutParams((48f * d).toInt(), (48f * d).toInt(), Gravity.TOP or Gravity.START)
        if (land) {
            addView(titleV, tp)
            addView(back, bp)
        } else {
            header.addView(titleV, tp)
            header.addView(back, bp)
        }
        setInsets(insetTop, insetBottom, insetLeft)
        rebuildCards()
    }

    private fun rebuildCards() {
        if (!land) return
        cardsRow.removeAllViews()
        val cw = cardW()
        for ((i, e) in entries.withIndex()) {
            val card = QueueCard(context, cardFont)
            card.entry = e
            card.index = i
            card.current = i == current
            card.tint = tint
            card.side = coverSide()
            ThumbCache.requestWith(context, e) { b ->
                card.thumb = b
                card.invalidate()
            }
            card.setOnClickListener { host?.onJump(e, i) }
            cardsRow.addView(card, LinearLayout.LayoutParams(cw, ViewGroup.LayoutParams.MATCH_PARENT))
        }
    }

    private fun refreshCards() {
        if (!land) return
        for (i in 0 until cardsRow.childCount) {
            val card = cardsRow.getChildAt(i) as? QueueCard ?: continue
            card.current = i == current
            card.tint = tint
            card.invalidate()
        }
    }

    fun setInsets(top: Int, bottom: Int, left: Int) {
        insetTop = top
        insetBottom = bottom
        insetLeft = left
        // کارت‌های لندسکیپ: بلوک کاور + اسم‌ها وسط صفحه (کمی بالاتر از مرکز)، زیر عنوان Queue
        val sh = shortSide()
        val block = coverSide() + 78f * d
        val center = (sh - block) / 2f - 0.02f * sh
        val padTop = maxOf(top + 0.19f * sh, center).toInt()
        cardsScroll.setPadding(left + (14f * d).toInt(), padTop, (18f * d).toInt(), bottom)
        val tl = titleV.layoutParams as LayoutParams
        tl.topMargin = top + (10f * d).toInt()
        titleV.layoutParams = tl
        val bl = back.layoutParams as LayoutParams
        bl.topMargin = top - (2f * d).toInt()
        bl.leftMargin = left + (10f * d).toInt()
        back.layoutParams = bl
        // بالای لیست به اندازه‌ی ردیفِ اضافه‌ی اول بالاتر میره تا چیدمان اولیه عوض نشه
        val extra = (0.10f * minOf(resources.displayMetrics.widthPixels, resources.displayMetrics.heightPixels)).toInt()
        headerH = top + (72f * d).toInt() - extra
        header.layoutParams = android.widget.AbsListView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, headerH)
        header.requestLayout()
        list.setPadding(0, 0, 0, bottom + (24f * d).toInt())
    }

    fun setBackdrop(b: Bitmap?) {
        backdrop = b
        invalidate()
    }

    fun setTint(c: Int) {
        tint = c
        adapter.notifyDataSetChanged()
        refreshCards()
    }

    /** لیست جدید (یا همون لیست با ترک فعلیِ تازه) */
    fun setData(list2: List<QueueEntry>, cur: Int, scrollToCurrent: Boolean) {
        val sameList = list2.size == entries.size && list2.indices.all { list2[it].key == entries[it].key }
        entries = list2
        current = cur
        adapter.notifyDataSetChanged()
        emptyV.visibility = if (entries.isEmpty()) VISIBLE else GONE
        if (scrollToCurrent || !sameList) {
            if (cur in entries.indices) list.setSelectionFromTop(cur + list.headerViewsCount, headerH)
        }
        if (land) {
            if (!sameList) rebuildCards() else refreshCards()
            if ((scrollToCurrent || !sameList) && cur in entries.indices) {
                cardsScroll.post { cardsScroll.smoothScrollTo((cur * cardW() - cardW() * 0.1f).toInt().coerceAtLeast(0), 0) }
            }
        }
    }

    private fun notifyThumbs() {
        if (thumbPosted) return
        thumbPosted = true
        postDelayed({
            thumbPosted = false
            adapter.notifyDataSetChanged()
            refreshCards()
        }, 120L)
    }

    override fun onDraw(c: Canvas) {
        val w = width
        val h = height
        if (w <= 0 || h <= 0) return
        c.drawColor(DarkUi.BG)
        var bg = backdrop
        if (bg == null) {
            if (grey == null) grey = VinylArt.greyBackground(w, h)
            bg = grey
        }
        if (bg != null) {
            dstRect.set(0f, 0f, w.toFloat(), h.toFloat())
            bgPaint.alpha = 255
            c.drawBitmap(bg, null, dstRect, bgPaint)
        }
        // کمی تیره‌تر برای خوانایی متن
        c.drawColor(Color.argb(60, 0, 0, 0))
    }

    private inner class Ad : BaseAdapter() {
        override fun getCount(): Int = entries.size
        override fun getItem(position: Int): Any = entries[position]
        override fun getItemId(position: Int): Long = position.toLong()
        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val row = (convertView as? QueueRow) ?: QueueRow(context)
            val e = entries[position]
            val th = ThumbCache.get(e.key)
            row.bind(e, position == current, tint, th, position)
            if (th == null) ThumbCache.request(context, e) { notifyThumbs() }
            return row
        }
    }
}
