package com.example.mediawidget

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import org.json.JSONArray
import org.json.JSONObject

/**
 * سبک دیسک ساخته‌شده توی ویرایشگر: رنگ بدنه + شفافیت + افکت.
 * effect: ۰ ساده (Clear)، ۱ Splatter (دو لایه‌ی Pattern 1 و Pattern 2 با رنگ جدا)، ۲ Marble (دود؛ رنگ = c1)
 */
class DiscStyle(
    var color: Int,
    var opacity: Int,       // ۱۰ تا ۱۰۰ (درصدِ پُری بدنه)
    var effect: Int,
    var c1: Int,            // Splatter: رنگ Pattern 1 | Marble: رنگ دود
    var c2: Int,            // Splatter: رنگ Pattern 2
    var effOpacity: Int,    // ۰ تا ۱۰۰
    var auto: Boolean = false   // true: رنگ بدنه از کاور آهنگ (تم پیش‌فرض) یا از رنگ تم گرفته میشه
) {
    fun copy() = DiscStyle(color, opacity, effect, c1, c2, effOpacity, auto)

    fun toJson(): JSONObject = JSONObject()
        .put("color", color).put("op", opacity).put("eff", effect)
        .put("c1", c1).put("c2", c2).put("eop", effOpacity).put("auto", auto)

    companion object {
        fun fromJson(o: JSONObject) = DiscStyle(
            o.optInt("color", Color.WHITE), o.optInt("op", 30), o.optInt("eff", 0),
            o.optInt("c1", Color.WHITE), o.optInt("c2", Color.BLACK), o.optInt("eop", 100),
            o.optBoolean("auto", false)
        )
    }
}

object DiscStyles {

    const val NONE = 0
    const val SPLATTER = 1
    const val MARBLE = 2
    const val INK = 3       // حلقه‌ی دود/جوهر تیره دور لیبل
    const val CROSS = 4     // دو گوه‌ی تیره‌ی روبه‌رو (پاپیونی)
    const val SPLIT = 5     // دیسک دو نیم‌رنگ

    // پالت مثل MD: فقط مشکی، خاکستری، سفید (+ انتخابگر رنگ کامل)
    val BLACK = Color.rgb(20, 20, 22)
    val GRAY = Color.rgb(128, 128, 134)
    val WHITE = Color.WHITE
    val PALETTE = intArrayOf(BLACK, GRAY, WHITE)

    fun clearPreset() = DiscStyle(WHITE, 30, NONE, WHITE, BLACK, 100, true)
    fun splatterPreset() = DiscStyle(WHITE, 30, SPLATTER, WHITE, BLACK, 100, true)
    fun marblePreset() = DiscStyle(WHITE, 30, MARBLE, BLACK, BLACK, 100, true)

    // سه دیسک جدید مثل Clear و Splatter و Marble شیشه‌ای و شفاف‌ان (بدنه ۳۵٪)، افکت‌هاشون هم کمی شفاف
    fun inkPreset() = DiscStyle(WHITE, 35, INK, BLACK, BLACK, 90, true)
    fun crossPreset() = DiscStyle(WHITE, 35, CROSS, BLACK, BLACK, 60, true)
    fun splitPreset() = DiscStyle(WHITE, 35, SPLIT, Color.rgb(120, 60, 30), BLACK, 48, true)

    /** بیشترین شفافیت افکت: Cross و Split بیشتر از این نمیشن تا شیارهای دیسک محو نشن */
    fun maxEffOpacity(effect: Int): Int = when (effect) {
        CROSS -> 60
        SPLIT -> 48
        else -> 100
    }

    /** کلید تنظیم Real rotation برای دیسک فعلی (دیسک مشکی پیش‌فرض = default؛ بقیه پیش‌فرضِ روشن) */
    fun rotationKey(ctx: Context): String {
        val f = ThemeStore.selected(ctx, ThemeStore.DISC)
        if (f != null) return f.name
        if (!isOn(ctx)) return "default"
        val i = savedIndex(ctx)
        return if (i >= 0) "saved$i" else "fx" + load(ctx).effect
    }

    /** همه‌ی افکت‌ها به ترتیب نمایش، با اسم */
    val EFFECTS = listOf(
        NONE to "Clear", SPLATTER to "Splatter", MARBLE to "Marble",
        INK to "Ink", CROSS to "Cross", SPLIT to "Split"
    )

    fun preset(effect: Int): DiscStyle = when (effect) {
        SPLATTER -> splatterPreset()
        MARBLE -> marblePreset()
        INK -> inkPreset()
        CROSS -> crossPreset()
        SPLIT -> splitPreset()
        else -> clearPreset()
    }

    private fun mix(a: Int, b: Int, t: Float) = Color.rgb(
        (Color.red(a) + (Color.red(b) - Color.red(a)) * t).toInt(),
        (Color.green(a) + (Color.green(b) - Color.green(a)) * t).toInt(),
        (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * t).toInt()
    )

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("theme", Context.MODE_PRIVATE)

    /** رنگ بدنه (و رنگ لایه‌های تیره‌ی افکت) رو از رنگ داده‌شده می‌سازه؛ برای سبک‌هایی که auto نیستن همون سبک برمیگرده */
    fun withTint(st: DiscStyle, tint: Int): DiscStyle {
        if (!st.auto) return st
        val r = st.copy()
        r.color = tint
        when (st.effect) {
            SPLATTER -> r.c2 = shade(tint, 0.5f)
            MARBLE -> r.c1 = shade(tint, 0.28f)
            INK -> {                       // بدنه‌ی شیشه‌ای هم‌رنگ کاور، دودِ تیره‌ی هم‌رنگ کاور
                r.color = tint
                r.c1 = shade(tint, 0.18f)
            }
            CROSS -> r.c1 = shade(tint, 0.22f)           // گوه‌های تیره‌ی هم‌رنگ کاور
            SPLIT -> {                     // یه نیمه روشنِ شیشه‌ای، نیمه‌ی دیگه تیره‌ی هم‌رنگ کاور
                r.color = mix(tint, WHITE, 0.4f)
                r.c1 = shade(tint, 0.3f)
            }
        }
        return r
    }

    // ---------- سبک فعال
    fun isOn(ctx: Context): Boolean = prefs(ctx).getBoolean("disc_style_on", false)

    fun setOn(ctx: Context, v: Boolean) {
        prefs(ctx).edit().putBoolean("disc_style_on", v).apply()
    }

    fun load(ctx: Context): DiscStyle {
        val p = prefs(ctx)
        val d = clearPreset()
        return DiscStyle(
            p.getInt("ds_color", d.color),
            p.getInt("ds_op", d.opacity),
            p.getInt("ds_eff", d.effect),
            p.getInt("ds_c1", d.c1),
            p.getInt("ds_c2", d.c2),
            p.getInt("ds_eop", d.effOpacity),
            p.getBoolean("ds_auto", d.auto)
        )
    }

    fun save(ctx: Context, s: DiscStyle) {
        prefs(ctx).edit()
            .putInt("ds_color", s.color)
            .putInt("ds_op", s.opacity)
            .putInt("ds_eff", s.effect)
            .putInt("ds_c1", s.c1)
            .putInt("ds_c2", s.c2)
            .putInt("ds_eop", s.effOpacity)
            .putBoolean("ds_auto", s.auto)
            .apply()
    }

    // ---------- دیسک‌های ذخیره‌شده‌ی خود کاربر (از ادیتور)
    fun listSaved(ctx: Context): MutableList<DiscStyle> {
        val out = ArrayList<DiscStyle>()
        try {
            val arr = JSONArray(prefs(ctx).getString("disc_saved", "[]"))
            for (i in 0 until arr.length()) out.add(DiscStyle.fromJson(arr.getJSONObject(i)))
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return out
    }

    private fun writeSaved(ctx: Context, list: List<DiscStyle>) {
        val arr = JSONArray()
        for (s in list) arr.put(s.toJson())
        prefs(ctx).edit().putString("disc_saved", arr.toString()).apply()
    }

    /** اگه index منفی باشه دیسک جدید اضافه میشه؛ وگرنه همون جایگزین میشه. شماره‌ی نهایی برمیگرده. */
    fun putSaved(ctx: Context, index: Int, s: DiscStyle): Int {
        val list = listSaved(ctx)
        val at: Int
        if (index in list.indices) {
            list[index] = s.copy()
            at = index
        } else {
            list.add(s.copy())
            at = list.size - 1
        }
        writeSaved(ctx, list)
        return at
    }

    fun deleteSaved(ctx: Context, index: Int) {
        val list = listSaved(ctx)
        if (index !in list.indices) return
        list.removeAt(index)
        writeSaved(ctx, list)
        val sel = savedIndex(ctx)
        if (sel == index) setSavedIndex(ctx, -1) else if (sel > index) setSavedIndex(ctx, sel - 1)
    }

    /** کدوم دیسک ذخیره‌شده فعاله (-1 = هیچ‌کدوم؛ یعنی یکی از سه آماده یا دیسک پیش‌فرض) */
    fun savedIndex(ctx: Context): Int = prefs(ctx).getInt("disc_saved_idx", -1)

    fun setSavedIndex(ctx: Context, i: Int) {
        prefs(ctx).edit().putInt("disc_saved_idx", i).apply()
    }

    // ---------- تصویرها
    /** تصویر دیسک شیشه‌ای (فایل theme.zip): بدنه‌ی همه‌ی دیسک‌های Clear، Splatter و Marble */
    fun glass(ctx: Context): Bitmap? = try {
        BitmapFactory.decodeResource(ctx.resources, R.drawable.disc_glass)
    } catch (e: Throwable) {
        null
    }

    private fun decode(ctx: Context, res: Int): Bitmap? = try {
        BitmapFactory.decodeResource(ctx.resources, res)
    } catch (e: Throwable) {
        null
    }

    /** لایه‌های افکت با رنگ هر کدوم: Splatter = Pattern 1 (c1) + Pattern 2 (c2)، Marble = دود (c1) */
    fun layers(ctx: Context, st: DiscStyle): List<Pair<Bitmap, Int>> {
        val out = ArrayList<Pair<Bitmap, Int>>()
        when (st.effect) {
            SPLATTER -> {
                decode(ctx, R.drawable.pat_splatter)?.let { out.add(Pair(it, st.c1)) }
                decode(ctx, R.drawable.pat_splatter2)?.let { out.add(Pair(it, st.c2)) }
            }
            MARBLE -> decode(ctx, R.drawable.pat_marble)?.let { out.add(Pair(it, st.c1)) }
            INK -> decode(ctx, R.drawable.pat_ink)?.let { out.add(Pair(it, st.c1)) }
            CROSS -> decode(ctx, R.drawable.pat_cross)?.let { out.add(Pair(it, st.c1)) }
            SPLIT -> decode(ctx, R.drawable.pat_split)?.let { out.add(Pair(it, st.c1)) }
        }
        return out
    }

    fun shade(c: Int, k: Float) =
        Color.rgb((Color.red(c) * k).toInt(), (Color.green(c) * k).toInt(), (Color.blue(c) * k).toInt())

    /** الگو رو یک‌رنگ می‌کنه: آلفای الگو × شفافیت افکت؛ روشنایی الگو فقط کمی عمق میده */
    fun colorize(pat: Bitmap, color: Int, effOpacity: Int, d: Int): Bitmap {
        val sc = Bitmap.createScaledBitmap(pat, d, d, true)
        val px = IntArray(d * d)
        sc.getPixels(px, 0, d, 0, 0, d, d)
        if (sc !== pat) sc.recycle()
        val dark = shade(color, 0.78f)
        val r1 = Color.red(color)
        val g1 = Color.green(color)
        val b1 = Color.blue(color)
        val r2 = Color.red(dark)
        val g2 = Color.green(dark)
        val b2 = Color.blue(dark)
        val eo = effOpacity / 100f
        for (i in px.indices) {
            val v = px[i]
            val a = v ushr 24
            if (a == 0) continue
            val t = ((v shr 16) and 0xFF) / 255f
            val r = (r2 + (r1 - r2) * t).toInt()
            val g = (g2 + (g1 - g2) * t).toInt()
            val b = (b2 + (b1 - b2) * t).toInt()
            px[i] = (((a * eo).toInt().coerceIn(0, 255)) shl 24) or (r shl 16) or (g shl 8) or b
        }
        val out = Bitmap.createBitmap(d, d, Bitmap.Config.ARGB_8888)
        out.setPixels(px, 0, d, 0, 0, d, d)
        return out
    }

    /** بندانگشتی گرد دیسک برای کشوی Theme؛ روی زمینه‌ی خاکستری که افکت‌های سفید و مشکی هر دو دیده بشن */
    fun thumb(ctx: Context, st: DiscStyle, size: Int): Bitmap {
        val out = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        val p = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
        val m = size / 2f
        p.color = Color.rgb(104, 104, 112)
        c.drawCircle(m, m, m, p)
        val op = (0.25f + 0.75f * st.opacity / 100f)
        p.color = Color.argb((255 * op).toInt(), Color.red(st.color), Color.green(st.color), Color.blue(st.color))
        c.drawCircle(m, m, m, p)
        val path = Path()
        path.addCircle(m, m, m, Path.Direction.CW)
        c.save()
        c.clipPath(path)
        for ((pat, col) in layers(ctx, st)) {
            val img = colorize(pat, col, minOf(st.effOpacity, maxEffOpacity(st.effect)), size)
            c.drawBitmap(img, 0f, 0f, p)
            img.recycle()
            pat.recycle()
        }
        c.restore()
        // لیبل میانی
        p.color = Color.rgb(196, 196, 202)
        c.drawCircle(m, m, m * 0.36f, p)
        p.color = Color.rgb(40, 40, 44)
        c.drawCircle(m, m, m * 0.05f, p)
        return out
    }
}
