package com.example.mediawidget

import android.appwidget.AppWidgetManager
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.os.Bundle
import android.provider.Settings
import android.widget.RemoteViews

/**
 * ویجت‌های «NOW PLAYING» سبک MD: کارت شیشه‌ای رنگی با فونت پیکسلی، کاور، چند کلید (LIKE، PLAY، PREVIOUS، NEXT)
 * و (تو نسخه‌ی بزرگ) ردیف «RECENTLY PLAYED». کل ظاهر یه تصویر واحده؛ کلیدها فقط ناحیه‌ی لمس شفاف دارن.
 */
object PixelWidgets {

    private const val WHITE = 0xFFFFFFFF.toInt()

    fun build(ctx: Context, mgr: AppWidgetManager?, id: Int, kind: Kind, info: MediaInfo, set: VSettings.Data): RemoteViews {
        PixelFont.ensure(ctx)
        val rv = RemoteViews(ctx.packageName, R.layout.pixel_widget)
        val d = ctx.resources.displayMetrics.density
        val opts = if (mgr != null) mgr.getAppWidgetOptions(id) else Bundle()
        var wDp = opts.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 0)
        var hDp = opts.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT, 0)
        if (wDp < 50) wDp = kind.defW
        if (hDp < 40) hDp = kind.defH
        wDp = wDp.coerceAtMost(700)
        hDp = hDp.coerceAtMost(600)
        val w = wDp * d
        val h = hDp * d
        val sc = WidgetRenderer.fitScale(ctx, w, h, 5.5f)
        val bw = (w * sc).toInt().coerceAtLeast(2)
        val bh = (h * sc).toInt().coerceAtLeast(2)
        val bmp = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888)
        val blur = set.theme == VSettings.BLUR
        draw(ctx, Canvas(bmp), kind, bw.toFloat(), bh.toFloat(), d * sc, info, blur)
        // بلر واقعی One UI: رنگ نیمه‌شفاف روی ویوی ریشه، بقیه (کارت، شیشه، کاور...) همون قبلی روش کشیده میشه
        rv.setInt(android.R.id.background, "setBackgroundColor", if (blur) Color.argb(VSettings.blurAlpha(set.blur), 0, 0, 0) else 0)
        rv.setImageViewBitmap(R.id.scene, bmp)

        // ناحیه‌ی لمس کلیدها دقیقاً روی کلیدهای کشیده‌شده
        val k = keysRect(kind, bw.toFloat(), bh.toFloat())
        rv.setViewPadding(
            R.id.keys_box,
            (k.left / sc).toInt(), (k.top / sc).toInt(),
            ((bw - k.right) / sc).toInt(), ((bh - k.bottom) / sc).toInt()
        )
        val base = 40 + kind.ordinal * 6
        rv.setOnClickPendingIntent(R.id.k_like, action(ctx, kind, BaseWidgetProvider.ACTION_LIKE, base))
        rv.setOnClickPendingIntent(R.id.k_play, action(ctx, kind, BaseWidgetProvider.ACTION_TOGGLE, base + 1))
        rv.setOnClickPendingIntent(R.id.k_prev, action(ctx, kind, BaseWidgetProvider.ACTION_PREV, base + 2))
        rv.setOnClickPendingIntent(R.id.k_next, action(ctx, kind, BaseWidgetProvider.ACTION_NEXT, base + 3))
        val openApp = if (!info.hasAccess) {
            WidgetRenderer.activity(ctx, Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS), 1)
        } else {
            info.openIntent ?: WidgetRenderer.launchPlayer(ctx, info.pkg)
        }
        rv.setOnClickPendingIntent(android.R.id.background, openApp)
        return rv
    }

    private fun action(ctx: Context, kind: Kind, action: String, code: Int) =
        android.app.PendingIntent.getBroadcast(
            ctx, code, Intent(ctx, kind.provider).setAction(action),
            android.app.PendingIntent.FLAG_IMMUTABLE or android.app.PendingIntent.FLAG_UPDATE_CURRENT
        )

    private fun big(kind: Kind) = kind == Kind.NOWBIG

    /** مستطیل ردیف کلیدها (به پیکسل تصویر) */
    private fun keysRect(kind: Kind, w: Float, h: Float): RectF =
        if (big(kind)) RectF(0.300f * w, 0.835f * h, 0.955f * w, 0.935f * h)
        else RectF(0.305f * w, 0.715f * h, 0.955f * w, 0.895f * h)

    private fun draw(ctx: Context, c: Canvas, kind: Kind, w: Float, h: Float, du: Float, info: MediaInfo, blur: Boolean) {
        val isBig = big(kind)
        val radius = if (isBig) 0.075f * w else 0.17f * h
        val art = info.art
        val playing = info.hasMedia && info.playing

        // پس‌زمینه‌ی بلر کاور داخل کارت گرد
        val bgSrc = if (art != null) VinylArt.coverBackground(art, w.toInt(), h.toInt()) else VinylArt.greyBackground(w.toInt(), h.toInt())
        val card = RectF(0f, 0f, w, h)
        val clip = Path()
        clip.addRoundRect(card, radius, radius, Path.Direction.CW)
        c.save()
        c.clipPath(clip)
        if (!blur) c.drawBitmap(bgSrc, null, card, Paint(Paint.FILTER_BITMAP_FLAG))
        // جلای شیشه‌ای بالا
        val gl = Paint()
        gl.shader = LinearGradient(0f, 0f, 0f, h * 0.35f, Color.argb(20, 255, 255, 255), Color.argb(0, 255, 255, 255), Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, w, h * 0.35f, gl)
        c.restore()
        val border = Paint(Paint.ANTI_ALIAS_FLAG)
        border.style = Paint.Style.STROKE
        border.strokeWidth = 1.6f * du
        border.color = Color.argb(36, 255, 255, 255)
        c.drawRoundRect(RectF(card).also { it.inset(border.strokeWidth / 2f, border.strokeWidth / 2f) }, radius, radius, border)

        val fill = Paint(Paint.ANTI_ALIAS_FLAG)
        val text = Paint(Paint.ANTI_ALIAS_FLAG)
        text.color = Color.argb(235, 255, 255, 255)
        val dim = Paint(Paint.ANTI_ALIAS_FLAG)
        dim.color = Color.argb(120, 255, 255, 255)

        // پنل بالایی
        val panel = if (isBig) RectF(0.045f * w, 0.045f * h, 0.955f * w, 0.705f * h) else RectF(0.04f * w, 0.075f * h, 0.96f * w, 0.585f * h)
        fill.color = Color.argb(16, 255, 255, 255)
        val pr = if (isBig) 0.05f * w else 0.09f * h
        c.drawRoundRect(panel, pr, pr, fill)

        // کاور فعلی
        val coverSize = if (isBig) 0.29f * w else 0.34f * h
        val cover = if (isBig) RectF(panel.left + 0.035f * w, panel.top + 0.035f * w, panel.left + 0.035f * w + coverSize, panel.top + 0.035f * w + coverSize)
        else RectF(panel.left + 0.033f * w, panel.centerY() - coverSize / 2f, panel.left + 0.033f * w + coverSize, panel.centerY() + coverSize / 2f)
        drawCover(c, art, cover, 0.12f * coverSize)

        val textX = cover.right + (if (isBig) 0.04f * w else 0.03f * w)
        val maxW = panel.right - textX - (if (isBig) 0.04f * w else 0.03f * w)

        // NOW PLAYING + آیکن دیسک
        val pHead = if (isBig) 0.0033f * w else 0.0074f * h
        val headBase = cover.top + (if (isBig) 0.14f else 0.30f) * coverSize
        val iconR = 4.6f * pHead
        fill.color = Color.argb(235, 255, 255, 255)
        c.drawCircle(textX + iconR, headBase - 3.5f * pHead, iconR, fill)
        fill.color = Color.argb(90, 0, 0, 0)
        c.drawCircle(textX + iconR, headBase - 3.5f * pHead, iconR * 0.38f, fill)
        PixelFont.draw(c, "NOW PLAYING", textX + 2f * iconR + 2.2f * pHead, headBase, pHead, text)

        // عنوان (و خواننده)
        val title = if (!info.hasMedia) "Not playing" else info.title
        val artist = if (!info.hasMedia) "Open a music player" else info.artist
        if (isBig) {
            drawLine(c, title, textX, cover.top + 0.72f * coverSize, 0.0036f * w, maxW, text, du)
            drawLine(c, artist, textX, cover.top + 0.96f * coverSize, 0.0033f * w, maxW, dim.also { it.color = Color.argb(170, 255, 255, 255) }, du)
        } else {
            val joined = if (artist.isNotEmpty() && info.hasMedia) "$title-$artist" else title
            drawLine(c, joined, textX, cover.top + 0.93f * coverSize, 0.0087f * h, maxW, text, du)
        }

        // RECENTLY PLAYED (فقط نسخه‌ی بزرگ)
        if (isBig) {
            dim.color = Color.argb(120, 255, 255, 255)
            PixelFont.draw(c, "RECENTLY PLAYED", panel.left + 0.035f * w, 0.455f * h, 0.0032f * w, dim)
            val recents = RecentStore.recent(ctx, RecentStore.keyOf(info), 4)
            val size = 0.19f * w
            val gap = (panel.width() - 0.07f * w - 4f * size) / 3f
            for (i in 0 until 4) {
                val x = panel.left + 0.035f * w + i * (size + gap)
                val r = RectF(x, 0.50f * h, x + size, 0.50f * h + size)
                val b = recents.getOrNull(i)?.second
                drawCover(c, b, r, 0.12f * size)
            }
        }

        // شیارهای بلندگو (چپ پایین)
        val gx0 = if (isBig) 0.045f * w else 0.045f * w
        val gx1 = if (isBig) 0.255f * w else 0.265f * w
        val gy0 = if (isBig) 0.805f * h else 0.665f * h
        val gy1 = if (isBig) 0.94f * h else 0.895f * h
        val lines = 7
        val lineH = (gy1 - gy0) / (lines * 1.9f)
        fill.color = Color.argb(42, 255, 255, 255)
        for (i in 0 until lines) {
            val y = gy0 + i * ((gy1 - gy0 - lineH) / (lines - 1))
            val shrink = if (i == lines - 1) 0.15f * (gx1 - gx0) else if (i == 0) 0.02f * (gx1 - gx0) else 0f
            c.drawRoundRect(RectF(gx0 + shrink, y, gx1 - shrink, y + lineH), lineH / 2f, lineH / 2f, fill)
        }

        // کلیدها و برچسب‌ها
        val k = keysRect(kind, w, h)
        val gapK = 0.012f * k.width()
        val kw = (k.width() - 3f * gapK) / 4f
        val labels = arrayOf("LIKE", "PLAY", "PREVIOUS", "NEXT")
        val pLab = if (isBig) 0.0022f * w else 0.0047f * h
        dim.color = Color.argb(105, 255, 255, 255)
        for (i in 0 until 4) {
            val x = k.left + i * (kw + gapK)
            val key = RectF(x, k.top, x + kw, k.bottom)
            // بدنه‌ی کلید
            fill.color = Color.argb(28, 255, 255, 255)
            c.drawRoundRect(key, 0.06f * kw, 0.06f * kw, fill)
            val hl = Paint(Paint.ANTI_ALIAS_FLAG)
            hl.style = Paint.Style.STROKE
            hl.strokeWidth = 1f * du
            hl.color = Color.argb(22, 255, 255, 255)
            c.drawRoundRect(key, 0.06f * kw, 0.06f * kw, hl)
            // برچسب بالای کلید (وسط‌چین)
            val lw = PixelFont.width(labels[i], pLab)
            val baseY = k.top - (if (isBig) 0.025f * h else 0.05f * h)
            val tx = key.centerX() - lw / 2f
            PixelFont.draw(c, labels[i], tx, baseY, pLab, dim)
            // LED: فقط سبز کنار PLAY وقتی پخش میشه
            val ledR = 3.4f * pLab
            if (i == 1) {
                fill.color = if (playing) Color.rgb(60, 220, 110) else Color.argb(110, 40, 40, 40)
                c.drawCircle(tx - ledR * 2.2f, baseY - 3.5f * pLab, ledR, fill)
                val ring = Paint(Paint.ANTI_ALIAS_FLAG)
                ring.style = Paint.Style.STROKE
                ring.strokeWidth = 1.2f * du
                ring.color = Color.argb(200, 10, 20, 10)
                c.drawCircle(tx - ledR * 2.2f, baseY - 3.5f * pLab, ledR + 0.6f * du, ring)
            }
        }
    }

    /** یه خط متن: پیکسلی برای ASCII و فونت معمولی برای بقیه (فارسی و...) */
    private fun drawLine(c: Canvas, s: String, x: Float, baseline: Float, p: Float, maxW: Float, paint: Paint, du: Float) {
        if (s.isEmpty()) return
        if (PixelFont.supports(s)) {
            var pp = p
            // اگه جا نشد اول کوچیک‌تر، بعد کوتاه
            while (pp > p * 0.6f && PixelFont.width(s, pp) > maxW) pp *= 0.94f
            PixelFont.draw(c, PixelFont.fit(s, pp, maxW), x, baseline, pp, paint)
        } else {
            val tp = Paint(paint)
            tp.typeface = Typeface.DEFAULT_BOLD
            tp.textSize = 9f * p
            var t = s
            while (t.length > 1 && tp.measureText(t) > maxW) t = t.dropLast(1)
            c.drawText(if (t.length < s.length) "$t…" else t, x, baseline, tp)
        }
    }

    private fun drawCover(c: Canvas, art: Bitmap?, r: RectF, radius: Float) {
        val path = Path()
        path.addRoundRect(r, radius, radius, Path.Direction.CW)
        c.save()
        c.clipPath(path)
        if (art != null) {
            val m = minOf(art.width, art.height)
            val src = android.graphics.Rect((art.width - m) / 2, (art.height - m) / 2, (art.width + m) / 2, (art.height + m) / 2)
            c.drawBitmap(art, src, r, Paint(Paint.FILTER_BITMAP_FLAG))
        } else {
            val p = Paint()
            p.color = Color.argb(70, 0, 0, 0)
            c.drawRect(r, p)
        }
        c.restore()
        val edge = Paint(Paint.ANTI_ALIAS_FLAG)
        edge.style = Paint.Style.STROKE
        edge.strokeWidth = 1.5f
        edge.color = Color.argb(60, 255, 255, 255)
        c.drawRoundRect(r, radius, radius, edge)
    }
}
