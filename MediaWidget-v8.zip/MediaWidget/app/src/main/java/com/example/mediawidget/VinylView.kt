package com.example.mediawidget

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.CornerPathEffect
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Typeface
import android.os.SystemClock
import android.text.TextPaint
import android.text.TextUtils
import android.view.GestureDetector
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import java.util.concurrent.Executors
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.min

/**
 * صفحه‌ی اصلی اپ: دیسک وینیل (فقط کاور روی برچسب می‌چرخه)، بازوی سوزن، متن و سه دکمه.
 * همه‌چیز با Canvas کشیده میشه؛ مختصات‌ها از VinylArt (بوم مرجع ۱۰۸۰×۲۳۴۰) میان.
 */
class VinylView(ctx: Context) : View(ctx) {

    interface Listener {
        fun onPlayPause()
        fun onPrev()
        fun onNext()
        fun onNeedAccess()
        fun onLongPress()
    }

    var listener: Listener? = null

    private class Assets(
        val record: Bitmap,
        val arm: Bitmap,
        val button: Bitmap,
        val greyBg: Bitmap,
        val blankLabel: Bitmap
    )

    private class Visual(
        val key: String,
        val title: String,
        val artist: String,
        val label: Bitmap,
        val bg: Bitmap
    )

    private val executor = Executors.newSingleThreadExecutor()
    private var assets: Assets? = null
    private var scale = 1f
    private val typeface: Typeface = loadFont()

    // اطلاعات پخش
    private var hasAccess = true
    private var hasMedia = false
    private var playing = false
    private var durationMs = 0L
    private var anchorPos = 0L
    private var anchorTime = 0L
    private var wantedInfo: MediaInfo? = null
    private var targetKey = ""
    private var visualRequestKey = ""
    private var buildGen = 0

    // آنچه الان نشون داده میشه
    private var shown: Visual? = null
    private var pending: Visual? = null
    private var prevBg: Bitmap? = null
    private var bgFade = 1f

    // انتقال بین آهنگ‌ها: 0 آرام، 1 خروج صفحه‌ی قبلی، 2 ورود صفحه‌ی جدید
    private var phase = 0
    private var phaseT = 0f
    private var recX = 0f
    private var textAlpha = 1f

    // حرکت
    private var armAngle = VinylArt.ARM_REST
    private var spinVel = 0f
    private var labelAngle = 0f
    private var lastNanos = 0L

    // لمس
    private var pressedBtn = -1
    private val btnCx = floatArrayOf(200f, 620f, 879f)

    private val bmpPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val titlePaint = TextPaint(Paint.ANTI_ALIAS_FLAG)
    private val artistPaint = TextPaint(Paint.ANTI_ALIAS_FLAG)
    private val smallPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val shapePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val dst = Rect()
    private val tmpRect = RectF()
    private val skipPath = Path()
    private val pocketPath = Path()
    private var pocketScale = 0f

    private val detector = GestureDetector(ctx, object : GestureDetector.SimpleOnGestureListener() {
        override fun onDown(e: MotionEvent): Boolean = true

        override fun onLongPress(e: MotionEvent) {
            if (pressedBtn < 0) listener?.onLongPress()
        }

        override fun onSingleTapUp(e: MotionEvent): Boolean {
            if (!hasAccess && pressedBtn < 0) listener?.onNeedAccess()
            return true
        }
    })

    init {
        titlePaint.typeface = typeface
        artistPaint.typeface = typeface
        smallPaint.typeface = typeface
        smallPaint.textAlign = Paint.Align.CENTER
    }

    private fun loadFont(): Typeface {
        return try {
            resources.getFont(R.font.sf_pro_soft)
        } catch (e: Exception) {
            Typeface.DEFAULT
        }
    }

    // ------------------------------------------------------------------ داده

    fun update(info: MediaInfo) {
        hasAccess = info.hasAccess
        hasMedia = info.hasAccess && info.hasMedia
        playing = hasMedia && info.playing
        durationMs = info.durationMs
        anchorPos = info.positionMs
        anchorTime = info.readAt
        wantedInfo = info
        targetKey = if (!info.hasAccess) "noaccess" else if (!info.hasMedia) "none" else info.key
        maybeBuildVisual()
        invalidate()
    }

    private fun currentPos(): Long {
        var p = anchorPos
        if (playing) p += SystemClock.elapsedRealtime() - anchorTime
        if (durationMs > 0L && p > durationMs) p = durationMs
        if (p < 0L) p = 0L
        return p
    }

    private fun progress(): Float {
        if (!hasMedia || durationMs <= 0L) return 0f
        return (currentPos().toFloat() / durationMs).coerceIn(0f, 1f)
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        if (w <= 0 || h <= 0) return
        scale = w / VinylArt.REF_W
        assets = null
        val s = scale
        val tf = typeface
        executor.execute {
            try {
                val labelPx = (2f * VinylArt.LR * s).toInt()
                val a = Assets(
                    VinylArt.recordBitmap(s),
                    VinylArt.armBitmap(s),
                    VinylArt.buttonBitmap(s),
                    VinylArt.greyBackground(w, h),
                    VinylArt.blankLabel(labelPx, tf)
                )
                post {
                    assets = a
                    visualRequestKey = ""
                    maybeBuildVisual()
                    invalidate()
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    /** برچسب و پس‌زمینه‌ی آهنگ جدید رو توی thread جدا می‌سازه */
    private fun maybeBuildVisual() {
        val a = assets ?: return
        val info = wantedInfo ?: return
        if (visualRequestKey == targetKey) return
        visualRequestKey = targetKey
        val key = targetKey
        val gen = ++buildGen
        val w = width
        val h = height
        val labelPx = (2f * VinylArt.LR * scale).toInt()
        val title: String
        val artist: String
        when {
            !info.hasAccess -> {
                title = "Allow access"
                artist = "Tap to allow notification access"
            }
            !info.hasMedia -> {
                title = "Not Launched"
                artist = "Open a music app to start"
            }
            else -> {
                title = if (info.title.isEmpty()) "Unknown" else info.title
                artist = info.artist
            }
        }
        val art: Bitmap? = if (info.hasAccess && info.hasMedia) info.art else null
        executor.execute {
            try {
                val label = if (art != null) VinylArt.labelFromCover(art, labelPx) else a.blankLabel
                val bg = if (art != null) VinylArt.coverBackground(art, w, h) else a.greyBg
                val v = Visual(key, title, artist, label, bg)
                post {
                    if (gen == buildGen) {
                        pending = v
                        invalidate()
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    private fun applyPending() {
        val p = pending ?: return
        prevBg = shown?.bg ?: assets?.greyBg
        shown = p
        pending = null
        bgFade = 0f
    }

    // ------------------------------------------------------------------ حرکت

    /** یک قدم انیمیشن؛ اگه هنوز چیزی در حال حرکته true برمی‌گردونه */
    private fun step(dt: Float): Boolean {
        var anim = false
        val s = scale

        when (phase) {
            0 -> {
                val p = pending
                if (p != null) {
                    val cur = shown
                    if (cur == null || (cur.title == p.title && cur.artist == p.artist)) {
                        applyPending()
                    } else {
                        phase = 1
                        phaseT = 0f
                    }
                    anim = true
                }
            }
            1 -> {
                phaseT += dt / OUT_DUR
                if (phaseT >= 1f) {
                    applyPending()
                    phase = 2
                    phaseT = 0f
                }
            }
            2 -> {
                phaseT += dt / IN_DUR
                if (phaseT >= 1f) {
                    phase = 0
                    phaseT = 1f
                }
            }
        }

        val outDist = (VinylArt.CX + VinylArt.R + 120f) * s
        val inDist = width + 100f * s - (VinylArt.CX - VinylArt.R) * s
        recX = when (phase) {
            1 -> -(phaseT * phaseT * phaseT) * outDist
            2 -> {
                val q = 1f - phaseT.coerceIn(0f, 1f)
                q * q * q * inDist
            }
            else -> 0f
        }
        textAlpha = when (phase) {
            1 -> 1f - phaseT.coerceIn(0f, 1f)
            2 -> phaseT.coerceIn(0f, 1f)
            else -> 1f
        }
        if (phase != 0) anim = true

        // بازوی سوزن: با پیشرفت آهنگ از لبه به مرکز میره؛ موقع توقف یا تغییر آهنگ میره کنار
        val playArm = VinylArt.ARM_OUTER + (VinylArt.ARM_INNER - VinylArt.ARM_OUTER) * progress()
        val armTarget = if (playing && phase == 0 && pending == null && shown != null) playArm else VinylArt.ARM_REST
        armAngle += (armTarget - armAngle) * (1f - exp(-dt / 0.20f))
        if (abs(armTarget - armAngle) > 0.05f) anim = true

        // چرخش کاور: نرم شروع و نرم متوقف میشه
        val spinTarget = if (playing && armAngle > 10f) SPIN_DPS else 0f
        spinVel += (spinTarget - spinVel) * (1f - exp(-dt / 0.7f))
        labelAngle = (labelAngle + spinVel * dt) % 360f
        if (spinTarget > 0f || spinVel > 0.3f) anim = true

        if (bgFade < 1f) {
            bgFade = min(1f, bgFade + dt / 0.6f)
            anim = true
        }
        return anim
    }

    // ------------------------------------------------------------------ رسم

    private fun by(refY: Float): Float = height - (VinylArt.REF_H - refY) * scale

    override fun onDraw(canvas: Canvas) {
        val now = System.nanoTime()
        var dt = if (lastNanos == 0L) 0f else (now - lastNanos) / 1_000_000_000f
        if (dt > 0.05f) dt = 0.05f
        lastNanos = now

        canvas.drawColor(Color.BLACK)
        val a = assets ?: return
        val anim = step(dt)
        drawBackground(canvas, a)
        drawBase(canvas)
        drawRecordGroup(canvas, a)
        drawArm(canvas, a)
        drawTexts(canvas)
        drawButtons(canvas, a)
        if (anim) postInvalidateOnAnimation() else lastNanos = 0L
    }

    private fun drawBackground(c: Canvas, a: Assets) {
        dst.set(0, 0, width, height)
        val cur = shown?.bg ?: a.greyBg
        val prev = prevBg
        if (bgFade < 1f && prev != null) {
            bmpPaint.alpha = 255
            c.drawBitmap(prev, null, dst, bmpPaint)
            bmpPaint.alpha = (bgFade * 255f).toInt().coerceIn(0, 255)
            c.drawBitmap(cur, null, dst, bmpPaint)
            bmpPaint.alpha = 255
        } else {
            c.drawBitmap(cur, null, dst, bmpPaint)
        }
    }

    private fun drawRecordGroup(c: Canvas, a: Assets) {
        val s = scale
        val cx = VinylArt.CX * s
        val cy = VinylArt.CY * s
        c.save()
        c.translate(recX, 0f)
        c.drawBitmap(a.record, cx - a.record.width / 2f, cy - a.record.height / 2f, bmpPaint)
        val label = shown?.label ?: a.blankLabel
        c.save()
        c.rotate(labelAngle, cx, cy)
        c.drawBitmap(label, cx - label.width / 2f, cy - label.height / 2f, bmpPaint)
        c.restore()
        c.restore()
    }

    /** پایه‌ی شفاف بازو (زیر دیسک): گولی با «جیب» که بازو توش می‌شینه، شکل از تصویر مرجع */
    private fun drawBase(c: Canvas) {
        val s = scale
        val k = VinylArt.K
        tmpRect.set(780f * s, 200f * s, (780f + 412f * k) * s, (200f + 604f * k) * s)
        val rad = 412f * k / 2f * s
        shapePaint.style = Paint.Style.FILL
        shapePaint.color = Color.argb(10, 0, 0, 0)
        c.drawRoundRect(tmpRect, rad, rad, shapePaint)
        shapePaint.style = Paint.Style.STROKE
        shapePaint.strokeWidth = 2f * s
        shapePaint.color = Color.argb(34, 255, 255, 255)
        c.drawRoundRect(tmpRect, rad, rad, shapePaint)

        if (pocketScale != s) {
            pocketPath.reset()
            val pts = VinylArt.POCKET
            pocketPath.moveTo((780f + pts[0] * k) * s, (200f + pts[1] * k) * s)
            var i = 2
            while (i < pts.size) {
                pocketPath.lineTo((780f + pts[i] * k) * s, (200f + pts[i + 1] * k) * s)
                i += 2
            }
            pocketPath.close()
            pocketScale = s
        }
        shapePaint.pathEffect = CornerPathEffect(10f * s)
        shapePaint.style = Paint.Style.FILL
        shapePaint.color = Color.argb(34, 0, 0, 0)
        c.drawPath(pocketPath, shapePaint)
        shapePaint.style = Paint.Style.STROKE
        shapePaint.strokeWidth = 1.5f * s
        shapePaint.color = Color.argb(30, 0, 0, 0)
        c.drawPath(pocketPath, shapePaint)
        shapePaint.pathEffect = null
    }

    private fun drawArm(c: Canvas, a: Assets) {
        val s = scale
        c.save()
        c.translate(VinylArt.PX * s, VinylArt.PY * s)
        c.rotate(armAngle)
        c.drawBitmap(a.arm, -VinylArt.ARM_OX * s, -VinylArt.ARM_OY * s, bmpPaint)
        c.restore()
    }

    private fun drawTexts(c: Canvas) {
        val v = shown ?: return
        val s = scale
        val maxW = (VinylArt.REF_W - 98f * 2f) * s

        titlePaint.textSize = 76f * s
        titlePaint.color = Color.WHITE
        titlePaint.alpha = (textAlpha * 255f).toInt().coerceIn(0, 255)
        val t = TextUtils.ellipsize(v.title, titlePaint, maxW, TextUtils.TruncateAt.END).toString()
        c.drawText(t, 98f * s, by(1752f), titlePaint)

        artistPaint.textSize = 46f * s
        artistPaint.color = Color.WHITE
        artistPaint.alpha = (textAlpha * 235f).toInt().coerceIn(0, 255)
        val ar = TextUtils.ellipsize(v.artist, artistPaint, maxW, TextUtils.TruncateAt.END).toString()
        c.drawText(ar, 98f * s, by(1840f), artistPaint)
    }

    private fun drawButtons(c: Canvas, a: Assets) {
        val s = scale
        val cy = by(2097f)
        for (i in 0..2) {
            val cx = btnCx[i] * s
            c.save()
            if (pressedBtn == i) c.scale(0.96f, 0.96f, cx, cy)
            c.drawBitmap(a.button, cx - a.button.width / 2f, cy - a.button.height / 2f, bmpPaint)
            c.restore()
        }

        smallPaint.color = Color.argb(205, 255, 255, 255)
        smallPaint.textSize = 35f * s
        c.drawText("PLAY", btnCx[0] * s, by(2206f), smallPaint)

        drawSkip(c, btnCx[1] * s, by(2205f), s, true)
        drawSkip(c, btnCx[2] * s, by(2205f), s, false)
    }

    private fun drawSkip(c: Canvas, cx: Float, cy: Float, s: Float, left: Boolean) {
        shapePaint.style = Paint.Style.FILL
        shapePaint.color = Color.argb(235, 255, 255, 255)
        skipPath.reset()
        if (left) {
            c.drawRect(cx - 22f * s, cy - 14f * s, cx - 16f * s, cy + 14f * s, shapePaint)
            skipPath.moveTo(cx + 22f * s, cy - 15f * s)
            skipPath.lineTo(cx + 22f * s, cy + 15f * s)
            skipPath.lineTo(cx - 12f * s, cy)
        } else {
            c.drawRect(cx + 16f * s, cy - 14f * s, cx + 22f * s, cy + 14f * s, shapePaint)
            skipPath.moveTo(cx - 22f * s, cy - 15f * s)
            skipPath.lineTo(cx - 22f * s, cy + 15f * s)
            skipPath.lineTo(cx + 12f * s, cy)
        }
        skipPath.close()
        c.drawPath(skipPath, shapePaint)
    }

    // ------------------------------------------------------------------ لمس

    private fun hitButton(x: Float, y: Float): Int {
        val s = scale
        val cy = by(2097f)
        for (i in 0..2) {
            val cx = btnCx[i] * s
            if (abs(x - cx) <= 118f * s && y >= cy - 62f * s && y <= cy + 135f * s) return i
        }
        return -1
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        detector.onTouchEvent(event)
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                pressedBtn = hitButton(event.x, event.y)
                if (pressedBtn >= 0) {
                    performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                    invalidate()
                }
            }
            MotionEvent.ACTION_UP -> {
                val was = pressedBtn
                pressedBtn = -1
                if (was >= 0 && hitButton(event.x, event.y) == was) {
                    when (was) {
                        0 -> listener?.onPlayPause()
                        1 -> listener?.onPrev()
                        else -> listener?.onNext()
                    }
                }
                invalidate()
            }
            MotionEvent.ACTION_CANCEL -> {
                pressedBtn = -1
                invalidate()
            }
        }
        return true
    }

    companion object {
        private const val OUT_DUR = 0.40f
        private const val IN_DUR = 0.55f
        private const val SPIN_DPS = 18f      // از روی ویدیوی MD Vinyl: حدود ۱۸ درجه بر ثانیه
    }
}
