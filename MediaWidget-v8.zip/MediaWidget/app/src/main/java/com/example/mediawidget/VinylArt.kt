package com.example.mediawidget

import android.graphics.Bitmap
import android.graphics.BlurMaskFilter
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.CornerPathEffect
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import kotlin.math.abs
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * رسم قطعه‌های ثابت صفحه‌ی وینیل (با کد، بدون هیچ فایل تصویر).
 * همه‌ی مختصات روی بوم مرجع ۱۰۸۰×۲۳۴۰ هستن و با ضریب s به اندازه‌ی صفحه‌ی گوشی تبدیل میشن.
 * اندازه‌ها، رنگ‌ها و پروفایل نور دیسک از روی تصویرهای مرجع (دیسک، بازو، پایه) اندازه‌گیری شده.
 */
object VinylArt {

    const val REF_W = 1080f
    const val REF_H = 2340f

    // دیسک و برچسب (کاور)
    const val CX = 296f
    const val CY = 842.5f
    const val R = 654f
    const val LR = 294.5f

    // محور چرخش بازو و زاویه‌ها (درجه، ساعت‌گرد مثبت)
    const val PX = 875f
    const val PY = 338f
    const val ARM_REST = 0f
    const val ARM_OUTER = 18f
    const val ARM_INNER = 41f

    // محدوده‌ی بیت‌مپ بازو نسبت به محور
    const val ARM_OX = 100f
    const val ARM_OY = 150f
    const val ARM_W = 300f
    const val ARM_H = 1250f

    // نسبت اندازه‌ی تصویر مرجع بازو/پایه به بوم ما
    const val K = 0.722f

    // دکمه‌ها
    const val BTN_W = 206f
    const val BTN_H = 105f
    const val BTN_PAD = 30f

    /** مرز «جیب» پایه‌ی بازو (مختصات تصویر مرجع) */
    val POCKET = floatArrayOf(
        196f, 20f, 167f, 24f, 133f, 35f, 98f, 55f, 66f, 84f, 44f, 115f, 31f, 143f, 22f, 178f,
        20f, 220f, 24f, 245f, 85f, 315f, 131f, 379f, 172f, 392f, 218f, 395f, 252f, 390f,
        282f, 380f, 317f, 360f, 349f, 331f, 368f, 305f, 385f, 269f, 394f, 230f, 395f, 197f,
        390f, 163f, 380f, 133f, 360f, 98f, 331f, 66f, 300f, 44f, 269f, 30f, 230f, 21f
    )

    private fun interp(x: Float, xs: FloatArray, ys: FloatArray): Float {
        if (x <= xs[0]) return ys[0]
        for (i in 1 until xs.size) {
            if (x <= xs[i]) {
                val t = (x - xs[i - 1]) / (xs[i] - xs[i - 1])
                return ys[i - 1] + (ys[i] - ys[i - 1]) * t
            }
        }
        return ys[ys.size - 1]
    }

    /**
     * بدنه‌ی دیسک. هر پیکسل از روی دیسک مرجع محاسبه میشه:
     * روشنایی شعاعی (تیره‌ی داخل، روشن‌تر به سمت لبه)، چهار لوب نور (ضربدری) مثل وینیل واقعی،
     * خط‌های نازک بین ترک‌ها، بافت ظریف شیار و لبه‌ی تیره. (خودِ دیسک نمی‌چرخه)
     */
    fun recordBitmap(s: Float): Bitmap {
        val pad = 0.12f * R
        val size = ((2f * R + 2f * pad) * s).toInt()
        val rPx = R * s
        val mid = size / 2f
        val px = IntArray(size * size)

        val rs = floatArrayOf(0.557f, 0.62f, 0.66f, 0.72f, 0.78f, 0.82f, 0.86f, 0.90f, 0.95f, 0.985f)
        val ls = floatArrayOf(40f, 39f, 43f, 44f, 46f, 51f, 53f, 56.5f, 59.5f, 63f)
        val lut = FloatArray(1024)
        for (i in 0 until 1024) {
            lut[i] = interp(0.55f + 0.45f * i / 1023f, rs, ls)
        }
        val lines = floatArrayOf(0.650f, 0.686f, 0.713f, 0.771f, 0.801f)
        val twoPi = 6.2831855f

        for (y in 0 until size) {
            val dy = y - mid
            for (x in 0 until size) {
                val dx = x - mid
                val rr = sqrt(dx * dx + dy * dy)
                if (rr < 1f) continue
                val r = rr / rPx
                if (r > 1.01f || r < 0.40f) continue

                val c = dx / rr
                val sn = dy / rr
                val c2 = 2f * c * c - 1f
                val s2 = 2f * sn * c
                val c4 = 2f * c2 * c2 - 1f
                val s4 = 2f * s2 * c2
                val cos4 = c4 * 0.848f - s4 * 0.530f
                var g = 0.67f + 0.30f * cos4 - 0.10f * sn
                if (g < 0.30f) g = 0.30f
                if (g > 1.0f) g = 1.0f

                var l: Float
                if (r < 0.555f) {
                    l = 21f * (0.8f + 0.2f * g)
                    if (abs(r - 0.50f) < 0.004f || abs(r - 0.534f) < 0.004f) l += 6f
                } else {
                    var idx = ((r - 0.55f) / 0.45f * 1023f).toInt()
                    if (idx < 0) idx = 0
                    if (idx > 1023) idx = 1023
                    l = lut[idx] * g + 2.6f * sin(twoPi * r / 0.028f)
                }
                for (ln in lines) {
                    if (abs(r - ln) < 0.003f) l *= 0.78f
                }
                if (r > 0.985f) l *= 0.62f

                var a = (1f - r) * rPx
                if (a <= 0f) continue
                if (a > 1f) a = 1f
                var v = l.toInt()
                if (v < 0) v = 0
                if (v > 255) v = 255
                px[y * size + x] = ((a * 255f).toInt() shl 24) or (v shl 16) or (v shl 8) or v
            }
        }

        val disc = Bitmap.createBitmap(px, size, size, Bitmap.Config.ARGB_8888)
        val out = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)

        // سایه‌ی نرم زیر دیسک روی پس‌زمینه
        p.color = Color.argb(100, 0, 0, 0)
        p.maskFilter = BlurMaskFilter(26f * s, BlurMaskFilter.Blur.NORMAL)
        c.drawCircle(mid, mid + 14f * s, rPx, p)
        p.maskFilter = null

        c.drawBitmap(disc, 0f, 0f, null)
        disc.recycle()
        return out
    }

    /** بازوی سوزن در حالت عمودی (استراحت)؛ شکل و رنگ از تصویر مرجع. موقع نمایش حول PX,PY می‌چرخه */
    fun armBitmap(s: Float): Bitmap {
        val bmp = Bitmap.createBitmap((ARM_W * s).toInt(), (ARM_H * s).toInt(), Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)

        // مختصات تصویر مرجع بازو → مختصات بیت‌مپ
        fun mx(x: Float): Float = (848f + (x - 162f) * K - PX + ARM_OX) * s
        fun my(y: Float): Float = (288f + (y - 96f) * K - PY + ARM_OY) * s

        val hull = floatArrayOf(414f, 1394f, 380f, 1581f, 297f, 1585f, 234f, 1547f, 234f, 1525f, 310f, 1393f)
        val rodProfile = intArrayOf(114, 111, 118, 137, 157, 183, 203, 211, 210, 202, 184, 167, 156, 147, 140)
        val rodColors = IntArray(rodProfile.size)
        val rodPos = FloatArray(rodProfile.size)
        for (i in rodProfile.indices) {
            rodColors[i] = Color.rgb(rodProfile[i], rodProfile[i], rodProfile[i])
            rodPos[i] = i / (rodProfile.size - 1f)
        }

        // پاس اول: سایه‌ی نرم، پاس دوم: خود بازو
        for (pass in 0..1) {
            val shadow = pass == 0
            val dx = if (shadow) 3f else 0f
            val dy = if (shadow) 8f else 0f
            p.shader = null
            p.pathEffect = null
            p.style = Paint.Style.FILL
            p.color = Color.BLACK
            p.maskFilter = if (shadow) BlurMaskFilter(16f * s, BlurMaskFilter.Blur.NORMAL) else null
            val shadowColor = Color.argb(88, 0, 0, 0)

            fun rr(l: Float, t: Float, r: Float, b: Float, rad: Float, color: Int) {
                p.shader = null
                p.color = if (shadow) shadowColor else color
                c.drawRoundRect(
                    RectF(mx(l) + dx * s, my(t) + dy * s, mx(r) + dx * s, my(b) + dy * s),
                    rad * K * s, rad * K * s, p
                )
            }

            rr(178f, 42f, 293f, 96f, 10f, Color.rgb(38, 38, 38))

            // بلوک بزرگ بالا با گرادیان ملایم
            if (shadow) {
                rr(162f, 96f, 389f, 235f, 14f, Color.BLACK)
            } else {
                p.color = Color.BLACK
                p.shader = LinearGradient(
                    0f, my(96f), 0f, my(235f),
                    Color.rgb(46, 46, 46), Color.rgb(32, 32, 32), Shader.TileMode.CLAMP
                )
                c.drawRoundRect(RectF(mx(162f), my(96f), mx(389f), my(235f)), 14f * K * s, 14f * K * s, p)
                p.shader = null
                rr(162f, 112f, 318f, 138f, 6f, Color.rgb(47, 47, 47))
            }

            rr(326f, 235f, 377f, 335f, 8f, Color.rgb(40, 40, 40))

            // میله‌ی نقره‌ای: پروفایل نور از تصویر مرجع
            if (shadow) {
                p.color = shadowColor
                c.drawRect(RectF(mx(330f) + dx * s, my(332f) + dy * s, mx(373f) + dx * s, my(1255f) + dy * s), p)
            } else {
                p.color = Color.BLACK
                p.shader = LinearGradient(mx(330f), 0f, mx(373f), 0f, rodColors, rodPos, Shader.TileMode.CLAMP)
                c.drawRect(RectF(mx(330f), my(332f), mx(373f), my(1255f)), p)
                p.shader = null
            }

            rr(326f, 1255f, 377f, 1315f, 6f, Color.rgb(45, 45, 45))
            rr(318f, 1315f, 385f, 1385f, 6f, Color.rgb(44, 44, 44))

            // هد (قاب کارتریج) و سوزن
            val path = Path()
            path.moveTo(mx(hull[0]) + dx * s, my(hull[1]) + dy * s)
            var i = 2
            while (i < hull.size) {
                path.lineTo(mx(hull[i]) + dx * s, my(hull[i + 1]) + dy * s)
                i += 2
            }
            path.close()
            p.pathEffect = CornerPathEffect(12f * K * s)
            p.color = if (shadow) shadowColor else Color.rgb(34, 34, 34)
            c.drawPath(path, p)
            p.pathEffect = null

            p.style = Paint.Style.STROKE
            p.strokeWidth = 14f * K * s
            p.strokeCap = Paint.Cap.ROUND
            p.color = if (shadow) shadowColor else Color.rgb(28, 28, 28)
            c.drawLine(
                mx(330f) + dx * s, my(1548f) + dy * s,
                mx(383f) + dx * s, my(1588f) + dy * s, p
            )
            p.style = Paint.Style.FILL
        }
        p.maskFilter = null
        return bmp
    }

    /** دکمه‌ی قرصی تیره (مات) با سایه (PLAY، قبلی، بعدی) */
    fun buttonBitmap(s: Float): Bitmap {
        val w = BTN_W
        val h = BTN_H
        val pad = BTN_PAD
        val bmp = Bitmap.createBitmap(((w + 2f * pad) * s).toInt(), ((h + 2f * pad) * s).toInt(), Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)

        // سایه
        p.color = Color.argb(110, 0, 0, 0)
        p.maskFilter = BlurMaskFilter(14f * s, BlurMaskFilter.Blur.NORMAL)
        c.drawRoundRect(RectF(pad * s, (pad + 10f) * s, (pad + w) * s, (pad + h + 10f) * s), h * s / 2f, h * s / 2f, p)
        p.maskFilter = null

        // حلقه‌ی بیرونی تیره
        p.color = Color.argb(55, 0, 0, 0)
        c.drawRoundRect(RectF(pad * s, pad * s, (pad + w) * s, (pad + h) * s), h * s / 2f, h * s / 2f, p)

        // قرص داخلی (کاملاً مات)
        val i = 11f
        val rect = RectF((pad + i) * s, (pad + i) * s, (pad + w - i) * s, (pad + h - i) * s)
        p.color = Color.BLACK
        p.shader = LinearGradient(
            0f, rect.top, 0f, rect.bottom,
            Color.rgb(44, 44, 44), Color.rgb(24, 24, 24), Shader.TileMode.CLAMP
        )
        c.drawRoundRect(rect, rect.height() / 2f, rect.height() / 2f, p)
        p.shader = null

        // لبه‌ی روشن بالا و خط تیره‌ی دور قرص
        p.style = Paint.Style.STROKE
        p.strokeWidth = 2f * s
        p.color = Color.argb(150, 0, 0, 0)
        c.drawRoundRect(rect, rect.height() / 2f, rect.height() / 2f, p)
        p.strokeWidth = 1.5f * s
        p.color = Color.argb(26, 255, 255, 255)
        c.drawArc(
            RectF(rect.left + 3f * s, rect.top + 2f * s, rect.right - 3f * s, rect.bottom - 2f * s),
            200f, 140f, false, p
        )
        return bmp
    }

    /** پس‌زمینه‌ی خاکستری وقتی هیچ آهنگی نیست (بیت‌مپ کوچک، موقع رسم بزرگ و نرم میشه) */
    fun greyBackground(w: Int, h: Int): Bitmap {
        val bw = (w / 4).coerceAtLeast(8)
        val bh = (h / 4).coerceAtLeast(8)
        val bmp = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val p = Paint()
        p.shader = LinearGradient(
            0f, 0f, 0f, bh.toFloat(),
            intArrayOf(
                Color.rgb(206, 206, 206), Color.rgb(185, 185, 185), Color.rgb(128, 128, 128),
                Color.rgb(92, 92, 92), Color.rgb(162, 162, 162), Color.rgb(110, 110, 110)
            ),
            floatArrayOf(0f, 0.30f, 0.55f, 0.70f, 0.84f, 1f),
            Shader.TileMode.CLAMP
        )
        c.drawRect(0f, 0f, bw.toFloat(), bh.toFloat(), p)
        return bmp
    }

    /** کاهش اندازه به صورت چندمرحله‌ای (برای اینکه موقع کوچک‌کردن زیاد، نویز نیاد) */
    private fun downscale(src: Bitmap, tw: Int, th: Int): Bitmap {
        var cur = src
        while (cur.width > tw * 2 || cur.height > th * 2) {
            val nw = (cur.width / 2).coerceAtLeast(tw)
            val nh = (cur.height / 2).coerceAtLeast(th)
            cur = Bitmap.createScaledBitmap(cur, nw, nh, true)
        }
        return Bitmap.createScaledBitmap(cur, tw, th, true)
    }

    /**
     * پس‌زمینه‌ی نرم از روی کاور، مثل MD Vinyl: کل کاور به اندازه‌ی صفحه کشیده میشه
     * (تا رنگ ناحیه‌های واقعی کاور بمونه)، خیلی بلر میشه و یه لایه‌ی تیره‌ی ملایم
     * (بالا ۱۵٪، پایین ۲۵٪) روش میاد. پارامترها از روی اسکرین‌شات مرجع برازش شده.
     */
    fun coverBackground(art: Bitmap, w: Int, h: Int): Bitmap {
        val bw = (w / 4).coerceAtLeast(8)
        val bh = (h / 4).coerceAtLeast(8)
        val sw = 30
        val sh = (sw * h / w.toFloat()).toInt().coerceAtLeast(8)
        val small = downscale(art, sw, sh)
        val blurred = Shapes.boxBlur(small, 8, 3)
        val big = Bitmap.createScaledBitmap(blurred, bw, bh, true)
        val out = big.copy(Bitmap.Config.ARGB_8888, true)
        val c = Canvas(out)
        val p = Paint()
        p.shader = LinearGradient(
            0f, 0f, 0f, bh.toFloat(),
            Color.argb(38, 0, 0, 0), Color.argb(64, 0, 0, 0), Shader.TileMode.CLAMP
        )
        c.drawRect(0f, 0f, bw.toFloat(), bh.toFloat(), p)
        return out
    }

    /** برچسب گرد از روی کاور آهنگ */
    fun labelFromCover(art: Bitmap, d: Int): Bitmap {
        val label = Shapes.cover(art, d, 0.5f)
        val c = Canvas(label)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.style = Paint.Style.STROKE
        p.strokeWidth = 0.012f * d
        p.color = Color.argb(110, 0, 0, 0)
        c.drawCircle(d / 2f, d / 2f, d / 2f - p.strokeWidth / 2f, p)
        return label
    }

    /** برچسب تیره وقتی آهنگی نیست */
    fun blankLabel(d: Int, tf: Typeface?): Bitmap {
        val bmp = Bitmap.createBitmap(d, d, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val m = d / 2f
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.color = Color.rgb(40, 40, 40)
        c.drawCircle(m, m, m, p)

        p.style = Paint.Style.STROKE
        p.strokeWidth = 0.02f * d
        p.color = Color.rgb(56, 56, 56)
        c.drawCircle(m, m, m * 0.93f, p)

        p.style = Paint.Style.FILL
        p.color = Color.rgb(32, 32, 32)
        c.drawCircle(m, m, m * 0.16f, p)
        p.color = Color.rgb(150, 150, 150)
        c.drawCircle(m, m, m * 0.04f, p)

        val tp = Paint(Paint.ANTI_ALIAS_FLAG)
        if (tf != null) tp.typeface = tf
        tp.color = Color.rgb(150, 138, 120)
        tp.textAlign = Paint.Align.CENTER
        tp.textSize = 0.095f * d
        c.drawText("VINYL", m, m - 0.15f * d, tp)
        tp.textSize = 0.065f * d
        c.drawText("33 1/3 RPM", m, m + 0.21f * d, tp)
        return bmp
    }
}
