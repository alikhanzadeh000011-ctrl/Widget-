package com.example.mediawidget

import android.content.Context

/** تنظیمات کتابخانه‌ی موزیک: حالت نمایش (آلبوم یا پوشه) و مخفی‌ها */
object LibraryPrefs {
    const val ALBUMS = 0
    const val FOLDERS = 1

    private fun p(ctx: Context) = ctx.getSharedPreferences("library", Context.MODE_PRIVATE)

    fun mode(ctx: Context): Int = p(ctx).getInt("mode", ALBUMS)

    fun setMode(ctx: Context, mode: Int) {
        p(ctx).edit().putInt("mode", mode).apply()
    }

    fun hidden(ctx: Context, mode: Int): Set<String> =
        HashSet(p(ctx).getStringSet("hidden_$mode", emptySet()) ?: emptySet())

    fun setHidden(ctx: Context, mode: Int, key: String, hide: Boolean) {
        val s = HashSet(hidden(ctx, mode))
        if (hide) s.add(key) else s.remove(key)
        p(ctx).edit().putStringSet("hidden_$mode", s).apply()
    }

    /** روش پخش ترک: ۰ = باز کردن فایل (پاپ‌آپ Samsung Music)، ۱ = تست الف (کنترل مستقیم نشست)، ۲ = تست ب (پخش از جستجو) */
    const val PLAY_OPEN = 0
    const val PLAY_SESSION = 1
    const val PLAY_SEARCH = 2

    fun playMethod(ctx: Context): Int = p(ctx).getInt("play_method", PLAY_OPEN)

    fun setPlayMethod(ctx: Context, m: Int) {
        p(ctx).edit().putInt("play_method", m).apply()
    }

    fun clearHidden(ctx: Context) {
        p(ctx).edit().remove("hidden_$ALBUMS").remove("hidden_$FOLDERS").apply()
    }
}
