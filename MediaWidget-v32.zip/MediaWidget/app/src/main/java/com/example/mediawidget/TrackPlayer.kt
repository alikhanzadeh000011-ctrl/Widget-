package com.example.mediawidget

import android.app.SearchManager
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Toast

/** پخش یه ترک تو Samsung Music؛ سه روش برای تست (از تنظیمات انتخاب میشه) */
object TrackPlayer {

    private const val SAMSUNG = "com.sec.android.app.music"

    fun play(ctx: Context, t: Track, album: Album?, folderMode: Boolean) {
        when (LibraryPrefs.playMethod(ctx)) {
            LibraryPrefs.PLAY_SESSION -> if (!viaSession(ctx, t)) openFile(ctx, t)
            LibraryPrefs.PLAY_SEARCH -> if (!viaSearch(ctx, t, album, folderMode)) openFile(ctx, t)
            else -> openFile(ctx, t)
        }
    }

    /** روش پیش‌فرض: «باز کردن فایل» (Samsung Music پاپ‌آپ نشون میده) */
    private fun openFile(ctx: Context, t: Track) {
        val i = Intent(Intent.ACTION_VIEW)
        i.setDataAndType(t.uri, "audio/*")
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        i.setPackage(SAMSUNG)
        try {
            ctx.startActivity(i)
        } catch (e: Exception) {
            i.setPackage(null)
            try {
                ctx.startActivity(Intent.createChooser(i, "Play with"))
            } catch (e2: Exception) {
                Toast.makeText(ctx, "No music app found", Toast.LENGTH_SHORT).show()
            }
        }
    }

    /** تست الف: اگه Samsung Music یه نشست فعال داره، مستقیم بهش میگیم این ترک رو پخش کن */
    private fun viaSession(ctx: Context, t: Track): Boolean {
        val list = MediaReader.controllers(ctx)
        if (list == null) {
            Toast.makeText(ctx, "A: no notification access, opening the file", Toast.LENGTH_SHORT).show()
            return false
        }
        val c = list.firstOrNull { it.packageName == SAMSUNG }
        if (c == null) {
            Toast.makeText(ctx, "A: Samsung Music has no active session, opening the file", Toast.LENGTH_SHORT).show()
            return false
        }
        return try {
            val extras = Bundle()
            extras.putString("android.intent.extra.title", t.title)
            c.transportControls.playFromUri(t.uri, extras)
            Toast.makeText(ctx, "A: sent to Samsung Music", Toast.LENGTH_SHORT).show()
            true
        } catch (e: Exception) {
            Toast.makeText(ctx, "A: not supported, opening the file", Toast.LENGTH_SHORT).show()
            false
        }
    }

    /** تست ب: درخواست «پخش از جستجو» با اسم ترک، آلبوم و خواننده */
    private fun viaSearch(ctx: Context, t: Track, album: Album?, folderMode: Boolean): Boolean {
        val i = Intent(MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH)
        i.setPackage(SAMSUNG)
        i.putExtra(MediaStore.EXTRA_MEDIA_FOCUS, MediaStore.Audio.Media.ENTRY_CONTENT_TYPE)
        i.putExtra(MediaStore.EXTRA_MEDIA_TITLE, t.title)
        i.putExtra(SearchManager.QUERY, t.title)
        if (album != null && !folderMode) {
            i.putExtra(MediaStore.EXTRA_MEDIA_ALBUM, album.title)
            if (album.artist.isNotBlank() && album.artist != "Various Artists" && album.artist != "Unknown artist") {
                i.putExtra(MediaStore.EXTRA_MEDIA_ARTIST, album.artist)
            }
        }
        return try {
            ctx.startActivity(i)
            Toast.makeText(ctx, "B: search request sent", Toast.LENGTH_SHORT).show()
            true
        } catch (e: Exception) {
            Toast.makeText(ctx, "B: not supported, opening the file", Toast.LENGTH_SHORT).show()
            false
        }
    }
}
