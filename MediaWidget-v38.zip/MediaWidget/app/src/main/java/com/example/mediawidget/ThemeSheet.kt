package com.example.mediawidget

import android.app.AlertDialog
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.TextView
import java.io.File
import kotlin.math.min

/** بندانگشتی گرد یا چهارگوش (گزینه‌ی پیش‌فرض، عکس سفارشی یا دکمه‌ی +) */
class ThumbView(act: VinylActivity, private val circle: Boolean) : View(act) {
    var bmp: Bitmap? = null
    var plus = false
    var chosen = false

    private val d = resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val path = Path()
    private val src = Rect()
    private val box = RectF()

    override fun onDraw(c: Canvas) {
        val m = 5f * d
        box.set(m, m, width - m, height - m)
        path.reset()
        if (circle) path.addOval(box, Path.Direction.CW) else path.addRoundRect(box, 13f * d, 13f * d, Path.Direction.CW)
        c.save()
        c.clipPath(path)
        p.style = Paint.Style.FILL
        p.color = Color.rgb(44, 43, 48)
        c.drawRect(box, p)
        val b = bmp
        if (b != null) {
            val side = min(b.width, b.height)
            val sx = (b.width - side) / 2
            val sy = ((b.height - side) * 0.35f).toInt()
            src.set(sx, sy, sx + side, sy + side)
            c.drawBitmap(b, src, box, p)
        } else if (plus) {
            p.style = Paint.Style.STROKE
            p.strokeWidth = 2.4f * d
            p.strokeCap = Paint.Cap.ROUND
            p.color = Color.WHITE
            val cx = width / 2f
            val cy = height / 2f
            val l = 9f * d
            c.drawLine(cx - l, cy, cx + l, cy, p)
            c.drawLine(cx, cy - l, cx, cy + l, p)
        }
        c.restore()
        if (chosen) {
            p.style = Paint.Style.STROKE
            p.strokeWidth = 2.4f * d
            p.color = Color.WHITE
            box.inset(-3.5f * d, -3.5f * d)
            if (circle) c.drawOval(box, p) else c.drawRoundRect(box, 16.5f * d, 16.5f * d, p)
        }
    }
}

/** صفحه‌ی تم (کشوی پایین)، مثل عکس مرجع: ردیف Theme برای پس‌زمینه و ردیف Vinyl برای دیسک */
class ThemeSheet(private val act: VinylActivity, private val vinyl: VinylView) : FrameLayout(act) {

    var onDismissed: (() -> Unit)? = null

    private val d = resources.displayMetrics.density
    private val panel = LinearLayout(act)
    private val bgRow = LinearLayout(act)
    private val discRow = LinearLayout(act)
    private val tf: Typeface = try {
        resources.getFont(R.font.sf_pro_soft)
    } catch (e: Exception) {
        Typeface.DEFAULT
    }
    private val defBg: Bitmap? = vinyl.defaultBackgroundPreview()
    private val defDisc: Bitmap? = vinyl.defaultRecordPreview()
    private var dismissing = false
    private var dragging = false
    private var dragStartY = 0f

    private fun dp(v: Float) = (v * d).toInt()

    private fun title(label: String, topPad: Int): TextView {
        val t = TextView(act)
        t.text = label
        t.setTextColor(Color.WHITE)
        t.textSize = 20f
        t.typeface = tf
        t.setPadding(dp(28f), topPad, 0, dp(8f))
        return t
    }

    private fun scroller(row: LinearLayout): HorizontalScrollView {
        val sv = HorizontalScrollView(act)
        sv.isHorizontalScrollBarEnabled = false
        sv.overScrollMode = View.OVER_SCROLL_NEVER
        sv.setPadding(dp(23f), 0, dp(23f), 0)
        sv.clipToPadding = false
        row.orientation = LinearLayout.HORIZONTAL
        sv.addView(row, ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        return sv
    }

    init {
        isClickable = true
        setOnClickListener { dismiss() }

        panel.orientation = LinearLayout.VERTICAL
        val r = 30f * d
        val bgd = GradientDrawable()
        bgd.setColor(Color.rgb(28, 27, 32))
        bgd.cornerRadii = floatArrayOf(r, r, r, r, 0f, 0f, 0f, 0f)
        panel.background = bgd
        panel.isClickable = true
        panel.setPadding(0, 0, 0, dp(34f))

        val handle = View(act)
        val hd = GradientDrawable()
        hd.setColor(Color.rgb(142, 140, 147))
        hd.cornerRadius = 4f * d
        handle.background = hd
        val hlp = LinearLayout.LayoutParams(dp(36f), dp(4f))
        hlp.gravity = Gravity.CENTER_HORIZONTAL
        hlp.topMargin = dp(14f)
        hlp.bottomMargin = dp(20f)
        panel.addView(handle, hlp)

        panel.addView(title("Theme", 0))
        panel.addView(scroller(bgRow))
        panel.addView(title("Vinyl", dp(12f)))
        panel.addView(scroller(discRow))

        panel.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    if (e.y < dp(56f)) {
                        dragging = true
                        dragStartY = e.rawY
                    }
                    dragging
                }
                MotionEvent.ACTION_MOVE -> {
                    if (dragging) panel.translationY = (e.rawY - dragStartY).coerceAtLeast(0f)
                    dragging
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    val was = dragging
                    dragging = false
                    if (was) {
                        if (panel.translationY > dp(90f)) dismiss()
                        else panel.animate().translationY(0f).setDuration(160).start()
                    }
                    was
                }
                else -> false
            }
        }

        addView(panel, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT, Gravity.BOTTOM))
        refresh()

        panel.alpha = 0f
        panel.post {
            panel.translationY = panel.height.toFloat()
            panel.alpha = 1f
            panel.animate().translationY(0f).setDuration(260).setInterpolator(DecelerateInterpolator()).start()
        }
    }

    fun dismiss() {
        if (dismissing) return
        dismissing = true
        panel.animate().translationY(panel.height.toFloat()).setDuration(200).withEndAction {
            (parent as? ViewGroup)?.removeView(this)
            onDismissed?.invoke()
        }.start()
    }

    fun refresh() {
        fill(bgRow, ThemeStore.BG, false, defBg)
        fill(discRow, ThemeStore.DISC, true, defDisc)
    }

    private fun item(circle: Boolean): ThumbView {
        val v = ThumbView(act, circle)
        val lp = LinearLayout.LayoutParams(dp(62f), dp(62f))
        lp.marginEnd = dp(14f)
        v.layoutParams = lp
        return v
    }

    private fun fill(row: LinearLayout, kind: String, circle: Boolean, defBmp: Bitmap?) {
        row.removeAllViews()
        val sel = ThemeStore.selected(act, kind)

        val def = item(circle)
        def.bmp = defBmp
        def.chosen = sel == null
        def.setOnClickListener {
            ThemeStore.select(act, kind, null)
            vinyl.reloadTheme()
            refresh()
        }
        if (kind == ThemeStore.DISC) {
            def.setOnLongClickListener {
                discMenu("default", null)
                true
            }
        }
        row.addView(def)

        for (f in ThemeStore.list(act, kind)) {
            val v = item(circle)
            v.bmp = ThemeStore.decodeFile(f, 200)
            v.chosen = sel != null && sel.name == f.name
            v.setOnClickListener {
                ThemeStore.select(act, kind, f)
                vinyl.reloadTheme()
                refresh()
            }
            v.setOnLongClickListener {
                if (kind == ThemeStore.DISC) discMenu(f.name, f) else confirmDelete(kind, f)
                true
            }
            row.addView(v)
        }

        val add = item(circle)
        add.plus = true
        add.setOnClickListener { act.pickImage(kind) }
        row.addView(add)
    }

    /** نگه داشتن انگشت روی یه دیسک: چرخش واقعی (و حذف برای دیسک‌های شخصی) */
    private fun discMenu(key: String, file: File?) {
        val dlg = MdDialog(act).title("Vinyl")
        dlg.addView(
            MdDialog.toggleRow(act, "Real rotation", "The whole disc spins at 33\u2153 RPM", ThemeStore.realRotation(act, key)) { on ->
                ThemeStore.setRealRotation(act, key, on)
                vinyl.refreshSpinMode()
            }
        )
        if (file != null) dlg.danger("Delete") { confirmDelete(ThemeStore.DISC, file) }
        dlg.secondary("Close")
        dlg.show()
    }

    private fun confirmDelete(kind: String, f: File) {
        MdDialog.confirm(act, null, "Delete this image?", "Delete", true) {
            ThemeStore.delete(act, kind, f)
            vinyl.reloadTheme()
            refresh()
        }
    }
}
