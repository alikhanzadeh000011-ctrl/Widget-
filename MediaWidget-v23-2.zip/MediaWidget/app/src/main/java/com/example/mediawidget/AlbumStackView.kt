package com.example.mediawidget

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.os.SystemClock
import android.util.LruCache
import android.view.MotionEvent
import android.view.VelocityTracker
import android.view.View
import android.view.ViewConfiguration
import java.util.concurrent.Executors
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlin.math.sin

/**
 * نمای ۳بعدی آلبوم‌ها: کارت‌ها عمودی روی هم چیده میشن، وسطی روبه‌رو و بقیه خوابیده با پرسپکتیو
 * و یک نوار رنگی با اسم آلبوم و خواننده. حالت گالری: شبکه‌ی ۳ستونه.
 */
class AlbumStackView(ctx: Context) : View(ctx) {

    interface Listener {
        fun onAlbumTap(album: Album, index: Int)
    }

    var listener: Listener? = null

    private var albums: List<Album> = emptyList()
    private val d = resources.displayMetrics.density
    private val slop = ViewConfiguration.get(ctx).scaledTouchSlop.toFloat()
    private val executor = Executors.newFixedThreadPool(2)
    private val pending = HashSet<Long>()
    private val holders = HashMap<Long, Bitmap>()

    private val covers = object : LruCache<Long, Bitmap>(
        (Runtime.getRuntime().maxMemory() / 9L).toInt().coerceAtLeast(8 * 1024 * 1024)
    ) {
        override fun sizeOf(key: Long, value: Bitmap): Int = value.byteCount
    }

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val titlePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val artistPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val rect = RectF()
    private val verts = FloatArray((ROWS + 1) * 4)

    private var topInset = 0
    private var bottomInset = 0

    // حالت پشته
    private var pos = 0f
    private var vel = 0f
    private var snapTo = -1
    private var cardW = 0f
    private var cx = 0f
    private var cy = 0f

    // حالت گالری
    private var gridMode = false
    private var modeT = 0f
    private var gridScroll = 0f
    private var gridVel = 0f

    // لمس
    private var touching = false
    private var moved = false
    private var downX = 0f
    private var downY = 0f
    private var lastY = 0f
    private var velocity: VelocityTracker? = null
    private var lastTime = 0L

    // برای تشخیص ضربه روی کارت‌ها (به ترتیب رسم)
    private val hitIdx = IntArray(40)
    private val hitTop = FloatArray(40)
    private val hitBottom = FloatArray(40)
    private var hitCount = 0

    init {
        val tf = DarkUi.font(ctx)
        titlePaint.typeface = Typeface.create(tf, Typeface.BOLD)
        artistPaint.typeface = tf
    }

    fun setAlbums(list: List<Album>) {
        albums = list
        pos = 0f
        vel = 0f
        snapTo = -1
        gridScroll = 0f
        invalidate()
    }

    fun setInsets(top: Int, bottom: Int) {
        topInset = top
        bottomInset = bottom
        invalidate()
    }

    fun isGrid(): Boolean = gridMode

    fun toggleMode() {
        gridMode = !gridMode
        if (gridMode) {
            // گالری از جایی شروع میشه که آلبوم فعلی دیده بشه
            val cols = 3
            val row = (pos.roundToInt() / cols)
            gridScroll = max(0f, row * (cellSize() + gap()) - dp(40f))
            gridVel = 0f
        }
        invalidate()
    }

    private fun dp(v: Float) = v * d
    private fun gap() = dp(6f)
    private fun cellSize() = (width - gap() * 4f) / 3f
    private fun itemPx() = max(1f, cardW * 0.30f)

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        cardW = min(w, h) * 0.80f
        cx = w / 2f
        cy = h * 0.5f
    }

    // ---------------------------------------------------------------- کاورها

    private fun cover(a: Album): Bitmap? {
        covers.get(a.id)?.let { return it }
        if (a.noCover) return null
        if (pending.add(a.id)) {
            val app = context.applicationContext
            executor.execute {
                val b = try {
                    AlbumRepo.loadCover(app, a.id, 360)
                } catch (e: Throwable) {
                    null
                }
                var col = 0
                var ok = false
                if (b != null) {
                    val sm = Bitmap.createScaledBitmap(b, 8, 8, true)
                    var r = 0
                    var g = 0
                    var bl = 0
                    for (y in 0 until 8) for (x in 0 until 8) {
                        val p = sm.getPixel(x, y)
                        r += Color.red(p)
                        g += Color.green(p)
                        bl += Color.blue(p)
                    }
                    sm.recycle()
                    col = Color.rgb(r / 64, g / 64, bl / 64)
                    ok = true
                }
                post {
                    pending.remove(a.id)
                    if (b != null) {
                        covers.put(a.id, b)
                        if (ok) {
                            val hsv = FloatArray(3)
                            Color.colorToHSV(col, hsv)
                            hsv[2] = max(hsv[2], 0.45f)
                            a.color = Color.HSVToColor(hsv)
                            a.hasColor = true
                        }
                    } else {
                        a.noCover = true
                    }
                    invalidate()
                }
            }
        }
        return null
    }

    private fun placeholder(a: Album): Bitmap {
        holders[a.id]?.let { return it }
        val bmp = Bitmap.createBitmap(96, 96, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val hsv = floatArrayOf(((a.id * 47L) % 360L).toFloat(), 0.35f, 0.36f)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.shader = LinearGradient(0f, 0f, 96f, 96f, Color.HSVToColor(hsv), Color.HSVToColor(floatArrayOf(hsv[0], 0.4f, 0.22f)), Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, 96f, 96f, p)
        p.shader = null
        p.color = Color.argb(200, 255, 255, 255)
        p.textAlign = Paint.Align.CENTER
        p.textSize = 44f
        c.drawText(a.title.take(1).uppercase(), 48f, 62f, p)
        if (holders.size > 80) holders.clear()
        holders[a.id] = bmp
        return bmp
    }

    // ---------------------------------------------------------------- مختصات ۳بعدی

    private fun offsetOf(t: Float): Float {
        val a = abs(t)
        val w = cardW
        val g = if (a <= 1f) a * 0.70f * w else 0.70f * w + 1.31f * w * (1f - 0.82f.pow(a - 1f))
        return if (t < 0f) -g else g
    }

    // ---------------------------------------------------------------- رسم

    override fun onDraw(c: Canvas) {
        val now = SystemClock.uptimeMillis()
        val dt = if (lastTime == 0L) 0.016f else ((now - lastTime) / 1000f).coerceIn(0f, 0.05f)
        lastTime = now
        var anim = step(dt)

        drawBackground(c)
        val n = albums.size
        if (n == 0) {
            invalidateIfNeeded(anim)
            return
        }

        val stackAlpha = 1f - modeT
        if (stackAlpha > 0.01f) drawStack(c, stackAlpha)
        if (modeT > 0.01f) drawGrid(c, modeT)

        if (anim) postInvalidateOnAnimation() else lastTime = 0L
    }

    private fun invalidateIfNeeded(anim: Boolean) {
        if (anim) postInvalidateOnAnimation() else lastTime = 0L
    }

    /** فیزیک اسکرول و جابه‌جایی بین دو حالت؛ true یعنی هنوز انیمیشن داریم */
    private fun step(dt: Float): Boolean {
        var anim = false
        val n = albums.size
        val target = if (gridMode) 1f else 0f
        if (modeT != target) {
            val dm = dt / 0.28f
            modeT = if (modeT < target) min(modeT + dm, 1f) else max(modeT - dm, 0f)
            anim = true
        }
        if (n == 0 || touching) return anim || touching

        if (!gridMode) {
            if (abs(vel) > 0.35f) {
                pos += vel * dt
                vel *= exp(-dt * 3.0f)
                if (pos < 0f) { pos = 0f; vel = 0f }
                if (pos > n - 1) { pos = (n - 1).toFloat(); vel = 0f }
                anim = true
            } else {
                vel = 0f
                val tg = if (snapTo >= 0) snapTo.toFloat() else pos.roundToInt().coerceIn(0, n - 1).toFloat()
                if (abs(pos - tg) > 0.002f) {
                    pos += (tg - pos) * (1f - exp(-dt * 14f))
                    anim = true
                } else {
                    pos = tg
                    snapTo = -1
                }
            }
        } else {
            val maxScroll = gridMax()
            if (abs(gridVel) > 20f) {
                gridScroll += gridVel * dt
                gridVel *= exp(-dt * 3.2f)
                if (gridScroll < 0f) { gridScroll = 0f; gridVel = 0f }
                if (gridScroll > maxScroll) { gridScroll = maxScroll; gridVel = 0f }
                anim = true
            } else {
                gridVel = 0f
            }
        }
        return anim
    }

    private fun mix(a: Int, b: Int, t: Float): Int = Color.rgb(
        (Color.red(a) + (Color.red(b) - Color.red(a)) * t).toInt(),
        (Color.green(a) + (Color.green(b) - Color.green(a)) * t).toInt(),
        (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * t).toInt()
    )

    private fun drawBackground(c: Canvas) {
        val n = albums.size
        var col = Color.rgb(70, 70, 78)
        if (n > 0) {
            val i0 = pos.toInt().coerceIn(0, n - 1)
            val i1 = (i0 + 1).coerceIn(0, n - 1)
            col = mix(albums[i0].color, albums[i1].color, (pos - i0).coerceIn(0f, 1f))
        }
        val top = mix(col, Color.WHITE, 0.10f)
        val bottom = mix(col, Color.BLACK, 0.55f)
        fill.shader = LinearGradient(0f, 0f, 0f, height.toFloat(), top, bottom, Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, width.toFloat(), height.toFloat(), fill)
        fill.shader = null
    }

    private fun drawStack(c: Canvas, gAlpha: Float) {
        val n = albums.size
        val center = pos.roundToInt().coerceIn(0, n - 1)
        hitCount = 0
        val range = 7
        // از دورترین به نزدیک‌ترین
        for (k in range downTo 1) {
            val a = center - k
            val b = center + k
            if (a >= 0) drawCard(c, a, a - pos, gAlpha)
            if (b < n) drawCard(c, b, b - pos, gAlpha)
        }
        drawCard(c, center, center - pos, gAlpha)
    }

    private fun drawCard(c: Canvas, index: Int, t: Float, gAlpha: Float) {
        val a = albums[index]
        val w = cardW
        val ang = max(-1f, min(1f, t)) * MAX_TILT
        val sinA = sin(ang)
        val cosA = cos(ang)
        val cyc = cy + offsetOf(t)
        val dist = 2.6f * w
        val fade = (1f - (abs(t) - 5f).coerceAtLeast(0f) * 0.45f).coerceIn(0f, 1f) * gAlpha
        if (fade <= 0.02f) return

        var k = 0
        for (r in 0..ROWS) {
            val y = -w / 2f + w * r / ROWS
            val z = -y * sinA
            val s = dist / (dist + z)
            val ys = cyc + y * cosA * s
            verts[k++] = cx - w / 2f * s
            verts[k++] = ys
            verts[k++] = cx + w / 2f * s
            verts[k++] = ys
        }
        val topY = min(verts[1], verts[ROWS * 4 + 1])
        val botY = max(verts[1], verts[ROWS * 4 + 1])
        if (botY < -w || topY > height + w) return

        val bmp = cover(a) ?: placeholder(a)
        paint.alpha = (255f * fade).toInt()
        c.drawBitmapMesh(bmp, 1, ROWS, verts, 0, null, 0, paint)

        // کمی تیره‌تر وقتی خوابیده‌تره
        val tilt = abs(ang) / MAX_TILT
        if (tilt > 0.02f) {
            path.reset()
            path.moveTo(verts[0], verts[1])
            path.lineTo(verts[2], verts[3])
            path.lineTo(verts[ROWS * 4 + 2], verts[ROWS * 4 + 3])
            path.lineTo(verts[ROWS * 4], verts[ROWS * 4 + 1])
            path.close()
            fill.color = Color.argb((60f * tilt * fade).toInt(), 0, 0, 0)
            c.drawPath(path, fill)
        }

        var bottomForHit = botY
        var topForHit = topY
        // نوار رنگی لبه‌ی نزدیک با اسم آلبوم و خواننده
        val strength = (abs(t) * 2.5f).coerceIn(0f, 1f)
        if (strength > 0.02f) {
            val row = if (ang < 0f) 0 else ROWS
            val ny = verts[row * 4 + 1]
            val xl = verts[row * 4]
            val xr = verts[row * 4 + 2]
            val sNear = (xr - xl) / w
            val sh = STRIP * w * sNear
            val top = if (ang < 0f) ny - sh else ny
            rect.set(xl, top, xr, top + sh)
            val sa = (255f * fade * strength).toInt()
            fill.color = Color.argb(sa, Color.red(a.color), Color.green(a.color), Color.blue(a.color))
            c.drawRect(rect, fill)
            drawStripText(c, a, rect, sa)
            topForHit = min(topForHit, rect.top)
            bottomForHit = max(bottomForHit, rect.bottom)
        }
        if (hitCount < hitIdx.size) {
            hitIdx[hitCount] = index
            hitTop[hitCount] = topForHit
            hitBottom[hitCount] = bottomForHit
            hitCount++
        }
    }

    private fun drawStripText(c: Canvas, a: Album, r: RectF, alpha: Int) {
        val lum = (0.299f * Color.red(a.color) + 0.587f * Color.green(a.color) + 0.114f * Color.blue(a.color)) / 255f
        val fg = if (lum > 0.55f) Color.rgb(24, 24, 28) else Color.WHITE
        val avail = r.width() - dp(16f)
        var size = r.height() * 0.58f
        titlePaint.textSize = size
        artistPaint.textSize = size
        val gapPx = size * 0.35f
        var tw = titlePaint.measureText(a.title)
        var aw = artistPaint.measureText(a.artist)
        if (tw + gapPx + aw > avail) {
            val k = max(0.65f, avail / (tw + gapPx + aw))
            size *= k
            titlePaint.textSize = size
            artistPaint.textSize = size
            tw = titlePaint.measureText(a.title)
            aw = artistPaint.measureText(a.artist)
        }
        var title = a.title
        var artist = a.artist
        while (tw + gapPx + aw > avail && title.length > 3) {
            title = title.substring(0, title.length - 2).trimEnd() + "\u2026"
            tw = titlePaint.measureText(title)
        }
        while (tw + gapPx + aw > avail && artist.length > 3) {
            artist = artist.substring(0, artist.length - 2).trimEnd() + "\u2026"
            aw = artistPaint.measureText(artist)
        }
        val total = tw + gapPx + aw
        val x = r.centerX() - total / 2f
        val base = r.centerY() + size * 0.35f
        titlePaint.color = Color.argb(alpha, Color.red(fg), Color.green(fg), Color.blue(fg))
        artistPaint.color = Color.argb((alpha * 0.8f).toInt(), Color.red(fg), Color.green(fg), Color.blue(fg))
        c.drawText(title, x, base, titlePaint)
        c.drawText(artist, x + tw + gapPx, base, artistPaint)
    }

    // ---------------------------------------------------------------- گالری

    private fun gridTop(): Float = topInset + dp(72f)

    private fun gridMax(): Float {
        val rows = (albums.size + 2) / 3
        val content = gridTop() + rows * (cellSize() + gap()) + dp(120f) + bottomInset
        return max(0f, content - height)
    }

    private fun drawGrid(c: Canvas, alpha: Float) {
        val cell = cellSize()
        val g = gap()
        val top = gridTop()
        val n = albums.size
        val layer = c.saveLayerAlpha(0f, 0f, width.toFloat(), height.toFloat(), (255f * alpha).toInt())
        for (i in 0 until n) {
            val row = i / 3
            val col = i % 3
            val x = g + col * (cell + g)
            val y = top + row * (cell + g) - gridScroll
            if (y > height || y + cell < 0) continue
            rect.set(x, y, x + cell, y + cell)
            val bmp = cover(albums[i]) ?: placeholder(albums[i])
            c.save()
            path.reset()
            path.addRoundRect(rect, dp(8f), dp(8f), Path.Direction.CW)
            c.clipPath(path)
            paint.alpha = 255
            c.drawBitmap(bmp, null, rect, paint)
            c.restore()
        }
        c.restoreToCount(layer)
    }

    // ---------------------------------------------------------------- لمس

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (albums.isEmpty()) return true
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                touching = true
                moved = false
                downX = e.x
                downY = e.y
                lastY = e.y
                vel = 0f
                gridVel = 0f
                snapTo = -1
                velocity?.recycle()
                velocity = VelocityTracker.obtain()
                velocity?.addMovement(e)
                parent?.requestDisallowInterceptTouchEvent(true)
            }
            MotionEvent.ACTION_MOVE -> {
                velocity?.addMovement(e)
                if (!moved && abs(e.y - downY) > slop) moved = true
                if (moved) {
                    val dy = e.y - lastY
                    if (!gridMode) {
                        pos -= dy / itemPx()
                        pos = pos.coerceIn(-0.4f, albums.size - 0.6f)
                    } else {
                        gridScroll = (gridScroll - dy).coerceIn(0f, gridMax())
                    }
                    invalidate()
                }
                lastY = e.y
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                velocity?.addMovement(e)
                touching = false
                if (e.actionMasked == MotionEvent.ACTION_UP && !moved) {
                    tap(e.x, e.y)
                } else if (moved) {
                    velocity?.computeCurrentVelocity(1000)
                    val vy = velocity?.yVelocity ?: 0f
                    if (!gridMode) {
                        vel = (-vy / itemPx()).coerceIn(-14f, 14f)
                    } else {
                        gridVel = -vy
                    }
                }
                velocity?.recycle()
                velocity = null
                invalidate()
            }
        }
        return true
    }

    private fun tap(x: Float, y: Float) {
        if (!gridMode) {
            val center = pos.roundToInt().coerceIn(0, albums.size - 1)
            // از جلوترین کارت شروع می‌کنیم (آخرین رسم‌شده)
            var i = hitCount - 1
            while (i >= 0) {
                if (y >= hitTop[i] && y <= hitBottom[i] && abs(x - cx) <= cardW * 0.58f) {
                    val idx = hitIdx[i]
                    if (idx == center) {
                        listener?.onAlbumTap(albums[idx], idx)
                    } else {
                        snapTo = idx
                        vel = 0f
                    }
                    invalidate()
                    return
                }
                i--
            }
        } else {
            val cell = cellSize()
            val g = gap()
            val col = ((x - g) / (cell + g)).toInt()
            val row = ((y - gridTop() + gridScroll) / (cell + g)).toInt()
            if (col in 0..2 && y >= gridTop() - g) {
                val idx = row * 3 + col
                if (idx in 0 until albums.size) {
                    pos = idx.toFloat()
                    snapTo = -1
                    vel = 0f
                    gridMode = false
                    invalidate()
                }
            }
        }
    }

    companion object {
        private const val ROWS = 12
        private const val STRIP = 0.075f
        private const val MAX_TILT = 1.22f   // حدود ۷۰ درجه (رادیان)
    }
}
