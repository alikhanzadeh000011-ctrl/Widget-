package com.example.mediawidget

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.util.concurrent.Executors

/** صفحه‌ی آلبوم‌ها: چیدمان ۳بعدی یا گالری، با نوار گرد پایین */
class AlbumsActivity : Activity(), AlbumStackView.Listener {

    private lateinit var stack: AlbumStackView
    private lateinit var toggle: ToggleView
    private lateinit var pill: LinearLayout
    private lateinit var permPanel: LinearLayout
    private lateinit var emptyText: TextView
    private var topInset = 0
    private var bottomInset = 0

    private fun perm(): String =
        if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE

    private fun hasPerm(): Boolean = checkSelfPermission(perm()) == PackageManager.PERMISSION_GRANTED

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        DarkUi.guard(this) { build() }
    }

    private fun dp(v: Float) = DarkUi.dp(this, v)

    @Suppress("DEPRECATION")
    private fun build() {
        DarkUi.setupWindow(this)
        val root = FrameLayout(this)
        root.setBackgroundColor(DarkUi.BG)

        stack = AlbumStackView(this)
        stack.listener = this
        root.addView(stack, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        // دکمه‌ی تغییر حالت (بالا-راست)
        toggle = ToggleView(this)
        toggle.setOnClickListener {
            stack.toggleMode()
            toggle.grid = stack.isGrid()
            toggle.invalidate()
        }
        val tlp = FrameLayout.LayoutParams(dp(52f), dp(52f), Gravity.TOP or Gravity.END)
        tlp.setMargins(0, dp(14f), dp(18f), 0)
        root.addView(toggle, tlp)

        // نوار گرد پایین: آلبوم‌ها | دیسک (برگشت به صفحه‌ی وینیل)
        pill = LinearLayout(this)
        pill.orientation = LinearLayout.HORIZONTAL
        pill.gravity = Gravity.CENTER
        val pbg = GradientDrawable()
        pbg.setColor(Color.argb(235, 242, 242, 246))
        pbg.cornerRadius = dp(32f).toFloat()
        pill.background = pbg
        pill.setPadding(dp(8f), dp(8f), dp(8f), dp(8f))
        pill.addView(pillItem(R.drawable.ic_albums_logo, true) { })
        pill.addView(pillItem(R.drawable.ic_theme_logo, false) { finish() })
        val plp = FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL)
        plp.bottomMargin = dp(28f)
        root.addView(pill, plp)

        // پیام نبودن آلبوم
        emptyText = TextView(this)
        emptyText.text = "No albums found on this device"
        emptyText.setTextColor(DarkUi.LABEL)
        emptyText.textSize = 18f
        emptyText.typeface = DarkUi.font(this)
        emptyText.gravity = Gravity.CENTER
        emptyText.visibility = View.GONE
        root.addView(emptyText, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        // درخواست مجوز
        permPanel = LinearLayout(this)
        permPanel.orientation = LinearLayout.VERTICAL
        permPanel.gravity = Gravity.CENTER
        permPanel.setPadding(dp(32f), 0, dp(32f), 0)
        val msg = TextView(this)
        msg.text = "Allow access to your music files to show your albums."
        msg.setTextColor(Color.WHITE)
        msg.textSize = 18f
        msg.typeface = DarkUi.font(this)
        msg.gravity = Gravity.CENTER
        msg.setLineSpacing(0f, 1.2f)
        permPanel.addView(msg)
        val btn = DarkUi.pill(this, "Allow access") { requestPermissions(arrayOf(perm()), 7) }
        val blp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        blp.topMargin = dp(22f)
        permPanel.addView(btn, blp)
        permPanel.visibility = View.GONE
        root.addView(permPanel, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        root.setOnApplyWindowInsetsListener { _, ins ->
            topInset = ins.systemWindowInsetTop
            bottomInset = ins.systemWindowInsetBottom
            stack.setInsets(topInset, bottomInset)
            val l = toggle.layoutParams as FrameLayout.LayoutParams
            l.topMargin = topInset + dp(10f)
            toggle.layoutParams = l
            val p = pill.layoutParams as FrameLayout.LayoutParams
            p.bottomMargin = bottomInset + dp(24f)
            pill.layoutParams = p
            ins
        }

        setContentView(root)
        root.requestApplyInsets()
        refreshState()
    }

    private fun pillItem(res: Int, selected: Boolean, onClick: () -> Unit): View {
        val box = FrameLayout(this)
        if (selected) {
            val g = GradientDrawable()
            g.setColor(Color.argb(40, 20, 20, 30))
            g.cornerRadius = dp(26f).toFloat()
            box.background = g
        }
        val img = ImageView(this)
        img.setImageResource(res)
        img.setColorFilter(Color.rgb(40, 40, 48))
        img.scaleType = ImageView.ScaleType.FIT_CENTER
        box.addView(img, FrameLayout.LayoutParams(dp(28f), dp(28f), Gravity.CENTER))
        box.setOnClickListener { onClick() }
        val lp = LinearLayout.LayoutParams(dp(66f), dp(48f))
        lp.setMargins(dp(4f), 0, dp(4f), 0)
        box.layoutParams = lp
        return box
    }

    override fun onResume() {
        super.onResume()
        if (::stack.isInitialized) refreshState()
    }

    private var loaded = false

    private fun refreshState() {
        if (hasPerm()) {
            permPanel.visibility = View.GONE
            if (!loaded) loadAlbums()
        } else {
            permPanel.visibility = View.VISIBLE
            stack.visibility = View.INVISIBLE
        }
    }

    private fun loadAlbums() {
        loaded = true
        val app = applicationContext
        Executors.newSingleThreadExecutor().execute {
            val list = AlbumRepo.load(app)
            runOnUiThread {
                if (isDestroyed) return@runOnUiThread
                stack.visibility = View.VISIBLE
                stack.setAlbums(list)
                emptyText.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
            }
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        refreshState()
    }

    override fun onAlbumTap(album: Album, index: Int) {
        // مرحله‌ی بعد: صفحه‌ی آلبوم با لیست ترک‌ها
        Toast.makeText(this, album.title + " (" + album.tracks + " tracks)", Toast.LENGTH_SHORT).show()
    }

    /** دکمه‌ی گرد بالا-راست: آیکن شبکه (در حالت ۳بعدی) یا آیکن پشته (در حالت گالری) */
    private class ToggleView(ctx: Activity) : View(ctx) {
        var grid = false
        private val p = Paint(Paint.ANTI_ALIAS_FLAG)
        private val r = RectF()

        override fun onDraw(c: Canvas) {
            val w = width.toFloat()
            val cx = w / 2f
            val cy = height / 2f
            p.style = Paint.Style.FILL
            p.color = Color.argb(90, 0, 0, 0)
            c.drawCircle(cx, cy, w / 2f, p)
            p.color = Color.WHITE
            val u = w / 52f
            if (!grid) {
                // آیکن شبکه ۲x۲
                val s = 8f * u
                val g = 4f * u
                for (i in 0..1) for (j in 0..1) {
                    val x = cx - s - g / 2f + i * (s + g)
                    val y = cy - s - g / 2f + j * (s + g)
                    r.set(x, y, x + s, y + s)
                    c.drawRoundRect(r, 2f * u, 2f * u, p)
                }
            } else {
                // آیکن کارت‌های روی هم
                for (i in 0..2) {
                    val y = cy - 9f * u + i * 9f * u
                    val inset = (2 - i) * 2.5f * u
                    r.set(cx - 12f * u + inset, y - 3f * u, cx + 12f * u - inset, y + 3f * u)
                    c.drawRoundRect(r, 1.5f * u, 1.5f * u, p)
                }
            }
        }
    }
}
