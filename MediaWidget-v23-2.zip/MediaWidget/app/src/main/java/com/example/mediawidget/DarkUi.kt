package com.example.mediawidget

import android.app.Activity
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import kotlin.math.min

/** ظاهر تیره و فول‌اسکرین صفحه‌های تنظیمات (شبیه MD Vinyl، فقط ظاهر) */
object DarkUi {
    val BG = Color.rgb(42, 43, 51)
    val CARD = Color.rgb(47, 48, 58)
    val CARD_LINE = Color.rgb(60, 61, 72)
    val LABEL = Color.rgb(140, 141, 152)
    val PURPLE = Color.rgb(133, 76, 230)
    val GREEN = Color.rgb(76, 217, 100)

    fun dp(ctx: Context, v: Float): Int = (v * ctx.resources.displayMetrics.density).toInt()

    fun font(ctx: Context): Typeface = try {
        ctx.resources.getFont(R.font.sf_pro_soft)
    } catch (e: Exception) {
        Typeface.DEFAULT
    }

    @Suppress("DEPRECATION")
    fun setupWindow(act: Activity) {
        try {
            val w = act.window
            w.setBackgroundDrawable(ColorDrawable(BG))
            w.statusBarColor = Color.TRANSPARENT
            w.navigationBarColor = BG
            // فول‌اسکرین (زیر استاتوس‌بار) با آیکن‌های روشن
            w.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
        } catch (e: Throwable) {
            e.printStackTrace()
        }
    }

    /** اگه ساختن صفحه خطا داد، به‌جای بسته شدن اپ متن خطا رو نشون می‌ده (برای فرستادن به من) */
    fun guard(act: Activity, block: () -> Unit) {
        try {
            block()
        } catch (e: Throwable) {
            val tv = TextView(act)
            tv.text = "Error (please send me this text):\n\n" + android.util.Log.getStackTraceString(e)
            tv.setTextIsSelectable(true)
            tv.setTextColor(Color.WHITE)
            tv.textSize = 12f
            tv.setPadding(dp(act, 16f), dp(act, 48f), dp(act, 16f), dp(act, 16f))
            val sv = ScrollView(act)
            sv.setBackgroundColor(Color.BLACK)
            sv.addView(tv)
            act.setContentView(sv)
        }
    }

    // ---------------------------------------------------------------- اجزا

    fun sectionLabel(ctx: Context, text: String): TextView {
        val t = TextView(ctx)
        t.text = text
        t.setTextColor(LABEL)
        t.textSize = 17f
        t.typeface = font(ctx)
        t.setPadding(dp(ctx, 30f), dp(ctx, 26f), dp(ctx, 30f), dp(ctx, 10f))
        return t
    }

    fun card(ctx: Context): LinearLayout {
        val c = LinearLayout(ctx)
        c.orientation = LinearLayout.VERTICAL
        val g = GradientDrawable()
        g.setColor(CARD)
        g.cornerRadius = dp(ctx, 24f).toFloat()
        g.setStroke(dp(ctx, 1f), CARD_LINE)
        c.background = g
        val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        lp.setMargins(dp(ctx, 20f), 0, dp(ctx, 20f), 0)
        c.layoutParams = lp
        return c
    }

    /** یک ردیف داخل کارت: عنوان (و توضیح اختیاری) + چیز سمت راست */
    fun addRow(card: LinearLayout, title: String, subtitle: String?, trailing: View?, onClick: (() -> Unit)?): LinearLayout {
        val ctx = card.context
        if (card.childCount > 0) {
            val line = View(ctx)
            line.setBackgroundColor(CARD_LINE)
            card.addView(line, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(ctx, 1f)))
        }
        val row = LinearLayout(ctx)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(dp(ctx, 22f), dp(ctx, 24f), dp(ctx, 20f), dp(ctx, 24f))

        val texts = LinearLayout(ctx)
        texts.orientation = LinearLayout.VERTICAL
        val t = TextView(ctx)
        t.text = title
        t.setTextColor(Color.WHITE)
        t.textSize = 19f
        t.typeface = font(ctx)
        t.paint.isFakeBoldText = true
        texts.addView(t)
        if (subtitle != null) {
            val s = TextView(ctx)
            s.text = subtitle
            s.setTextColor(LABEL)
            s.textSize = 17f
            s.typeface = font(ctx)
            s.setPadding(0, dp(ctx, 12f), 0, 0)
            texts.addView(s)
        }
        row.addView(texts, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        if (trailing != null) row.addView(trailing)
        if (onClick != null) {
            row.isClickable = true
            row.setOnClickListener { onClick() }
        }
        card.addView(row)
        return row
    }

    fun pill(ctx: Context, text: String, onClick: () -> Unit): TextView {
        val t = TextView(ctx)
        t.text = text
        t.setTextColor(Color.WHITE)
        t.textSize = 18f
        t.typeface = font(ctx)
        t.gravity = Gravity.CENTER
        t.setPadding(dp(ctx, 22f), dp(ctx, 10f), dp(ctx, 22f), dp(ctx, 10f))
        val g = GradientDrawable()
        g.setColor(Color.TRANSPARENT)
        g.cornerRadius = dp(ctx, 30f).toFloat()
        g.setStroke(dp(ctx, 1.5f), Color.rgb(230, 230, 235))
        t.background = g
        t.setOnClickListener { onClick() }
        return t
    }

    fun pillSmall(ctx: Context, text: String, onClick: () -> Unit): TextView {
        val t = pill(ctx, text, onClick)
        t.textSize = 15f
        t.setPadding(dp(ctx, 16f), dp(ctx, 8f), dp(ctx, 16f), dp(ctx, 8f))
        return t
    }

    fun glyph(ctx: Context, kind: Int, sizeDp: Float): GlyphView {
        val g = GlyphView(ctx, kind)
        g.layoutParams = LinearLayout.LayoutParams(dp(ctx, sizeDp), dp(ctx, sizeDp))
        return g
    }

    /** صفحه‌ی تیره با هدر (فلش برگشت + عنوان) و بدنه‌ی اسکرول‌شونده */
    @Suppress("DEPRECATION")
    class Screen(val act: Activity, title: String, showBack: Boolean = true) {
        val root = FrameLayout(act)
        val body = LinearLayout(act)
        private val header = LinearLayout(act)
        private val baseTop = dp(act, 16f)

        init {
            setupWindow(act)
            root.setBackgroundColor(BG)
            body.orientation = LinearLayout.VERTICAL

            header.orientation = LinearLayout.HORIZONTAL
            header.gravity = Gravity.CENTER_VERTICAL
            header.setPadding(dp(act, 18f), baseTop, dp(act, 20f), dp(act, 12f))
            if (showBack) {
                val b = GlyphView(act, GlyphView.BACK)
                b.isClickable = true
                b.setOnClickListener { act.finish() }
                header.addView(b, LinearLayout.LayoutParams(dp(act, 44f), dp(act, 44f)))
            }
            val t = TextView(act)
            t.text = title
            t.setTextColor(Color.WHITE)
            t.textSize = 28f
            t.typeface = font(act)
            t.paint.isFakeBoldText = true
            t.setPadding(dp(act, if (showBack) 10f else 12f), 0, 0, 0)
            header.addView(t)
            body.addView(header)

            val scroll = ScrollView(act)
            scroll.isFillViewport = true
            scroll.addView(body)
            root.addView(scroll, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))

            root.setOnApplyWindowInsetsListener { _, ins ->
                val top = ins.systemWindowInsetTop
                val bottom = ins.systemWindowInsetBottom
                header.setPadding(dp(act, 18f), baseTop + top, dp(act, 20f), dp(act, 12f))
                body.setPadding(0, 0, 0, bottom + dp(act, 28f))
                ins
            }
        }

        fun show() {
            act.setContentView(root)
            root.requestApplyInsets()
        }
    }
}

/** آیکن‌های ساده‌ی صفحه‌های تنظیمات */
class GlyphView(ctx: Context, private val kind: Int) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val cx = w / 2f
        val cy = h / 2f
        val u = min(w, h) / 40f
        p.strokeCap = Paint.Cap.ROUND
        p.strokeJoin = Paint.Join.ROUND
        path.reset()
        when (kind) {
            BACK, CHEVRON -> {
                p.style = Paint.Style.STROKE
                p.strokeWidth = 3.2f * u
                p.color = Color.WHITE
                if (kind == BACK) {
                    path.moveTo(cx + 5f * u, cy - 11f * u)
                    path.lineTo(cx - 6f * u, cy)
                    path.lineTo(cx + 5f * u, cy + 11f * u)
                } else {
                    path.moveTo(cx - 4f * u, cy - 10f * u)
                    path.lineTo(cx + 6f * u, cy)
                    path.lineTo(cx - 4f * u, cy + 10f * u)
                }
                c.drawPath(path, p)
            }
            CHECK -> {
                p.style = Paint.Style.FILL
                p.color = DarkUi.GREEN
                c.drawCircle(cx, cy, 14f * u, p)
                p.style = Paint.Style.STROKE
                p.strokeWidth = 3f * u
                p.color = Color.WHITE
                path.moveTo(cx - 6.5f * u, cy + 0.5f * u)
                path.lineTo(cx - 1.5f * u, cy + 5.5f * u)
                path.lineTo(cx + 7f * u, cy - 5f * u)
                c.drawPath(path, p)
            }
            PLUS -> {
                p.style = Paint.Style.FILL
                p.color = DarkUi.PURPLE
                c.drawCircle(cx, cy, 17f * u, p)
                p.style = Paint.Style.STROKE
                p.strokeWidth = 3f * u
                p.color = Color.WHITE
                c.drawLine(cx - 8f * u, cy, cx + 8f * u, cy, p)
                c.drawLine(cx, cy - 8f * u, cx, cy + 8f * u, p)
            }
            ROUND_CHEVRON -> {
                p.style = Paint.Style.FILL
                p.color = Color.argb(120, 20, 20, 26)
                c.drawCircle(cx, cy, 17f * u, p)
                p.style = Paint.Style.STROKE
                p.strokeWidth = 1.5f * u
                p.color = Color.rgb(70, 71, 82)
                c.drawCircle(cx, cy, 17f * u, p)
                p.strokeWidth = 2.6f * u
                p.color = Color.WHITE
                path.moveTo(cx - 3f * u, cy - 6.5f * u)
                path.lineTo(cx + 4f * u, cy)
                path.lineTo(cx - 3f * u, cy + 6.5f * u)
                c.drawPath(path, p)
            }
        }
    }

    companion object {
        const val BACK = 0
        const val CHEVRON = 1
        const val CHECK = 2
        const val PLUS = 3
        const val ROUND_CHEVRON = 4
    }
}
