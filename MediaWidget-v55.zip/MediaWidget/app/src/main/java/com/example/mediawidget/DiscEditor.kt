package com.example.mediawidget

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView

/** اسلایدر شفافیت: نوار شطرنجی با گرادیان رنگ و دسته‌ی گرد */
class AlphaSlider(ctx: Context, private val onChange: (Float) -> Unit) : View(ctx) {
    var value = 1f
        set(v) {
            field = v.coerceIn(0f, 1f)
            invalidate()
        }
    var tint = Color.WHITE
        set(v) {
            field = v
            invalidate()
        }

    private val d = resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val box = RectF()
    private val path = Path()

    override fun onDraw(c: Canvas) {
        val h = 22f * d
        val cy = height / 2f
        val m = 14f * d
        box.set(m, cy - h / 2f, width - m, cy + h / 2f)
        path.reset()
        path.addRoundRect(box, h / 2f, h / 2f, Path.Direction.CW)
        c.save()
        c.clipPath(path)
        // شطرنجی
        val sq = 7f * d
        var yy = box.top
        var row = 0
        while (yy < box.bottom) {
            var xx = box.left
            var col = row % 2
            while (xx < box.right) {
                p.color = if (col % 2 == 0) Color.rgb(236, 236, 238) else Color.rgb(168, 168, 174)
                c.drawRect(xx, yy, xx + sq, yy + sq, p)
                xx += sq
                col++
            }
            yy += sq
            row++
        }
        p.shader = LinearGradient(
            box.left, 0f, box.right, 0f,
            Color.argb(0, Color.red(tint), Color.green(tint), Color.blue(tint)),
            Color.argb(255, Color.red(tint), Color.green(tint), Color.blue(tint)),
            Shader.TileMode.CLAMP
        )
        c.drawRect(box, p)
        p.shader = null
        c.restore()
        val x = box.left + (box.width()) * value
        p.style = Paint.Style.FILL
        p.color = Color.WHITE
        c.drawCircle(x, cy, h / 2f + 3f * d, p)
        p.color = Color.argb(60, 0, 0, 0)
        p.style = Paint.Style.STROKE
        p.strokeWidth = 1f * d
        c.drawCircle(x, cy, h / 2f + 3f * d, p)
        p.style = Paint.Style.FILL
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        parent.requestDisallowInterceptTouchEvent(true)
        val m = 14f * d
        value = ((e.x - m) / (width - 2f * m))
        onChange(value)
        return true
    }
}

/** آیکن ساده‌ی ✕ یا ✓ برای بالای ویرایشگر */
class EditorGlyph(ctx: Context, private val check: Boolean) : View(ctx) {
    private val d = resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onDraw(c: Canvas) {
        p.style = Paint.Style.STROKE
        p.strokeWidth = 2.4f * d
        p.strokeCap = Paint.Cap.ROUND
        p.strokeJoin = Paint.Join.ROUND
        p.color = Color.WHITE
        val cx = width / 2f
        val cy = height / 2f
        val l = 7f * d
        if (check) {
            val path = Path()
            path.moveTo(cx - l, cy + 0.5f * d)
            path.lineTo(cx - l * 0.3f, cy + l * 0.75f)
            path.lineTo(cx + l, cy - l * 0.7f)
            c.drawPath(path, p)
        } else {
            c.drawLine(cx - l, cy - l, cx + l, cy + l, p)
            c.drawLine(cx + l, cy - l, cx - l, cy + l, p)
        }
    }
}

/**
 * ویرایشگر دیسک (مثل MD): پنل پایین با تب‌های Vinyl و Effect، ✕ برای برگشت و ✓ برای تأیید.
 * تغییرها همون لحظه روی دیسکِ پشت پنل دیده میشن.
 */
class DiscEditor(
    private val act: VinylActivity,
    private val vinyl: VinylView,
    private val editIndex: Int,      // شماره‌ی دیسک ذخیره‌شده‌ای که ویرایش میشه؛ -1 یعنی دیسک جدید
    start: DiscStyle
) : FrameLayout(act) {

    var onClosed: (() -> Unit)? = null

    private val d = resources.displayMetrics.density
    private val tf: Typeface = try {
        resources.getFont(R.font.sf_pro_soft)
    } catch (e: Exception) {
        Typeface.DEFAULT
    }
    private val compact = resources.displayMetrics.heightPixels < (520f * d)

    private val st = start.copy().also { it.auto = false }
    private val oldStyle = DiscStyles.load(act)
    private val wasOn = DiscStyles.isOn(act)
    private val oldFile = ThemeStore.selected(act, ThemeStore.DISC)
    private val oldSaved = DiscStyles.savedIndex(act)

    private var touched = false
    private var tab = 0
    private var closing = false

    private val panel = LinearLayout(act)
    private val content = LinearLayout(act)
    private val tabs = ArrayList<TextView>()

    private val palette = DiscStyles.PALETTE

    private fun dp(v: Float) = (v * d).toInt()

    private val applyRun = Runnable {
        DiscStyles.save(act, st)
        DiscStyles.setOn(act, true)
        ThemeStore.select(act, ThemeStore.DISC, null)
        vinyl.reloadDisc()
    }

    private fun changed() {
        touched = true
        removeCallbacks(applyRun)
        postDelayed(applyRun, 70)
    }

    init {
        panel.orientation = LinearLayout.VERTICAL
        val r = 28f * d
        val bg = GradientDrawable()
        bg.setColor(Color.rgb(28, 27, 32))
        bg.cornerRadii = floatArrayOf(r, r, r, r, 0f, 0f, 0f, 0f)
        panel.background = bg
        panel.isClickable = true
        panel.setPadding(0, 0, 0, if (compact) dp(10f) else dp(26f))

        // بالا: ✕  Vinyl  Effect  ✓
        val head = LinearLayout(act)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        val close = EditorGlyph(act, false)
        close.setOnClickListener { cancel() }
        head.addView(close, LinearLayout.LayoutParams(dp(56f), dp(52f)))
        val sp1 = View(act)
        head.addView(sp1, LinearLayout.LayoutParams(0, 1, 1f))
        for ((i, name) in listOf("Vinyl", "Effect").withIndex()) {
            val t = TextView(act)
            t.text = name
            t.textSize = 17f
            t.typeface = tf
            t.gravity = Gravity.CENTER
            t.setPadding(dp(14f), 0, dp(14f), 0)
            t.setOnClickListener {
                tab = i
                build()
            }
            tabs.add(t)
            head.addView(t, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(52f)))
        }
        val sp2 = View(act)
        head.addView(sp2, LinearLayout.LayoutParams(0, 1, 1f))
        val ok = EditorGlyph(act, true)
        ok.setOnClickListener { confirm() }
        head.addView(ok, LinearLayout.LayoutParams(dp(56f), dp(52f)))
        panel.addView(head, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        content.orientation = LinearLayout.VERTICAL
        content.setPadding(dp(18f), 0, dp(18f), 0)
        panel.addView(content, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        addView(panel, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT, Gravity.BOTTOM))
        build()

        panel.alpha = 0f
        panel.post {
            panel.translationY = panel.height.toFloat()
            panel.alpha = 1f
            panel.animate().translationY(0f).setDuration(240).setInterpolator(DecelerateInterpolator()).start()
        }
    }

    private fun label(text: String): TextView {
        val t = TextView(act)
        t.text = text
        t.setTextColor(Color.WHITE)
        t.textSize = 15f
        t.typeface = tf
        return t
    }

    private fun rowBox(): LinearLayout {
        val r = LinearLayout(act)
        r.orientation = LinearLayout.HORIZONTAL
        r.gravity = Gravity.CENTER_VERTICAL
        r.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(if (compact) 40f else 46f))
        return r
    }

    private fun colorRow(name: String, get: () -> Int, set: (Int) -> Unit): LinearLayout {
        val row = rowBox()
        row.addView(label(name), LinearLayout.LayoutParams(dp(72f), ViewGroup.LayoutParams.WRAP_CONTENT))
        val cur = get()
        var matched = false
        // دایره‌ها با وزن مساوی تقسیم میشن تا همیشه تو عرض صفحه جا بشن و انتخابگر رنگ بیرون نزنه
        val wl = { LinearLayout.LayoutParams(0, dp(40f), 1f) }
        for (col in palette) {
            val sw = SwatchView(act, col, false)
            sw.chosen = cur == col
            if (sw.chosen) matched = true
            sw.setOnClickListener {
                set(col)
                changed()
                build()
            }
            row.addView(sw, wl())
        }
        // رنگ دلخواه (از انتخابگر): همون رنگ هم به‌صورت یه دایره نشون داده میشه
        if (!matched) {
            val custom = SwatchView(act, cur, false)
            custom.chosen = true
            row.addView(custom, wl())
        }
        val pick = SwatchView(act, Color.WHITE, true)
        pick.setOnClickListener {
            ColorPickerView.show(act, get(), name) { col ->
                set(col)
                changed()
                build()
            }
        }
        row.addView(pick, wl())
        return row
    }

    private fun opacityRow(get: () -> Float, tint: Int, set: (Float) -> Unit): LinearLayout {
        val row = rowBox()
        row.addView(label("Opacity"), LinearLayout.LayoutParams(dp(72f), ViewGroup.LayoutParams.WRAP_CONTENT))
        val sl = AlphaSlider(act) { v ->
            set(v)
            changed()
        }
        sl.value = get()
        sl.tint = tint
        row.addView(sl, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f))
        return row
    }

    private fun chip(text: String, on: Boolean, click: () -> Unit): TextView {
        val t = TextView(act)
        t.text = text
        t.textSize = 15f
        t.typeface = tf
        t.gravity = Gravity.CENTER
        t.setTextColor(Color.WHITE)
        val g = GradientDrawable()
        g.cornerRadius = dp(18f).toFloat()
        g.setColor(if (on) Color.rgb(108, 70, 222) else Color.rgb(52, 52, 60))
        t.background = g
        t.setOnClickListener { click() }
        return t
    }

    private fun build() {
        for ((i, t) in tabs.withIndex()) {
            t.setTextColor(if (i == tab) Color.WHITE else Color.rgb(142, 140, 147))
            t.typeface = if (i == tab) Typeface.create(tf, Typeface.BOLD) else tf
        }
        content.removeAllViews()
        if (tab == 0) {
            content.addView(colorRow("Color", { st.color }) { st.color = it })
            content.addView(opacityRow({ (st.opacity - 10) / 90f }, st.color) { st.opacity = 10 + (it * 90f).toInt() })
        } else {
            val effs = DiscStyles.EFFECTS
            for (rowIdx in 0 until 2) {
                val chips = LinearLayout(act)
                chips.orientation = LinearLayout.HORIZONTAL
                chips.gravity = Gravity.CENTER_VERTICAL
                for (k in 0 until 3) {
                    val (i, n) = effs[rowIdx * 3 + k]
                    val c = chip(n, st.effect == i) {
                        if (st.effect != i) {
                            st.effect = i
                            if (i != DiscStyles.NONE) {
                                // رنگ‌های آماده‌ی همین افکت (رنگ و شفافیت بدنه دست‌نخورده می‌مونه)
                                val pre = DiscStyles.preset(i)
                                st.c1 = pre.c1
                                st.c2 = pre.c2
                                st.effOpacity = pre.effOpacity
                            }
                            changed()
                            build()
                        }
                    }
                    val lp = LinearLayout.LayoutParams(0, dp(34f), 1f)
                    if (k > 0) lp.marginStart = dp(8f)
                    chips.addView(c, lp)
                }
                val clp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(if (compact) 38f else 44f))
                content.addView(chips, clp)
            }
            when (st.effect) {
                DiscStyles.SPLATTER -> {
                    // مثل MD: دو لایه‌ی Splatter، هر کدوم با رنگ جدا
                    content.addView(colorRow("Pattern 1", { st.c1 }) { st.c1 = it })
                    content.addView(colorRow("Pattern 2", { st.c2 }) { st.c2 = it })
                }
                DiscStyles.INK -> {
                    content.addView(colorRow("Color", { st.c1 }) { st.c1 = it })
                    content.addView(colorRow("Color 2", { st.c2 }) { st.c2 = it })
                }
                DiscStyles.MARBLE, DiscStyles.CROSS, DiscStyles.SPLIT ->
                    content.addView(colorRow("Color", { st.c1 }) { st.c1 = it })
            }
            if (st.effect != DiscStyles.NONE) {
                content.addView(opacityRow({ st.effOpacity / 100f }, st.c1) { st.effOpacity = (it * 100f).toInt() })
            }
        }
    }

    /** ✓: دیسک توی ردیف Vinyl ذخیره میشه (جدید یا جایگزین قبلی) و فعال میشه */
    private fun confirm() {
        if (closing) return
        if (touched) {
            removeCallbacks(applyRun)
            DiscStyles.save(act, st)
            DiscStyles.setOn(act, true)
            ThemeStore.select(act, ThemeStore.DISC, null)
            DiscStyles.setSavedIndex(act, DiscStyles.putSaved(act, editIndex, st))
            vinyl.reloadDisc()
        }
        close()
    }

    /** ✕ یا دکمه‌ی برگشت: هرچی بوده برمیگرده */
    fun cancel() {
        if (closing) return
        removeCallbacks(applyRun)
        if (touched) {
            DiscStyles.save(act, oldStyle)
            DiscStyles.setOn(act, wasOn)
            DiscStyles.setSavedIndex(act, oldSaved)
            ThemeStore.select(act, ThemeStore.DISC, oldFile)
            vinyl.reloadTheme()
        }
        close()
    }

    private fun close() {
        closing = true
        panel.animate().translationY(panel.height.toFloat()).setDuration(200).withEndAction {
            (parent as? ViewGroup)?.removeView(this)
            onClosed?.invoke()
        }.start()
    }
}
