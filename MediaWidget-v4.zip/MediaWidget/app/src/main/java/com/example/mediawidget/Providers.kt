package com.example.mediawidget

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.media.session.MediaController
import android.media.session.PlaybackState
import android.os.Bundle

/** همه‌ی ویجت‌ها از این ارث می‌برن: آپدیت و دکمه‌های کنترل پخش */
open class BaseWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        WidgetRenderer.updateAll(context)
    }

    override fun onAppWidgetOptionsChanged(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetId: Int,
        newOptions: Bundle
    ) {
        WidgetRenderer.updateAll(context)
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        when (intent.action) {
            ACTION_TOGGLE -> withController(context) { c ->
                if (c.playbackState?.state == PlaybackState.STATE_PLAYING) {
                    c.transportControls.pause()
                } else {
                    c.transportControls.play()
                }
            }
            ACTION_NEXT -> withController(context) { c -> c.transportControls.skipToNext() }
            ACTION_PREV -> withController(context) { c -> c.transportControls.skipToPrevious() }
        }
    }

    private fun withController(context: Context, block: (MediaController) -> Unit) {
        try {
            val list = MediaReader.controllers(context) ?: return
            val c = MediaReader.pick(list) ?: return
            block(c)
        } catch (e: SecurityException) {
            // دسترسی Notification access داده نشده
        }
    }

    companion object {
        const val ACTION_TOGGLE = "com.example.mediawidget.ACTION_TOGGLE"
        const val ACTION_NEXT = "com.example.mediawidget.ACTION_NEXT"
        const val ACTION_PREV = "com.example.mediawidget.ACTION_PREV"
    }
}

class Widget2x2Provider : BaseWidgetProvider()

class Widget2x2MiniProvider : BaseWidgetProvider()

class Widget2x1Provider : BaseWidgetProvider()

class Widget4x2Provider : BaseWidgetProvider()
