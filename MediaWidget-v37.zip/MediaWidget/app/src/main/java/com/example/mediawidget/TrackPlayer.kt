package com.example.mediawidget

import android.app.SearchManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.MediaStore
import android.widget.Toast
import java.io.File

/** پخش تو Samsung Music: یه ترک (جستجو یا باز کردن فایل) و کل لیست (فایل m3u) */
object TrackPlayer {

    private const val SAMSUNG = "com.sec.android.app.music"

    /** تپ روی یه ترک: پلیر داخلی (از همون ترک تا آخر صف) یا Samsung Music */
    fun play(ctx: Context, list: List<Track>, index: Int, album: Album?, folderMode: Boolean) {
        if (LibraryPrefs.playerType(ctx) == LibraryPrefs.PLAYER_BUILTIN) {
            PlayerService.start(ctx, list, index)
            return
        }
        playSamsung(ctx, list[index], album, folderMode)
    }

    private fun playSamsung(ctx: Context, t: Track, album: Album?, folderMode: Boolean) {
        when (LibraryPrefs.playMethod(ctx)) {
            LibraryPrefs.PLAY_OPEN -> openFile(ctx, t)
            else -> if (!viaSearch(ctx, t, album, folderMode)) openFile(ctx, t)
        }
    }

    /** دکمه‌ی Play یا Shuffle: کل آلبوم یا پوشه به‌صورت یه لیست پخش (m3u) */
    fun playAll(ctx: Context, list: List<Track>, shuffle: Boolean, album: Album?, folderMode: Boolean) {
        if (list.isEmpty()) return
        if (LibraryPrefs.playerType(ctx) == LibraryPrefs.PLAYER_BUILTIN) {
            PlayerService.start(ctx, if (shuffle) list.shuffled() else list, 0)
            return
        }
        val tracks = (if (shuffle) list.shuffled() else list).filter { it.path.isNotBlank() }
        if (tracks.isEmpty()) {
            Toast.makeText(ctx, "Could not read the file paths, playing one track", Toast.LENGTH_SHORT).show()
            playSamsung(ctx, list[0], album, folderMode)
            return
        }
        val dir = File(ctx.cacheDir, "playlists")
        dir.mkdirs()
        dir.listFiles()?.forEach { it.delete() }
        val name = "queue_" + System.currentTimeMillis() + ".m3u"
        val sb = StringBuilder("#EXTM3U\n")
        for (t in tracks) {
            val label = if (t.artist.isNotBlank()) t.artist + " - " + t.title else t.title
            sb.append("#EXTINF:").append(t.durationMs / 1000).append(',').append(label).append('\n')
            sb.append(t.path).append('\n')
        }
        try {
            File(dir, name).writeText(sb.toString())
        } catch (e: Exception) {
            Toast.makeText(ctx, "Could not create the playlist, playing one track", Toast.LENGTH_SHORT).show()
            playSamsung(ctx, tracks[0], album, folderMode)
            return
        }
        val uri = Uri.parse("content://" + ctx.packageName + ".playlists/" + name)
        for (type in arrayOf("audio/x-mpegurl", "audio/mpegurl")) {
            val i = Intent(Intent.ACTION_VIEW)
            i.setDataAndType(uri, type)
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            i.setPackage(SAMSUNG)
            try {
                ctx.startActivity(i)
                Toast.makeText(ctx, "Playlist sent (" + tracks.size + " tracks)", Toast.LENGTH_SHORT).show()
                return
            } catch (e: Exception) {
                // نوع بعدی
            }
        }
        Toast.makeText(ctx, "Samsung Music can't open playlist files, playing one track", Toast.LENGTH_LONG).show()
        playSamsung(ctx, tracks[0], album, folderMode)
    }

    /** «باز کردن فایل» (Samsung Music پاپ‌آپ نشون میده) */
    private fun openFile(ctx: Context, t: Track) {
        val i = Intent(Intent.ACTION_VIEW)
        i.setDataAndType(t.uri, "audio/*")
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        i.setPackage(SAMSUNG)
        try {
            ctx.startActivity(i)
        } catch (e: Exception) {
            i.setPackage(null)
            try {
                ctx.startActivity(Intent.createChooser(i, "Play with"))
            } catch (e2: Exception) {
                Toast.makeText(ctx, "No music app found", Toast.LENGTH_SHORT).show()
            }
        }
    }

    /** پخش از جستجو: اسم ترک + خواننده و آلبوم خود فایل (حتی تو حالت پوشه) تا ترک اشتباه پخش نشه */
    private fun viaSearch(ctx: Context, t: Track, album: Album?, folderMode: Boolean): Boolean {
        val i = Intent(MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH)
        i.setPackage(SAMSUNG)
        i.putExtra(MediaStore.EXTRA_MEDIA_FOCUS, MediaStore.Audio.Media.ENTRY_CONTENT_TYPE)
        i.putExtra(MediaStore.EXTRA_MEDIA_TITLE, t.title)
        i.putExtra(SearchManager.QUERY, t.title)
        var artist = t.artist
        var albumName = t.album
        if (artist.isBlank() && album != null && !folderMode) {
            val a = album.artist
            if (a.isNotBlank() && a != "Various Artists" && a != "Unknown artist") artist = a
        }
        if (albumName.isBlank() && album != null && !folderMode) albumName = album.title
        if (artist.isNotBlank()) i.putExtra(MediaStore.EXTRA_MEDIA_ARTIST, artist)
        if (albumName.isNotBlank()) i.putExtra(MediaStore.EXTRA_MEDIA_ALBUM, albumName)
        return try {
            ctx.startActivity(i)
            true
        } catch (e: Exception) {
            Toast.makeText(ctx, "Search play not supported, opening the file", Toast.LENGTH_SHORT).show()
            false
        }
    }
}
