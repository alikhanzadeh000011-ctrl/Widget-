package com.example.mediawidget

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.view.View
import android.widget.TextView

/** صفحه‌ی دسترسی‌ها: دسترسی نوتیفیکیشن (برای خوندن پخش موزیک) و بهینه‌سازی باتری */
class PermissionsActivity : Activity() {

    private lateinit var screen: DarkUi.Screen

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        screen = DarkUi.Screen(this, "Permissions")
        screen.show()
    }

    override fun onResume() {
        super.onResume()
        build()
    }

    private fun listenerGranted(): Boolean {
        val s = Settings.Secure.getString(contentResolver, "enabled_notification_listeners") ?: return false
        return s.contains(packageName)
    }

    private fun batteryIgnored(): Boolean {
        val pm = getSystemService(PowerManager::class.java)
        return pm?.isIgnoringBatteryOptimizations(packageName) ?: false
    }

    private fun trailing(granted: Boolean, onGrant: () -> Unit): View {
        return if (granted) {
            DarkUi.glyph(this, GlyphView.CHECK, 36f)
        } else {
            DarkUi.pill(this, "Grant", onGrant)
        }
    }

    private fun build() {
        val body = screen.body
        // هدر (اولین بچه) می‌مونه؛ بقیه رو دوباره می‌سازیم
        while (body.childCount > 1) body.removeViewAt(1)

        body.addView(DarkUi.sectionLabel(this, "Notifications"))
        val c1 = DarkUi.card(this)
        DarkUi.addRow(
            c1, "Access notifications", "This is required to display music playback content",
            trailing(listenerGranted()) {
                startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
            }, null
        )
        body.addView(c1)

        body.addView(DarkUi.sectionLabel(this, "Background Service"))
        val c2 = DarkUi.card(this)
        DarkUi.addRow(
            c2, "Ignore battery optimization", null,
            trailing(batteryIgnored()) {
                try {
                    startActivity(
                        Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
                            .setData(Uri.parse("package:$packageName"))
                    )
                } catch (e: Exception) {
                    startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
                }
            }, null
        )
        body.addView(c2)

        val note = TextView(this)
        note.text = "We recommend granting both permissions to allow the widgets to respond more promptly to the music player's playback status."
        note.setTextColor(DarkUi.LABEL)
        note.textSize = 17f
        note.typeface = DarkUi.font(this)
        note.setLineSpacing(0f, 1.25f)
        note.setPadding(DarkUi.dp(this, 30f), DarkUi.dp(this, 28f), DarkUi.dp(this, 30f), 0)
        body.addView(note)
    }
}
