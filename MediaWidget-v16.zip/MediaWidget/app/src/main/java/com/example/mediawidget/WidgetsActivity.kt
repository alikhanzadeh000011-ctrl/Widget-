package com.example.mediawidget

import android.app.Activity
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import kotlin.math.min

/**
 * صفحه‌ی ویجت‌ها: صفحه‌ی اصلی (Vibe و Vinyl و راهنما)، لیست Vibe و لیست Vinyl.
 * ویجت‌های Vibe همون ویجت‌های فعلی‌ان (پیش‌نمایش واقعی با آهنگ در حال پخش).
 */
class WidgetsActivity : Activity() {

    private lateinit var screen: DarkUi.Screen

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        when (intent.getStringExtra(EXTRA_PAGE)) {
            PAGE_VIBE -> buildList("Vibe", true)
            PAGE_VINYL -> buildList("Vinyl", false)
            else -> buildHome()
        }
    }

    // ------------------------------------------------------------------ صفحه‌ی اصلی

    private fun buildHome() {
        screen = DarkUi.Screen(this, "Widgets")
        val body = screen.body

        body.addView(sectionHeader("Vibe", null) { open(PAGE_VIBE) })
        body.addView(previewCard(Kind.WIDE))

        body.addView(sectionHeader("Vinyl", null) { open(PAGE_VINYL) })
        body.addView(comingSoonCard())

        val line = View(this)
        line.setBackgroundColor(DarkUi.CARD_LINE)
        val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, DarkUi.dp(this, 1f))
        lp.setMargins(0, DarkUi.dp(this, 34f), 0, DarkUi.dp(this, 10f))
        body.addView(line, lp)

        val h = TextView(this)
        h.text = "Add Widget to Your Home Screen"
        h.setTextColor(Color.WHITE)
        h.textSize = 26f
        h.typeface = DarkUi.font(this)
        h.paint.isFakeBoldText = true
        h.setPadding(DarkUi.dp(this, 28f), DarkUi.dp(this, 22f), DarkUi.dp(this, 28f), DarkUi.dp(this, 10f))
        body.addView(h)

        body.addView(step("1", "On a Home screen, touch and hold an empty space."))
        body.addView(step("2", "Tap Widgets."))
        body.addView(step("3", "Touch and hold a Media Widget. Slide the widget to where you want it. Lift your finger."))

        screen.show()
    }

    private fun step(n: String, text: String): View {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(DarkUi.dp(this, 28f), DarkUi.dp(this, 16f), DarkUi.dp(this, 28f), DarkUi.dp(this, 16f))
        val num = TextView(this)
        num.text = n
        num.setTextColor(Color.WHITE)
        num.textSize = 18f
        num.gravity = Gravity.CENTER
        num.typeface = DarkUi.font(this)
        val g = GradientDrawable()
        g.setColor(Color.TRANSPARENT)
        g.shape = GradientDrawable.OVAL
        g.setStroke(DarkUi.dp(this, 1.5f), Color.rgb(200, 200, 210))
        num.background = g
        row.addView(num, LinearLayout.LayoutParams(DarkUi.dp(this, 40f), DarkUi.dp(this, 40f)))
        val t = TextView(this)
        t.text = text
        t.setTextColor(DarkUi.LABEL)
        t.textSize = 18f
        t.typeface = DarkUi.font(this)
        t.setLineSpacing(0f, 1.2f)
        t.setPadding(DarkUi.dp(this, 22f), 0, 0, 0)
        row.addView(t, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        return row
    }

    private fun open(page: String) {
        startActivity(Intent(this, WidgetsActivity::class.java).putExtra(EXTRA_PAGE, page))
    }

    // ------------------------------------------------------------------ لیست Vibe / Vinyl

    private fun buildList(title: String, vibe: Boolean) {
        screen = DarkUi.Screen(this, title)
        val body = screen.body
        if (!vibe) {
            body.addView(comingSoonCard())
            screen.show()
            return
        }
        val items = listOf(
            Pair("Cover 2x2", Kind.MINI),
            Pair("Player 2x2", Kind.FULL),
            Pair("Pill 2x1", Kind.PILL),
            Pair("Player 4x2", Kind.WIDE),
            Pair("Library 4x2", Kind.LIB)
        )
        for ((name, kind) in items) {
            body.addView(sectionHeader(name, kind) { pin(kind) })
            body.addView(previewCard(kind))
        }
        screen.show()
    }

    /** اضافه کردن ویجت به صفحه‌ی اصلی با خود سیستم (اگه لانچر پشتیبانی کنه) */
    private fun pin(kind: Kind) {
        val mgr = AppWidgetManager.getInstance(this)
        if (mgr.isRequestPinAppWidgetSupported) {
            mgr.requestPinAppWidget(ComponentName(this, kind.provider), null, null)
        } else {
            Toast.makeText(
                this,
                "Your launcher can't add widgets from here. Long-press the home screen > Widgets > Media Widget",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    // ------------------------------------------------------------------ اجزا

    private fun sectionHeader(name: String, plusFor: Kind?, onClick: () -> Unit): View {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(DarkUi.dp(this, 28f), DarkUi.dp(this, 24f), DarkUi.dp(this, 26f), DarkUi.dp(this, 14f))
        val t = TextView(this)
        t.text = name
        t.setTextColor(Color.WHITE)
        t.textSize = 28f
        t.typeface = DarkUi.font(this)
        t.paint.isFakeBoldText = true
        row.addView(t, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        val g = DarkUi.glyph(this, if (plusFor != null) GlyphView.PLUS else GlyphView.ROUND_CHEVRON, 42f)
        g.setOnClickListener { onClick() }
        row.addView(g)
        return row
    }

    private fun roundedBg(): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(Color.rgb(36, 37, 45))
        g.cornerRadius = DarkUi.dp(this, 26f).toFloat()
        return g
    }

    private fun comingSoonCard(): View {
        val card = FrameLayout(this)
        card.background = roundedBg()
        val t = TextView(this)
        t.text = "Coming soon"
        t.setTextColor(DarkUi.LABEL)
        t.textSize = 18f
        t.typeface = DarkUi.font(this)
        t.gravity = Gravity.CENTER
        card.addView(t, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, DarkUi.dp(this, 120f)))
        val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        lp.setMargins(DarkUi.dp(this, 20f), 0, DarkUi.dp(this, 20f), 0)
        card.layoutParams = lp
        return card
    }

    /** کارت پیش‌نمایش واقعی ویجت (از همون RemoteViews ویجت اصلی) */
    private fun previewCard(kind: Kind): View {
        val card = FrameLayout(this)
        card.background = roundedBg()
        val pad = DarkUi.dp(this, 16f)
        card.setPadding(pad, pad, pad, pad)

        val metrics = resources.displayMetrics
        val availDp = metrics.widthPixels / metrics.density - 40f - 32f
        val k = min(1f, availDp / kind.defW)

        val inner = object : FrameLayout(this) {
            // پیش‌نمایش فقط نمایشیه؛ لمس‌ها رو می‌گیریم تا دکمه‌هاش کار نکنه
            override fun onInterceptTouchEvent(ev: MotionEvent?): Boolean = true
        }
        inner.clipChildren = false
        val lp = FrameLayout.LayoutParams(DarkUi.dp(this, kind.defW * k), DarkUi.dp(this, kind.defH * k))
        lp.gravity = Gravity.CENTER_HORIZONTAL
        card.addView(inner, lp)

        WidgetRenderer.preview(this, kind) { rv ->
            if (isDestroyed) return@preview
            try {
                val v = rv.apply(this, inner)
                val vlp = FrameLayout.LayoutParams(DarkUi.dp(this, kind.defW.toFloat()), DarkUi.dp(this, kind.defH.toFloat()))
                inner.removeAllViews()
                inner.addView(v, vlp)
                v.pivotX = 0f
                v.pivotY = 0f
                v.scaleX = k
                v.scaleY = k
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }

        val cl = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        cl.setMargins(DarkUi.dp(this, 20f), 0, DarkUi.dp(this, 20f), 0)
        card.layoutParams = cl
        return card
    }

    companion object {
        const val EXTRA_PAGE = "page"
        const val PAGE_VIBE = "vibe"
        const val PAGE_VINYL = "vinyl"
    }
}
