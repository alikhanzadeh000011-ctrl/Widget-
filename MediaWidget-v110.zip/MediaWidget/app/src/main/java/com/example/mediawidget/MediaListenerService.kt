package com.example.mediawidget

import android.content.ComponentName
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.service.notification.NotificationListenerService

/**
 * این سرویس برای گرفتن اجازه‌ی دسترسی به MediaSessionها وجود داره
 * (کاربر باید توی Settings > Notification access فعالش کنه)
 * و با هر تغییر آهنگ یا وضعیت پخش ویجت‌ها رو آپدیت می‌کنه.
 */
class MediaListenerService : NotificationListenerService() {

    private var msm: MediaSessionManager? = null
    private var controllers: List<MediaController> = emptyList()
    private val component by lazy { ComponentName(this, MediaListenerService::class.java) }
    private val handler = Handler(Looper.getMainLooper())

    private val sessionsListener = MediaSessionManager.OnActiveSessionsChangedListener { list ->
        bind(list.orEmpty())
    }

    private val callback = object : MediaController.Callback() {
        override fun onMetadataChanged(metadata: MediaMetadata?) = refresh()
        override fun onPlaybackStateChanged(state: PlaybackState?) = refresh()
        override fun onSessionDestroyed() = refresh()
    }

    private fun refresh() = WidgetRenderer.updateAll(this)

    // با روشن شدن صفحه یا باز شدن قفل: کنترلرها دوباره گرفته میشن (کالبک‌های قدیمی ممکنه از کار افتاده باشن) و ویجت‌ها آپدیت میشن
    private val screenReceiver = object : android.content.BroadcastReceiver() {
        override fun onReceive(context: android.content.Context, intent: android.content.Intent) {
            resync()
        }
    }
    private var receiverOn = false

    private fun resync() {
        try {
            val m = msm ?: getSystemService(MediaSessionManager::class.java).also { msm = it }
            bind(m.getActiveSessions(component))
        } catch (e: Exception) {
            refresh()
        }
    }

    private val delayedRefresh = Runnable { resync() }

    // نوتیفیکیشن پخش‌کننده عوض شد: ممکنه سشن عوض شده باشه، پس بعد از یه مکث کوتاه دوباره همگام میشیم
    private fun scheduleResync() {
        handler.removeCallbacks(delayedRefresh)
        handler.postDelayed(delayedRefresh, 500L)
    }

    override fun onNotificationPosted(sbn: android.service.notification.StatusBarNotification?) {
        if (sbn?.notification?.category == android.app.Notification.CATEGORY_TRANSPORT || sbn?.notification?.extras?.containsKey("android.mediaSession") == true) scheduleResync()
    }

    override fun onNotificationRemoved(sbn: android.service.notification.StatusBarNotification?) {
        if (sbn?.notification?.category == android.app.Notification.CATEGORY_TRANSPORT || sbn?.notification?.extras?.containsKey("android.mediaSession") == true) scheduleResync()
    }

    override fun onListenerConnected() {
        val m = getSystemService(MediaSessionManager::class.java)
        msm = m
        m.addOnActiveSessionsChangedListener(sessionsListener, component)
        bind(m.getActiveSessions(component))
        if (!receiverOn) {
            try {
                val f = android.content.IntentFilter()
                f.addAction(android.content.Intent.ACTION_SCREEN_ON)
                f.addAction(android.content.Intent.ACTION_USER_PRESENT)
                registerReceiver(screenReceiver, f)
                receiverOn = true
            } catch (e: Exception) {
                // مهم نیست
            }
        }
    }

    override fun onListenerDisconnected() {
        msm?.removeOnActiveSessionsChangedListener(sessionsListener)
        controllers.forEach { it.unregisterCallback(callback) }
        controllers = emptyList()
        if (receiverOn) {
            try { unregisterReceiver(screenReceiver) } catch (e: Exception) { }
            receiverOn = false
        }
        // سیستم سرویس رو قطع کرده؛ از سیستم می‌خوایم دوباره وصلش کنه تا ویجت‌ها از آپدیت نیفتن
        try {
            requestRebind(component)
        } catch (e: Exception) {
            // مهم نیست
        }
    }

    override fun onDestroy() {
        if (receiverOn) {
            try { unregisterReceiver(screenReceiver) } catch (e: Exception) { }
            receiverOn = false
        }
        super.onDestroy()
    }

    private fun bind(list: List<MediaController>) {
        controllers.forEach { it.unregisterCallback(callback) }
        controllers = list
        list.forEach { it.registerCallback(callback) }
        refresh()
    }

}
