package com.example.mediawidget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.widget.RemoteViews
import java.util.concurrent.Executors

/** انواع ویجت‌ها. defW/defH ابعاد پیش‌فرض (dp) وقتی لانچر اندازه نمیده */
enum class Kind(val provider: Class<*>, val defW: Int, val defH: Int) {
    SMALL(WidgetVibeSmallProvider::class.java, 160, 170),
    MEDIUM(WidgetVibeMediumProvider::class.java, 340, 170),
    LARGE(WidgetVibeLargeProvider::class.java, 340, 385),
    VDISC(WidgetVDiscProvider::class.java, 160, 185),
    VHALF(WidgetVHalfProvider::class.java, 160, 185),
    VWIDE(WidgetVWideProvider::class.java, 340, 170),
    VBIG(WidgetVBigProvider::class.java, 340, 385),
    NOW(WidgetNowProvider::class.java, 340, 170),
    NOWBIG(WidgetNowBigProvider::class.java, 340, 385),
    SPIN22(WidgetSpin22Provider::class.java, 160, 170),
    SPIN42(WidgetSpin42Provider::class.java, 340, 170),
    SPIN44(WidgetSpin44Provider::class.java, 340, 340),
    NOW22(WidgetNow22Provider::class.java, 160, 170);

    /** ویجت‌های 2x2: توی لیست ویجت‌های اپ مربع نشون داده میشن (squareList) */
    val sq: Boolean get() = this == SMALL || this == VDISC || this == SPIN22 || this == NOW22
    /** ارتفاع پیش‌فرض (dp): توی لیست اپ برای 2x2ها برابر عرض (مربع) */
    fun h(): Int = if (WidgetRenderer.squareList && sq) defW else defH

    val pixel: Boolean get() = this == NOW || this == NOWBIG || this == NOW22
    val spin: Boolean get() = this == SPIN22 || this == SPIN42 || this == SPIN44
    // تم‌های وینیل (سفید، زرد، خاکستری، کاور، مشکی، بلر) برای ویجت‌های Now Spinning هم هست
    val vinyl: Boolean get() = this == VDISC || this == VHALF || this == VWIDE || this == VBIG || spin
    val vibe: Boolean get() = this == SMALL || this == MEDIUM || this == LARGE
}

object WidgetRenderer {

    /** فقط وقتی صفحه‌ی لیست ویجت‌های اپ بازه true میشه تا پیش‌نمایش 2x2ها مربع دیده بشن */
    @Volatile var squareList = false

    private var blankCoverBmp: Bitmap? = null

    /** کاور خالی (مربع تیره با گرد و غبار) وقتی آهنگی نیست؛ تصویر خود کاربر، یک بار خونده میشه */
    fun blankCover(ctx: Context): Bitmap? {
        blankCoverBmp?.let { if (!it.isRecycled) return it }
        return try {
            android.graphics.BitmapFactory.decodeResource(ctx.resources, R.drawable.cover_blank)?.also { blankCoverBmp = it }
        } catch (e: Throwable) {
            null
        }
    }

    /**
     * ضریب کوچک‌کردن تصویرها: تا جایی که حافظه‌ی مجاز RemoteViews (حدود ۱.۵ برابر اندازه‌ی صفحه) اجازه میده
     * کیفیت کامل (۱.۰) نگه داشته میشه. bytesPerPx = مجموع بایت تصویرهای هم‌اندازه‌ی ویجت به‌ازای هر پیکسل
     */
    fun fitScale(ctx: Context, w: Float, h: Float, bytesPerPx: Float): Float {
        val dm = ctx.resources.displayMetrics
        val budget = dm.widthPixels.toFloat() * dm.heightPixels * 4f * 1.5f
        val need = w * h * bytesPerPx
        return if (need <= budget) 1f else Math.sqrt((budget / need).toDouble()).toFloat()
    }

    /** پس‌زمینه‌ی نرمِ بلر کاور با گوشه‌های گرد (بدون کاور: همون خاکستری تیره‌ی وینیل) */
    internal fun softBackground(art: Bitmap?, w: Int, h: Int, radius: Float): Bitmap {
        val src = if (art != null) VinylArt.coverBackground(art, w, h) else VinylArt.greyBackground(w, h)
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        val rect = RectF(0f, 0f, w.toFloat(), h.toFloat())
        val clip = Path()
        clip.addRoundRect(rect, radius, radius, Path.Direction.CW)
        c.clipPath(clip)
        c.drawBitmap(src, null, rect, Paint(Paint.FILTER_BITMAP_FLAG))
        return out
    }

    @Volatile private var executor = Executors.newSingleThreadExecutor()
    // آپدیت‌های پشت سر هم یکی میشن (هر کدوم آخرین وضعیت رو می‌خونه) و اگه یه رندر گیر کنه، صف جدید ساخته میشه تا ویجت‌ها یخ نزنن
    private val queued = java.util.concurrent.atomic.AtomicBoolean(false)
    @Volatile private var runningSince = 0L
    private const val STUCK_MS = 12_000L

    // همه‌ی این‌ها فقط داخل executor استفاده میشن
    private var cacheKey: String? = null
    private var tint: Tint = Palette.neutral()

    fun updateAll(context: Context) {
        val app = context.applicationContext
        val since = runningSince
        if (since != 0L && SystemClock.uptimeMillis() - since > STUCK_MS) {
            // رندر قبلی گیر کرده؛ ترد قدیمی رو رها کن و با یه ترد تازه ادامه بده
            try { executor.shutdownNow() } catch (e: Exception) { }
            executor = Executors.newSingleThreadExecutor()
            runningSince = 0L
            queued.set(false)
        }
        if (!queued.compareAndSet(false, true)) return
        try {
            executor.execute {
                queued.set(false)
                runningSince = SystemClock.uptimeMillis()
                try {
                    renderAll(app)
                } catch (e: Throwable) {
                    e.printStackTrace()
                } finally {
                    runningSince = 0L
                }
            }
        } catch (e: Exception) {
            queued.set(false)
            e.printStackTrace()
        }
    }

    /** رنگ‌ها رو برای آهنگ فعلی آماده می‌کنه (فقط داخل executor) */
    private fun prepare(info: MediaInfo) {
        if (info.key != cacheKey) {
            tint = Palette.tintFor(info.art)
            cacheKey = info.key
        }
    }

    /** ساخت ویجت از روی نوعش و تنظیمات اون (همه‌ی ویجت‌ها تنظیمات خودشون رو دارن) */
    private fun build(ctx: Context, mgr: AppWidgetManager?, id: Int, kind: Kind, info: MediaInfo, coverTint: Tint, set: VSettings.Data, anim: Float? = null): RemoteViews =
        when {
            kind.pixel -> PixelWidgets.build(ctx, mgr, id, kind, info, set)
            kind.vibe -> VibeWidgets.build(ctx, mgr, id, kind, info, coverTint, set)
            kind.spin -> VinylWidgets.buildSpin(ctx, mgr, id, kind, info, set)
            else -> VinylWidgets.build(ctx, mgr, id, kind, info, coverTint, set, anim)
        }

    // انیمیشن انتقال توقف ↔ پخش ویجت‌های وینیل: چند فریم پشت سر هم (آپدیت RemoteViews گسسته‌ست)
    private val lastPlaying = HashMap<Int, Boolean>()
    private val animGen = HashMap<Int, Int>()
    private val animUntil = HashMap<Int, Long>()
    private val mainHandler = Handler(Looper.getMainLooper())

    /** یک ویجت رو از وضعیت فعلی پلیر دوباره می‌سازه (برای فریم‌های انیمیشن) */
    private fun renderWidget(ctx: Context, mgr: AppWidgetManager, id: Int, kind: Kind, anim: Float?) {
        val set = VSettings.load(ctx, id, kind)
        val info = if (set.players.isEmpty()) MediaReader.read(ctx).also { prepare(it) } else MediaReader.read(ctx, set.players)
        val t = if (set.players.isEmpty()) tint else Palette.tintFor(info.art)
        mgr.updateAppWidget(id, build(ctx, mgr, id, kind, info, t, set, anim))
    }

    /** پیش‌نمایش ویجت برای صفحه‌ی ویجت‌ها و تنظیمات (با اندازه‌ی پیش‌فرض)؛ جواب روی ترد اصلی میاد */
    fun preview(context: Context, kind: Kind, set: VSettings.Data? = null, onReady: (RemoteViews) -> Unit) {
        val app = context.applicationContext
        executor.execute {
            try {
                val info = MediaReader.read(app)
                prepare(info)
                val s = set ?: VSettings.defaults(kind)
                val i = if (s.players.isEmpty()) info else MediaReader.read(app, s.players)
                val rv = build(app, null, -1, kind, i, if (i === info) tint else Palette.tintFor(i.art), s)
                Handler(Looper.getMainLooper()).post { onReady(rv) }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    private fun renderAll(ctx: Context) {
        val mgr = AppWidgetManager.getInstance(ctx)
        val jobs = ArrayList<Pair<Kind, IntArray>>()
        for (k in Kind.values()) {
            val ids = mgr.getAppWidgetIds(ComponentName(ctx, k.provider))
            if (ids.isNotEmpty()) jobs.add(Pair(k, ids))
        }
        val info = MediaReader.read(ctx)
        // تاریخچه‌ی آخرین آهنگ‌ها برای ویجت Now Playing بزرگ (حتی اگه هنوز ویجتی اضافه نشده)
        RecentStore.record(ctx, info)
        if (jobs.isEmpty()) return
        prepare(info)
        if (info.pkg.isNotEmpty() && info.pkg != AppPrefs.lastPlayer(ctx)) {
            AppPrefs.setLastPlayer(ctx, info.pkg)
        }
        if (info.pkg.isNotEmpty()) AppPrefs.addSeen(ctx, info.pkg)
        // هر ویجت تنظیمات خودش رو داره (پلیرهای انتخابی، تم، سوییچ‌ها)
        val perSet = HashMap<Set<String>, Pair<MediaInfo, Tint>>()
        for ((kind, ids) in jobs) {
            for (id in ids) {
                val set = VSettings.load(ctx, id, kind)
                val pair = if (set.players.isEmpty()) Pair(info, tint) else perSet.getOrPut(set.players) {
                    val i = MediaReader.read(ctx, set.players)
                    if (i.pkg.isNotEmpty()) AppPrefs.addSeen(ctx, i.pkg)
                    Pair(i, Palette.tintFor(i.art))
                }
                var firstAnim: Float? = null
                if (kind.vinyl && !kind.spin && VSettings.ANIMATE_STATE) {
                    val nowPlaying = pair.first.hasMedia && pair.first.playing
                    val prev = lastPlaying.put(id, nowPlaying)
                    if (prev == null || prev == nowPlaying) {
                        // وسط انیمیشن، آپدیت‌های دیگه صبر می‌کنن (وگرنه فریم‌ها برمی‌گشتن عقب)؛ فریم آخر وضعیت نهایی رو میذاره
                        if (SystemClock.uptimeMillis() < (animUntil[id] ?: 0L)) continue
                    }
                    if (prev != null && prev != nowPlaying) {
                        val gen = (animGen[id] ?: 0) + 1
                        animGen[id] = gen
                        val steps = if (nowPlaying) floatArrayOf(0.2f, 0.45f, 0.7f, 0.9f, 1f) else floatArrayOf(0.8f, 0.55f, 0.3f, 0.1f, 0f)
                        firstAnim = steps[0]
                        animUntil[id] = SystemClock.uptimeMillis() + 70L * steps.size + 150L
                        for (i in 1 until steps.size) {
                            mainHandler.postDelayed({
                                executor.execute {
                                    try {
                                        if (animGen[id] == gen) renderWidget(ctx, mgr, id, kind, steps[i])
                                    } catch (e: Exception) {
                                        e.printStackTrace()
                                    }
                                }
                            }, 70L * i)
                        }
                    }
                }
                mgr.updateAppWidget(id, build(ctx, mgr, id, kind, pair.first, pair.second, set, firstAnim))
            }
        }
    }

    /** دکمه‌های کنترل ویجت وینیل Wide (پخش، قبلی، بعدی) */
    internal fun wideAction(ctx: Context, action: String, code: Int): PendingIntent =
        PendingIntent.getBroadcast(
            ctx, code,
            Intent(ctx, WidgetVWideProvider::class.java).setAction(action),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

    internal fun launchPlayer(ctx: Context, pkg: String): PendingIntent {
        val pm = ctx.packageManager
        val intent = (if (pkg.isNotEmpty()) pm.getLaunchIntentForPackage(pkg) else null)
            ?: pm.getLaunchIntentForPackage(ctx.packageName)
            ?: Intent(Settings.ACTION_SOUND_SETTINGS)
        return activity(ctx, intent, 2)
    }

    internal fun activity(ctx: Context, intent: Intent, code: Int): PendingIntent =
        PendingIntent.getActivity(
            ctx, code, intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
}
