package com.example.mediawidget

import android.app.Activity
import android.os.Bundle
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView

/** انتخاب پلیرهایی که اپ و ویجت‌ها باهاشون کار می‌کنن (سوییچ روشن = استفاده میشه) */
class PlayersActivity : Activity() {

    private lateinit var screen: DarkUi.Screen

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        DarkUi.guard(this) {
            screen = DarkUi.Screen(this, "Players")
            screen.show()
            fill()
        }
    }

    private fun note(text: String): TextView {
        val t = TextView(this)
        t.text = text
        t.setTextColor(DarkUi.LABEL)
        t.textSize = 16f
        t.typeface = DarkUi.font(this)
        t.setPadding(DarkUi.dp(this, 30f), DarkUi.dp(this, 14f), DarkUi.dp(this, 30f), DarkUi.dp(this, 6f))
        return t
    }

    private fun fill() {
        val body = screen.body
        while (body.childCount > 1) body.removeViewAt(1)
        val pm = packageManager
        val map = LinkedHashMap<String, String>()
        for ((pkg, label) in VSettings.players(this)) map[pkg] = label
        // پلیری که خاموش شده ممکنه تو لیست‌های بالا نباشه؛ باید بتونه دوباره روشنش کنه
        for (pkg in AppPrefs.blocked(this)) {
            if (pkg in map) continue
            try {
                map[pkg] = pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
            } catch (e: Exception) {
                // برنامه‌ی حذف‌شده
            }
        }
        body.addView(note("Turn off the players you don't want the app and widgets to use."))
        if (map.isEmpty()) {
            body.addView(note("No music players found yet. Play something in your music app first."))
            return
        }
        val blocked = AppPrefs.blocked(this)
        body.addView(DarkUi.sectionLabel(this, "Music players (" + map.size + ")"))
        val card = DarkUi.card(this)
        for ((pkg, label) in map.entries.sortedBy { it.value.lowercase() }) {
            val sw = DarkUi.styledSwitch(this, pkg !in blocked)
            sw.setOnCheckedChangeListener { _, on -> AppPrefs.setBlocked(this, pkg, !on) }
            DarkUi.addRow(card, label, pkg, sw) { sw.toggle() }
        }
        body.addView(card)
        val spacer = View(this)
        body.addView(spacer, LinearLayout.LayoutParams(1, DarkUi.dp(this, 10f)))
    }

    override fun onPause() {
        super.onPause()
        // با عوض شدن پلیرها، ویجت‌ها همون لحظه به‌روز میشن
        try {
            WidgetRenderer.updateAll(this)
        } catch (e: Exception) {
            // مهم نیست
        }
    }
}
