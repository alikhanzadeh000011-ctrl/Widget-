package com.example.mediawidget

import android.appwidget.AppWidgetManager
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.os.Bundle
import android.provider.Settings
import android.widget.RemoteViews
import kotlin.math.min

/**
 * ویجت‌های «NOW PLAYING» سبک MD: کارت شیشه‌ای رنگی با فونت پیکسلی، کاور، چند کلید (LIKE، PLAY، PREVIOUS، NEXT)
 * و (تو نسخه‌ی بزرگ) ردیف «RECENTLY PLAYED». کل ظاهر یه تصویر واحده؛ کلیدها فقط ناحیه‌ی لمس شفاف دارن.
 */
object PixelWidgets {

    private const val WHITE = 0xFFFFFFFF.toInt()

    fun build(ctx: Context, mgr: AppWidgetManager?, id: Int, kind: Kind, info: MediaInfo, set: VSettings.Data): RemoteViews {
        PixelFont.ensure(ctx)
        val rv = RemoteViews(ctx.packageName, R.layout.pixel_widget)
        val d = ctx.resources.displayMetrics.density
        val opts = if (mgr != null) mgr.getAppWidgetOptions(id) else Bundle()
        var wDp = opts.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 0)
        var hDp = opts.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT, 0)
        if (wDp < 50) wDp = kind.defW
        if (hDp < 40) hDp = kind.h()
        wDp = wDp.coerceAtMost(700)
        hDp = hDp.coerceAtMost(600)
        val w = wDp * d
        val h = hDp * d
        val sc = WidgetRenderer.fitScale(ctx, w, h, 5.5f)
        val bw = (w * sc).toInt().coerceAtLeast(2)
        val bh = (h * sc).toInt().coerceAtLeast(2)
        val bmp = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888)
        // شکل: مستطیل = کل ناحیه‌ی ویجت (بلر ممکنه)، مربع = کارت مربع وسط ویجت (بلر نه)
        val square = VSettings.hasShape(kind) && !set.rect
        val radio = set.theme == VSettings.RADIO
        val blur = !square && !radio && set.theme == VSettings.BLUR
        val cw = if (square) min(bw, bh).toFloat() else bw.toFloat()
        val ch = if (square) min(bw, bh).toFloat() else bh.toFloat()
        val ox = (bw - cw) / 2f
        val oy = (bh - ch) / 2f
        val cv = Canvas(bmp)
        cv.translate(ox, oy)
        if (kind == Kind.NOW22) drawSmall(ctx, cv, cw, ch, d * sc, info, blur, radio) else draw(ctx, cv, kind, cw, ch, d * sc, info, blur, radio)
        // بلر واقعی One UI: رنگ نیمه‌شفاف روی ویوی ریشه، بقیه (کارت، شیشه، کاور...) همون قبلی روش کشیده میشه
        rv.setInt(android.R.id.background, "setBackgroundColor", if (blur) Color.argb(VSettings.blurAlpha(set.blur), 0, 0, 0) else 0)
        rv.setImageViewBitmap(R.id.scene, bmp)

        // ناحیه‌ی لمس کلیدها دقیقاً روی کلیدهای کشیده‌شده
        val k = keysRect(kind, cw, ch)
        k.offset(ox, oy)
        rv.setViewPadding(
            R.id.keys_box,
            (k.left / sc).toInt(), (k.top / sc).toInt(),
            ((bw - k.right) / sc).toInt(), ((bh - k.bottom) / sc).toInt()
        )
        val base = 40 + kind.ordinal * 6
        if (kind == Kind.NOW22) {
            // 2x2: فقط نشانه‌ی پخش/توقف بالا-راست لمس میشه (پخش/توقف)؛ بقیه‌ی ویجت اپ رو باز می‌کنه
            val t = action(ctx, kind, BaseWidgetProvider.ACTION_TOGGLE, base + 1)
            rv.setOnClickPendingIntent(R.id.k_like, t)
            rv.setOnClickPendingIntent(R.id.k_play, t)
            rv.setOnClickPendingIntent(R.id.k_prev, t)
            rv.setOnClickPendingIntent(R.id.k_next, t)
        } else {
            rv.setOnClickPendingIntent(R.id.k_like, action(ctx, kind, BaseWidgetProvider.ACTION_LIKE, base))
            rv.setOnClickPendingIntent(R.id.k_play, action(ctx, kind, BaseWidgetProvider.ACTION_TOGGLE, base + 1))
            rv.setOnClickPendingIntent(R.id.k_prev, action(ctx, kind, BaseWidgetProvider.ACTION_PREV, base + 2))
            rv.setOnClickPendingIntent(R.id.k_next, action(ctx, kind, BaseWidgetProvider.ACTION_NEXT, base + 3))
        }
        val openApp = if (!info.hasAccess) {
            WidgetRenderer.activity(ctx, Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS), 1)
        } else {
            WidgetRenderer.launchPlayer(ctx, "")   // لمس ویجت: باز شدن خود اپ (نه پلیر)
        }
        rv.setOnClickPendingIntent(android.R.id.background, openApp)
        return rv
    }

    private fun action(ctx: Context, kind: Kind, action: String, code: Int) =
        android.app.PendingIntent.getBroadcast(
            ctx, code, Intent(ctx, kind.provider).setAction(action),
            android.app.PendingIntent.FLAG_IMMUTABLE or android.app.PendingIntent.FLAG_UPDATE_CURRENT
        )

    private fun big(kind: Kind) = kind == Kind.NOWBIG

    /** مستطیل ردیف کلیدها (به پیکسل تصویر) */
    private fun keysRect(kind: Kind, w: Float, h: Float): RectF =
        if (kind == Kind.NOW22) RectF(0.62f * w, 0.05f * h, 0.94f * w, 0.30f * h)
        else if (big(kind)) RectF(0.300f * w, 0.835f * h, 0.955f * w, 0.935f * h)
        else RectF(0.305f * w, 0.715f * h, 0.955f * w, 0.895f * h)

    private fun draw(ctx: Context, c: Canvas, kind: Kind, w: Float, h: Float, du: Float, info: MediaInfo, blur: Boolean, radio: Boolean = false) {
        if (radio) {
            drawRadio(ctx, c, kind, w, h, du, info)
            return
        }
        val isBig = big(kind)
        val radius = if (isBig) 0.075f * w else 0.17f * h
        val art = info.art
        val playing = info.hasMedia && info.playing

        val card = RectF(0f, 0f, w, h)
        body(c, card, radius, du, art, blur, radio)

        val fill = Paint(Paint.ANTI_ALIAS_FLAG)
        val text = Paint(Paint.ANTI_ALIAS_FLAG)
        text.color = if (radio) RADIO_TEXT else Color.argb(235, 255, 255, 255)
        val dim = Paint(Paint.ANTI_ALIAS_FLAG)
        dim.color = if (radio) RADIO_DIM else Color.argb(120, 255, 255, 255)

        // پنل بالایی
        val panel = if (isBig) RectF(0.045f * w, 0.045f * h, 0.955f * w, 0.705f * h) else RectF(0.04f * w, 0.075f * h, 0.96f * w, 0.585f * h)
        fill.color = if (radio) Color.rgb(4, 6, 5) else Color.argb(16, 255, 255, 255)
        val pr = if (isBig) 0.05f * w else 0.09f * h
        c.drawRoundRect(panel, pr, pr, fill)
        if (radio) lcdEdge(c, panel, pr, du)

        // کاور فعلی
        val coverSize = if (isBig) 0.29f * w else 0.34f * h
        val cover = if (isBig) RectF(panel.left + 0.035f * w, panel.top + 0.035f * w, panel.left + 0.035f * w + coverSize, panel.top + 0.035f * w + coverSize)
        else RectF(panel.left + 0.033f * w, panel.centerY() - coverSize / 2f, panel.left + 0.033f * w + coverSize, panel.centerY() + coverSize / 2f)
        drawCover(c, art ?: (if (blur) null else WidgetRenderer.blankCover(ctx)), cover, 0.12f * coverSize)

        val textX = cover.right + (if (isBig) 0.04f * w else 0.03f * w)
        val maxW = panel.right - textX - (if (isBig) 0.04f * w else 0.03f * w)

        // NOW PLAYING + آیکن دیسک
        val pHead = if (isBig) 0.0033f * w else 0.0074f * h
        val headBase = cover.top + (if (isBig) 0.14f else 0.30f) * coverSize
        val iconR = 4.6f * pHead
        if (radio) {
            // رادیو: فقط متن وضعیت (بدون آیکن دیسک)، مثل صفحه‌ی LCD
            PixelFont.draw(c, if (playing) "NOW PLAYING" else "NOT PLAYING", textX, headBase, pHead, dim)
        } else {
            fill.color = Color.argb(235, 255, 255, 255)
            c.drawCircle(textX + iconR, headBase - 3.5f * pHead, iconR, fill)
            fill.color = Color.argb(90, 0, 0, 0)
            c.drawCircle(textX + iconR, headBase - 3.5f * pHead, iconR * 0.38f, fill)
            PixelFont.draw(c, "NOW PLAYING", textX + 2f * iconR + 2.2f * pHead, headBase, pHead, text)
        }

        // عنوان (و خواننده)
        val title = if (!info.hasMedia) "Not playing" else info.title
        val artist = if (!info.hasMedia) "Open a music player" else info.artist
        if (isBig) {
            drawLine(c, title, textX, cover.top + 0.72f * coverSize, 0.0036f * w, maxW, text, du)
            drawLine(c, artist, textX, cover.top + 0.96f * coverSize, 0.0033f * w, maxW, dim.also { it.color = if (radio) RADIO_ARTIST else Color.argb(170, 255, 255, 255) }, du)
        } else {
            val joined = if (artist.isNotEmpty() && info.hasMedia) "$title-$artist" else title
            drawLine(c, joined, textX, cover.top + 0.93f * coverSize, 0.0087f * h, maxW, text, du)
        }

        // RECENTLY PLAYED (فقط نسخه‌ی بزرگ)
        if (isBig) {
            dim.color = if (radio) RADIO_DIM else Color.argb(120, 255, 255, 255)
            PixelFont.draw(c, "RECENTLY PLAYED", panel.left + 0.035f * w, 0.455f * h, 0.0032f * w, dim)
            val recents = RecentStore.recent(ctx, RecentStore.keyOf(info), 4)
            val size = 0.19f * w
            val gap = (panel.width() - 0.07f * w - 4f * size) / 3f
            for (i in 0 until 4) {
                val x = panel.left + 0.035f * w + i * (size + gap)
                val r = RectF(x, 0.50f * h, x + size, 0.50f * h + size)
                val b = recents.getOrNull(i)?.second
                drawCover(c, b, r, 0.12f * size)
            }
        }

        // شیارهای بلندگو (چپ پایین)
        val gx0 = if (isBig) 0.045f * w else 0.045f * w
        val gx1 = if (isBig) 0.255f * w else 0.265f * w
        val gy0 = if (isBig) 0.805f * h else 0.665f * h
        val gy1 = if (isBig) 0.94f * h else 0.895f * h
        val lines = 7
        val lineH = (gy1 - gy0) / (lines * 1.9f)
        fill.color = if (radio) Color.argb(34, 255, 255, 255) else Color.argb(42, 255, 255, 255)
        for (i in 0 until lines) {
            val y = gy0 + i * ((gy1 - gy0 - lineH) / (lines - 1))
            val shrink = if (i == lines - 1) 0.15f * (gx1 - gx0) else if (i == 0) 0.02f * (gx1 - gx0) else 0f
            c.drawRoundRect(RectF(gx0 + shrink, y, gx1 - shrink, y + lineH), lineH / 2f, lineH / 2f, fill)
        }

        // کلیدها و برچسب‌ها
        val k = keysRect(kind, w, h)
        val gapK = 0.012f * k.width()
        val kw = (k.width() - 3f * gapK) / 4f
        val labels = arrayOf("LIKE", "PLAY", "PREVIOUS", "NEXT")
        val pLab = if (isBig) 0.0022f * w else 0.0047f * h
        dim.color = if (radio) Color.argb(125, 150, 150, 156) else Color.argb(105, 255, 255, 255)
        for (i in 0 until 4) {
            val x = k.left + i * (kw + gapK)
            val key = RectF(x, k.top, x + kw, k.bottom)
            // بدنه‌ی کلید
            if (radio) {
                radioKey(c, key, 0.06f * kw, du)
            } else {
                fill.color = Color.argb(28, 255, 255, 255)
                c.drawRoundRect(key, 0.06f * kw, 0.06f * kw, fill)
                val hl = Paint(Paint.ANTI_ALIAS_FLAG)
                hl.style = Paint.Style.STROKE
                hl.strokeWidth = 1f * du
                hl.color = Color.argb(22, 255, 255, 255)
                c.drawRoundRect(key, 0.06f * kw, 0.06f * kw, hl)
            }
            // برچسب بالای کلید (وسط‌چین)
            val lw = PixelFont.width(labels[i], pLab)
            val baseY = k.top - (if (isBig) 0.025f * h else 0.05f * h)
            val tx = key.centerX() - lw / 2f
            PixelFont.draw(c, labels[i], tx, baseY, pLab, dim)
            // LED: فقط سبز کنار PLAY وقتی پخش میشه
            val ledR = 3.4f * pLab
            if (i == 1) {
                fill.color = if (radio) (if (playing) Color.rgb(255, 70, 60) else Color.argb(150, 90, 25, 22)) else if (playing) Color.rgb(60, 220, 110) else Color.argb(110, 40, 40, 40)
                c.drawCircle(tx - ledR * 2.2f, baseY - 3.5f * pLab, ledR, fill)
                val ring = Paint(Paint.ANTI_ALIAS_FLAG)
                ring.style = Paint.Style.STROKE
                ring.strokeWidth = 1.2f * du
                ring.color = Color.argb(200, 10, 20, 10)
                c.drawCircle(tx - ledR * 2.2f, baseY - 3.5f * pLab, ledR + 0.6f * du, ring)
            }
        }
    }

    private val RADIO_TEXT = Color.argb(240, 150, 240, 175)
    private val RADIO_ARTIST = Color.argb(205, 120, 205, 150)
    private val RADIO_DIM = Color.argb(150, 105, 175, 128)

    /** بدنه‌ی کارت: شیشه‌ای (بلر کاور / بلر واقعی) یا بدنه‌ی مشکی رادیو */
    private fun body(c: Canvas, card: RectF, radius: Float, du: Float, art: Bitmap?, blur: Boolean, radio: Boolean) {
        val clip = Path()
        clip.addRoundRect(card, radius, radius, Path.Direction.CW)
        c.save()
        c.clipPath(clip)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        if (radio) {
            p.shader = LinearGradient(0f, card.top, 0f, card.bottom, Color.rgb(47, 48, 55), Color.rgb(29, 30, 35), Shader.TileMode.CLAMP)
            c.drawRect(card, p)
            p.shader = LinearGradient(0f, card.top, 0f, card.top + card.height() * 0.22f, Color.argb(34, 255, 255, 255), Color.argb(0, 255, 255, 255), Shader.TileMode.CLAMP)
            c.drawRect(card.left, card.top, card.right, card.top + card.height() * 0.22f, p)
        } else {
            val bgSrc = if (art != null) VinylArt.coverBackground(art, card.width().toInt(), card.height().toInt()) else VinylArt.greyBackground(card.width().toInt(), card.height().toInt())
            if (!blur) c.drawBitmap(bgSrc, null, card, Paint(Paint.FILTER_BITMAP_FLAG))
            // جلای شیشه‌ای بالا
            p.shader = LinearGradient(0f, 0f, 0f, card.height() * 0.35f, Color.argb(20, 255, 255, 255), Color.argb(0, 255, 255, 255), Shader.TileMode.CLAMP)
            c.drawRect(0f, 0f, card.width(), card.height() * 0.35f, p)
        }
        c.restore()
        val border = Paint(Paint.ANTI_ALIAS_FLAG)
        border.style = Paint.Style.STROKE
        border.strokeWidth = 1.6f * du
        border.color = if (radio) Color.argb(46, 255, 255, 255) else Color.argb(36, 255, 255, 255)
        c.drawRoundRect(RectF(card).also { it.inset(border.strokeWidth / 2f, border.strokeWidth / 2f) }, radius, radius, border)
    }

    /** قاب و لبه‌ی صفحه‌ی LCD رادیو: حلقه‌ی تیره‌ی بیرونی، روشنایی کم، و براقی شیشه */
    private fun lcdEdge(c: Canvas, panel: RectF, pr: Float, du: Float) {
        val e = Paint(Paint.ANTI_ALIAS_FLAG)
        e.style = Paint.Style.STROKE
        // حلقه‌ی تیره‌ی بیرون صفحه
        e.strokeWidth = 3.2f * du
        e.color = Color.rgb(12, 12, 15)
        c.drawRoundRect(RectF(panel).also { it.inset(-1.8f * du, -1.8f * du) }, pr + 1.8f * du, pr + 1.8f * du, e)
        // برق خیلی کم لبه‌ی بیرونی قاب
        e.strokeWidth = 1f * du
        e.color = Color.argb(22, 255, 255, 255)
        c.drawRoundRect(RectF(panel).also { it.inset(-3.9f * du, -3.9f * du) }, pr + 3.9f * du, pr + 3.9f * du, e)
        // لبه‌ی داخلی صفحه
        e.strokeWidth = 1.2f * du
        e.color = Color.argb(34, 255, 255, 255)
        c.drawRoundRect(RectF(panel).also { it.inset(0.6f * du, 0.6f * du) }, pr, pr, e)
        // براقی شیشه: روشن‌تر گوشه‌ی بالا
        val clip = Path()
        clip.addRoundRect(panel, pr, pr, Path.Direction.CW)
        c.save()
        c.clipPath(clip)
        val g = Paint(Paint.ANTI_ALIAS_FLAG)
        g.shader = LinearGradient(panel.left, panel.top, panel.left + panel.width() * 0.6f, panel.top + panel.height() * 0.9f, Color.argb(14, 255, 255, 255), Color.argb(0, 255, 255, 255), Shader.TileMode.CLAMP)
        c.drawRect(panel, g)
        c.restore()
    }

    /** کلید برجسته‌ی رادیو */
    private fun radioKey(c: Canvas, key: RectF, r: Float, du: Float) {
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        // سایه‌ی زیر کلید
        p.color = Color.argb(170, 0, 0, 0)
        c.drawRoundRect(RectF(key.left, key.top + 1.6f * du, key.right, key.bottom + 1.6f * du), r, r, p)
        p.shader = LinearGradient(0f, key.top, 0f, key.bottom, Color.rgb(74, 75, 80), Color.rgb(45, 46, 50), Shader.TileMode.CLAMP)
        c.drawRoundRect(key, r, r, p)
        p.shader = null
        p.style = Paint.Style.STROKE
        p.strokeWidth = 1f * du
        p.color = Color.argb(70, 255, 255, 255)
        c.save()
        c.clipRect(key.left, key.top, key.right, key.top + key.height() * 0.5f)
        c.drawRoundRect(RectF(key).also { it.inset(0.5f * du, 0.5f * du) }, r, r, p)
        c.restore()
        p.color = Color.argb(90, 0, 0, 0)
        c.save()
        c.clipRect(key.left, key.top + key.height() * 0.6f, key.right, key.bottom)
        c.drawRoundRect(RectF(key).also { it.inset(0.5f * du, 0.5f * du) }, r, r, p)
        c.restore()
    }

    /** خطوط بلندگو (تم رادیو): تیره‌تر از بدنه با برق کم زیرش */
    private fun grooves(c: Canvas, x0: Float, x1: Float, y0: Float, y1: Float, lines: Int, du: Float) {
        val lineH = (y1 - y0) / (lines * 1.9f)
        val dark = Paint(Paint.ANTI_ALIAS_FLAG)
        dark.color = Color.argb(120, 0, 0, 0)
        val light = Paint(Paint.ANTI_ALIAS_FLAG)
        light.color = Color.argb(16, 255, 255, 255)
        for (i in 0 until lines) {
            val y = y0 + i * ((y1 - y0 - lineH) / (lines - 1))
            val shrink = if (i == lines - 1) 0.15f * (x1 - x0) else if (i == 0) 0.02f * (x1 - x0) else 0f
            c.drawRoundRect(RectF(x0 + shrink, y + 0.8f * du, x1 - shrink, y + lineH + 0.8f * du), lineH / 2f, lineH / 2f, light)
            c.drawRoundRect(RectF(x0 + shrink, y, x1 - shrink, y + lineH), lineH / 2f, lineH / 2f, dark)
        }
    }

    /** نماد دیسک کنار NOW PLAYING */
    private fun discIcon(c: Canvas, cx: Float, cy: Float, r: Float, paint: Paint) {
        c.drawCircle(cx, cy, r, paint)
        val cut = Paint(Paint.ANTI_ALIAS_FLAG)
        cut.color = Color.rgb(4, 6, 5)
        c.drawCircle(cx, cy, r * 0.28f, cut)
        c.drawArc(RectF(cx - r * 0.92f, cy - r * 0.92f, cx + r * 0.92f, cy + r * 0.92f), -62f, 34f, true, cut)
    }

    /** نماد توقف (دو خط) */
    private fun pauseIcon(c: Canvas, x: Float, cy: Float, h: Float, paint: Paint): Float {
        val bw = h * 0.32f
        c.drawRect(x, cy - h / 2f, x + bw, cy + h / 2f, paint)
        c.drawRect(x + bw * 1.7f, cy - h / 2f, x + bw * 2.7f, cy + h / 2f, paint)
        return bw * 2.7f
    }

    private fun heart(c: Canvas, cx: Float, cy: Float, sz: Float, paint: Paint) {
        val p = Path()
        p.moveTo(cx, cy + sz * 0.95f)
        p.cubicTo(cx - sz * 1.55f, cy - sz * 0.15f, cx - sz * 0.95f, cy - sz * 1.15f, cx, cy - sz * 0.32f)
        p.cubicTo(cx + sz * 0.95f, cy - sz * 1.15f, cx + sz * 1.55f, cy - sz * 0.15f, cx, cy + sz * 0.95f)
        p.close()
        c.drawPath(p, paint)
    }

    /** شکستن عنوان به حداکثر دو خط (برای ویجت بزرگ)؛ متن غیر ASCII یک خطه */
    private fun wrap2(s: String, p: Float, maxW: Float): List<String> {
        if (!PixelFont.supports(s) || PixelFont.width(s, p) <= maxW) return listOf(s)
        val words = s.split(' ').filter { it.isNotEmpty() }
        var first = ""
        var i = 0
        while (i < words.size) {
            val t = if (first.isEmpty()) words[i] else first + " " + words[i]
            if (PixelFont.width(t, p) > maxW) break
            first = t
            i++
        }
        if (first.isEmpty()) return listOf(PixelFont.fit(s, p, maxW))
        val rest = words.drop(i).joinToString(" ")
        return if (rest.isEmpty()) listOf(first) else listOf(first, PixelFont.fit(rest, p, maxW))
    }

    /** تم Radio برای 4x2 و 4x4: بدنه‌ی تیره، صفحه‌ی LCD مشکی با متن سبز، کلیدهای برجسته داخل سینی */
    private fun drawRadio(ctx: Context, c: Canvas, kind: Kind, w: Float, h: Float, du: Float, info: MediaInfo) {
        val isBig = big(kind)
        val radius = if (isBig) 0.075f * w else 0.17f * h
        val art = info.art
        val playing = info.hasMedia && info.playing
        body(c, RectF(0f, 0f, w, h), radius, du, art, false, true)

        val fill = Paint(Paint.ANTI_ALIAS_FLAG)
        val text = Paint(Paint.ANTI_ALIAS_FLAG)
        text.color = RADIO_TEXT
        val dim = Paint(Paint.ANTI_ALIAS_FLAG)
        dim.color = RADIO_DIM
        val sub = Paint(Paint.ANTI_ALIAS_FLAG)
        sub.color = RADIO_ARTIST

        // صفحه‌ی LCD
        val panel = if (isBig) RectF(0.045f * w, 0.045f * h, 0.955f * w, 0.705f * h) else RectF(0.04f * w, 0.075f * h, 0.96f * w, 0.585f * h)
        val pr = if (isBig) 0.05f * w else 0.09f * h
        fill.color = Color.rgb(2, 3, 3)
        c.drawRoundRect(panel, pr, pr, fill)

        // کاور
        val cs = if (isBig) 0.29f * w else 0.34f * h
        val cover = if (isBig) RectF(panel.left + 0.035f * w, panel.top + 0.035f * w, panel.left + 0.035f * w + cs, panel.top + 0.035f * w + cs)
        else RectF(panel.left + 0.033f * w, panel.centerY() - cs / 2f, panel.left + 0.033f * w + cs, panel.centerY() + cs / 2f)
        drawCover(c, art ?: WidgetRenderer.blankCover(ctx), cover, 0.12f * cs)
        lcdEdge(c, panel, pr, du)

        val textX = cover.right + (if (isBig) 0.04f * w else 0.03f * w)
        val rightPad = if (isBig) 0.04f * w else 0.03f * w
        val maxW = panel.right - textX - rightPad

        // وضعیت: دیسک + NOW PLAYING یا دو خط + PAUSED
        val pHead = if (isBig) 0.0033f * w else 0.0074f * h
        val headBase = cover.top + (if (isBig) 0.14f else 0.30f) * cs
        val iconR = 4.6f * pHead
        val label = if (!info.hasMedia) "NOT PLAYING" else if (playing) "NOW PLAYING" else "PAUSED"
        fill.color = RADIO_DIM
        val iconCy = headBase - 3.5f * pHead
        val iconW: Float
        if (info.hasMedia && !playing) {
            iconW = pauseIcon(c, textX, iconCy, 2f * iconR, fill)
        } else {
            discIcon(c, textX + iconR, iconCy, iconR, fill)
            iconW = 2f * iconR
        }
        PixelFont.draw(c, label, textX + iconW + 2.2f * pHead, headBase, pHead, dim)

        // قلب (فقط وقتی پخش میشه، مثل MD)
        if (playing) {
            fill.color = Color.rgb(112, 205, 132)
            val hs = if (isBig) 0.016f * w else 0.05f * h
            heart(c, panel.right - rightPad - hs * 1.2f, iconCy, hs, fill)
        }

        // عنوان و خواننده
        val title = if (!info.hasMedia) "Not playing" else info.title
        val artist = if (!info.hasMedia) "Open a music player" else info.artist
        if (isBig) {
            val tp = 0.0050f * w
            val lines = wrap2(title, tp, maxW)
            if (lines.size == 2) {
                drawLine(c, lines[0], textX, cover.top + 0.56f * cs, tp, maxW, text, du)
                drawLine(c, lines[1], textX, cover.top + 0.78f * cs, tp, maxW, text, du)
            } else {
                drawLine(c, lines[0], textX, cover.top + 0.68f * cs, tp, maxW, text, du)
            }
            drawLine(c, artist, textX, cover.top + 0.99f * cs, 0.0040f * w, maxW, sub, du)
        } else {
            val joined = if (artist.isNotEmpty() && info.hasMedia) "$title-$artist" else title
            drawLine(c, joined, textX, cover.top + 0.93f * cs, 0.0087f * h, maxW, text, du)
        }

        // RECENTLY PLAYED (فقط 4x4)
        if (isBig) {
            dim.color = RADIO_DIM
            PixelFont.draw(c, "RECENTLY PLAYED", panel.left + 0.035f * w, 0.455f * h, 0.0032f * w, dim)
            val recents = RecentStore.recent(ctx, RecentStore.keyOf(info), 4)
            val size = 0.19f * w
            val gap = (panel.width() - 0.07f * w - 4f * size) / 3f
            for (i in 0 until 4) {
                val x = panel.left + 0.035f * w + i * (size + gap)
                val r = RectF(x, 0.50f * h, x + size, 0.50f * h + size)
                val b = recents.getOrNull(i)?.second
                if (b != null) {
                    drawCover(c, b, r, 0.12f * size)
                } else {
                    fill.color = Color.rgb(16, 17, 18)
                    c.drawRoundRect(r, 0.12f * size, 0.12f * size, fill)
                    val ed = Paint(Paint.ANTI_ALIAS_FLAG)
                    ed.style = Paint.Style.STROKE
                    ed.strokeWidth = 1f * du
                    ed.color = Color.argb(26, 255, 255, 255)
                    c.drawRoundRect(r, 0.12f * size, 0.12f * size, ed)
                }
            }
        }

        // خطوط بلندگو
        val gx0 = 0.045f * w
        val gx1 = if (isBig) 0.255f * w else 0.265f * w
        val gy0 = if (isBig) 0.805f * h else 0.665f * h
        val gy1 = if (isBig) 0.94f * h else 0.895f * h
        grooves(c, gx0, gx1, gy0, gy1, if (isBig) 8 else 7, du)

        // سینی و کلیدها
        val k = keysRect(kind, w, h)
        val tray = RectF(k).also { it.inset(-0.011f * k.width(), -0.06f * k.height()) }
        fill.color = Color.rgb(20, 21, 24)
        c.drawRoundRect(tray, 0.035f * tray.width(), 0.035f * tray.width(), fill)
        val tb = Paint(Paint.ANTI_ALIAS_FLAG)
        tb.style = Paint.Style.STROKE
        tb.strokeWidth = 1.2f * du
        tb.color = Color.argb(34, 255, 255, 255)
        c.drawRoundRect(tray, 0.035f * tray.width(), 0.035f * tray.width(), tb)

        val gapK = 0.012f * k.width()
        val kw = (k.width() - 3f * gapK) / 4f
        val labels = arrayOf("LIKE", "PLAY", "PREVIOUS", "NEXT")
        val pLab = if (isBig) 0.0022f * w else 0.0047f * h
        dim.color = Color.argb(150, 112, 114, 122)
        for (i in 0 until 4) {
            val x = k.left + i * (kw + gapK)
            val key = RectF(x, k.top, x + kw, k.bottom)
            radioKey(c, key, 0.06f * kw, du)
            val lw = PixelFont.width(labels[i], pLab)
            val baseY = tray.top - (if (isBig) 0.02f * h else 0.035f * h)
            val tx = key.centerX() - lw / 2f
            PixelFont.draw(c, labels[i], tx, baseY, pLab, dim)
            if (i == 1) {
                val ledR = 3.4f * pLab
                val lx = tx - ledR * 2.2f
                val ly = baseY - 3.5f * pLab
                fill.color = if (playing) Color.rgb(70, 205, 95) else Color.rgb(255, 82, 70)
                c.drawCircle(lx, ly, ledR, fill)
                val ring = Paint(Paint.ANTI_ALIAS_FLAG)
                ring.style = Paint.Style.STROKE
                ring.strokeWidth = 1f * du
                ring.color = Color.argb(150, 0, 0, 0)
                c.drawCircle(lx, ly, ledR + 0.5f * du, ring)
            }
        }
    }

    /** Now Playing 2x2 («Radio» در MD): پنل بالا با کاور، نشانه‌ی پخش/توقف، عنوان و خواننده؛ پایین سه دسته شیار بلندگو */
    private fun drawSmall(ctx: Context, c: Canvas, w: Float, h: Float, du: Float, info: MediaInfo, blur: Boolean, radio: Boolean) {
        val u = minOf(w, h)
        val radius = 0.17f * u
        val art = info.art
        val playing = info.hasMedia && info.playing
        val card = RectF(0f, 0f, w, h)
        body(c, card, radius, du, art, blur, radio)

        val fill = Paint(Paint.ANTI_ALIAS_FLAG)
        val text = Paint(Paint.ANTI_ALIAS_FLAG)
        text.color = if (radio) RADIO_TEXT else Color.argb(235, 255, 255, 255)
        val sub = Paint(Paint.ANTI_ALIAS_FLAG)
        sub.color = if (radio) RADIO_ARTIST else Color.argb(170, 255, 255, 255)

        val panel = RectF(0.06f * w, 0.06f * h, 0.94f * w, 0.76f * h)
        val pr = 0.09f * u
        fill.color = if (radio) Color.rgb(4, 6, 5) else Color.argb(16, 255, 255, 255)
        c.drawRoundRect(panel, pr, pr, fill)
        if (radio) lcdEdge(c, panel, pr, du)

        // کاور بالا-چپ
        val cs = 0.30f * u
        val cover = RectF(panel.left + 0.05f * u, panel.top + 0.05f * u, panel.left + 0.05f * u + cs, panel.top + 0.05f * u + cs)
        drawCover(c, art ?: (if (blur) null else WidgetRenderer.blankCover(ctx)), cover, 0.12f * cs)

        // نشانه‌ی پخش (دو خط) یا توقف (مثلث) بالا-راست
        // مثل پیش‌نمایش: دو خط درشت بالا-راست (پخش) یا مثلث (توقف)
        val ih = 0.095f * u
        val bw = 0.028f * u
        val ix = 0.86f * w - (2f * bw + 0.024f * u)
        val iy = 0.115f * h
        fill.color = if (radio) text.color else Color.argb(240, 255, 255, 255)
        if (playing) {
            c.drawRect(ix, iy, ix + bw, iy + ih, fill)
            c.drawRect(ix + bw + 0.024f * u, iy, ix + 2f * bw + 0.024f * u, iy + ih, fill)
        } else {
            val tri = Path()
            tri.moveTo(ix + 0.01f * u, iy)
            tri.lineTo(ix + 0.01f * u + 0.075f * u, iy + ih / 2f)
            tri.lineTo(ix + 0.01f * u, iy + ih)
            tri.close()
            c.drawPath(tri, fill)
        }

        // عنوان و خواننده
        val title = if (!info.hasMedia) "Not playing" else info.title
        val artist = if (!info.hasMedia) "Open a music player" else info.artist
        val tx = panel.left + 0.05f * u
        val maxW = panel.width() - 0.10f * u
        drawLine(c, title, tx, cover.bottom + 0.17f * u, 0.0092f * u, maxW, text, du)
        drawLine(c, artist, tx, cover.bottom + 0.30f * u, 0.0078f * u, maxW, sub, du)

        // شیارهای بلندگو: سه دسته، هر دسته سه خط
        val gw = 0.24f * w
        val lh = 0.011f * h
        if (radio) {
            for (g in 0 until 3) {
                val cx = (0.2f + 0.3f * g) * w
                grooves(c, cx - gw / 2f, cx + gw / 2f, 0.815f * h, 0.815f * h + 0.033f * h * 2f + lh, 3, du)
            }
        } else {
            fill.color = Color.argb(42, 255, 255, 255)
            for (g in 0 until 3) {
                val cx = (0.2f + 0.3f * g) * w
                for (i in 0 until 3) {
                    val y = 0.815f * h + i * 0.033f * h
                    c.drawRoundRect(RectF(cx - gw / 2f, y, cx + gw / 2f, y + lh), lh / 2f, lh / 2f, fill)
                }
            }
        }
    }

    /** یه خط متن: پیکسلی برای ASCII و فونت معمولی برای بقیه (فارسی و...) */
    private fun drawLine(c: Canvas, s: String, x: Float, baseline: Float, p: Float, maxW: Float, paint: Paint, du: Float) {
        if (s.isEmpty()) return
        if (PixelFont.supports(s)) {
            var pp = p
            // اگه جا نشد اول کوچیک‌تر، بعد کوتاه
            while (pp > p * 0.6f && PixelFont.width(s, pp) > maxW) pp *= 0.94f
            PixelFont.draw(c, PixelFont.fit(s, pp, maxW), x, baseline, pp, paint)
        } else {
            val tp = Paint(paint)
            tp.typeface = Typeface.DEFAULT_BOLD
            tp.textSize = 9f * p
            var t = s
            while (t.length > 1 && tp.measureText(t) > maxW) t = t.dropLast(1)
            c.drawText(if (t.length < s.length) "$t…" else t, x, baseline, tp)
        }
    }

    private fun drawCover(c: Canvas, art: Bitmap?, r: RectF, radius: Float) {
        val path = Path()
        path.addRoundRect(r, radius, radius, Path.Direction.CW)
        c.save()
        c.clipPath(path)
        if (art != null) {
            val m = minOf(art.width, art.height)
            val src = android.graphics.Rect((art.width - m) / 2, (art.height - m) / 2, (art.width + m) / 2, (art.height + m) / 2)
            c.drawBitmap(art, src, r, Paint(Paint.FILTER_BITMAP_FLAG))
        } else {
            val p = Paint()
            p.color = Color.argb(70, 0, 0, 0)
            c.drawRect(r, p)
        }
        c.restore()
        val edge = Paint(Paint.ANTI_ALIAS_FLAG)
        edge.style = Paint.Style.STROKE
        edge.strokeWidth = 1.5f
        edge.color = Color.argb(60, 255, 255, 255)
        c.drawRoundRect(r, radius, radius, edge)
    }
}
