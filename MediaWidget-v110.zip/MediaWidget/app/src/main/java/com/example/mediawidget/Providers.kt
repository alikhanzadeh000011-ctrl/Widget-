package com.example.mediawidget

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.media.session.MediaController
import android.media.session.PlaybackState
import android.os.Bundle

/** همه‌ی ویجت‌ها از این ارث می‌برن: آپدیت و دکمه‌های کنترل پخش */
open class BaseWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        WidgetRenderer.updateAll(context)
    }

    override fun onAppWidgetOptionsChanged(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetId: Int,
        newOptions: Bundle
    ) {
        WidgetRenderer.updateAll(context)
    }

    override fun onDeleted(context: Context, appWidgetIds: IntArray) {
        VSettings.remove(context, appWidgetIds)
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        when (intent.action) {
            ACTION_TOGGLE -> withController(context) { c ->
                if (c.playbackState?.state == PlaybackState.STATE_PLAYING) {
                    c.transportControls.pause()
                } else {
                    c.transportControls.play()
                }
            }
            ACTION_NEXT -> withController(context) { c -> c.transportControls.skipToNext() }
            ACTION_PREV -> withController(context) { c -> c.transportControls.skipToPrevious() }
            ACTION_LIKE -> {
                // لایک (فقط داخل اپ): آهنگ فعلی رو به علاقه‌مندی‌ها اضافه یا ازشون حذف می‌کنه
                val info = MediaReader.read(context)
                if (info.hasMedia && info.title.isNotBlank()) {
                    Favorites.toggle(context, RecentStore.keyOf(info))
                    WidgetRenderer.updateAll(context)
                }
            }
        }
    }

    private fun withController(context: Context, block: (MediaController) -> Unit) {
        try {
            val list = MediaReader.controllers(context) ?: return
            val c = MediaReader.pick(list) ?: return
            block(c)
            // اگه کالبک سشن دیر برسه یا از دست بره، ویجت بعد از دکمه خودش وضعیت تازه رو میگیره
            val app = context.applicationContext
            val h = android.os.Handler(android.os.Looper.getMainLooper())
            h.postDelayed({ WidgetRenderer.updateAll(app) }, 400L)
            h.postDelayed({ WidgetRenderer.updateAll(app) }, 1500L)
        } catch (e: SecurityException) {
            // دسترسی Notification access داده نشده
        }
    }

    companion object {
        const val ACTION_TOGGLE = "com.example.mediawidget.ACTION_TOGGLE"
        const val ACTION_NEXT = "com.example.mediawidget.ACTION_NEXT"
        const val ACTION_PREV = "com.example.mediawidget.ACTION_PREV"
        const val ACTION_LIKE = "com.example.mediawidget.ACTION_LIKE"
    }
}

class WidgetVibeSmallProvider : BaseWidgetProvider()

class WidgetVibeMediumProvider : BaseWidgetProvider()

class WidgetVibeLargeProvider : BaseWidgetProvider()

class WidgetVDiscProvider : BaseWidgetProvider()

/** فقط برای حالت نیم‌دیسکِ Disc 2x2 (دیگه ویجت جدا نیست و توی مانیفست نیست) */
class WidgetVHalfProvider : BaseWidgetProvider()

class WidgetVWideProvider : BaseWidgetProvider()

class WidgetVBigProvider : BaseWidgetProvider()

class WidgetNowProvider : BaseWidgetProvider()

class WidgetNowBigProvider : BaseWidgetProvider()

class WidgetNow22Provider : BaseWidgetProvider()

class WidgetSpin22Provider : BaseWidgetProvider()

class WidgetSpin42Provider : BaseWidgetProvider()

class WidgetSpin44Provider : BaseWidgetProvider()
