package com.example.mediawidget

import android.content.Context
import android.media.session.MediaController

/** تنظیمات کوچیک اپ: آخرین پلیری که آهنگ پخش کرده (برای باز کردنش با لمس ویجت) */
object AppPrefs {
    fun lastPlayer(ctx: Context): String =
        ctx.getSharedPreferences("state", Context.MODE_PRIVATE).getString("last_pkg", "") ?: ""

    fun setLastPlayer(ctx: Context, pkg: String) {
        ctx.getSharedPreferences("state", Context.MODE_PRIVATE).edit().putString("last_pkg", pkg).apply()
    }

    /** همه‌ی پلیرهایی که تا حالا آهنگ پخش کردن (برای لیست انتخاب پلیر در تنظیمات ویجت) */
    fun seen(ctx: Context): Set<String> =
        ctx.getSharedPreferences("state", Context.MODE_PRIVATE).getStringSet("seen_pkgs", emptySet())?.toSet() ?: emptySet()

    fun addSeen(ctx: Context, pkg: String) {
        val p = ctx.getSharedPreferences("state", Context.MODE_PRIVATE)
        val cur = p.getStringSet("seen_pkgs", emptySet()) ?: emptySet()
        if (pkg in cur) return
        p.edit().putStringSet("seen_pkgs", HashSet(cur).also { it.add(pkg) }).apply()
    }

    /** پلیرهایی که کاربر خاموش کرده؛ اپ و ویجت‌ها فقط با بقیه کار می‌کنن (خالی = همه) */
    fun blocked(ctx: Context): Set<String> =
        ctx.getSharedPreferences("state", Context.MODE_PRIVATE).getStringSet("blocked_pkgs", emptySet())?.toSet() ?: emptySet()

    fun setBlocked(ctx: Context, pkg: String, block: Boolean) {
        val p = ctx.getSharedPreferences("state", Context.MODE_PRIVATE)
        val cur = HashSet(p.getStringSet("blocked_pkgs", emptySet()) ?: emptySet())
        if (block) cur.add(pkg) else cur.remove(pkg)
        p.edit().putStringSet("blocked_pkgs", cur).apply()
    }

    fun filterAllowed(ctx: Context, list: List<MediaController>): List<MediaController> {
        val b = blocked(ctx)
        return if (b.isEmpty()) list else list.filter { it.packageName !in b }
    }
}
