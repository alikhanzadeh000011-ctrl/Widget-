package com.example.mediawidget

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path

/**
 * سبک دیسک ساخته‌شده توی ویرایشگر: رنگ بدنه + شفافیت + افکت (Splatter یا Marble با دو رنگ).
 * effect: ۰ ساده (Clear)، ۱ Splatter، ۲ Marble
 */
class DiscStyle(
    var color: Int,
    var opacity: Int,       // ۱۰ تا ۱۰۰ (درصدِ پُری بدنه)
    var effect: Int,
    var c1: Int,            // رنگ روشن افکت
    var c2: Int,            // رنگ تیره افکت
    var effOpacity: Int,    // ۰ تا ۱۰۰
    var variant: Int = 0    // سبک Splatter: ۰ = Style 1، ۱ = Style 2
) {
    fun copy() = DiscStyle(color, opacity, effect, c1, c2, effOpacity, variant)
}

object DiscStyles {

    const val NONE = 0
    const val SPLATTER = 1
    const val MARBLE = 2

    fun clearPreset() = DiscStyle(Color.WHITE, 30, NONE, Color.WHITE, Color.BLACK, 100)
    fun splatterPreset() = DiscStyle(Color.WHITE, 30, SPLATTER, Color.rgb(200, 45, 45), Color.rgb(112, 22, 22), 92)
    fun marblePreset() = DiscStyle(Color.rgb(200, 200, 200), 100, MARBLE, Color.rgb(236, 236, 236), Color.rgb(24, 24, 24), 100)

    fun preset(effect: Int): DiscStyle = when (effect) {
        SPLATTER -> splatterPreset()
        MARBLE -> marblePreset()
        else -> clearPreset()
    }

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("theme", Context.MODE_PRIVATE)

    fun isOn(ctx: Context): Boolean = prefs(ctx).getBoolean("disc_style_on", false)

    fun setOn(ctx: Context, v: Boolean) {
        prefs(ctx).edit().putBoolean("disc_style_on", v).apply()
    }

    fun load(ctx: Context): DiscStyle {
        val p = prefs(ctx)
        val d = clearPreset()
        return DiscStyle(
            p.getInt("ds_color", d.color),
            p.getInt("ds_op", d.opacity),
            p.getInt("ds_eff", d.effect),
            p.getInt("ds_c1", d.c1),
            p.getInt("ds_c2", d.c2),
            p.getInt("ds_eop", d.effOpacity),
            p.getInt("ds_var", 0)
        )
    }

    fun save(ctx: Context, s: DiscStyle) {
        prefs(ctx).edit()
            .putInt("ds_color", s.color)
            .putInt("ds_op", s.opacity)
            .putInt("ds_eff", s.effect)
            .putInt("ds_c1", s.c1)
            .putInt("ds_c2", s.c2)
            .putInt("ds_eop", s.effOpacity)
            .putInt("ds_var", s.variant)
            .apply()
    }

    /** تصویر دیسک شیشه‌ای (فایل theme.zip): بدنه‌ی همه‌ی دیسک‌های Clear، Splatter و Marble */
    fun glass(ctx: Context): Bitmap? = try {
        BitmapFactory.decodeResource(ctx.resources, R.drawable.disc_glass)
    } catch (e: Throwable) {
        null
    }

    /** الگوی افکت (سیاه‌وسفید + آلفا)؛ برای Clear صفر برمیگرده. Splatter دو سبک داره، Marble همون بافت ابری فایل */
    fun pattern(ctx: Context, effect: Int, variant: Int = 0): Bitmap? {
        val res = when (effect) {
            SPLATTER -> if (variant == 1) R.drawable.pat_splatter2 else R.drawable.pat_splatter
            MARBLE -> R.drawable.pat_marble
            else -> return null
        }
        return try {
            BitmapFactory.decodeResource(ctx.resources, res)
        } catch (e: Throwable) {
            null
        }
    }

    /** الگو رو با دو رنگ می‌ریزه: نقطه‌های روشنِ الگو → c1، تیره‌ها → c2، آلفا = پُری الگو × شفافیت افکت */
    fun colorize(pat: Bitmap, c1: Int, c2: Int, effOpacity: Int, d: Int): Bitmap {
        val sc = Bitmap.createScaledBitmap(pat, d, d, true)
        val px = IntArray(d * d)
        sc.getPixels(px, 0, d, 0, 0, d, d)
        if (sc !== pat) sc.recycle()
        val r1 = Color.red(c1)
        val g1 = Color.green(c1)
        val b1 = Color.blue(c1)
        val r2 = Color.red(c2)
        val g2 = Color.green(c2)
        val b2 = Color.blue(c2)
        val eo = effOpacity / 100f
        for (i in px.indices) {
            val v = px[i]
            val a = v ushr 24
            if (a == 0) continue
            val t = ((v shr 16) and 0xFF) / 255f
            val r = (r2 + (r1 - r2) * t).toInt()
            val g = (g2 + (g1 - g2) * t).toInt()
            val b = (b2 + (b1 - b2) * t).toInt()
            px[i] = (((a * eo).toInt().coerceIn(0, 255)) shl 24) or (r shl 16) or (g shl 8) or b
        }
        val out = Bitmap.createBitmap(d, d, Bitmap.Config.ARGB_8888)
        out.setPixels(px, 0, d, 0, 0, d, d)
        return out
    }

    /** بندانگشتی گرد دیسک برای کشوی Theme */
    fun thumb(ctx: Context, st: DiscStyle, size: Int): Bitmap {
        val out = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        val p = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
        val m = size / 2f
        p.color = Color.rgb(54, 54, 60)
        c.drawCircle(m, m, m, p)
        val op = st.opacity / 100f
        p.color = Color.argb((255 * op).toInt(), Color.red(st.color), Color.green(st.color), Color.blue(st.color))
        c.drawCircle(m, m, m, p)
        val pat = pattern(ctx, st.effect, st.variant)
        if (pat != null) {
            val col = colorize(pat, st.c1, st.c2, st.effOpacity, size)
            c.save()
            val path = Path()
            path.addCircle(m, m, m, Path.Direction.CW)
            c.clipPath(path)
            c.drawBitmap(col, 0f, 0f, p)
            c.restore()
            col.recycle()
            pat.recycle()
        }
        // لیبل میانی
        p.color = Color.rgb(196, 196, 202)
        c.drawCircle(m, m, m * 0.36f, p)
        p.color = Color.rgb(40, 40, 44)
        c.drawCircle(m, m, m * 0.05f, p)
        return out
    }
}
