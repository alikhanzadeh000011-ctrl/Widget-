package com.example.mediawidget

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.os.SystemClock
import android.util.LruCache
import android.view.MotionEvent
import android.view.VelocityTracker
import android.view.View
import android.view.ViewConfiguration
import java.util.concurrent.Executors
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * نمای ۳بعدی آلبوم‌ها (مثل MD Vinyl): همه‌ی کارت‌ها خوابیده و کج می‌مونن، فاصله‌ها یکسانه،
 * کارتی که به خط وسط می‌رسه از لبه دیده میشه (فقط یک نوار باریک) و بعد از طرف دیگه باز میشه.
 * نوار اسم (عطف) هم موقع رد شدن از وسط از بالای کارت به پایینش می‌لغزه.
 * حالت گالری: شبکه‌ی ۳ستونه.
 */
class AlbumStackView(ctx: Context) : View(ctx) {

    interface Listener {
        fun onAlbumTap(album: Album, index: Int)
        fun onAlbumLongPress(album: Album, index: Int)
    }

    var listener: Listener? = null

    private var albums: List<Album> = emptyList()
    private val d = resources.displayMetrics.density
    private val slop = ViewConfiguration.get(ctx).scaledTouchSlop.toFloat()
    private val executor = Executors.newFixedThreadPool(2)
    private val pending = HashSet<Long>()
    private val holders = HashMap<Long, Bitmap>()

    private val covers = object : LruCache<Long, Bitmap>(
        (Runtime.getRuntime().maxMemory() / 9L).toInt().coerceAtLeast(8 * 1024 * 1024)
    ) {
        override fun sizeOf(key: Long, value: Bitmap): Int = value.byteCount
    }

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val titlePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val artistPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val rect = RectF()
    private val verts = FloatArray((ROWS + 1) * 4)

    private var topInset = 0
    private var bottomInset = 0

    // حالت پشته
    private var pos = 0f
    private var vel = 0f
    private var minPos = 0f
    private var maxPos = 0f
    private var cardW = 0f
    private var cx = 0f
    private var cy = 0f

    // حالت گالری
    private var gridMode = false
    private var modeT = 0f
    private var gridScroll = 0f
    private var gridVel = 0f

    // لمس
    private var touching = false
    private var moved = false
    private var longFired = false
    private var downX = 0f
    private var downY = 0f
    private var lastY = 0f
    private var velocity: VelocityTracker? = null
    private var lastTime = 0L
    private val longRunnable = Runnable {
        if (touching && !moved) {
            val idx = indexAt(downX, downY)
            if (idx >= 0) {
                longFired = true
                performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS)
                listener?.onAlbumLongPress(albums[idx], idx)
            }
        }
    }

    // ضربه روی کارت‌ها (به ترتیب رسم)
    private val hitIdx = IntArray(48)
    private val hitTop = FloatArray(48)
    private val hitBottom = FloatArray(48)
    private var hitCount = 0

    init {
        val tf = DarkUi.font(ctx)
        titlePaint.typeface = Typeface.create(tf, Typeface.BOLD)
        artistPaint.typeface = tf
    }

    fun setAlbums(list: List<Album>) {
        albums = list
        recomputeRange()
        pos = minPos
        vel = 0f
        gridScroll = 0f
        invalidate()
    }

    fun setInsets(top: Int, bottom: Int) {
        topInset = top
        bottomInset = bottom
        invalidate()
    }

    fun isGrid(): Boolean = gridMode

    fun toggleMode() {
        gridMode = !gridMode
        if (gridMode) {
            val row = (pos.roundToInt().coerceIn(0, max(0, albums.size - 1))) / 3
            gridScroll = (row * (cellSize() + gap()) - dp(60f)).coerceIn(0f, gridMax())
            gridVel = 0f
        }
        invalidate()
    }

    private fun dp(v: Float) = v * d
    private fun gap() = dp(6f)
    private fun cellSize() = (width - gap() * 4f) / 3f
    private fun spacing() = max(1f, cardW * 0.267f)

    private fun recomputeRange() {
        val n = albums.size
        if (n == 0 || cardW <= 0f) {
            minPos = 0f
            maxPos = 0f
            return
        }
        // کارت اول بتونه بره بالای صفحه و کارت آخر پایین صفحه
        val k0 = floor((cy - dp(70f)) / spacing()).toInt().coerceAtLeast(0)
        minPos = min(k0.toFloat(), (n - 1) / 2f)
        maxPos = max(minPos, (n - 1 - k0).toFloat())
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        cardW = min(w, h) * 0.82f
        cx = w / 2f
        cy = h * 0.5f
        val keep = pos
        recomputeRange()
        pos = keep.coerceIn(minPos, maxPos)
    }

    // ---------------------------------------------------------------- کاورها

    private fun cover(a: Album): Bitmap? {
        covers.get(a.id)?.let { return it }
        if (a.noCover) return null
        if (pending.add(a.id)) {
            val app = context.applicationContext
            executor.execute {
                val b = try {
                    AlbumRepo.loadItemCover(app, a, 360)
                } catch (e: Throwable) {
                    null
                }
                var col = 0
                if (b != null) {
                    val sm = Bitmap.createScaledBitmap(b, 8, 8, true)
                    var r = 0
                    var g = 0
                    var bl = 0
                    for (y in 0 until 8) for (x in 0 until 8) {
                        val p = sm.getPixel(x, y)
                        r += Color.red(p)
                        g += Color.green(p)
                        bl += Color.blue(p)
                    }
                    sm.recycle()
                    col = Color.rgb(r / 64, g / 64, bl / 64)
                }
                post {
                    pending.remove(a.id)
                    if (b != null) {
                        covers.put(a.id, b)
                        val hsv = FloatArray(3)
                        Color.colorToHSV(col, hsv)
                        hsv[2] = max(hsv[2], 0.45f)
                        a.color = Color.HSVToColor(hsv)
                        a.hasColor = true
                    } else {
                        a.noCover = true
                    }
                    invalidate()
                }
            }
        }
        return null
    }

    private fun placeholder(a: Album): Bitmap {
        holders[a.id]?.let { return it }
        val bmp = Bitmap.createBitmap(96, 96, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val hue = ((a.id * 47L) % 360L).toFloat()
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.shader = LinearGradient(
            0f, 0f, 96f, 96f,
            Color.HSVToColor(floatArrayOf(hue, 0.35f, 0.38f)),
            Color.HSVToColor(floatArrayOf(hue, 0.4f, 0.22f)),
            Shader.TileMode.CLAMP
        )
        c.drawRect(0f, 0f, 96f, 96f, p)
        p.shader = null
        p.color = Color.argb(200, 255, 255, 255)
        p.textAlign = Paint.Align.CENTER
        p.textSize = 44f
        c.drawText(a.title.take(1).uppercase(), 48f, 62f, p)
        if (holders.size > 80) holders.clear()
        holders[a.id] = bmp
        return bmp
    }

    // ---------------------------------------------------------------- رسم

    override fun onDraw(c: Canvas) {
        val now = SystemClock.uptimeMillis()
        val dt = if (lastTime == 0L) 0.016f else ((now - lastTime) / 1000f).coerceIn(0f, 0.05f)
        lastTime = now
        val anim = step(dt)

        c.drawColor(DarkUi.BG)
        if (albums.isNotEmpty()) {
            val stackAlpha = 1f - modeT
            if (stackAlpha > 0.01f) drawStack(c, stackAlpha)
            if (modeT > 0.01f) drawGrid(c, modeT)
        }
        if (anim) postInvalidateOnAnimation() else lastTime = 0L
    }

    private fun step(dt: Float): Boolean {
        var anim = false
        val target = if (gridMode) 1f else 0f
        if (modeT != target) {
            val dm = dt / 0.28f
            modeT = if (modeT < target) min(modeT + dm, 1f) else max(modeT - dm, 0f)
            anim = true
        }
        if (albums.isEmpty()) return anim
        if (touching) return true

        if (!gridMode) {
            if (abs(vel) > 0.05f) {
                pos += vel * dt
                vel *= exp(-dt * 2.6f)
                if (pos < minPos) { pos = minPos; vel = 0f }
                if (pos > maxPos) { pos = maxPos; vel = 0f }
                anim = true
            } else {
                vel = 0f
            }
        } else {
            if (abs(gridVel) > 20f) {
                gridScroll += gridVel * dt
                gridVel *= exp(-dt * 3.2f)
                val mx = gridMax()
                if (gridScroll < 0f) { gridScroll = 0f; gridVel = 0f }
                if (gridScroll > mx) { gridScroll = mx; gridVel = 0f }
                anim = true
            } else {
                gridVel = 0f
            }
        }
        return anim
    }

    private fun scale(col: Int, m: Float): Int = Color.rgb(
        (Color.red(col) * m).toInt().coerceIn(0, 255),
        (Color.green(col) * m).toInt().coerceIn(0, 255),
        (Color.blue(col) * m).toInt().coerceIn(0, 255)
    )

    private fun drawStack(c: Canvas, gAlpha: Float) {
        val n = albums.size
        val s = spacing()
        hitCount = 0
        val span = (max(cy, height - cy) / s).toInt() + 2
        val lo = floor(pos - span).toInt().coerceAtLeast(0)
        val hi = floor(pos + span).toInt().coerceAtMost(n - 1)
        // از دورترین به نزدیک‌ترین به وسط
        val order = ArrayList<Int>()
        for (i in lo..hi) order.add(i)
        order.sortByDescending { abs(it - pos) }
        for (i in order) drawCard(c, i, i - pos, gAlpha)
    }

    private fun drawCard(c: Canvas, index: Int, t: Float, gAlpha: Float) {
        val a = albums[index]
        val w = cardW
        val s = spacing()
        val yN = cy + t * s                        // لبه‌ی نزدیک (جایی که نوار هست)
        if (yN < -s * 1.5f || yN > height + s * 1.5f) return

        val g = 1f - exp(-0.75f * abs(t))          // ۰ وسط (از لبه) تا ۱ دور (بازتر)
        val hh = 0.24f * w * g                     // ارتفاع نمایان رویه‌ی کارت
        val sFar = 1f - 0.26f * g                  // پرسپکتیو: لبه‌ی دور باریک‌تره
        val above = t < 0f                         // کارت‌های بالا: لبه‌ی نزدیک بالاست، رویه به سمت وسط (پایین)

        // رویه‌ی کارت با مش
        var k = 0
        for (r in 0..ROWS) {
            val f = r.toFloat() / ROWS
            val y: Float
            val wf: Float
            if (above) {
                y = yN + hh * f
                wf = 1f - (1f - sFar) * f
            } else {
                y = yN - hh + hh * f
                wf = sFar + (1f - sFar) * f
            }
            val half = w / 2f * wf
            verts[k++] = cx - half
            verts[k++] = y
            verts[k++] = cx + half
            verts[k++] = y
        }
        val bmp = cover(a) ?: placeholder(a)
        paint.alpha = (255f * gAlpha).toInt()
        if (hh > 1f) c.drawBitmapMesh(bmp, 1, ROWS, verts, 0, null, 0, paint)

        // نور: نزدیک خط وسط (از لبه) تیره‌تر، و کارت‌های پایین کمی تیره‌تر
        val p = (0.5f + t * 3.2f).coerceIn(0f, 1f)
        val dark = (0.42f * (1f - g) + 0.10f * p) * gAlpha
        if (hh > 1f && dark > 0.01f) {
            path.reset()
            path.moveTo(verts[0], verts[1])
            path.lineTo(verts[2], verts[3])
            path.lineTo(verts[ROWS * 4 + 2], verts[ROWS * 4 + 3])
            path.lineTo(verts[ROWS * 4], verts[ROWS * 4 + 1])
            path.close()
            fill.color = Color.argb((255f * dark).toInt().coerceIn(0, 255), 0, 0, 0)
            c.drawPath(path, fill)
        }

        // عطف جلد: کنار لبه‌ی نزدیک؛ موقع رد شدن از وسط از بالا به پایین می‌لغزه
        val stripH = STRIP * w
        val top = yN - stripH * (1f - p)
        rect.set(cx - w / 2f, top, cx + w / 2f, top + stripH)
        val m = 1.08f - 0.20f * p
        val sa = (255f * gAlpha).toInt()
        val base = a.color
        fill.color = Color.argb(sa, Color.red(scale(base, m * 1.05f)), Color.green(scale(base, m * 1.05f)), Color.blue(scale(base, m * 1.05f)))
        c.drawRect(rect.left, rect.top, rect.right, rect.top + stripH * 0.55f, fill)
        val low = scale(base, m * 0.92f)
        fill.color = Color.argb(sa, Color.red(low), Color.green(low), Color.blue(low))
        c.drawRect(rect.left, rect.top + stripH * 0.55f, rect.right, rect.bottom, fill)
        drawStripText(c, a, rect, scale(base, m), sa)

        val faceTop = if (above) yN else yN - hh
        val faceBottom = if (above) yN + hh else yN
        if (hitCount < hitIdx.size) {
            hitIdx[hitCount] = index
            hitTop[hitCount] = min(faceTop, rect.top)
            hitBottom[hitCount] = max(faceBottom, rect.bottom)
            hitCount++
        }
    }

    private fun drawStripText(c: Canvas, a: Album, r: RectF, bg: Int, alpha: Int) {
        val lum = (0.299f * Color.red(bg) + 0.587f * Color.green(bg) + 0.114f * Color.blue(bg)) / 255f
        val fg = if (lum > 0.55f) Color.rgb(24, 24, 28) else Color.WHITE
        val avail = r.width() - dp(16f)
        var size = r.height() * 0.58f
        titlePaint.textSize = size
        artistPaint.textSize = size
        val gapPx = size * 0.35f
        var tw = titlePaint.measureText(a.title)
        var aw = artistPaint.measureText(a.artist)
        if (tw + gapPx + aw > avail) {
            val kf = max(0.65f, avail / (tw + gapPx + aw))
            size *= kf
            titlePaint.textSize = size
            artistPaint.textSize = size
            tw = titlePaint.measureText(a.title)
            aw = artistPaint.measureText(a.artist)
        }
        var title = a.title
        var artist = a.artist
        while (tw + gapPx + aw > avail && title.length > 3) {
            title = title.substring(0, title.length - 2).trimEnd() + "\u2026"
            tw = titlePaint.measureText(title)
        }
        while (tw + gapPx + aw > avail && artist.length > 3) {
            artist = artist.substring(0, artist.length - 2).trimEnd() + "\u2026"
            aw = artistPaint.measureText(artist)
        }
        val total = tw + gapPx + aw
        val x = r.centerX() - total / 2f
        val base = r.centerY() + size * 0.35f
        titlePaint.color = Color.argb(alpha, Color.red(fg), Color.green(fg), Color.blue(fg))
        artistPaint.color = Color.argb((alpha * 0.8f).toInt(), Color.red(fg), Color.green(fg), Color.blue(fg))
        c.drawText(title, x, base, titlePaint)
        c.drawText(artist, x + tw + gapPx, base, artistPaint)
    }

    // ---------------------------------------------------------------- گالری

    private fun gridTop(): Float = topInset + dp(78f)

    private fun gridMax(): Float {
        val rows = (albums.size + 2) / 3
        val content = gridTop() + rows * (cellSize() + gap()) + dp(40f) + bottomInset
        return max(0f, content - height)
    }

    private fun drawGrid(c: Canvas, alpha: Float) {
        val cell = cellSize()
        val g = gap()
        val top = gridTop()
        val layer = c.saveLayerAlpha(0f, 0f, width.toFloat(), height.toFloat(), (255f * alpha).toInt())
        for (i in 0 until albums.size) {
            val row = i / 3
            val col = i % 3
            val x = g + col * (cell + g)
            val y = top + row * (cell + g) - gridScroll
            if (y > height || y + cell < 0) continue
            rect.set(x, y, x + cell, y + cell)
            val bmp = cover(albums[i]) ?: placeholder(albums[i])
            c.save()
            path.reset()
            path.addRoundRect(rect, dp(8f), dp(8f), Path.Direction.CW)
            c.clipPath(path)
            paint.alpha = 255
            c.drawBitmap(bmp, null, rect, paint)
            c.restore()
        }
        c.restoreToCount(layer)
    }

    // ---------------------------------------------------------------- لمس

    /** اندیس آیتم زیر نقطه‌ی لمس (یا -1) */
    private fun indexAt(x: Float, y: Float): Int {
        if (albums.isEmpty()) return -1
        if (!gridMode) {
            var i = hitCount - 1
            while (i >= 0) {
                if (y >= hitTop[i] && y <= hitBottom[i] && abs(x - cx) <= cardW * 0.56f) return hitIdx[i]
                i--
            }
            return -1
        }
        val cell = cellSize()
        val g = gap()
        val col = ((x - g) / (cell + g)).toInt()
        val row = ((y - gridTop() + gridScroll) / (cell + g)).toInt()
        if (col in 0..2 && y >= gridTop() - g) {
            val idx = row * 3 + col
            if (idx in 0 until albums.size) return idx
        }
        return -1
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (albums.isEmpty()) return true
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                touching = true
                moved = false
                longFired = false
                downX = e.x
                downY = e.y
                lastY = e.y
                vel = 0f
                gridVel = 0f
                velocity?.recycle()
                velocity = VelocityTracker.obtain()
                velocity?.addMovement(e)
                parent?.requestDisallowInterceptTouchEvent(true)
                postDelayed(longRunnable, 450L)
            }
            MotionEvent.ACTION_MOVE -> {
                velocity?.addMovement(e)
                if (!moved && abs(e.y - downY) > slop) {
                    moved = true
                    removeCallbacks(longRunnable)
                }
                if (moved) {
                    val dy = e.y - lastY
                    if (!gridMode) {
                        pos = (pos - dy / spacing()).coerceIn(minPos - 0.5f, maxPos + 0.5f)
                    } else {
                        gridScroll = (gridScroll - dy).coerceIn(0f, gridMax())
                    }
                    invalidate()
                }
                lastY = e.y
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                removeCallbacks(longRunnable)
                velocity?.addMovement(e)
                touching = false
                if (e.actionMasked == MotionEvent.ACTION_UP && !moved && !longFired) {
                    tap(e.x, e.y)
                } else if (moved) {
                    velocity?.computeCurrentVelocity(1000)
                    val vy = velocity?.yVelocity ?: 0f
                    if (!gridMode) {
                        vel = (-vy / spacing()).coerceIn(-16f, 16f)
                        if (pos < minPos || pos > maxPos) {
                            pos = pos.coerceIn(minPos, maxPos)
                            vel = 0f
                        }
                    } else {
                        gridVel = -vy
                    }
                }
                velocity?.recycle()
                velocity = null
                invalidate()
            }
        }
        return true
    }

    private fun tap(x: Float, y: Float) {
        val idx = indexAt(x, y)
        if (idx < 0) return
        if (!gridMode) {
            listener?.onAlbumTap(albums[idx], idx)
        } else {
            // برگشت به نمای ۳بعدی روی همون آلبوم
            pos = idx.toFloat().coerceIn(minPos, maxPos)
            vel = 0f
            gridMode = false
            invalidate()
        }
    }

    companion object {
        private const val ROWS = 12
        private const val STRIP = 0.052f
    }
}
