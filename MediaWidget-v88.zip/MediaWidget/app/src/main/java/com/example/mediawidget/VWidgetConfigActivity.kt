package com.example.mediawidget

import android.app.Activity
import android.appwidget.AppWidgetManager
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.Shader
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import kotlin.math.min

/**
 * صفحه‌ی تنظیمات ویجت‌های وینیل (مثل MD Vinyl): پیش‌نمایش زنده، نمایش اطلاعات، تم، دکمه‌ها،
 * انتخاب پلیر و دکمه‌ی Save. هر ویجت تنظیمات خودش رو داره.
 */
class VWidgetConfigActivity : Activity() {

    private var widgetId = AppWidgetManager.INVALID_APPWIDGET_ID
    private lateinit var kind: Kind
    private var showInfo = true
    private var showControl = true
    private var theme = VSettings.COVER
    private var players: Set<String> = emptySet()
    private var rect = true
    private var blurAmt = 65

    private lateinit var previewBox: FrameLayout
    private lateinit var playersSummary: TextView
    private val dots = ArrayList<Dot>()
    private lateinit var seek: android.widget.SeekBar
    private lateinit var blurRow: View
    private lateinit var blurValue: TextView
    private val shapeTabs = ArrayList<TextView>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setResult(RESULT_CANCELED)
        widgetId = intent?.extras?.getInt(AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID)
            ?: AppWidgetManager.INVALID_APPWIDGET_ID
        if (widgetId == AppWidgetManager.INVALID_APPWIDGET_ID) {
            finish()
            return
        }
        val cn = AppWidgetManager.getInstance(this).getAppWidgetInfo(widgetId)?.provider?.className
        val k = Kind.values().firstOrNull { it.provider.name == cn }
        if (k == null) {
            finish()
            return
        }
        kind = k
        val cur = VSettings.load(this, widgetId, kind)
        showInfo = cur.info
        showControl = cur.control
        theme = cur.theme
        players = cur.players
        rect = cur.rect || !VSettings.hasShape(kind)
        blurAmt = cur.blur
        if (!rect && theme == VSettings.BLUR) theme = VSettings.COVER
        if (!kind.vinyl && theme != VSettings.BLUR) theme = VSettings.COVER
        DarkUi.guard(this) { build() }
    }

    private fun current() = VSettings.Data(showInfo, showControl, theme, players, rect, blurAmt)

    private fun dp(v: Float) = DarkUi.dp(this, v)

    // ------------------------------------------------------------------ ساخت صفحه

    @Suppress("DEPRECATION")
    private fun build() {
        DarkUi.setupWindow(this)
        val root = FrameLayout(this)
        root.setBackgroundColor(DarkUi.BG)

        val body = LinearLayout(this)
        body.orientation = LinearLayout.VERTICAL

        // دکمه‌ی بستن
        val close = CloseView(this)
        close.isClickable = true
        close.setOnClickListener { finish() }
        val clp = LinearLayout.LayoutParams(dp(48f), dp(48f))
        clp.setMargins(dp(20f), dp(14f), 0, 0)
        body.addView(close, clp)

        // پیش‌نمایش زنده
        previewBox = FrameLayout(this)
        val plp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        plp.setMargins(dp(20f), dp(26f), dp(20f), dp(26f))
        body.addView(previewBox, plp)
        refreshPreview()

        // کارت تنظیمات
        val card = DarkUi.card(this)
        if (VSettings.hasInfo(kind)) {
            val sw = DarkUi.styledSwitch(this, showInfo)
            sw.setOnCheckedChangeListener { _, v -> showInfo = v; refreshPreview() }
            DarkUi.addRow(card, "Show music info", null, sw, null)
        }
        DarkUi.addRow(card, "Theme", null, themeDots(), null)
        if (VSettings.hasControl(kind)) {
            val sw = DarkUi.styledSwitch(this, showControl)
            sw.setOnCheckedChangeListener { _, v -> showControl = v; refreshPreview() }
            DarkUi.addRow(card, "Show control", null, sw, null)
        }
        body.addView(card)

        // باکس جدا: شکل ویجت + میزان بلر
        body.addView(View(this), LinearLayout.LayoutParams(1, dp(16f)))
        val card2 = DarkUi.card(this)
        if (VSettings.hasShape(kind)) {
            DarkUi.addRow(card2, "Shape", null, buildShapeTabs(), null)
        }
        blurRow = blurSlider()
        DarkUi.addRow(card2, "Blur", null, blurRow, null)
        body.addView(card2)
        updateEnabled()

        // انتخاب پلیر
        val pick = LinearLayout(this)
        pick.orientation = LinearLayout.HORIZONTAL
        pick.gravity = Gravity.CENTER_VERTICAL
        pick.setPadding(dp(30f), dp(34f), dp(30f), dp(10f))
        pick.addView(DarkUi.glyph(this, GlyphView.PLUS, 42f))
        val pt = TextView(this)
        pt.text = "Select music player"
        pt.setTextColor(Color.rgb(160, 110, 255))
        pt.textSize = 24f
        pt.typeface = DarkUi.font(this)
        pt.setPadding(dp(14f), 0, 0, 0)
        pick.addView(pt)
        pick.isClickable = true
        pick.setOnClickListener { choosePlayers() }
        body.addView(pick)

        playersSummary = TextView(this)
        playersSummary.setTextColor(Color.WHITE)
        playersSummary.textSize = 17f
        playersSummary.typeface = DarkUi.font(this)
        playersSummary.setPadding(dp(32f), dp(4f), dp(32f), dp(6f))
        body.addView(playersSummary)
        updateSummary()

        val d1 = TextView(this)
        d1.text = "Display the latest music from the players you choose."
        val d2 = TextView(this)
        d2.text = "If no specific players are selected, your most recent listening music from all players will be shown in this widget."
        for ((i, t) in listOf(d1, d2).withIndex()) {
            t.setTextColor(DarkUi.LABEL)
            t.textSize = 19f
            t.typeface = DarkUi.font(this)
            t.setLineSpacing(0f, 1.2f)
            t.setPadding(dp(32f), dp(if (i == 0) 8f else 22f), dp(32f), 0)
            body.addView(t)
        }
        // جا برای دکمه‌ی Save
        body.addView(View(this), LinearLayout.LayoutParams(1, dp(130f)))

        val scroll = ScrollView(this)
        scroll.isFillViewport = true
        scroll.addView(body)
        root.addView(scroll, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))

        // محو شدن متن زیر دکمه‌ی Save
        val fade = View(this)
        fade.background = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(Color.argb(0, 42, 43, 51), Color.rgb(42, 43, 51))
        )
        root.addView(fade, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, dp(150f), Gravity.BOTTOM))

        // دکمه‌ی Save
        val saveBtn = TextView(this)
        saveBtn.text = "Save Widget Settings"
        saveBtn.setTextColor(Color.WHITE)
        saveBtn.textSize = 17f
        saveBtn.typeface = DarkUi.font(this)
        saveBtn.paint.isFakeBoldText = true
        saveBtn.gravity = Gravity.CENTER
        val sg = GradientDrawable()
        sg.setColor(Color.rgb(125, 68, 226))
        sg.cornerRadius = dp(40f).toFloat()
        saveBtn.background = sg
        saveBtn.setOnClickListener { save() }
        val slp = FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, dp(66f), Gravity.BOTTOM)
        slp.setMargins(dp(28f), 0, dp(28f), dp(24f))
        root.addView(saveBtn, slp)

        root.setOnApplyWindowInsetsListener { _, ins ->
            body.setPadding(0, ins.systemWindowInsetTop, 0, 0)
            slp.bottomMargin = dp(24f) + ins.systemWindowInsetBottom
            saveBtn.layoutParams = slp
            ins
        }
        setContentView(root)
        root.requestApplyInsets()
    }

    // ------------------------------------------------------------------ پیش‌نمایش

    private fun refreshPreview() {
        val metrics = resources.displayMetrics
        val availDp = metrics.widthPixels / metrics.density - 40f
        val k = min(1.15f, availDp / kind.defW)
        val wDp = kind.defW * k
        val hDp = kind.defH * k

        previewBox.background = null
        previewBox.setPadding(0, 0, 0, 0)

        WidgetRenderer.preview(this, kind, current()) { rv ->
            if (isDestroyed) return@preview
            try {
                val inner = object : FrameLayout(this) {
                    override fun onInterceptTouchEvent(ev: MotionEvent?): Boolean = true
                }
                inner.clipChildren = false
                // گوشه‌های گرد مثل لانچر؛ برای تم شفاف پشتش شطرنجی (چون بلر واقعی فقط روی صفحه‌ی اصلی دیده میشه)
                val rad = dp(28f * k).toFloat()
                inner.outlineProvider = object : android.view.ViewOutlineProvider() {
                    override fun getOutline(view: View, outline: android.graphics.Outline) {
                        outline.setRoundRect(0, 0, view.width, view.height, rad)
                    }
                }
                inner.clipToOutline = true
                if (theme == VSettings.BLUR) inner.background = CheckerDrawable(dp(10f).toFloat())
                val v = rv.apply(this, inner)
                inner.addView(v, FrameLayout.LayoutParams(dp(kind.defW.toFloat()), dp(kind.defH.toFloat())))
                v.pivotX = 0f
                v.pivotY = 0f
                v.scaleX = k
                v.scaleY = k
                previewBox.removeAllViews()
                previewBox.addView(inner, FrameLayout.LayoutParams(dp(wDp), dp(hDp), Gravity.CENTER_HORIZONTAL))
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    // ------------------------------------------------------------------ تم

    private fun themeDots(): View {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        val availDp = resources.displayMetrics.widthPixels / resources.displayMetrics.density - 40f - 44f - 90f
        val size = min(36f, availDp / 6f - 4f)
        for (t in VSettings.themes(kind)) {
            val dot = Dot(this, t)
            dot.sel = t == theme
            dot.setOnClickListener {
                if (!dot.on) return@setOnClickListener
                theme = t
                for (d in dots) {
                    d.sel = d.theme == theme
                    d.invalidate()
                }
                updateEnabled()
                refreshPreview()
            }
            dots.add(dot)
            val lp = LinearLayout.LayoutParams(dp(size), dp(size))
            lp.leftMargin = dp(4f)
            row.addView(dot, lp)
        }
        return row
    }

    // ------------------------------------------------------------------ شکل و بلر

    private fun buildShapeTabs(): View {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.HORIZONTAL
        val bg = GradientDrawable()
        bg.setColor(Color.rgb(52, 53, 62))
        bg.cornerRadius = dp(20f).toFloat()
        box.background = bg
        box.setPadding(dp(3f), dp(3f), dp(3f), dp(3f))
        for ((label, isRect) in listOf(Pair("Rectangle", true), Pair("Square", false))) {
            val t = TextView(this)
            t.text = label
            t.textSize = 15f
            t.typeface = DarkUi.font(this)
            t.gravity = Gravity.CENTER
            t.setPadding(dp(12f), dp(8f), dp(12f), dp(8f))
            t.tag = isRect
            t.setOnClickListener {
                rect = isRect
                if (!rect && theme == VSettings.BLUR) {
                    theme = VSettings.COVER
                    for (d in dots) {
                        d.sel = d.theme == theme
                        d.invalidate()
                    }
                }
                styleShapeTabs()
                updateEnabled()
                refreshPreview()
            }
            shapeTabs.add(t)
            box.addView(t)
        }
        styleShapeTabs()
        return box
    }

    private fun styleShapeTabs() {
        for (t in shapeTabs) {
            val on = (t.tag as Boolean) == rect
            val g = GradientDrawable()
            g.cornerRadius = dp(17f).toFloat()
            g.setColor(if (on) Color.rgb(125, 68, 226) else Color.TRANSPARENT)
            t.background = g
            t.setTextColor(if (on) Color.WHITE else Color.rgb(170, 172, 186))
        }
    }

    private fun blurSlider(): View {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        seek = android.widget.SeekBar(this)
        seek.max = 100
        seek.progress = blurAmt
        val purple = android.content.res.ColorStateList.valueOf(Color.rgb(140, 92, 240))
        seek.progressTintList = purple
        seek.thumbTintList = purple
        seek.progressBackgroundTintList = android.content.res.ColorStateList.valueOf(Color.rgb(78, 80, 94))
        blurValue = TextView(this)
        blurValue.setTextColor(Color.WHITE)
        blurValue.textSize = 16f
        blurValue.typeface = DarkUi.font(this)
        blurValue.gravity = Gravity.END
        blurValue.text = blurAmt.toString()
        seek.setOnSeekBarChangeListener(object : android.widget.SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: android.widget.SeekBar?, p: Int, fromUser: Boolean) {
                blurAmt = p
                blurValue.text = p.toString()
            }

            override fun onStartTrackingTouch(sb: android.widget.SeekBar?) {}
            override fun onStopTrackingTouch(sb: android.widget.SeekBar?) {
                refreshPreview()
            }
        })
        row.addView(seek, LinearLayout.LayoutParams(dp(150f), LinearLayout.LayoutParams.WRAP_CONTENT))
        row.addView(blurValue, LinearLayout.LayoutParams(dp(36f), LinearLayout.LayoutParams.WRAP_CONTENT))
        return row
    }

    /** بلر فقط برای ویجت مستطیل: دایره‌ی شفاف و اسلایدر وقتی مربع انتخاب باشه تاریک و خاموش میشن */
    private fun updateEnabled() {
        val rectOk = !VSettings.hasShape(kind) || rect
        for (d in dots) {
            if (d.theme == VSettings.BLUR) {
                d.on = rectOk
                d.alpha = if (rectOk) 1f else 0.3f
            }
        }
        val sliderOn = rectOk && theme == VSettings.BLUR
        seek.isEnabled = sliderOn
        blurRow.alpha = if (sliderOn) 1f else 0.3f
    }

    // ------------------------------------------------------------------ پلیرها

    private fun updateSummary() {
        if (players.isEmpty()) {
            playersSummary.visibility = View.GONE
            return
        }
        val names = VSettings.players(this).filter { it.first in players }.map { it.second }
        playersSummary.text = if (names.isEmpty()) "${players.size} selected" else names.joinToString(", ")
        playersSummary.visibility = View.VISIBLE
    }

    private fun choosePlayers() {
        val list = VSettings.players(this)
        val chosen = HashSet(players)
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        if (list.isEmpty()) {
            val t = TextView(this)
            t.text = "No music players found yet. Play something in your music app first."
            t.setTextColor(DarkUi.LABEL)
            t.textSize = 16f
            t.typeface = DarkUi.font(this)
            box.addView(t)
        }
        for ((pkg, label) in list) {
            box.addView(MdDialog.toggleRow(this, label, pkg, pkg in chosen) { on ->
                if (on) chosen.add(pkg) else chosen.remove(pkg)
            })
        }
        MdDialog(this)
            .title("Select music player")
            .addView(box)
            .primary("OK") {
                players = chosen
                updateSummary()
                refreshPreview()
            }
            .secondary("Cancel")
            .show()
    }

    // ------------------------------------------------------------------ ذخیره

    private fun save() {
        VSettings.save(this, widgetId, current())
        setResult(RESULT_OK, Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId))
        WidgetRenderer.updateAll(this)
        finish()
    }

    // ------------------------------------------------------------------ ویوهای کوچیک

    /** دایره‌ی انتخاب تم */
    private class Dot(ctx: android.content.Context, val theme: Int) : View(ctx) {
        var sel = false
        var on = true
        private val p = Paint(Paint.ANTI_ALIAS_FLAG)

        override fun onDraw(c: Canvas) {
            val w = width.toFloat()
            val cx = w / 2f
            val cy = height / 2f
            val ring = w * 0.07f
            val r = w / 2f - ring * 2.2f
            if (sel) {
                p.shader = null
                p.style = Paint.Style.STROKE
                p.strokeWidth = ring * 1.6f
                p.color = Color.rgb(140, 92, 240)
                c.drawCircle(cx, cy, w / 2f - ring, p)
            }
            p.style = Paint.Style.FILL
            when (theme) {
                VSettings.COVER -> {
                    p.shader = RadialGradient(cx - r * 0.35f, cy - r * 0.35f, r * 1.5f,
                        intArrayOf(Color.rgb(210, 210, 214), Color.rgb(110, 110, 118), Color.rgb(48, 48, 54)),
                        floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP)
                    c.drawCircle(cx, cy, r, p)
                }
                VSettings.BLUR -> {
                    val clip = Path()
                    clip.addCircle(cx, cy, r, Path.Direction.CW)
                    c.save()
                    c.clipPath(clip)
                    p.shader = null
                    val n = 4
                    val cell = 2f * r / n
                    for (i in 0 until n) for (j in 0 until n) {
                        p.color = if ((i + j) % 2 == 0) Color.rgb(112, 112, 120) else Color.rgb(64, 64, 72)
                        c.drawRect(cx - r + i * cell, cy - r + j * cell, cx - r + (i + 1) * cell, cy - r + (j + 1) * cell, p)
                    }
                    c.restore()
                }
                else -> {
                    p.shader = null
                    p.color = when (theme) {
                        VSettings.WHITE -> Color.rgb(244, 242, 236)
                        VSettings.YELLOW -> Color.rgb(255, 160, 10)
                        VSettings.GRAY -> Color.rgb(48, 48, 52)
                        else -> Color.rgb(10, 10, 10)
                    }
                    c.drawCircle(cx, cy, r, p)
                }
            }
            p.shader = null
        }
    }

    /** پس‌زمینه‌ی شطرنجی برای پیش‌نمایش تم شفاف */
    private class CheckerDrawable(private val cell: Float) : android.graphics.drawable.Drawable() {
        private val a = Paint().apply { color = Color.rgb(92, 93, 102) }
        private val b = Paint().apply { color = Color.rgb(62, 63, 72) }

        override fun draw(c: Canvas) {
            val r = bounds
            var y = 0
            var yy = r.top.toFloat()
            while (yy < r.bottom) {
                var x = 0
                var xx = r.left.toFloat()
                while (xx < r.right) {
                    c.drawRect(xx, yy, minOf(xx + cell, r.right.toFloat()), minOf(yy + cell, r.bottom.toFloat()), if ((x + y) % 2 == 0) a else b)
                    xx += cell
                    x++
                }
                yy += cell
                y++
            }
        }

        override fun setAlpha(alpha: Int) {}
        override fun setColorFilter(cf: android.graphics.ColorFilter?) {}
        @Suppress("OVERRIDE_DEPRECATION")
        override fun getOpacity(): Int = android.graphics.PixelFormat.OPAQUE
    }

    /** دایره‌ی تیره با ضربدر (بستن) */
    private class CloseView(ctx: android.content.Context) : View(ctx) {
        private val p = Paint(Paint.ANTI_ALIAS_FLAG)

        override fun onDraw(c: Canvas) {
            val w = width.toFloat()
            p.style = Paint.Style.FILL
            p.color = Color.rgb(52, 53, 62)
            c.drawCircle(w / 2f, height / 2f, w / 2f, p)
            p.style = Paint.Style.STROKE
            p.color = Color.WHITE
            p.strokeWidth = w * 0.065f
            p.strokeCap = Paint.Cap.ROUND
            val a = w * 0.32f
            c.drawLine(a, a, w - a, w - a, p)
            c.drawLine(w - a, a, a, w - a, p)
        }
    }
}
