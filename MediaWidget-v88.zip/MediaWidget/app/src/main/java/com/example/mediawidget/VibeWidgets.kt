package com.example.mediawidget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BlurMaskFilter
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.RemoteViews
import kotlin.math.min

/**
 * ویجت‌های Vibe (Small 2x2، Medium 4x2، Large 4x4): کاور قاب‌دار با سایه‌ی نرم روی پس‌زمینه‌ی نرمِ رنگ کاور
 * یا بلر واقعی One UI. متن و دکمه‌ها ویوی معمولی‌ان تا فارسی و کوتاه‌شدن متن درست کار کنه.
 */
object VibeWidgets {

    private const val CORNER_DP = 28.16f
    private val bgCache = HashMap<String, Bitmap>()

    fun build(ctx: Context, mgr: AppWidgetManager?, id: Int, kind: Kind, info: MediaInfo, coverTint: Tint, set: VSettings.Data): RemoteViews {
        val blur = set.theme == VSettings.BLUR
        val tint = VSettings.tint(if (blur) VSettings.BLUR else VSettings.COVER, coverTint)
        val layout = when (kind) {
            Kind.SMALL -> R.layout.vibe_small
            Kind.MEDIUM -> R.layout.vibe_medium
            else -> R.layout.vibe_large
        }
        val rv = RemoteViews(ctx.packageName, layout)
        val d = ctx.resources.displayMetrics.density

        // اندازه‌ی ویجت (dp) از لانچر؛ اگه نداد اندازه‌ی پیش‌فرض
        val opts = if (mgr != null) mgr.getAppWidgetOptions(id) else Bundle()
        var wDp = opts.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 0)
        var hDp = opts.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT, 0)
        if (wDp < 50) wDp = kind.defW
        if (hDp < 40) hDp = kind.defH
        wDp = wDp.coerceAtMost(700)
        hDp = hDp.coerceAtMost(600)
        val sc = WidgetRenderer.fitScale(ctx, wDp * d, hDp * d, 9f)
        val bw = (wDp * d * sc).toInt().coerceAtLeast(2)
        val bh = (hDp * d * sc).toInt().coerceAtLeast(2)
        val du = d * sc
        val art = info.art

        // پس‌زمینه: بلر واقعی (رنگ نیمه‌شفاف روی ویوی ریشه) یا بلر نرم کاور داخل کارت گرد
        if (blur) {
            rv.setViewVisibility(R.id.bg, View.GONE)
            rv.setInt(android.R.id.background, "setBackgroundColor", Color.argb(VSettings.blurAlpha(set.blur), 0, 0, 0))
        } else {
            rv.setViewVisibility(R.id.bg, View.VISIBLE)
            rv.setInt(android.R.id.background, "setBackgroundColor", 0)
            val key = "${info.key}|$bw|$bh"
            if (bgCache.size > 6) bgCache.clear()
            val bg = bgCache.getOrPut(key) { WidgetRenderer.softBackground(art, bw, bh, CORNER_DP * du) }
            rv.setImageViewBitmap(R.id.bg, bg)
        }

        // کاور + سایه‌ی نرم
        val scene = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888)
        val r = coverRect(kind, set.info, bw.toFloat(), bh.toFloat(), du)
        val c = Canvas(scene)
        val side = r.width()
        val sp = Paint(Paint.ANTI_ALIAS_FLAG)
        sp.color = Color.argb(if (blur) 80 else 95, 0, 0, 0)
        sp.maskFilter = BlurMaskFilter(0.07f * side, BlurMaskFilter.Blur.NORMAL)
        c.drawRect(RectF(r.left, r.top + 0.035f * side, r.right, r.bottom + 0.035f * side), sp)
        if (art != null) {
            val m = min(art.width, art.height)
            val src = Rect((art.width - m) / 2, (art.height - m) / 2, (art.width + m) / 2, (art.height + m) / 2)
            c.drawBitmap(art, src, r, Paint(Paint.FILTER_BITMAP_FLAG))
        } else {
            val p = Paint()
            p.color = Color.argb(70, 0, 0, 0)
            c.drawRect(r, p)
        }
        rv.setImageViewBitmap(R.id.scene, scene)

        // متن‌ها
        val title = when {
            !info.hasAccess -> "Tap to allow access"
            !info.hasMedia -> "Not playing"
            info.title.isEmpty() -> "Unknown"
            else -> info.title
        }
        rv.setTextViewText(R.id.title, title)
        rv.setTextViewText(R.id.artist, info.artist)
        rv.setTextColor(R.id.title, tint.primary)
        rv.setTextColor(R.id.artist, tint.secondary)
        val tv = if (set.info) View.VISIBLE else View.GONE
        rv.setViewVisibility(R.id.title, tv)
        rv.setViewVisibility(R.id.artist, tv)

        // دکمه‌ها (فقط Medium و Large)
        val openApp = if (!info.hasAccess) {
            WidgetRenderer.activity(ctx, Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS), 1)
        } else {
            WidgetRenderer.launchPlayer(ctx, "")   // لمس ویجت: باز شدن خود اپ (نه پلیر)
        }
        if (VSettings.hasControl(kind)) {
            rv.setViewVisibility(R.id.controls, if (set.control) View.VISIBLE else View.GONE)
            for (vid in intArrayOf(R.id.prev, R.id.play, R.id.next)) {
                rv.setInt(vid, "setColorFilter", tint.primary)
            }
            rv.setImageViewResource(R.id.play, if (info.playing) R.drawable.ic_pause else R.drawable.ic_play)
            val base = 100 + kind.ordinal * 3
            rv.setOnClickPendingIntent(R.id.prev, action(ctx, kind, BaseWidgetProvider.ACTION_PREV, base))
            rv.setOnClickPendingIntent(R.id.play, action(ctx, kind, BaseWidgetProvider.ACTION_TOGGLE, base + 1))
            rv.setOnClickPendingIntent(R.id.next, action(ctx, kind, BaseWidgetProvider.ACTION_NEXT, base + 2))
        }
        rv.setOnClickPendingIntent(android.R.id.background, openApp)
        return rv
    }

    /** جای کاور داخل ویجت (پیکسل تصویر) */
    private fun coverRect(kind: Kind, showInfo: Boolean, bw: Float, bh: Float, du: Float): RectF = when (kind) {
        Kind.SMALL ->
            if (showInfo) {
                // کاور بالا-چپ و متن زیرش
                val side = 0.54f * min(bw, bh)
                val m = 16f * du
                RectF(m, m, m + side, m + side)
            } else {
                // فقط کاور، وسط ویجت
                val side = 0.787f * min(bw, bh)
                RectF((bw - side) / 2f, (bh - side) / 2f, (bw + side) / 2f, (bh + side) / 2f)
            }
        Kind.MEDIUM -> {
            val side = 0.79f * bh
            val right = 0.105f * bh
            RectF(bw - right - side, (bh - side) / 2f, bw - right, (bh + side) / 2f)
        }
        else -> {
            val side = 0.70f * bw
            val top = 0.079f * bw
            RectF((bw - side) / 2f, top, (bw + side) / 2f, top + side)
        }
    }

    private fun action(ctx: Context, kind: Kind, action: String, code: Int) =
        PendingIntent.getBroadcast(
            ctx, code, Intent(ctx, kind.provider).setAction(action),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
}
