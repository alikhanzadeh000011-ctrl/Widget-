package com.example.mediawidget

import android.app.Activity
import android.content.Intent
import android.content.pm.ActivityInfo
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

/**
 * صفحه‌های اولین اجرا (شبیه MD Vinyl):
 * ۱) اسپلش سفید با لوگو  ۲) Welcome با دیسک در حال پخش و دکمه‌ی Continue
 * ۳) Connect to music player با دکمه‌ی Allow notification access و Ask me later
 */
class OnboardingActivity : Activity() {

    private lateinit var root: FrameLayout
    private var force = false
    private val h = Handler(Looper.getMainLooper())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        DarkUi.guard(this) {
            force = intent.getBooleanExtra("force", false)
            requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
            window.setBackgroundDrawable(ColorDrawable(Color.WHITE))
            if (Build.VERSION.SDK_INT >= 28) {
                val lp = window.attributes
                lp.layoutInDisplayCutoutMode = if (Build.VERSION.SDK_INT >= 30) {
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
                } else {
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
                }
                window.attributes = lp
            }
            window.statusBarColor = Color.TRANSPARENT
            window.navigationBarColor = Color.TRANSPARENT
            root = FrameLayout(this)
            root.setBackgroundColor(Color.WHITE)
            setContentView(root)
            enterImmersive()
            lightBars(true)
            showSplash()
        }
    }

    override fun onResume() {
        super.onResume()
        if (::root.isInitialized) enterImmersive()
    }

    override fun onDestroy() {
        super.onDestroy()
        h.removeCallbacksAndMessages(null)
    }

    @Suppress("DEPRECATION")
    private fun enterImmersive() {
        if (Build.VERSION.SDK_INT >= 30) {
            window.setDecorFitsSystemWindows(false)
            val ctl = window.insetsController
            if (ctl != null) {
                ctl.systemBarsBehavior = WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                ctl.hide(WindowInsets.Type.navigationBars())
                ctl.show(WindowInsets.Type.statusBars())
            }
        } else {
            window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        }
    }

    /** آیکن‌های نوار وضعیت: روی اسپلش سفید تیره، روی صفحه‌های تیره روشن */
    @Suppress("DEPRECATION")
    private fun lightBars(light: Boolean) {
        if (Build.VERSION.SDK_INT >= 30) {
            val ctl = window.insetsController ?: return
            ctl.setSystemBarsAppearance(
                if (light) WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS else 0,
                WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS
            )
        } else if (Build.VERSION.SDK_INT >= 23) {
            var f = window.decorView.systemUiVisibility
            f = if (light) f or View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR else f and View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR.inv()
            window.decorView.systemUiVisibility = f
        }
    }

    private fun dp(v: Float) = DarkUi.dp(this, v)

    private fun markDone() {
        getSharedPreferences("ui", MODE_PRIVATE).edit().putBoolean("onboarded", true).apply()
    }

    private fun listenerGranted(): Boolean {
        val s = Settings.Secure.getString(contentResolver, "enabled_notification_listeners") ?: return false
        return s.contains(packageName)
    }

    // ------------------------------------------------------------ ۱) اسپلش

    private fun showSplash() {
        val iv = ImageView(this)
        try {
            iv.setImageDrawable(packageManager.getApplicationIcon(packageName))
        } catch (e: Exception) {
            // آیکن نبود: صفحه‌ی سفید ساده
        }
        iv.scaleX = 0.82f
        iv.scaleY = 0.82f
        iv.alpha = 0f
        root.addView(iv, FrameLayout.LayoutParams(dp(150f), dp(150f), Gravity.CENTER))
        iv.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(520).start()
        h.postDelayed({ showWelcome() }, 1100L)
    }

    // ------------------------------------------------------------ ۲) Welcome

    private fun showWelcome() {
        root.removeAllViews()
        root.setBackgroundColor(Color.rgb(110, 0, 255))
        window.setBackgroundDrawable(ColorDrawable(Color.rgb(110, 0, 255)))
        lightBars(false)

        val scene = WelcomeScene(this)
        scene.alpha = 0f
        root.addView(scene, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        scene.animate().alpha(1f).setDuration(450).start()

        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.gravity = Gravity.BOTTOM
        box.setPadding(dp(30f), 0, dp(30f), dp(30f))
        val font = DarkUi.font(this)

        val title = TextView(this)
        title.text = "Welcome to Vinyl+"
        title.setTextColor(Color.WHITE)
        title.textSize = 36f
        title.typeface = Typeface.create(font, Typeface.BOLD)
        title.setLineSpacing(0f, 0.95f)
        box.addView(title)

        val sub = TextView(this)
        sub.text = "Your digital gateway to the classic vinyl experience."
        sub.setTextColor(Color.argb(190, 255, 255, 255))
        sub.textSize = 17f
        sub.typeface = font
        sub.setLineSpacing(0f, 1.05f)
        val slp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        slp.topMargin = dp(12f)
        box.addView(sub, slp)

        val btn = TextView(this)
        btn.text = "Continue"
        btn.setTextColor(Color.rgb(100, 20, 230))
        btn.textSize = 20f
        btn.typeface = Typeface.create(font, Typeface.BOLD)
        btn.gravity = Gravity.CENTER
        val g = GradientDrawable()
        g.cornerRadius = dp(31f).toFloat()
        g.setColor(Color.WHITE)
        btn.background = g
        val blp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(60f))
        blp.topMargin = dp(30f)
        box.addView(btn, blp)
        btn.setOnClickListener {
            markDone()
            if (!force && listenerGranted()) finish() else showConnect()
        }

        root.addView(box, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        box.alpha = 0f
        box.translationY = dp(24f).toFloat()
        box.animate().alpha(1f).translationY(0f).setStartDelay(250).setDuration(450).start()
    }

    private fun purpleButton(text: String): TextView {
        val b = TextView(this)
        b.text = text
        b.setTextColor(Color.WHITE)
        b.textSize = 21f
        b.typeface = Typeface.create(DarkUi.font(this), Typeface.BOLD)
        b.gravity = Gravity.CENTER
        val g = GradientDrawable()
        g.cornerRadius = dp(31f).toFloat()
        g.setColor(Color.rgb(130, 68, 228))
        g.setStroke(dp(2f), Color.rgb(98, 54, 190))
        b.background = g
        return b
    }

    // ------------------------------------------------------------ ۳) Connect to music player

    private fun showConnect() {
        val font = DarkUi.font(this)
        val page = LinearLayout(this)
        page.orientation = LinearLayout.VERTICAL
        page.setBackgroundColor(DarkUi.BG)
        page.setPadding(dp(32f), 0, dp(32f), dp(34f))

        val top = View(this)
        page.addView(top, LinearLayout.LayoutParams(1, 0, 1f))

        val orbit = OrbitView(this)
        page.addView(orbit, LinearLayout.LayoutParams(dp(150f), dp(150f)).also {
            it.gravity = Gravity.CENTER_HORIZONTAL
        })

        val title = TextView(this)
        title.text = "Connect to music player"
        title.setTextColor(Color.WHITE)
        title.textSize = 30f
        title.typeface = Typeface.create(font, Typeface.BOLD)
        val tlp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        tlp.topMargin = dp(40f)
        page.addView(title, tlp)

        val body = TextView(this)
        body.text = "Vinyl+ requires access to the Notification API in order to display the current music information.\n\nVinyl+ won't use this access to collect any kind of data."
        body.setTextColor(DarkUi.LABEL)
        body.textSize = 17f
        body.typeface = font
        body.setLineSpacing(0f, 1.1f)
        val blp0 = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        blp0.topMargin = dp(16f)
        page.addView(body, blp0)

        val bottom = View(this)
        page.addView(bottom, LinearLayout.LayoutParams(1, 0, 1.1f))

        val allow = purpleButton("Allow notification access")
        page.addView(allow, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(62f)))
        allow.setOnClickListener {
            try {
                startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
            } catch (e: Exception) {
                // نبود
            }
            finish()
        }

        val later = TextView(this)
        later.text = "Ask me later"
        later.setTextColor(Color.rgb(150, 100, 235))
        later.textSize = 16f
        later.typeface = font
        later.gravity = Gravity.CENTER
        later.setOnClickListener { finish() }
        page.addView(later, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52f)).also {
            it.topMargin = dp(6f)
        })

        page.alpha = 0f
        root.addView(page, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        page.animate().alpha(1f).setDuration(380).withEndAction {
            // صفحه‌ی Welcome (با دیسک) دیگه لازم نیست
            while (root.childCount > 1) root.removeViewAt(0)
        }.start()
    }
}

/** آیکن مداری: چند حلقه‌ی تو در تو با دو گوی کوچیک، خط نازک سفید */
class OrbitView(ctx: android.content.Context) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val d = ctx.resources.displayMetrics.density

    override fun onDraw(c: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val r = minOf(width, height) / 2f - 3f * d
        p.style = Paint.Style.STROKE
        p.strokeWidth = 2.6f * d
        p.color = Color.WHITE
        c.drawCircle(cx, cy, r, p)
        c.drawCircle(cx, cy, r * 0.64f, p)
        c.drawCircle(cx, cy, r * 0.28f, p)
        // دو گوی روی مدارها
        fun knob(rad: Float, deg: Float, kr: Float) {
            val a = Math.toRadians(deg.toDouble())
            val x = cx + (rad * Math.cos(a)).toFloat()
            val y = cy + (rad * Math.sin(a)).toFloat()
            p.style = Paint.Style.FILL
            p.color = DarkUi.BG
            c.drawCircle(x, y, kr, p)
            p.style = Paint.Style.STROKE
            p.color = Color.WHITE
            c.drawCircle(x, y, kr, p)
        }
        knob(r, 135f, r * 0.13f)
        knob(r * 0.64f, -42f, r * 0.1f)
    }
}


/** صحنه‌ی Welcome: بکگراند بنفش گرادیانتی + دیسک بنفش + بازو؛ هندسه دقیقاً مثل صفحه‌ی اصلی (عمودی) */
class WelcomeScene(ctx: android.content.Context) : View(ctx) {
    private val bg: Bitmap? = android.graphics.BitmapFactory.decodeResource(resources, R.drawable.welcome_bg)
    private val disc: Bitmap? = android.graphics.BitmapFactory.decodeResource(resources, R.drawable.welcome_disc)
    private var arm: Bitmap? = null
    private var s = 1f
    private val p = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val shadow = Paint(Paint.ANTI_ALIAS_FLAG)
    private val dst = android.graphics.RectF()
    private var spin = 0f
    private var armAngle = VinylArt.ARM_REST
    private val armTarget = VinylArt.ARM_OUTER + (VinylArt.ARM_INNER - VinylArt.ARM_OUTER) * 0.22f
    private val spinAnim = android.animation.ValueAnimator.ofFloat(0f, 360f)
    private val armAnim = android.animation.ValueAnimator.ofFloat(VinylArt.ARM_REST, armTarget)

    init {
        spinAnim.duration = 1800L        // ۳۳⅓ دور در دقیقه
        spinAnim.repeatCount = android.animation.ValueAnimator.INFINITE
        spinAnim.interpolator = android.view.animation.LinearInterpolator()
        spinAnim.addUpdateListener {
            spin = it.animatedValue as Float
            invalidate()
        }
        armAnim.duration = 1100L
        armAnim.startDelay = 600L
        armAnim.interpolator = android.view.animation.DecelerateInterpolator(1.6f)
        armAnim.addUpdateListener {
            armAngle = it.animatedValue as Float
            invalidate()
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        spinAnim.start()
        armAnim.start()
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        spinAnim.cancel()
        armAnim.cancel()
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        s = w / VinylArt.REF_W
        arm = try {
            VinylArt.armBitmap(s)
        } catch (e: Throwable) {
            null
        }
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val b = bg
        if (b != null) {
            // پر کردن صفحه (center-crop)
            val k = maxOf(w / b.width, h / b.height)
            val bw = b.width * k
            val bh = b.height * k
            dst.set((w - bw) / 2f, (h - bh) / 2f, (w + bw) / 2f, (h + bh) / 2f)
            c.drawBitmap(b, null, dst, p)
        } else {
            c.drawColor(Color.rgb(110, 0, 255))
        }
        val cx = VinylArt.CX * s
        val cy = VinylArt.CY * s
        val r = VinylArt.R * s
        // سایه‌ی نرم زیر دیسک
        shadow.shader = android.graphics.RadialGradient(
            cx + 14f * s, cy + 26f * s, r + 70f * s,
            intArrayOf(Color.argb(110, 20, 0, 60), Color.argb(110, 20, 0, 60), Color.argb(0, 20, 0, 60)),
            floatArrayOf(0f, r / (r + 70f * s), 1f), Shader.TileMode.CLAMP
        )
        c.drawCircle(cx + 14f * s, cy + 26f * s, r + 70f * s, shadow)
        val d = disc
        if (d != null) {
            c.save()
            c.rotate(spin, cx, cy)
            dst.set(cx - r, cy - r, cx + r, cy + r)
            c.drawBitmap(d, null, dst, p)
            c.restore()
        }
        val a = arm
        if (a != null) {
            c.save()
            c.translate(VinylArt.PX * s, VinylArt.PY * s)
            c.rotate(armAngle)
            c.drawBitmap(a, -VinylArt.ARM_OX * s, -VinylArt.ARM_OY * s, p)
            c.restore()
        }
    }
}
