package com.example.mediawidget

import android.app.Activity
import android.app.PendingIntent
import android.content.ComponentName
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.media.AudioManager
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.KeyEvent
import android.view.View
import java.io.File
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.view.WindowManager
import android.view.ViewGroup
import android.view.Gravity
import android.graphics.Bitmap
import android.graphics.Canvas
import android.widget.FrameLayout
import android.widget.Toast

/** صفحه‌ی اصلی اپ: فول‌اسکرین، دیسک وینیل. با هر پلیری کار می‌کنه (از MediaSession می‌خونه). */
class VinylActivity : Activity(), VinylView.Listener {

    private lateinit var vinyl: VinylView
    private lateinit var root: FrameLayout
    private var sheet: ThemeSheet? = null
    private var editor: View? = null
    private var statusShown = false
    private var locked = false
    private var forced = 0          // 0 خودکار، 1 اجبار عمودی، 2 اجبار افقی
    private var awake = false
    private var lastPkg = ""
    private var lastOpen: PendingIntent? = null
    private var msm: MediaSessionManager? = null
    private var controllers: List<MediaController> = emptyList()
    private val component by lazy { ComponentName(this, MediaListenerService::class.java) }

    private val sessionsListener = MediaSessionManager.OnActiveSessionsChangedListener { list ->
        bind(list.orEmpty())
    }

    private val callback = object : MediaController.Callback() {
        override fun onMetadataChanged(metadata: MediaMetadata?) = reload()
        override fun onPlaybackStateChanged(state: PlaybackState?) = reload()
        override fun onSessionDestroyed() = reload()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setBackgroundDrawable(ColorDrawable(Color.BLACK))
        setupWindow()
        vinyl = VinylView(this)
        vinyl.listener = this
        root = FrameLayout(this)
        root.addView(vinyl, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        setContentView(root)
        val ui = getSharedPreferences("ui", MODE_PRIVATE)
        locked = ui.getBoolean("lock", false)
        awake = ui.getBoolean("awake", false)
        applyOrientation()
        applyAwake()
        vinyl.setLocked(locked)
        vinyl.setAwake(awake)
        vinyl.setHideText(ui.getBoolean("hide_text", false))
        enterImmersive()
        showLastCrash()
        // انیمیشن چرخش رو خودمون انجام میدیم (مثل MD)، پس انیمیشن پیش‌فرض سیستم خاموش
        try {
            val lp = window.attributes
            lp.rotationAnimation = WindowManager.LayoutParams.ROTATION_ANIMATION_JUMPCUT
            window.attributes = lp
        } catch (e: Throwable) {
            // مهم نیست
        }
        lastRot = displayRot()
    }

    // ---------- انیمیشن چرخش عمودی ↔ افقی (شبیه iPad: دیسک از جای قبلی به جای جدید می‌لغزه) ----------
    private var morph: RotateMorphView? = null
    private var layoutL: View.OnLayoutChangeListener? = null
    private val morphH = android.os.Handler(android.os.Looper.getMainLooper())
    private var morphGen = 0
    private var lastRot = 0
    private val MORPH_K = 0.75f

    @Suppress("DEPRECATION")
    private fun displayRot(): Int = try { windowManager.defaultDisplay.rotation } catch (e: Throwable) { 0 }

    private fun finishMorph() {
        morphGen++
        morphH.removeCallbacksAndMessages(null)
        layoutL?.let { try { vinyl.removeOnLayoutChangeListener(it) } catch (e: Throwable) { } }
        layoutL = null
        morph?.let {
            try { root.removeView(it) } catch (e: Throwable) { }
            it.release()
        }
        morph = null
    }

    private fun snapshotOf(v: View): Bitmap? = try {
        val k = MORPH_K
        val b = Bitmap.createBitmap((v.width * k).toInt().coerceAtLeast(1), (v.height * k).toInt().coerceAtLeast(1), Bitmap.Config.ARGB_8888)
        val c = Canvas(b)
        c.scale(k, k)
        c.drawColor(Color.BLACK)
        v.draw(c)
        b
    } catch (e: Throwable) {
        null
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        val oldW = root.width
        val oldH = root.height
        val toLand = newConfig.orientation == Configuration.ORIENTATION_LANDSCAPE
        val toPort = newConfig.orientation == Configuration.ORIENTATION_PORTRAIT
        val wasLand = oldW > oldH
        val change = oldW > 0 && oldH > 0 && ((toLand && !wasLand) || (toPort && wasLand))
        finishMorph()
        var bmp: Bitmap? = null
        var og: FloatArray? = null
        if (change) {
            og = vinyl.discGeom()
            bmp = snapshotOf(root)
        }
        super.onConfigurationChanged(newConfig)
        lastRot = displayRot()
        if (bmp != null && og != null) startMorph(bmp, oldW, oldH, og, toLand)
    }

    private fun startMorph(bmp: Bitmap, oldW: Int, oldH: Int, og: FloatArray, toLand: Boolean) {
        val ov = RotateMorphView(this)
        ov.setOld(bmp, MORPH_K, oldW, oldH, og)
        ov.onDone = { if (morph === ov) finishMorph() }
        root.addView(ov, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        morph = ov
        val gen = ++morphGen
        val l = object : View.OnLayoutChangeListener {
            override fun onLayoutChange(v: View, l: Int, t: Int, r: Int, b: Int, ol: Int, ot: Int, or2: Int, ob: Int) {
                val w = r - l
                val h = b - t
                if (w <= 0 || h <= 0 || (w > h) != toLand) return
                v.removeOnLayoutChangeListener(this)
                layoutL = null
                if (gen != morphGen || morph !== ov) return
                ov.begin(vinyl.discGeom())
                pollReady(gen, ov, android.os.SystemClock.uptimeMillis())
            }
        }
        layoutL = l
        vinyl.addOnLayoutChangeListener(l)
        // اگه به هر دلیلی چیدمان جدید نیومد، لایه رو بردار تا صفحه گیر نکنه
        morphH.postDelayed({ if (gen == morphGen && morph === ov && !ov.begun) finishMorph() }, 700L)
    }

    /** صبر میکنیم دیسک و برچسب و پس‌زمینه‌ی چیدمان جدید ساخته بشن، بعد ازش عکس میگیریم */
    private fun pollReady(gen: Int, ov: RotateMorphView, start: Long) {
        val r = object : Runnable {
            override fun run() {
                if (gen != morphGen || morph !== ov) return
                val timeout = android.os.SystemClock.uptimeMillis() - start > 900L
                if (vinyl.isMorphReady() || timeout) {
                    val nb = snapshotOf(vinyl)
                    if (nb != null) ov.setNew(nb, MORPH_K) else ov.fail()
                } else {
                    morphH.postDelayed(this, 30L)
                }
            }
        }
        morphH.postDelayed(r, 30L)
    }

    /** اگه دفعه‌ی قبل کرش شده بود، متنش رو نشون میده تا بشه برای من فرستاد */
    private fun showLastCrash() {
        try {
            val f = java.io.File(filesDir, "last_crash.txt")
            if (!f.exists()) return
            val txt = f.readText()
            f.delete()
            val tv = android.widget.TextView(this)
            tv.text = txt
            tv.setTextIsSelectable(true)
            tv.textSize = 11f
            tv.setPadding(40, 24, 40, 24)
            val sv = android.widget.ScrollView(this)
            sv.addView(tv)
            android.app.AlertDialog.Builder(this)
                .setTitle("The app crashed last time")
                .setView(sv)
                .setPositiveButton("Copy") { _, _ ->
                    val cm = getSystemService(android.content.ClipboardManager::class.java)
                    cm?.setPrimaryClip(android.content.ClipData.newPlainText("crash", txt))
                    MdToast.show(this, "Copied")
                }
                .setNegativeButton("Close", null)
                .show()
        } catch (e: Throwable) {
            // نادیده
        }
    }

    private fun applyOrientation() {
        requestedOrientation = when {
            locked -> ActivityInfo.SCREEN_ORIENTATION_LOCKED
            forced == 1 -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
            forced == 2 -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            else -> ActivityInfo.SCREEN_ORIENTATION_FULL_SENSOR
        }
    }

    private fun applyAwake() {
        if (awake) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    /** تپ روی دکمه‌ی چرخش: بین عمودی و افقی جابه‌جا میشه و تو همون حالت میمونه */
    override fun onRotate() {
        if (locked) {
            MdToast.show(this, "Rotation is locked. Hold the button to unlock")
            return
        }
        val land = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
        forced = if (land) 1 else 2
        applyOrientation()
    }

    /** نگه داشتن دکمه‌ی چرخش: قفل / باز کردن قفل */
    override fun onLock() {
        locked = !locked
        if (!locked) forced = 0
        getSharedPreferences("ui", MODE_PRIVATE).edit().putBoolean("lock", locked).apply()
        applyOrientation()
        vinyl.setLocked(locked)
        MdToast.show(this, if (locked) "Rotation locked" else "Rotation unlocked")
    }

    /** دکمه‌ی لامپ: صفحه تا وقتی اپ بازه خاموش نمیشه */
    override fun onKeepAwake() {
        awake = !awake
        getSharedPreferences("ui", MODE_PRIVATE).edit().putBoolean("awake", awake).apply()
        applyAwake()
        vinyl.setAwake(awake)
        MdToast.show(this, if (awake) "Screen stays on while the app is open" else "Screen timeout restored")
    }

    // هر یک ثانیه وضعیت پخش پلیر با دیسک مقایسه میشه (مثلاً وقتی موزیک از نوتیفیکیشن قطع شده)
    private val syncH = android.os.Handler(android.os.Looper.getMainLooper())
    private val syncRun = object : Runnable {
        override fun run() {
            try {
                MediaReader.playingNow(this@VinylActivity)?.let { vinyl.syncPlaying(it) }
            } catch (e: Throwable) {
                // مهم نیست
            }
            syncH.postDelayed(this, 1000L)
        }
    }

    override fun onResume() {
        super.onResume()
        lastRot = displayRot()
        syncH.removeCallbacks(syncRun)
        syncH.postDelayed(syncRun, 1000L)
        enterImmersive()
        vinyl.rebuildGlow()      // شدت چراغ سوزن ممکنه توی تنظیمات عوض شده باشه
        vinyl.setHideText(getSharedPreferences("ui", MODE_PRIVATE).getBoolean("hide_text", false))
        val m = getSystemService(MediaSessionManager::class.java)
        msm = m
        try {
            m.addOnActiveSessionsChangedListener(sessionsListener, component)
            bind(m.getActiveSessions(component))
        } catch (e: SecurityException) {
            controllers = emptyList()
            vinyl.update(MediaInfo(hasAccess = false))
        }
    }

    override fun onPause() {
        super.onPause()
        finishMorph()
        syncH.removeCallbacks(syncRun)
        // دیسک یا تم عوض شده باشه، ویجت‌ها هم همون لحظه‌ی خروج به‌روز میشن
        try {
            WidgetRenderer.updateAll(this)
        } catch (e: Exception) {
            // مهم نیست
        }
        try {
            msm?.removeOnActiveSessionsChangedListener(sessionsListener)
        } catch (e: Exception) {
            // مهم نیست
        }
        controllers.forEach { it.unregisterCallback(callback) }
        controllers = emptyList()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) enterImmersive()
    }

    private fun bind(all: List<MediaController>) {
        val list = AppPrefs.filterAllowed(this, all)
        controllers.forEach { it.unregisterCallback(callback) }
        controllers = list
        list.forEach { it.registerCallback(callback) }
        reload()
    }

    private fun reload() {
        val info = MediaReader.read(this)
        if (info.pkg.isNotEmpty()) {
            lastPkg = info.pkg
            lastOpen = info.openIntent
        }
        vinyl.update(info)
    }

    // ------------------------------------------------------------ فول‌اسکرین

    private fun setupWindow() {
        if (Build.VERSION.SDK_INT >= 28) {
            val lp = window.attributes
            lp.layoutInDisplayCutoutMode = if (Build.VERSION.SDK_INT >= 30) {
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
            } else {
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
            window.attributes = lp
        }
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
    }

    @Suppress("DEPRECATION")
    private fun enterImmersive() {
        if (Build.VERSION.SDK_INT >= 30) {
            window.setDecorFitsSystemWindows(false)
            val ctl = window.insetsController
            if (ctl != null) {
                ctl.systemBarsBehavior = WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                ctl.hide(WindowInsets.Type.navigationBars())
                if (statusShown) ctl.show(WindowInsets.Type.statusBars()) else ctl.hide(WindowInsets.Type.statusBars())
            }
        } else {
            var flags = View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            if (!statusShown) flags = flags or View.SYSTEM_UI_FLAG_FULLSCREEN
            window.decorView.systemUiVisibility = flags
        }
    }

    // ------------------------------------------------------------ دکمه‌ها

    private fun currentController(): MediaController? {
        return try {
            val list = MediaReader.controllers(this)
            if (list == null) null else MediaReader.pick(list)
        } catch (e: SecurityException) {
            null
        }
    }

    private fun sendKey(code: Int) {
        val am = getSystemService(AudioManager::class.java)
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
    }

    override fun onPlayPause() {
        val c = currentController()
        if (c != null) {
            if (c.playbackState?.state == PlaybackState.STATE_PLAYING) {
                c.transportControls.pause()
            } else {
                c.transportControls.play()
            }
        } else {
            sendKey(KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE)
        }
    }

    override fun onPrev() {
        val c = currentController()
        if (c != null) c.transportControls.skipToPrevious() else sendKey(KeyEvent.KEYCODE_MEDIA_PREVIOUS)
    }

    override fun onNext() {
        val c = currentController()
        if (c != null) c.transportControls.skipToNext() else sendKey(KeyEvent.KEYCODE_MEDIA_NEXT)
    }

    override fun onNeedleLift() {
        val c = currentController()
        if (c != null) c.transportControls.pause() else sendKey(KeyEvent.KEYCODE_MEDIA_PAUSE)
    }

    override fun onNeedleDrop(positionMs: Long) {
        val c = currentController()
        if (c != null) {
            if (positionMs >= 0L) c.transportControls.seekTo(positionMs)
            c.transportControls.play()
        } else {
            sendKey(KeyEvent.KEYCODE_MEDIA_PLAY)
        }
    }

    override fun onNeedAccess() {
        startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
    }

    /** دکمه‌ی تنظیمات: صفحه‌ی قدیمی (دسترسی و پوشه‌های ویجت Library) */
    override fun onSettings() {
        startActivity(Intent(this, MainActivity::class.java))
    }

    /** دکمه‌ی پلیر: برنامه‌ی موزیکی که الان پخش می‌کنه رو باز می‌کنه */
    override fun onPlayer() {
        val fresh = MediaReader.read(this)
        val pkg = if (fresh.pkg.isNotEmpty()) fresh.pkg else lastPkg
        val pi = fresh.openIntent ?: lastOpen

        // ۱) باز کردن خود برنامه (مطمئن‌ترین راه)
        if (pkg.isNotEmpty()) {
            try {
                val intent = packageManager.getLaunchIntentForPackage(pkg)
                if (intent != null) {
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    startActivity(intent)
                    return
                }
            } catch (e: Exception) {
                // می‌ریم سراغ روش بعدی
            }
        }
        // ۲) صفحه‌ی «در حال پخش» که خود پلیر معرفی کرده
        if (pi != null) {
            try {
                if (Build.VERSION.SDK_INT >= 34) {
                    val opts = android.app.ActivityOptions.makeBasic()
                    opts.setPendingIntentBackgroundActivityStartMode(android.app.ActivityOptions.MODE_BACKGROUND_ACTIVITY_START_ALLOWED)
                    pi.send(this, 0, null, null, null, null, opts.toBundle())
                } else {
                    pi.send()
                }
                return
            } catch (e: Exception) {
                // آخرین راه: پیام
            }
        }
        MdToast.show(this, if (pkg.isEmpty()) "No music player is active" else "Couldn't open $pkg")
    }

    override fun onAlbums() {
        startActivity(Intent(this, AlbumsActivity::class.java))
    }

    override fun onWidgets() {
        startActivity(Intent(this, WidgetsActivity::class.java))
    }

    override fun onTheme() {
        if (sheet != null) return
        val sh = ThemeSheet(this, vinyl)
        sh.onDismissed = { sheet = null }
        sheet = sh
        root.addView(sh, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
    }

    /** ویرایشگر دیسک (رنگ، شفافیت، افکت) */
    fun openDiscEditor(index: Int = -1) {
        if (editor != null) return
        val saved = DiscStyles.listSaved(this)
        val start = if (index in saved.indices) saved[index].copy() else DiscStyles.clearPreset()
        val e = DiscEditor(this, vinyl, index, start)
        e.onClosed = {
            editor = null
            onTheme()
        }
        editor = e
        root.addView(e, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
    }

    /** ویرایشگر پس‌زمینه (دکمه‌ی + جلوی Theme)؛ file = پس‌زمینه‌ی ساخته‌شده‌ای که ویرایش میشه، یا null برای جدید */
    fun openBgEditor(file: File? = null) {
        if (editor != null) return
        val start = ThemeStore.bgStyle(this, file) ?: BgStyle()
        val e = BgEditor(this, vinyl, file, start)
        e.onClosed = {
            editor = null
            onTheme()
        }
        editor = e
        root.addView(e, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
    }

    override fun onOverlay(show: Boolean) {
        statusShown = show
        enterImmersive()
    }

    // ------------------------------------------------------------ انتخاب عکس از گالری

    fun pickImage(kind: String) {
        val i = Intent(Intent.ACTION_GET_CONTENT)
        i.type = "image/*"
        i.addCategory(Intent.CATEGORY_OPENABLE)
        startActivityForResult(i, if (kind == ThemeStore.BG) REQ_BG else REQ_DISC)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val uri = data?.data
        if (resultCode != RESULT_OK || uri == null) return
        if (requestCode != REQ_BG && requestCode != REQ_DISC) return
        val kind = if (requestCode == REQ_BG) ThemeStore.BG else ThemeStore.DISC
        Thread {
            val f = try {
                ThemeStore.import(this, kind, uri)
            } catch (e: Throwable) {
                null
            }
            runOnUiThread {
                if (f != null) {
                    ThemeStore.select(this, kind, f)
                    vinyl.reloadTheme()
                    sheet?.refresh()
                } else {
                    MdToast.show(this, "Couldn't open this image")
                }
            }
        }.start()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        val ed = editor
        val sh = sheet
        if (ed is DiscEditor) ed.cancel() else if (ed is BgEditor) ed.cancel() else if (sh != null) sh.dismiss() else super.onBackPressed()
    }

    companion object {
        private const val REQ_BG = 11
        private const val REQ_DISC = 12
    }
}
