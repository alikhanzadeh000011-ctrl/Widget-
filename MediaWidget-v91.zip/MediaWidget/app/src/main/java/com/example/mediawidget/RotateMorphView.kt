package com.example.mediawidget

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.os.SystemClock
import android.view.View

/**
 * انیمیشن چرخش عمودی ↔ افقی (شبیه نسخه‌ی iPad): دو تا عکس، یکی از صفحه‌ی قبلی و یکی از چیدمان جدید.
 * هر دو با یک تبدیل مشترک جابه‌جا و مقیاس میشن که مرکز و شعاع دیسک‌شون همیشه روی هم باشه؛
 * یعنی دیسک از جای قبلی به جای جدیدش می‌لغزه و بقیه‌ی صحنه نرم محو و ظاهر میشه.
 */
class RotateMorphView(ctx: Context) : View(ctx) {

    private var oldBmp: Bitmap? = null
    private var newBmp: Bitmap? = null
    private var oldK = 1f
    private var newK = 1f
    private var oldW = 0
    private var oldH = 0
    private var og = floatArrayOf(0f, 0f, 1f)   // مرکز و شعاع دیسک توی صفحه‌ی قبلی
    private var ng = floatArrayOf(0f, 0f, 1f)   // مرکز و شعاع دیسک توی صفحه‌ی جدید
    var begun = false
        private set
    private var failed = false
    private var t0 = 0L
    private var xf0 = 0L
    private var rv0 = 0L
    private var done = false
    var onDone: (() -> Unit)? = null
    private val p = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)

    fun setOld(bmp: Bitmap, k: Float, w: Int, h: Int, geom: FloatArray) {
        oldBmp = bmp
        oldK = k
        oldW = w
        oldH = h
        og = geom
    }

    /** چیدمان جدید آماده‌ی اندازه‌گیریه؛ حرکت دیسک شروع میشه */
    fun begin(geom: FloatArray) {
        ng = geom
        begun = true
        t0 = SystemClock.uptimeMillis()
        postInvalidateOnAnimation()
    }

    /** عکس صفحه‌ی جدید آماده شد؛ محو شدن صفحه‌ی قبلی شروع میشه */
    fun setNew(bmp: Bitmap, k: Float) {
        newBmp = bmp
        newK = k
        xf0 = SystemClock.uptimeMillis()
        postInvalidateOnAnimation()
    }

    /** عکس صفحه‌ی جدید نشد؛ فقط حرکت میکنه و بعد صفحه‌ی زنده‌ی زیرش رو نشون میده */
    fun fail() {
        failed = true
        postInvalidateOnAnimation()
    }

    fun release() {
        onDone = null
        done = true
        oldBmp?.recycle()
        newBmp?.recycle()
        oldBmp = null
        newBmp = null
    }

    private fun smooth(x: Float): Float {
        val t = x.coerceIn(0f, 1f)
        return t * t * (3f - 2f * t)
    }

    override fun onDraw(canvas: Canvas) {
        if (done) return
        val W = width.toFloat()
        val H = height.toFloat()
        if (W <= 0f || H <= 0f || oldW <= 0 || oldH <= 0) return
        val now = SystemClock.uptimeMillis()

        // شروع: صفحه‌ی قبلی تو صفحه‌ی جدید جا میشه (نوار کناری)، دیسکش همون‌جا که هست
        val s0 = Math.min(W / oldW, H / oldH)
        val q0x = (W - oldW * s0) / 2f + og[0] * s0
        val q0y = (H - oldH * s0) / 2f + og[1] * s0
        val r0 = Math.max(1f, og[2] * s0)
        val r1 = Math.max(1f, ng[2])

        var mt = 0f
        if (begun) mt = ((now - t0) / MOVE_MS.toFloat()).coerceIn(0f, 1f)
        val e = 1f - (1f - mt) * (1f - mt) * (1f - mt)
        val qx = q0x + (ng[0] - q0x) * (if (begun) e else 0f)
        val qy = q0y + (ng[1] - q0y) * (if (begun) e else 0f)
        val r = if (begun) (r0 * Math.pow((r1 / r0).toDouble(), e.toDouble()).toFloat()) else r0

        val nb = newBmp
        val xp = if (nb != null) ((now - xf0) / XF_MS.toFloat()).coerceIn(0f, 1f) else 0f
        val oldA = 1f - smooth(xp)

        // وقتی همه‌چی تموم شد، لایه آروم محو میشه و صفحه‌ی زنده‌ی زیرش دیده میشه
        var overlayA = 1f
        val finished = begun && mt >= 1f && (xp >= 1f || failed)
        if (finished) {
            if (rv0 == 0L) rv0 = now
            overlayA = 1f - ((now - rv0) / REVEAL_MS.toFloat()).coerceIn(0f, 1f)
        }

        canvas.drawColor(Color.argb((255f * overlayA).toInt(), 0, 0, 0))
        if (nb != null && !nb.isRecycled && ng[2] > 1f) {
            val s = r / ng[2]
            canvas.save()
            canvas.translate(qx - ng[0] * s, qy - ng[1] * s)
            canvas.scale(s / newK, s / newK)
            p.alpha = (255f * overlayA).toInt()
            canvas.drawBitmap(nb, 0f, 0f, p)
            canvas.restore()
        }
        val ob = oldBmp
        if (ob != null && !ob.isRecycled && oldA > 0.001f && og[2] > 1f) {
            val s = r / og[2]
            canvas.save()
            canvas.translate(qx - og[0] * s, qy - og[1] * s)
            canvas.scale(s / oldK, s / oldK)
            p.alpha = (255f * oldA * overlayA).toInt()
            canvas.drawBitmap(ob, 0f, 0f, p)
            canvas.restore()
        }

        if (finished && overlayA <= 0f) {
            done = true
            val cb = onDone
            post { cb?.invoke() }
        } else {
            postInvalidateOnAnimation()
        }
    }

    companion object {
        const val MOVE_MS = 560L
        const val XF_MS = 320L
        const val REVEAL_MS = 160L
    }
}
