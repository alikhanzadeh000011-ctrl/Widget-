package com.example.mediawidget

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.os.SystemClock
import android.util.LruCache
import android.view.MotionEvent
import android.view.VelocityTracker
import android.view.View
import android.view.ViewConfiguration
import java.util.concurrent.Executors
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.floor
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin

/**
 * نمای ۳بعدی آلبوم‌ها (مثل MD Vinyl): همه‌ی کارت‌ها خوابیده و کج می‌مونن، فاصله‌ها یکسانه،
 * کارتی که به خط وسط می‌رسه از لبه دیده میشه (فقط یک نوار باریک) و بعد از طرف دیگه باز میشه.
 * نوار اسم (عطف) هم موقع رد شدن از وسط از بالای کارت به پایینش می‌لغزه.
 * حالت گالری: شبکه‌ی ۳ستونه.
 */
class AlbumStackView(ctx: Context) : View(ctx) {

    interface Listener {
        fun onAlbumTap(album: Album, index: Int)
        fun onAlbumLongPress(album: Album, index: Int)
    }

    var listener: Listener? = null

    private var albums: List<Album> = emptyList()
    private val d = resources.displayMetrics.density
    private val slop = ViewConfiguration.get(ctx).scaledTouchSlop.toFloat()
    private val executor = Executors.newFixedThreadPool(3)
    @Volatile private var wanted: Set<Long> = emptySet()
    private var building = HashSet<Long>()
    private val pending = HashSet<Long>()
    private val holders = HashMap<Long, Bitmap>()

    private val covers = object : LruCache<Long, Bitmap>(
        (Runtime.getRuntime().maxMemory() / 6L).toInt().coerceAtLeast(16 * 1024 * 1024)
    ) {
        override fun sizeOf(key: Long, value: Bitmap): Int = value.byteCount
    }

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val titlePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val artistPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val rect = RectF()
    private val verts = FloatArray((ROWS + 1) * 4)

    private var topInset = 0
    private var bottomInset = 0

    // حالت پشته
    private var pos = 0f
    private var vel = 0f
    private var minPos = 0f
    private var maxPos = 0f
    private var cardW = 0f
    // لندسکیپ: پشته به‌صورت افقی؛ همون هندسه‌ی عمودی تو فضای «مجازی» محاسبه و با ترانهاده (x,y)->(y,x) کشیده میشه
    private var horiz = false
    private var vw = 0f
    private var vh = 0f
    private val transM = Matrix().also { it.setValues(floatArrayOf(0f, 1f, 0f, 1f, 0f, 0f, 0f, 0f, 1f)) }
    private val transCache = LruCache<Bitmap, Bitmap>(24)
    private var focusFromGrid = false
    private var cx = 0f
    private var cy = 0f

    // حالت گالری
    private var gridMode = false
    private var modeT = 0f
    private var gridScroll = 0f
    private var gridVel = 0f

    // لمس
    private var touching = false
    private var moved = false
    private var longFired = false
    private var downX = 0f
    private var downY = 0f
    private var lastY = 0f
    private var velocity: VelocityTracker? = null
    private var lastTime = 0L
    private val longRunnable = Runnable {
        if (touching && !moved) {
            val idx = indexAt(downX, downY)
            if (idx >= 0) {
                longFired = true
                performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS)
                listener?.onAlbumLongPress(albums[idx], idx)
            }
        }
    }

    // ضربه روی کارت‌ها (به ترتیب رسم)
    private val hitIdx = IntArray(48)
    private val hitTop = FloatArray(48)
    private val hitBottom = FloatArray(48)
    private var hitCount = 0

    init {
        val tf = DarkUi.font(ctx)
        titlePaint.typeface = Typeface.create(tf, Typeface.BOLD)
        artistPaint.typeface = tf
    }

    fun setAlbums(list: List<Album>) {
        albums = list
        recomputeRange()
        pos = minPos
        vel = 0f
        gridScroll = 0f
        invalidate()
    }

    fun setInsets(top: Int, bottom: Int) {
        topInset = top
        bottomInset = bottom
        invalidate()
    }

    fun isGrid(): Boolean = gridMode

    // ---------------------------------------------------------------- پس‌زمینه (بلر کاورِ آهنگ در حال پخش)

    private var bgCur: Bitmap? = null
    private var bgPrev: Bitmap? = null
    private var bgFade = 1f
    private var greyBg: Bitmap? = null
    private val bgPaint = Paint(Paint.FILTER_BITMAP_FLAG)
    private val dstRect = RectF()

    /** پس‌زمینه‌ی جدید با کراس‌فید؛ null = خاکستری تیره‌ی صفحه‌ی وینیل (چیزی پخش نمیشه) */
    fun setBackdrop(b: Bitmap?) {
        bgPrev = bgCur ?: greyBg
        bgCur = b
        bgFade = 0f
        invalidate()
    }

    private fun grey(): Bitmap? {
        if (greyBg == null && width > 0 && height > 0) greyBg = VinylArt.greyBackground(width, height)
        return greyBg
    }

    private fun drawBackdrop(c: Canvas) {
        c.drawColor(DarkUi.BG)
        dstRect.set(0f, 0f, width.toFloat(), height.toFloat())
        val prev = bgPrev
        val cur = bgCur ?: grey()
        if (bgFade < 1f && prev != null) {
            bgPaint.alpha = 255
            c.drawBitmap(prev, null, dstRect, bgPaint)
        }
        if (cur != null) {
            bgPaint.alpha = (255f * bgFade).toInt().coerceIn(0, 255)
            c.drawBitmap(cur, null, dstRect, bgPaint)
        }
        if (gradA > 0.01f) {
            if (gradShader == null || gradH != height || gradTopC != gradTop || gradBotC != gradBot) {
                gradShader = LinearGradient(0f, 0f, 0f, height.toFloat(), gradTop, gradBot, Shader.TileMode.CLAMP)
                gradH = height
                gradTopC = gradTop
                gradBotC = gradBot
            }
            gradPaint.shader = gradShader
            gradPaint.alpha = (255f * gradA).toInt().coerceIn(0, 255)
            c.drawRect(dstRect, gradPaint)
        }
    }

    // ---------------------------------------------------------------- باز شدن آلبوم (کاور از پشته بلند میشه)

    private var focusIndex = -1
    private var focusE = 0f
    private val finalRect = RectF()
    private var focusBmp: Bitmap? = null
    private var gradTop = 0
    private var gradBot = 0
    private var gradA = 0f
    private var gradShader: LinearGradient? = null
    private var gradH = 0
    private var gradTopC = 0
    private var gradBotC = 0
    private val gradPaint = Paint()
    private val q0 = FloatArray(8)
    private val qd = FloatArray(8)
    private val q1 = FloatArray(8)
    private val qq = FloatArray(8)
    private val spineQuad = FloatArray(8)
    private val flyMesh = FloatArray((FLY_N + 1) * (FLY_N + 1) * 2)

    fun isOpening(): Boolean = focusIndex >= 0

    private var focusHold = false

    /** وقتی صفحه‌ی آلبوم باز و کاورش فرود اومده، پشته دیگه کاور رو نمی‌کشه (وگرنه موقع اسکرول زیر کاور واقعی دیده میشه) */
    fun setFocusHold(h: Boolean) {
        focusHold = h
        invalidate()
    }

    fun beginFocus(index: Int) {
        focusFromGrid = gridMode
        focusIndex = index
        focusE = 0f
        vel = 0f
        invalidate()
    }

    fun setFocusProgress(e: Float) {
        focusE = e
        invalidate()
    }

    fun endFocus() {
        focusIndex = -1
        focusE = 0f
        focusBmp = null
        focusHold = false
        focusFromGrid = false
        gradA = 0f
        invalidate()
    }

    fun setFinalRect(r: RectF) = finalRect.set(r)

    fun setFocusBitmap(b: Bitmap?) {
        focusBmp = b
        invalidate()
    }

    fun setGradient(top: Int, bottom: Int, alpha: Float) {
        gradTop = top
        gradBot = bottom
        gradA = alpha
        invalidate()
    }

    /** کاور آیتم (یا جای‌خالی) برای انیمیشن و صفحه‌ی آلبوم */
    fun bitmapFor(index: Int): Bitmap = cover(albums[index]) ?: placeholder(albums[index])

    fun hasCover(index: Int): Boolean = cover(albums[index]) != null

    fun toggleMode() {
        gridMode = !gridMode
        if (gridMode) {
            val row = (pos.roundToInt().coerceIn(0, max(0, albums.size - 1))) / 3
            gridScroll = (row * (cellSize() + gap()) - dp(60f)).coerceIn(0f, gridMax())
            gridVel = 0f
        }
        invalidate()
    }

    private fun dp(v: Float) = v * d
    private fun gap() = dp(6f)
    private fun cols() = if (horiz) 6 else 3
    private fun cellSize() = (width - gap() * (cols() + 1)) / cols()
    private fun spacing() = max(1f, cardW * 0.267f)

    private fun recomputeRange() {
        val n = albums.size
        if (n == 0 || cardW <= 0f) {
            minPos = 0f
            maxPos = 0f
            return
        }
        // کارت اول بتونه بره بالای صفحه و کارت آخر پایین صفحه
        val k0 = floor((cy - dp(70f)) / spacing()).toInt().coerceAtLeast(0)
        minPos = min(k0.toFloat(), (n - 1) / 2f)
        maxPos = max(minPos, (n - 1 - k0).toFloat())
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        horiz = w > h
        vw = if (horiz) h.toFloat() else w.toFloat()
        vh = if (horiz) w.toFloat() else h.toFloat()
        cardW = if (horiz) vw * 0.70f else min(w, h) * 0.82f
        cx = vw / 2f
        cy = vh * 0.5f
        val keep = pos
        recomputeRange()
        pos = keep.coerceIn(minPos, maxPos)
    }

    // ---------------------------------------------------------------- کاورها

    private fun cover(a: Album): Bitmap? {
        building.add(a.id)
        covers.get(a.id)?.let { return it }
        if (a.noCover) return null
        if (pending.add(a.id)) {
            val app = context.applicationContext
            executor.execute {
                if (a.id !in wanted) {
                    post { pending.remove(a.id) }
                    return@execute
                }
                val b = try {
                    AlbumRepo.loadItemCover(app, a, 512)
                } catch (e: Throwable) {
                    null
                }
                var col = 0
                if (b != null) {
                    val sm = Bitmap.createScaledBitmap(b, 8, 8, true)
                    var r = 0
                    var g = 0
                    var bl = 0
                    for (y in 0 until 8) for (x in 0 until 8) {
                        val p = sm.getPixel(x, y)
                        r += Color.red(p)
                        g += Color.green(p)
                        bl += Color.blue(p)
                    }
                    sm.recycle()
                    col = Color.rgb(r / 64, g / 64, bl / 64)
                }
                post {
                    pending.remove(a.id)
                    if (b != null) {
                        covers.put(a.id, b)
                        val hsv = FloatArray(3)
                        Color.colorToHSV(col, hsv)
                        hsv[2] = max(hsv[2], 0.45f)
                        a.color = Color.HSVToColor(hsv)
                        a.hasColor = true
                    } else {
                        a.noCover = true
                    }
                    invalidate()
                }
            }
        }
        return null
    }

    /** نسخه‌ی ترانهاده‌ی کاور برای حالت افقی (تا بعد از ترانهاده‌ی کل صحنه، کاور صاف دیده بشه) */
    private fun transposed(b: Bitmap): Bitmap {
        transCache.get(b)?.let { return it }
        val t = Bitmap.createBitmap(b, 0, 0, b.width, b.height, transM, true)
        transCache.put(b, t)
        return t
    }

    private fun stackBitmap(a: Album): Bitmap {
        val b = cover(a) ?: placeholder(a)
        return if (horiz) transposed(b) else b
    }

    private var blankTile: Bitmap? = null

    /** جای خالی ساده و تیره تا کاور لود بشه (بدون حرف و عدد) */
    private fun placeholder(a: Album): Bitmap {
        blankTile?.let { return it }
        val bmp = Bitmap.createBitmap(64, 64, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val p = Paint()
        p.shader = LinearGradient(0f, 0f, 64f, 64f, Color.rgb(58, 58, 64), Color.rgb(36, 36, 40), Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, 64f, 64f, p)
        blankTile = bmp
        return bmp
    }

    // ---------------------------------------------------------------- رسم

    override fun onDraw(c: Canvas) {
        val now = SystemClock.uptimeMillis()
        val dt = if (lastTime == 0L) 0.016f else ((now - lastTime) / 1000f).coerceIn(0f, 0.05f)
        lastTime = now
        val anim = step(dt)

        building = HashSet()
        drawBackdrop(c)
        if (albums.isNotEmpty()) {
            val stackAlpha = 1f - modeT
            if (stackAlpha > 0.01f) {
                if (horiz) {
                    c.save()
                    c.concat(transM)
                }
                drawStack(c, stackAlpha)
                if (horiz) c.restore()
            }
            if (modeT > 0.01f) drawGrid(c, modeT)
        }
        wanted = building
        if (anim) postInvalidateOnAnimation() else lastTime = 0L
    }

    private fun step(dt: Float): Boolean {
        var anim = false
        if (bgFade < 1f) {
            bgFade = min(1f, bgFade + dt / 0.6f)
            if (bgFade >= 1f) bgPrev = null
            anim = true
        }
        val target = if (gridMode) 1f else 0f
        if (modeT != target) {
            val dm = dt / 0.28f
            modeT = if (modeT < target) min(modeT + dm, 1f) else max(modeT - dm, 0f)
            anim = true
        }
        if (albums.isEmpty()) return anim
        if (touching) return true

        if (!gridMode) {
            if (abs(vel) > 0.05f) {
                pos += vel * dt
                vel *= exp(-dt * 2.6f)
                if (pos < minPos) { pos = minPos; vel = 0f }
                if (pos > maxPos) { pos = maxPos; vel = 0f }
                anim = true
            } else {
                vel = 0f
            }
        } else {
            if (abs(gridVel) > 20f) {
                gridScroll += gridVel * dt
                gridVel *= exp(-dt * 3.2f)
                val mx = gridMax()
                if (gridScroll < 0f) { gridScroll = 0f; gridVel = 0f }
                if (gridScroll > mx) { gridScroll = mx; gridVel = 0f }
                anim = true
            } else {
                gridVel = 0f
            }
        }
        return anim
    }

    private fun scale(col: Int, m: Float): Int = Color.rgb(
        (Color.red(col) * m).toInt().coerceIn(0, 255),
        (Color.green(col) * m).toInt().coerceIn(0, 255),
        (Color.blue(col) * m).toInt().coerceIn(0, 255)
    )

    private fun drawStack(c: Canvas, gAlpha: Float) {
        val n = albums.size
        val s = spacing()
        hitCount = 0
        val span = (max(cy, vh - cy) / s).toInt() + 2
        val lo = floor(pos - span).toInt().coerceAtLeast(0)
        val hi = floor(pos + span).toInt().coerceAtMost(n - 1)
        // از دورترین به نزدیک‌ترین به وسط
        val order = ArrayList<Int>()
        for (i in lo..hi) order.add(i)
        order.sortByDescending { abs(it - pos) }
        for (j in (lo - 6)..(hi + 6)) if (j in 0 until n) cover(albums[j])
        val e = focusE
        val ep = 1f - (1f - e) * (1f - e) * (1f - e)
        for (i in order) {
            if (i == focusIndex) continue
            val ga = if (focusIndex >= 0) gAlpha * (1f - ep * 1.3f).coerceIn(0f, 1f) else gAlpha
            if (ga > 0.01f) drawCard(c, i, i - pos, ga)
        }
        if (focusIndex in lo..hi) {
            val t = focusIndex - pos
            if (e <= 0.001f) {
                drawCard(c, focusIndex, t, gAlpha)
            } else if (!focusHold) {
                // عطف کم‌کم محو میشه و کاور آزاد میشه و به جای نهایی میره
                val sa = (1f - ep * 3f).coerceIn(0f, 1f)
                if (sa > 0.01f) drawCard(c, focusIndex, t, gAlpha * sa, true)
                drawFly(c, focusIndex, t, e)
            }
        }
    }

    // ---------------------------------------------------------------- کشیدن کاور با تبدیل دقیق + فیلتر قبل از کوچیک شدن

    private val mipCache = LruCache<Bitmap, Array<Bitmap?>>(18)
    private val srcPts = FloatArray(8)
    private val quadMatrix = Matrix()

    /** نسخه‌ی کوچیک‌شده‌ی عمودیِ کاور (مثل mipmap) تا وقتی کارت تخت میشه تصویر نویز و موج نده */
    private fun levelFor(base: Bitmap, hDest: Float): Bitmap {
        var k = 0
        var h = base.height.toFloat()
        while (k < 3 && h / 2f >= hDest) {
            h /= 2f
            k++
        }
        if (k == 0) return base
        var arr = mipCache.get(base)
        if (arr == null) {
            arr = arrayOfNulls<Bitmap>(4)
            arr[0] = base
            mipCache.put(base, arr)
        }
        for (i in 1..k) {
            if (arr[i] == null) {
                val prev = arr[i - 1]!!
                arr[i] = Bitmap.createScaledBitmap(prev, prev.width, max(1, prev.height / 2), true)
            }
        }
        return arr[k]!!
    }

    /** کاور رو روی چهارضلعی q (بالا‌چپ، بالا‌راست، پایین‌راست، پایین‌چپ) با پرسپکتیو دقیق و لبه‌ی نرم می‌کشه */
    private fun drawQuad(c: Canvas, base: Bitmap, q: FloatArray, alpha: Int) {
        val l = Math.hypot((q[6] - q[0]).toDouble(), (q[7] - q[1]).toDouble())
        val r = Math.hypot((q[4] - q[2]).toDouble(), (q[5] - q[3]).toDouble())
        val hDest = ((l + r) / 2.0).toFloat()
        if (hDest < 0.5f) return
        val bm = levelFor(base, hDest)
        val bw = bm.width.toFloat()
        val bh = bm.height.toFloat()
        srcPts[0] = 0f; srcPts[1] = 0f
        srcPts[2] = bw; srcPts[3] = 0f
        srcPts[4] = bw; srcPts[5] = bh
        srcPts[6] = 0f; srcPts[7] = bh
        if (!quadMatrix.setPolyToPoly(srcPts, 0, q, 0, 4)) return
        paint.alpha = alpha
        c.drawBitmap(bm, quadMatrix, paint)
    }

    /** چهار گوشه‌ی رویه‌ی کارت روی صفحه: بالا‌چپ، بالا‌راست، پایین‌راست، پایین‌چپ (به ترتیب تصویر) */
    private fun faceQuad(t: Float, out: FloatArray) {
        val w = cardW
        val s = spacing()
        val sc = w / REF_W
        val dSigned = t * s
        val dn = abs(dSigned)
        val dir = if (dSigned >= 0f) 1f else -1f
        val ph = tilt(dn / sc)
        val den1 = 1f + ZETA * cos(ph)
        val off1 = (dn + w * sin(ph)) / den1
        val yN = cy + dSigned
        val yF = cy + dir * off1
        val half1 = w / 2f / den1
        if (t < 0f) {
            out[0] = cx - w / 2f; out[1] = yN
            out[2] = cx + w / 2f; out[3] = yN
            out[4] = cx + half1; out[5] = yF
            out[6] = cx - half1; out[7] = yF
        } else {
            out[0] = cx - half1; out[1] = yF
            out[2] = cx + half1; out[3] = yF
            out[4] = cx + w / 2f; out[5] = yN
            out[6] = cx - w / 2f; out[7] = yN
        }
    }

    /** گوشه‌های مستطیل نهایی (به ترتیب تصویر)؛ تو حالت افقی در فضای مجازی و به ترتیب ترانهاده‌ی تصویر */
    private fun setFinalCorners() {
        val l = finalRect.left
        val t = finalRect.top
        val r = finalRect.right
        val b = finalRect.bottom
        if (horiz) {
            q1[0] = t; q1[1] = l
            q1[2] = b; q1[3] = l
            q1[4] = b; q1[5] = r
            q1[6] = t; q1[7] = r
        } else {
            q1[0] = l; q1[1] = t
            q1[2] = r; q1[3] = t
            q1[4] = r; q1[5] = b
            q1[6] = l; q1[7] = b
        }
    }

    /**
     * کل آلبوم در حال پرواز: کاور از ذوزنقه‌ی پشته تا مربع نهایی (با کمی چرخش و بزرگ‌نمایی) میره
     * و عطفش به لبه‌ی نزدیک چسبیده می‌مونه، می‌چرخه و کم‌کم باریک میشه تا موقع فرود پشت کاور قایم بشه.
     */
    private fun drawFly(c: Canvas, index: Int, t: Float, e: Float) {
        val a = albums[index]
        val w = cardW
        val s = spacing()
        val sc = w / REF_W
        val dn = abs(t * s)
        val ph = tilt(dn / sc)
        val g = (ph / TILT_FULL).coerceIn(0f, 1f)
        val above = t < 0f
        val lean = (if (above) lerpTable(LEAN_X, LEAN_UP, dn) else lerpTable(LEAN_X, LEAN_DOWN, dn)) * (w / LEAN_REF_W)
        val p0 = (0.5f + t * 3.2f).coerceIn(0f, 1f)
        val dark0 = 0.42f * (1f - g) + 0.10f * p0

        faceQuad(t, q0)
        setFinalCorners()
        val ep = 1f - (1f - e) * (1f - e) * (1f - e)
        val sw = sin(Math.PI * e).toFloat()
        var mx = 0f
        var my = 0f
        for (i in 0..3) {
            qq[i * 2] = q0[i * 2] + (q1[i * 2] - q0[i * 2]) * ep
            qq[i * 2 + 1] = q0[i * 2 + 1] + (q1[i * 2 + 1] - q0[i * 2 + 1]) * ep
            mx += qq[i * 2] / 4f
            my += qq[i * 2 + 1] / 4f
        }
        val ang = FLY_ROLL * sw
        val ca = cos(ang)
        val sa = sin(ang)
        val zoom = 1f + 0.05f * sw
        for (i in 0..3) {
            val x = (qq[i * 2] - mx) * zoom
            val y = (qq[i * 2 + 1] - my) * zoom
            qq[i * 2] = mx + x * ca - y * sa
            qq[i * 2 + 1] = my + x * sa + y * ca
        }

        // سایه‌ی نرم زیر کاور
        if (ep > 0.05f) {
            for (k in 3 downTo 1) {
                path.reset()
                val off = dp(3.5f * k) * ep
                val grow = dp(1.5f * k) * ep
                path.moveTo(qq[0] - grow, qq[1] + off - grow)
                path.lineTo(qq[2] + grow, qq[3] + off - grow)
                path.lineTo(qq[4] + grow, qq[5] + off + grow)
                path.lineTo(qq[6] - grow, qq[7] + off + grow)
                path.close()
                fill.color = Color.argb((20f * ep).toInt().coerceIn(0, 255), 0, 0, 0)
                c.drawPath(path, fill)
            }
        }

        // رویه
        val fb = focusBmp ?: bitmapFor(index)
        drawQuad(c, if (horiz) transposed(fb) else fb, qq, 255)
        val dk = dark0 * (1f - ep)
        if (dk > 0.01f) {
            path.reset()
            path.moveTo(qq[0], qq[1])
            path.lineTo(qq[2], qq[3])
            path.lineTo(qq[4], qq[5])
            path.lineTo(qq[6], qq[7])
            path.close()
            fill.color = Color.argb((255f * dk).toInt().coerceIn(0, 255), 0, 0, 0)
            c.drawPath(path, fill)
        }

        // عطف چسبیده به لبه‌ی نزدیک
        val stripH = STRIP * w
        val thick = stripH * (1f - e)
        if (thick > 0.8f) {
            val n0x: Float; val n0y: Float; val n1x: Float; val n1y: Float
            if (above) {
                n0x = qq[0]; n0y = qq[1]; n1x = qq[2]; n1y = qq[3]
            } else {
                n0x = qq[6]; n0y = qq[7]; n1x = qq[4]; n1y = qq[5]
            }
            val ex = n1x - n0x
            val ey = n1y - n0y
            val el = Math.hypot(ex.toDouble(), ey.toDouble()).toFloat().coerceAtLeast(1f)
            val ux = ex / el
            val uy = ey / el
            // جهت «بیرون» = عمود بر لبه، دور از مرکز کاور
            var ox = uy
            var oy = -ux
            val midx = (n0x + n1x) / 2f
            val midy = (n0y + n1y) / 2f
            if (ox * (mx - midx) + oy * (my - midy) > 0f) {
                ox = -ox
                oy = -oy
            }
            val ins = lean * (1f - e)
            val o0x = n0x + ox * thick + ux * ins
            val o0y = n0y + oy * thick + uy * ins
            val o1x = n1x + ox * thick - ux * ins
            val o1y = n1y + oy * thick - uy * ins
            val fade = (1f - ((e - 0.7f) / 0.3f).coerceIn(0f, 1f))
            val sa2 = (255f * fade).toInt()
            val m = 1.08f - 0.20f * p0
            val col = scale(a.color, m)
            fill.color = Color.argb(sa2, Color.red(col), Color.green(col), Color.blue(col))
            path.reset()
            path.moveTo(n0x, n0y)
            path.lineTo(n1x, n1y)
            path.lineTo(o1x, o1y)
            path.lineTo(o0x, o0y)
            path.close()
            c.drawPath(path, fill)

            // متن عطف روی همون چهارضلعی (زود محو میشه)
            val ta = (255f * (1f - e * 4f)).toInt().coerceIn(0, 255)
            if (ta > 4) {
                srcPts[0] = 0f; srcPts[1] = 0f
                srcPts[2] = w; srcPts[3] = 0f
                srcPts[4] = w; srcPts[5] = stripH
                srcPts[6] = 0f; srcPts[7] = stripH
                if (above) {
                    spineQuad[0] = o0x; spineQuad[1] = o0y; spineQuad[2] = o1x; spineQuad[3] = o1y
                    spineQuad[4] = n1x; spineQuad[5] = n1y; spineQuad[6] = n0x; spineQuad[7] = n0y
                } else {
                    spineQuad[0] = n0x; spineQuad[1] = n0y; spineQuad[2] = n1x; spineQuad[3] = n1y
                    spineQuad[4] = o1x; spineQuad[5] = o1y; spineQuad[6] = o0x; spineQuad[7] = o0y
                }
                if (quadMatrix.setPolyToPoly(srcPts, 0, spineQuad, 0, 4)) {
                    c.save()
                    c.concat(quadMatrix)
                    rect.set(0f, 0f, w, stripH)
                    drawStripText(c, a, rect, col, ta)
                    c.restore()
                }
            }
        }
    }

    private fun buildHomographyMesh(q: FloatArray, out: FloatArray) {
        val x0 = q[0]; val y0 = q[1]
        val x1 = q[2]; val y1 = q[3]
        val x2 = q[4]; val y2 = q[5]
        val x3 = q[6]; val y3 = q[7]
        val dx1 = x1 - x2; val dx2 = x3 - x2; val dx3 = x0 - x1 + x2 - x3
        val dy1 = y1 - y2; val dy2 = y3 - y2; val dy3 = y0 - y1 + y2 - y3
        val det = dx1 * dy2 - dx2 * dy1
        var g = 0f
        var h = 0f
        if (abs(det) > 1e-3f && (abs(dx3) > 1e-4f || abs(dy3) > 1e-4f)) {
            g = (dx3 * dy2 - dx2 * dy3) / det
            h = (dx1 * dy3 - dx3 * dy1) / det
        }
        val a = x1 - x0 + g * x1
        val b = x3 - x0 + h * x3
        val dd = y1 - y0 + g * y1
        val e = y3 - y0 + h * y3
        var k = 0
        for (r in 0..FLY_N) {
            val v = r.toFloat() / FLY_N
            for (cc in 0..FLY_N) {
                val u = cc.toFloat() / FLY_N
                val den = g * u + h * v + 1f
                out[k++] = (a * u + b * v + x0) / den
                out[k++] = (dd * u + e * v + y0) / den
            }
        }
    }

    /** درون‌یابی خطی روی جدول (xs صعودی) */
    private fun lerpTable(xs: FloatArray, ys: FloatArray, x: Float): Float {
        if (x <= xs[0]) return ys[0]
        var i = 0
        while (i < xs.size - 2 && x > xs[i + 1]) i++
        val f = ((x - xs[i]) / (xs[i + 1] - xs[i])).coerceIn(0f, 1f)
        return ys[i] + (ys[i + 1] - ys[i]) * f
    }

    /** زاویه‌ی کج‌شدن ورق (رادیان) بر حسب فاصله‌ی لبه‌ی نزدیک تا افق (پیکسلِ مرجع ۱۰۸۰ عرضی) */
    private fun tilt(dRef: Float): Float {
        val x = dRef.coerceAtLeast(0f)
        var i = 0
        while (i < TILT_X.size - 2 && x > TILT_X[i + 1]) i++
        val f = ((x - TILT_X[i]) / (TILT_X[i + 1] - TILT_X[i])).coerceIn(0f, 1f)
        val deg = TILT_DEG[i] + (TILT_DEG[i + 1] - TILT_DEG[i]) * f
        return Math.toRadians(deg.toDouble()).toFloat()
    }

    private fun drawCard(c: Canvas, index: Int, t: Float, gAlpha: Float, coverOff: Boolean = false) {
        val a = albums[index]
        val w = cardW
        val s = spacing()
        val yN = cy + t * s                        // لبه‌ی نزدیک (جایی که نوار هست)
        if (yN < -s * 1.5f || yN > vh + s * 1.5f) return

        // ---- هندسه‌ی ۳بعدی (از اندازه‌گیری روی ویدیوی MD):
        // هر کارت یه ورق مربعیه که لبه‌ی نزدیکش (عطف) هم‌عرض و هم‌عمق همه‌ی کارت‌هاست و لبه‌ی دورش با پرسپکتیو
        // کوچیک‌تر میشه. هرچی کارت از خط وسط (افق) دورتر باشه، ورق بیشتر به سمت بیننده کج میشه (رو‌به‌رو‌تر).
        val sc = w / REF_W
        val dSigned = t * s
        val dn = abs(dSigned)
        val dir = if (dSigned >= 0f) 1f else -1f
        val ph = tilt(dn / sc)
        val sinP = sin(ph)
        val cosP = cos(ph)
        val above = t < 0f                         // کارت‌های بالا: عطف بالاست و رویه به سمت وسط (پایین)
        val g = (ph / TILT_FULL).coerceIn(0f, 1f)  // ۰ وسط (از لبه) تا ۱ دور (رو‌به‌رو)

        // کجی دو طرف عطف (عطف وجه جلویی ورقه: لبه‌ی بالاش پهن و لبه‌ی پایینش باریک‌تره)
        val lean = (if (above) lerpTable(LEAN_X, LEAN_UP, dn) else lerpTable(LEAN_X, LEAN_DOWN, dn)) * (w / LEAN_REF_W)
        // لبه‌ی عطف که به کاور چسبیده هم‌عرض کاوره؛ لبه‌ی بیرونیش (بالا برای کارت‌های بالا، پایین برای پایینی‌ها) باریک‌تره
        val wn = w

        // رویه‌ی کارت: چهارضلعیِ پرسپکتیو که یک‌جا با تبدیل دقیق کشیده میشه
        faceQuad(t, qd)
        val hh = abs(qd[5] - qd[1])
        val bmp = stackBitmap(a)
        if (hh > 1f && !coverOff) drawQuad(c, bmp, qd, (255f * gAlpha).toInt())

        // نور: نزدیک خط وسط (از لبه) تیره‌تر، و کارت‌های پایین کمی تیره‌تر
        val p = (0.5f + t * 3.2f).coerceIn(0f, 1f)
        val dark = (0.42f * (1f - g) + 0.10f * p) * gAlpha
        if (hh > 1f && dark > 0.01f && !coverOff) {
            path.reset()
            path.moveTo(qd[0], qd[1])
            path.lineTo(qd[2], qd[3])
            path.lineTo(qd[4], qd[5])
            path.lineTo(qd[6], qd[7])
            path.close()
            fill.color = Color.argb((255f * dark).toInt().coerceIn(0, 255), 0, 0, 0)
            c.drawPath(path, fill)
        }

        // عطف جلد: کنار لبه‌ی نزدیک؛ موقع رد شدن از وسط از بالا به پایین می‌لغزه
        val stripH = STRIP * w
        val top = yN - stripH * (1f - p)
        rect.set(cx - w / 2f, top, cx + w / 2f, top + stripH)
        val m = 1.08f - 0.20f * p
        val sa = (255f * gAlpha).toInt()
        val base = a.color
        val l0 = rect.left
        val r0 = rect.right
        // عطف یک‌رنگ؛ سمت بیرونی (بالا برای کارت‌های بالا، پایین برای پایینی‌ها) باریک‌تره
        val inTop = if (above) lean else 0f
        val inBot = if (above) 0f else lean
        val sc1 = scale(base, m)
        fill.color = Color.argb(sa, Color.red(sc1), Color.green(sc1), Color.blue(sc1))
        path.reset()
        path.moveTo(l0 + inTop, rect.top)
        path.lineTo(r0 - inTop, rect.top)
        path.lineTo(r0 - inBot, rect.bottom)
        path.lineTo(l0 + inBot, rect.bottom)
        path.close()
        c.drawPath(path, fill)
        drawStripText(c, a, rect, scale(base, m), sa)

        val faceTop = if (above) yN else yN - hh
        val faceBottom = if (above) yN + hh else yN
        if (hitCount < hitIdx.size) {
            hitIdx[hitCount] = index
            hitTop[hitCount] = min(faceTop, rect.top)
            hitBottom[hitCount] = max(faceBottom, rect.bottom)
            hitCount++
        }
    }

    private fun drawStripText(c: Canvas, a: Album, r: RectF, bg: Int, alpha: Int) {
        // تو حالت افقی کل صحنه ترانهاده میشه؛ اینجا افقی آینه می‌کنیم تا متن عمودی بعدش درست (پایین به بالا) خونده بشه
        if (horiz) {
            c.save()
            c.scale(-1f, 1f, r.centerX(), r.centerY())
            drawStripTextInner(c, a, r, bg, alpha)
            c.restore()
        } else {
            drawStripTextInner(c, a, r, bg, alpha)
        }
    }

    private fun drawStripTextInner(c: Canvas, a: Album, r: RectF, bg: Int, alpha: Int) {
        val lum = (0.299f * Color.red(bg) + 0.587f * Color.green(bg) + 0.114f * Color.blue(bg)) / 255f
        val fg = if (lum > 0.55f) Color.rgb(24, 24, 28) else Color.WHITE
        val avail = r.width() - dp(16f)
        var size = r.height() * 0.58f
        titlePaint.textSize = size
        artistPaint.textSize = size
        val gapPx = size * 0.35f
        var tw = titlePaint.measureText(a.title)
        var aw = artistPaint.measureText(a.artist)
        if (tw + gapPx + aw > avail) {
            val kf = max(0.65f, avail / (tw + gapPx + aw))
            size *= kf
            titlePaint.textSize = size
            artistPaint.textSize = size
            tw = titlePaint.measureText(a.title)
            aw = artistPaint.measureText(a.artist)
        }
        var title = a.title
        var artist = a.artist
        while (tw + gapPx + aw > avail && title.length > 3) {
            title = title.substring(0, title.length - 2).trimEnd() + "\u2026"
            tw = titlePaint.measureText(title)
        }
        while (tw + gapPx + aw > avail && artist.length > 3) {
            artist = artist.substring(0, artist.length - 2).trimEnd() + "\u2026"
            aw = artistPaint.measureText(artist)
        }
        val total = tw + gapPx + aw
        val x = r.centerX() - total / 2f
        val base = r.centerY() + size * 0.35f
        titlePaint.color = Color.argb(alpha, Color.red(fg), Color.green(fg), Color.blue(fg))
        artistPaint.color = Color.argb((alpha * 0.8f).toInt(), Color.red(fg), Color.green(fg), Color.blue(fg))
        c.drawText(title, x, base, titlePaint)
        c.drawText(artist, x + tw + gapPx, base, artistPaint)
    }

    // ---------------------------------------------------------------- گالری

    private fun gridTop(): Float = topInset + dp(78f)

    private fun gridMax(): Float {
        val rows = (albums.size + cols() - 1) / cols()
        val content = gridTop() + rows * (cellSize() + gap()) + dp(40f) + bottomInset
        return max(0f, content - height)
    }

    private fun drawGrid(c: Canvas, alpha: Float) {
        val cell = cellSize()
        val g = gap()
        val top = gridTop()
        val firstRow = ((gridScroll - top) / (cell + g)).toInt() - 2
        val lastRow = ((gridScroll + height - top) / (cell + g)).toInt() + 3
        val nc = cols()
        for (r in firstRow..lastRow) for (cc in 0 until nc) {
            val k = r * nc + cc
            if (k in 0 until albums.size) cover(albums[k])
        }
        val fromGrid = focusIndex >= 0 && focusFromGrid
        val epG = 1f - (1f - focusE) * (1f - focusE) * (1f - focusE)
        val fade = if (fromGrid) (1f - epG * 1.3f).coerceIn(0f, 1f) else 1f
        val layer = c.saveLayerAlpha(0f, 0f, width.toFloat(), height.toFloat(), (255f * alpha * fade).toInt())
        for (i in 0 until albums.size) {
            if (fromGrid && i == focusIndex) continue
            val row = i / nc
            val col = i % nc
            val x = g + col * (cell + g)
            val y = top + row * (cell + g) - gridScroll
            if (y > height || y + cell < 0) continue
            rect.set(x, y, x + cell, y + cell)
            val bmp = cover(albums[i]) ?: placeholder(albums[i])
            c.save()
            path.reset()
            path.addRoundRect(rect, dp(8f), dp(8f), Path.Direction.CW)
            c.clipPath(path)
            paint.alpha = 255
            c.drawBitmap(bmp, null, rect, paint)
            c.restore()
        }
        c.restoreToCount(layer)
        if (fromGrid && !focusHold) drawFlyGrid(c, focusIndex, focusE)
    }

    /** باز شدن آلبوم از گرید: کاور از خونه‌ی خودش (مربع) به جای نهایی پرواز می‌کنه */
    private fun drawFlyGrid(c: Canvas, index: Int, e: Float) {
        if (index !in 0 until albums.size || e <= 0.001f) return
        val cell = cellSize()
        val g = gap()
        val nc = cols()
        val x = g + (index % nc) * (cell + g)
        val y = gridTop() + (index / nc) * (cell + g) - gridScroll
        q0[0] = x; q0[1] = y
        q0[2] = x + cell; q0[3] = y
        q0[4] = x + cell; q0[5] = y + cell
        q0[6] = x; q0[7] = y + cell
        q1[0] = finalRect.left; q1[1] = finalRect.top
        q1[2] = finalRect.right; q1[3] = finalRect.top
        q1[4] = finalRect.right; q1[5] = finalRect.bottom
        q1[6] = finalRect.left; q1[7] = finalRect.bottom
        val ep = 1f - (1f - e) * (1f - e) * (1f - e)
        val sw = sin(Math.PI * e).toFloat()
        var mx = 0f
        var my = 0f
        for (i in 0..3) {
            qq[i * 2] = q0[i * 2] + (q1[i * 2] - q0[i * 2]) * ep
            qq[i * 2 + 1] = q0[i * 2 + 1] + (q1[i * 2 + 1] - q0[i * 2 + 1]) * ep
            mx += qq[i * 2] / 4f
            my += qq[i * 2 + 1] / 4f
        }
        val ang = FLY_ROLL * sw
        val ca = cos(ang)
        val sa = sin(ang)
        val zoom = 1f + 0.05f * sw
        for (i in 0..3) {
            val dx = (qq[i * 2] - mx) * zoom
            val dy = (qq[i * 2 + 1] - my) * zoom
            qq[i * 2] = mx + dx * ca - dy * sa
            qq[i * 2 + 1] = my + dx * sa + dy * ca
        }
        for (k in 3 downTo 1) {
            path.reset()
            val off = dp(3.5f * k) * ep
            val grow = dp(1.5f * k) * ep
            path.moveTo(qq[0] - grow, qq[1] + off - grow)
            path.lineTo(qq[2] + grow, qq[3] + off - grow)
            path.lineTo(qq[4] + grow, qq[5] + off + grow)
            path.lineTo(qq[6] - grow, qq[7] + off + grow)
            path.close()
            fill.color = Color.argb((20f * ep).toInt().coerceIn(0, 255), 0, 0, 0)
            c.drawPath(path, fill)
        }
        drawQuad(c, focusBmp ?: bitmapFor(index), qq, 255)
    }

    // ---------------------------------------------------------------- لمس

    /** اندیس آیتم زیر نقطه‌ی لمس (یا -1) */
    private fun indexAt(x: Float, y: Float): Int {
        if (albums.isEmpty()) return -1
        if (!gridMode) {
            val vx = if (horiz) y else x
            val vy = if (horiz) x else y
            var i = hitCount - 1
            while (i >= 0) {
                if (vy >= hitTop[i] && vy <= hitBottom[i] && abs(vx - cx) <= cardW * 0.56f) return hitIdx[i]
                i--
            }
            return -1
        }
        val cell = cellSize()
        val g = gap()
        val col = ((x - g) / (cell + g)).toInt()
        val row = ((y - gridTop() + gridScroll) / (cell + g)).toInt()
        if (col in 0 until cols() && y >= gridTop() - g) {
            val idx = row * cols() + col
            if (idx in 0 until albums.size) return idx
        }
        return -1
    }

    /** محور اسکرول: افقی تو لندسکیپ (پشته)، عمودی بقیه */
    private fun axisOf(e: MotionEvent): Float = if (horiz && !gridMode) e.x else e.y

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (albums.isEmpty() || focusIndex >= 0) return true
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                touching = true
                moved = false
                longFired = false
                downX = e.x
                downY = axisOf(e)
                lastY = axisOf(e)
                vel = 0f
                gridVel = 0f
                velocity?.recycle()
                velocity = VelocityTracker.obtain()
                velocity?.addMovement(e)
                parent?.requestDisallowInterceptTouchEvent(true)
                postDelayed(longRunnable, 450L)
            }
            MotionEvent.ACTION_MOVE -> {
                velocity?.addMovement(e)
                if (!moved && abs(axisOf(e) - downY) > slop) {
                    moved = true
                    removeCallbacks(longRunnable)
                }
                if (moved) {
                    val dy = axisOf(e) - lastY
                    if (!gridMode) {
                        pos = (pos - dy / spacing()).coerceIn(minPos - 0.5f, maxPos + 0.5f)
                    } else {
                        gridScroll = (gridScroll - dy).coerceIn(0f, gridMax())
                    }
                    invalidate()
                }
                lastY = axisOf(e)
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                removeCallbacks(longRunnable)
                velocity?.addMovement(e)
                touching = false
                if (e.actionMasked == MotionEvent.ACTION_UP && !moved && !longFired) {
                    tap(e.x, e.y)
                } else if (moved) {
                    velocity?.computeCurrentVelocity(1000)
                    val vy = (if (horiz && !gridMode) velocity?.xVelocity else velocity?.yVelocity) ?: 0f
                    if (!gridMode) {
                        vel = (-vy / spacing()).coerceIn(-16f, 16f)
                        if (pos < minPos || pos > maxPos) {
                            pos = pos.coerceIn(minPos, maxPos)
                            vel = 0f
                        }
                    } else {
                        gridVel = -vy
                    }
                }
                velocity?.recycle()
                velocity = null
                invalidate()
            }
        }
        return true
    }

    private fun tap(x: Float, y: Float) {
        val idx = indexAt(x, y)
        if (idx < 0) return
        // هم تو پشته و هم تو گرید: باز کردن صفحه‌ی آلبوم (تو گرید انیمیشن از خود خونه شروع میشه)
        listener?.onAlbumTap(albums[idx], idx)
    }

    companion object {
        private const val ROWS = 12
        private const val STRIP = 0.043f
        private const val FLY_N = 8
        private const val FLY_ROLL = 0.35f       // چرخش کاور وسط پرواز (رادیان)
        private const val LEAN_REF_W = 884f     // عرض کارت در عکس مرجع MD
        private val LEAN_X = floatArrayOf(0f, 150f, 300f, 400f, 540f, 630f, 780f, 880f, 1020f, 4000f)
        // کجیِ هر طرف عطف (پیکسل) به فاصله‌ی لبه‌ی کارت از افق؛ اندازه‌گیری از اسکرین‌شات MD
        private val LEAN_DOWN = floatArrayOf(0f, 2f, 4f, 6f, 9f, 11f, 10.8f, 10.5f, 10f, 10f)
        private val LEAN_UP = floatArrayOf(0f, 3f, 6.5f, 6.6f, 6.7f, 6.7f, 6.7f, 7.5f, 8f, 8f)
        private const val REF_W = 818f          // عرض عطف در ویدیوی مرجع (پیکسل)
        private const val ZETA = 0.89f           // قدرت پرسپکتیو (عرض ورق نسبت به فاصله‌ی دوربین)
        private const val TILT_FULL = 0.38f      // زاویه‌ای که نور و تیرگی کامل میشه (رادیان)
        private val TILT_X = floatArrayOf(0f, 200f, 423f, 650f, 865f, 1200f, 4000f)
        private val TILT_DEG = floatArrayOf(0f, 2.7f, 6.1f, 12.4f, 19.5f, 31f, 40f)
    }
}
