package com.example.mediawidget

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.Switch
import android.widget.TextView
import android.content.res.ColorStateList
import android.graphics.Color

/** صفحه‌ی تنظیمات: ظاهر تیره و فول‌اسکرین (فقط گزینه‌های خود اپ) */
class MainActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        DarkUi.guard(this) { build() }
    }

    private fun build() {
        val screen = DarkUi.Screen(this, "Settings")
        val prefs = getSharedPreferences("ui", MODE_PRIVATE)

        screen.body.addView(DarkUi.sectionLabel(this, "General"))
        val general = DarkUi.card(this)
        DarkUi.addRow(general, "Permissions", null, DarkUi.glyph(this, GlyphView.CHEVRON, 28f)) {
            startActivity(Intent(this, PermissionsActivity::class.java))
        }
        DarkUi.addRow(general, "Library folders", null, DarkUi.glyph(this, GlyphView.CHEVRON, 28f)) {
            startActivity(Intent(this, TilesActivity::class.java))
        }

        screen.body.addView(general)

        screen.body.addView(DarkUi.sectionLabel(this, "Music library"))
        val lib = DarkUi.card(this)
        val modeText = TextView(this)
        modeText.text = if (LibraryPrefs.mode(this) == LibraryPrefs.FOLDERS) "Folders" else "Albums"
        modeText.setTextColor(DarkUi.LABEL)
        modeText.textSize = 17f
        modeText.typeface = DarkUi.font(this)
        DarkUi.addRow(lib, "Show music by", "Group the 3D view by albums or folders", modeText) {
            val items = arrayOf("Albums", "Folders")
            AlertDialog.Builder(this)
                .setTitle("Show music by")
                .setSingleChoiceItems(items, LibraryPrefs.mode(this)) { dlg, which ->
                    LibraryPrefs.setMode(this, which)
                    modeText.text = items[which]
                    dlg.dismiss()
                }
                .show()
        }
        DarkUi.addRow(lib, "Hidden items", "Choose albums or folders to hide", DarkUi.glyph(this, GlyphView.CHEVRON, 28f)) {
            startActivity(Intent(this, HiddenActivity::class.java))
        }
        screen.body.addView(lib)
        screen.body.addView(DarkUi.sectionLabel(this, "Display"))
        val display = DarkUi.card(this)
        val sw = Switch(this)
        sw.isChecked = !prefs.getBoolean("hide_text", false)
        sw.thumbTintList = ColorStateList.valueOf(Color.WHITE)
        sw.trackTintList = ColorStateList(
            arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()),
            intArrayOf(DarkUi.PURPLE, Color.rgb(85, 86, 98))
        )
        sw.setOnCheckedChangeListener { _, on -> prefs.edit().putBoolean("hide_text", !on).apply() }
        DarkUi.addRow(display, "Song title and artist", "Show them under the vinyl", sw) { sw.toggle() }
        screen.body.addView(display)

        val spacer = View(this)
        screen.body.addView(spacer, LinearLayout.LayoutParams(1, 0, 1f))
        val foot = TextView(this)
        foot.text = "Media Widget"
        foot.setTextColor(DarkUi.LABEL)
        foot.textSize = 15f
        foot.typeface = DarkUi.font(this)
        foot.gravity = Gravity.CENTER
        foot.setPadding(0, DarkUi.dp(this, 36f), 0, 0)
        screen.body.addView(foot)

        screen.show()
    }
}
