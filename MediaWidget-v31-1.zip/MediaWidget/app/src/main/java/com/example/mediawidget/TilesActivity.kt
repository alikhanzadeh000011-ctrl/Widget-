package com.example.mediawidget

import android.app.Activity
import android.content.Intent
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Outline
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewOutlineProvider
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.util.concurrent.Executors

/** صفحه‌ی انتخاب ۵ پوشه‌ی آلبوم برای ویجت Library */
class TilesActivity : Activity() {

    private val executor = Executors.newSingleThreadExecutor()
    private val handler = Handler(Looper.getMainLooper())
    private val thumbs = arrayOfNulls<ImageView>(TileStore.COUNT)
    private val labels = arrayOfNulls<TextView>(TileStore.COUNT)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        DarkUi.guard(this) { build() }
    }

    private fun build() {
        val screen = DarkUi.Screen(this, "Library folders")
        val body = screen.body

        val hint = TextView(this)
        hint.text = "Choose up to 5 album folders. The cover of the first song in each folder " +
            "(or cover.jpg / folder.jpg) is shown on the Library widget. " +
            "Tapping a cover opens your music player."
        hint.setTextColor(DarkUi.LABEL)
        hint.textSize = 16f
        hint.typeface = DarkUi.font(this)
        hint.setLineSpacing(0f, 1.2f)
        hint.setPadding(DarkUi.dp(this, 30f), DarkUi.dp(this, 8f), DarkUi.dp(this, 30f), DarkUi.dp(this, 14f))
        body.addView(hint)

        val card = DarkUi.card(this)
        for (i in 0 until TileStore.COUNT) {
            if (i > 0) {
                val line = View(this)
                line.setBackgroundColor(DarkUi.CARD_LINE)
                card.addView(line, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, DarkUi.dp(this, 1f)))
            }
            card.addView(buildRow(i))
        }
        body.addView(card)

        val refresh = DarkUi.pill(this, "Refresh all covers") { refreshAll() }
        val rlp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        rlp.gravity = Gravity.CENTER_HORIZONTAL
        rlp.topMargin = DarkUi.dp(this, 26f)
        body.addView(refresh, rlp)

        screen.show()
        updateRows()
    }

    private fun buildRow(i: Int): View {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(DarkUi.dp(this, 18f), DarkUi.dp(this, 16f), DarkUi.dp(this, 18f), DarkUi.dp(this, 16f))

        val size = DarkUi.dp(this, 68f)
        val thumb = ImageView(this)
        thumb.scaleType = ImageView.ScaleType.CENTER_CROP
        thumb.setBackgroundColor(Color.rgb(58, 59, 70))
        thumb.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, DarkUi.dp(this@TilesActivity, 14f).toFloat())
            }
        }
        thumb.clipToOutline = true
        thumbs[i] = thumb
        row.addView(thumb, LinearLayout.LayoutParams(size, size))

        val column = LinearLayout(this)
        column.orientation = LinearLayout.VERTICAL
        column.setPadding(DarkUi.dp(this, 16f), 0, 0, 0)

        val label = TextView(this)
        label.setTextColor(Color.WHITE)
        label.textSize = 17f
        label.typeface = DarkUi.font(this)
        labels[i] = label
        column.addView(label)

        val buttons = LinearLayout(this)
        buttons.orientation = LinearLayout.HORIZONTAL
        buttons.setPadding(0, DarkUi.dp(this, 10f), 0, 0)
        val choose = DarkUi.pillSmall(this, "Choose folder") { pickFolder(i) }
        val clear = DarkUi.pillSmall(this, "Clear") {
            TileStore.clear(this@TilesActivity, i)
            updateRows()
            WidgetRenderer.updateAll(this@TilesActivity)
        }
        buttons.addView(choose)
        val clp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        clp.marginStart = DarkUi.dp(this, 10f)
        buttons.addView(clear, clp)
        column.addView(buttons)

        row.addView(column, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        return row
    }

    private fun pickFolder(slot: Int) {
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT_TREE), REQ_BASE + slot)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val slot = requestCode - REQ_BASE
        if (resultCode != RESULT_OK || slot < 0 || slot >= TileStore.COUNT) return
        val uri = data?.data ?: return
        try {
            contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (e: Exception) {
            // بعضی دستگاه‌ها اجازه‌ی دائمی نمیدن؛ همین الان کافیه
        }
        TileStore.setFolder(this, slot, uri)
        labels[slot]?.text = "Slot ${slot + 1}: reading..."
        executor.execute {
            val ok = TileStore.loadCover(this, slot)
            handler.post {
                updateRows()
                WidgetRenderer.updateAll(this)
                if (!ok) {
                    Toast.makeText(this, "No cover found in this folder", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun refreshAll() {
        Toast.makeText(this, "Refreshing...", Toast.LENGTH_SHORT).show()
        executor.execute {
            for (i in 0 until TileStore.COUNT) {
                if (TileStore.folderUri(this, i) != null) TileStore.loadCover(this, i)
            }
            handler.post {
                updateRows()
                WidgetRenderer.updateAll(this)
            }
        }
    }

    private fun updateRows() {
        for (i in 0 until TileStore.COUNT) {
            val name = TileStore.folderName(this, i)
            val f = TileStore.file(this, i)
            val text = when {
                name == null -> "Slot ${i + 1}: empty"
                f.exists() -> "Slot ${i + 1}: $name"
                else -> "Slot ${i + 1}: $name (no cover found)"
            }
            labels[i]?.text = text
            val img = thumbs[i]
            if (f.exists()) {
                img?.setImageBitmap(BitmapFactory.decodeFile(f.absolutePath))
            } else {
                img?.setImageDrawable(null)
            }
        }
    }

    companion object {
        private const val REQ_BASE = 4100
    }
}
