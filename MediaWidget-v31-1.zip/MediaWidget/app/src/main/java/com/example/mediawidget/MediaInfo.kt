package com.example.mediawidget

import android.app.PendingIntent
import android.content.ComponentName
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.net.Uri
import android.os.SystemClock

/** اطلاعات آهنگی که الان پخش میشه (از هر پلیری) */
data class MediaInfo(
    val hasAccess: Boolean = true,
    val hasMedia: Boolean = false,
    val title: String = "",
    val artist: String = "",
    val art: Bitmap? = null,
    val playing: Boolean = false,
    val openIntent: PendingIntent? = null,
    val pkg: String = "",
    val album: String = "",
    val durationMs: Long = 0L,
    val positionMs: Long = 0L,
    val readAt: Long = 0L
) {
    /** با عوض شدن آهنگ این کلید عوض میشه (برای کش بلر و رنگ‌ها) */
    val key: String
        get() {
            val a = art
            val sample = if (a != null) a.getPixel(a.width / 3, a.height / 3) else 0
            return "$title|$artist|${a?.width}x${a?.height}|$sample"
        }
}

class Playback(val playing: Boolean, val positionMs: Long, val durationMs: Long)

object MediaReader {

    fun controllers(ctx: Context): List<MediaController>? {
        return try {
            val msm = ctx.getSystemService(MediaSessionManager::class.java)
            msm.getActiveSessions(ComponentName(ctx, MediaListenerService::class.java))
        } catch (e: SecurityException) {
            null
        }
    }

    fun pick(list: List<MediaController>): MediaController? =
        list.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING }
            ?: list.firstOrNull { it.metadata != null }

    fun read(ctx: Context): MediaInfo {
        val list = controllers(ctx) ?: return MediaInfo(hasAccess = false)
        val c = pick(list) ?: return MediaInfo()
        val md = c.metadata
        val raw = md?.getBitmap(MediaMetadata.METADATA_KEY_ART)
            ?: md?.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
            ?: loadUri(ctx, md?.getString(MediaMetadata.METADATA_KEY_ART_URI))
            ?: loadUri(ctx, md?.getString(MediaMetadata.METADATA_KEY_ALBUM_ART_URI))
        val art = raw?.copy(Bitmap.Config.ARGB_8888, false)
        val duration = md?.getLong(MediaMetadata.METADATA_KEY_DURATION) ?: 0L
        val now = SystemClock.elapsedRealtime()
        return MediaInfo(
            hasMedia = md != null,
            title = md?.getString(MediaMetadata.METADATA_KEY_TITLE).orEmpty(),
            artist = (md?.getString(MediaMetadata.METADATA_KEY_ARTIST)
                ?: md?.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST)).orEmpty(),
            art = art,
            playing = c.playbackState?.state == PlaybackState.STATE_PLAYING,
            openIntent = c.sessionActivity,
            pkg = c.packageName,
            album = md?.getString(MediaMetadata.METADATA_KEY_ALBUM).orEmpty(),
            durationMs = duration,
            positionMs = positionOf(c.playbackState, now, duration),
            readAt = now
        )
    }

    /** فقط وضعیت پخش (سبک، بدون خوندن کاور) برای آپدیت نوار پیشرفت */
    fun playback(ctx: Context): Playback? {
        val list = controllers(ctx) ?: return null
        val c = pick(list) ?: return null
        val duration = c.metadata?.getLong(MediaMetadata.METADATA_KEY_DURATION) ?: 0L
        val st = c.playbackState
        return Playback(
            st?.state == PlaybackState.STATE_PLAYING,
            positionOf(st, SystemClock.elapsedRealtime(), duration),
            duration
        )
    }

    /** موقعیت فعلی آهنگ (میلی‌ثانیه) */
    fun positionOf(st: PlaybackState?, now: Long, duration: Long): Long {
        if (st == null) return 0L
        var p = st.position
        if (st.state == PlaybackState.STATE_PLAYING && st.lastPositionUpdateTime > 0) {
            val speed = if (st.playbackSpeed > 0f) st.playbackSpeed else 1f
            p += ((now - st.lastPositionUpdateTime) * speed).toLong()
        }
        if (p < 0L) p = 0L
        if (duration > 0L && p > duration) p = duration
        return p
    }

    private fun loadUri(ctx: Context, uri: String?): Bitmap? {
        if (uri.isNullOrEmpty()) return null
        val u = Uri.parse(uri)
        if (u.scheme != "content" && u.scheme != "file") return null
        return try {
            ctx.contentResolver.openInputStream(u)?.use { BitmapFactory.decodeStream(it) }
        } catch (e: Exception) {
            null
        }
    }
}
