package com.example.mediawidget

import android.app.Application
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter

/** اگه اپ کرش کنه، متن خطا ذخیره میشه و دفعه‌ی بعد که اپ بالا اومد نشون داده میشه */
class App : Application() {
    override fun onCreate() {
        super.onCreate()
        val prev = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            try {
                val sw = StringWriter()
                e.printStackTrace(PrintWriter(sw))
                File(filesDir, "last_crash.txt").writeText(sw.toString().take(6000))
            } catch (x: Throwable) {
                // نادیده
            }
            prev?.uncaughtException(t, e)
        }
    }
}
