package com.example.mediawidget

import android.app.Activity
import android.os.Bundle
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import java.util.concurrent.Executors

/** انتخاب آلبوم‌ها و پوشه‌هایی که نباید نمایش داده بشن (سوییچ روشن = نمایش) */
class HiddenActivity : Activity() {

    private lateinit var screen: DarkUi.Screen

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        DarkUi.guard(this) {
            screen = DarkUi.Screen(this, "Hidden items")
            screen.show()
            loadAndBuild()
        }
    }

    private fun loadAndBuild() {
        val body = screen.body
        while (body.childCount > 1) body.removeViewAt(1)
        val loading = TextView(this)
        loading.text = "Loading..."
        loading.setTextColor(DarkUi.LABEL)
        loading.textSize = 17f
        loading.typeface = DarkUi.font(this)
        loading.setPadding(DarkUi.dp(this, 30f), DarkUi.dp(this, 24f), 0, 0)
        body.addView(loading)

        val app = applicationContext
        Executors.newSingleThreadExecutor().execute {
            val albums = try { AlbumRepo.load(app, LibraryPrefs.ALBUMS) } catch (e: Throwable) { emptyList() }
            val folders = try { AlbumRepo.load(app, LibraryPrefs.FOLDERS) } catch (e: Throwable) { emptyList() }
            runOnUiThread {
                if (isDestroyed) return@runOnUiThread
                DarkUi.guard(this) { fill(albums, folders) }
            }
        }
    }

    private fun fill(albums: List<Album>, folders: List<Album>) {
        val body = screen.body
        while (body.childCount > 1) body.removeViewAt(1)

        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        val showAll = DarkUi.pill(this, "Show all") {
            LibraryPrefs.clearHidden(this)
            loadAndBuild()
        }
        bar.addView(showAll)
        bar.setPadding(DarkUi.dp(this, 24f), DarkUi.dp(this, 6f), 0, DarkUi.dp(this, 4f))
        body.addView(bar)

        addSection("Albums", LibraryPrefs.ALBUMS, albums)
        addSection("Folders", LibraryPrefs.FOLDERS, folders)
    }

    private fun addSection(title: String, mode: Int, items: List<Album>) {
        val body = screen.body
        body.addView(DarkUi.sectionLabel(this, title + " (" + items.size + ")"))
        if (items.isEmpty()) {
            val t = TextView(this)
            t.text = "Nothing found"
            t.setTextColor(DarkUi.LABEL)
            t.textSize = 16f
            t.typeface = DarkUi.font(this)
            t.setPadding(DarkUi.dp(this, 30f), 0, 0, 0)
            body.addView(t)
            return
        }
        val hidden = LibraryPrefs.hidden(this, mode)
        val card = DarkUi.card(this)
        for (a in items) {
            val sw = DarkUi.styledSwitch(this, a.key !in hidden)
            sw.setOnCheckedChangeListener { _, visible -> LibraryPrefs.setHidden(this, mode, a.key, !visible) }
            DarkUi.addRow(card, a.title, a.extra, sw) { sw.toggle() }
        }
        body.addView(card)
        val spacer = View(this)
        body.addView(spacer, LinearLayout.LayoutParams(1, DarkUi.dp(this, 10f)))
    }
}
