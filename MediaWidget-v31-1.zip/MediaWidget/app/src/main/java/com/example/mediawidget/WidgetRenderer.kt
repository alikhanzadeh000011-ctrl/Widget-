package com.example.mediawidget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.os.Build
import android.provider.Settings
import android.text.format.DateUtils
import android.view.View
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.RemoteViews
import java.util.concurrent.Executors

/** انواع ویجت‌ها. defW/defH ابعاد پیش‌فرض (dp) وقتی لانچر اندازه نمیده */
enum class Kind(val provider: Class<*>, val defW: Int, val defH: Int) {
    FULL(Widget2x2Provider::class.java, 160, 170),
    MINI(Widget2x2MiniProvider::class.java, 160, 170),
    PILL(Widget2x1Provider::class.java, 160, 72),
    WIDE(Widget4x2Provider::class.java, 340, 170),
    LIB(WidgetLibProvider::class.java, 340, 180),
    VDISC(WidgetVDiscProvider::class.java, 160, 185),
    VHALF(WidgetVHalfProvider::class.java, 160, 185),
    VCTRL(WidgetVCtrlProvider::class.java, 160, 185),
    VWIDE(WidgetVWideProvider::class.java, 340, 170),
    VBIG(WidgetVBigProvider::class.java, 340, 340);

    val vinyl: Boolean get() = this == VDISC || this == VHALF || this == VCTRL || this == VWIDE || this == VBIG
}

object WidgetRenderer {

    // گردی گوشه‌ها: از روی ویجت هوای سامسونگ (عکس ۳) اندازه گرفته شده
    // برای ویجت‌های ۲×۲ نسبت به عرض، برای ۴×۲ مقدار ثابت (dp) تا هم‌اندازه‌ی بقیه باشه
    private const val CORNER_RATIO = 0.176f
    private const val CORNER_DP = 28.16f

    /**
     * ضریب کوچک‌کردن تصویرها: تا جایی که حافظه‌ی مجاز RemoteViews (حدود ۱.۵ برابر اندازه‌ی صفحه) اجازه میده
     * کیفیت کامل (۱.۰) نگه داشته میشه. bytesPerPx = مجموع بایت تصویرهای هم‌اندازه‌ی ویجت به‌ازای هر پیکسل
     */
    fun fitScale(ctx: Context, w: Float, h: Float, bytesPerPx: Float): Float {
        val dm = ctx.resources.displayMetrics
        val budget = dm.widthPixels.toFloat() * dm.heightPixels.toFloat() * 4f * 0.85f
        val need = w * h * bytesPerPx
        return if (need <= budget) 1f else Math.sqrt((budget / need).toDouble()).toFloat()
    }

    /**
     * پس‌زمینه‌ی نرمِ ویجت‌های وینیل (بلر کاور) برای ویجت‌های Vibe، با کمی تیره‌کردن اضافه برای خوانایی متن.
     * بدون کاور: همون خاکستری تیره‌ی وینیل
     */
    private fun vinylStyleBackground(art: Bitmap?, w: Int, h: Int, radius: Float): Bitmap {
        val src = if (art != null) VinylArt.coverBackground(art, w, h) else VinylArt.greyBackground(w, h)
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        val rect = RectF(0f, 0f, w.toFloat(), h.toFloat())
        val clip = Path()
        clip.addRoundRect(rect, radius, radius, Path.Direction.CW)
        c.clipPath(clip)
        c.drawBitmap(src, null, rect, Paint(Paint.FILTER_BITMAP_FLAG))
        if (art != null) {
            val p = Paint()
            p.shader = LinearGradient(
                0f, 0f, 0f, h.toFloat(),
                Color.argb(30, 0, 0, 0), Color.argb(62, 0, 0, 0), Shader.TileMode.CLAMP
            )
            c.drawRect(rect, p)
        }
        return out
    }

    private const val PROGRESS_W = 720
    private const val PROGRESS_H = 20

    private val executor = Executors.newSingleThreadExecutor()

    // همه‌ی این‌ها فقط داخل executor استفاده میشن
    private var cacheKey: String? = null
    private var tint: Tint = Palette.neutral()
    private val bgCache = HashMap<String, Bitmap>()
    private val coverCache = HashMap<String, Bitmap>()
    private val tileCache = HashMap<String, Bitmap>()
    private var solid: Int = Color.parseColor("#3A4658")
    private val tileIds = intArrayOf(R.id.t0, R.id.t1, R.id.t2, R.id.t3, R.id.t4)

    fun updateAll(context: Context) {
        val app = context.applicationContext
        executor.execute {
            try {
                renderAll(app)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    /** آپدیت سبک: فقط نوار پیشرفت ویجت ۴×۲ (وقتی آهنگ پخش میشه) */
    fun tickProgress(context: Context) {
        val app = context.applicationContext
        executor.execute {
            try {
                val mgr = AppWidgetManager.getInstance(app)
                val ids = mgr.getAppWidgetIds(ComponentName(app, Kind.WIDE.provider))
                if (ids.isEmpty()) return@execute
                val pb = MediaReader.playback(app) ?: return@execute
                if (!pb.playing || pb.durationMs <= 0L) return@execute
                val frac = (pb.positionMs.toFloat() / pb.durationMs).coerceIn(0f, 1f)
                val rv = RemoteViews(app.packageName, R.layout.widget_4x2)
                rv.setImageViewBitmap(R.id.progress, Shapes.progress(PROGRESS_W, PROGRESS_H, frac, tint.primary))
                mgr.partiallyUpdateAppWidget(ids, rv)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    /** رنگ‌ها و کش‌ها رو برای آهنگ فعلی آماده می‌کنه (فقط داخل executor) */
    private fun prepare(info: MediaInfo) {
        if (info.key != cacheKey) {
            bgCache.clear()
            coverCache.clear()
            tint = Palette.tintFor(info.art)
            solid = Palette.solidFor(info.art)
            cacheKey = info.key
        }
    }

    /** پیش‌نمایش ویجت برای صفحه‌ی ویجت‌ها (با اندازه‌ی پیش‌فرض)؛ جواب روی ترد اصلی میاد */
    fun preview(context: Context, kind: Kind, onReady: (RemoteViews) -> Unit) {
        val app = context.applicationContext
        executor.execute {
            try {
                val info = MediaReader.read(app)
                prepare(info)
                val rv = build(app, null, -1, kind, info)
                Handler(Looper.getMainLooper()).post { onReady(rv) }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    private fun renderAll(ctx: Context) {
        val mgr = AppWidgetManager.getInstance(ctx)
        val jobs = ArrayList<Pair<Kind, IntArray>>()
        for (k in Kind.values()) {
            val ids = mgr.getAppWidgetIds(ComponentName(ctx, k.provider))
            if (ids.isNotEmpty()) jobs.add(Pair(k, ids))
        }
        if (jobs.isEmpty()) return

        val info = MediaReader.read(ctx)
        prepare(info)
        if (info.pkg.isNotEmpty() && info.pkg != AppPrefs.lastPlayer(ctx)) {
            AppPrefs.setLastPlayer(ctx, info.pkg)
        }
        for ((kind, ids) in jobs) {
            for (id in ids) {
                mgr.updateAppWidget(id, build(ctx, mgr, id, kind, info))
            }
        }
    }

    private fun build(ctx: Context, mgr: AppWidgetManager?, id: Int, kind: Kind, info: MediaInfo): RemoteViews {
        if (kind.vinyl) return VinylWidgets.build(ctx, mgr, id, kind, info, tint)
        val layout = when (kind) {
            Kind.FULL -> R.layout.widget_2x2
            Kind.MINI -> R.layout.widget_2x2_mini
            Kind.PILL -> R.layout.widget_2x1
            Kind.WIDE -> R.layout.widget_4x2
            else -> R.layout.widget_lib
        }
        val rv = RemoteViews(ctx.packageName, layout)
        val d = ctx.resources.displayMetrics.density

        // اندازه‌ی ویجت (برای ساخت بلر هم‌اندازه)
        val opts = if (mgr != null) mgr.getAppWidgetOptions(id) else Bundle()
        var wDp = opts.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 0)
        var hDp = opts.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT, 0)
        if (wDp < 50) wDp = kind.defW
        if (hDp < 40) hDp = kind.defH
        wDp = wDp.coerceAtMost(700)
        hDp = hDp.coerceAtMost(500)

        val w = wDp * d
        val h = hDp * d
        val s = fitScale(ctx, w, h, 9f)
        val bw = (w * s).toInt().coerceAtLeast(2)
        val bh = (h * s).toInt().coerceAtLeast(2)
        val radius = when (kind) {
            Kind.PILL -> bh / 2f
            Kind.WIDE, Kind.LIB -> CORNER_DP * d * s
            else -> bw * CORNER_RATIO
        }

        val coverDp = when (kind) {
            Kind.FULL -> 73f
            Kind.MINI -> 100f
            Kind.PILL -> 54f
            Kind.WIDE -> 70f
            else -> 90f
        }
        val coverPx = (coverDp * d * 2f).toInt().coerceIn(120, 640)
        val coverFrac = when (kind) {
            Kind.PILL -> 0.5f
            Kind.LIB -> 0.13f
            else -> 0.15f
        }
        val topAlpha = when (kind) {
            Kind.PILL -> 105
            Kind.WIDE -> 80
            else -> 70
        }
        val bottomAlpha = when (kind) {
            Kind.PILL -> 135
            Kind.WIDE -> 150
            else -> 175
        }

        val art = info.art
        if (art != null) {
            val bg = bgCache.getOrPut("${kind.name}|$bw|$bh") {
                if (kind == Kind.LIB) {
                    Shapes.solidBackground(bw, bh, radius, solid, (1f - 64f / hDp).coerceIn(0.5f, 0.85f))
                } else {
                    vinylStyleBackground(art, bw, bh, radius)
                }
            }
            val cv = coverCache.getOrPut(kind.name) {
                Shapes.cover(art, coverPx, coverFrac)
            }
            rv.setImageViewBitmap(R.id.bg, bg)
            rv.setImageViewBitmap(R.id.cover, cv)
        } else {
            val bg = bgCache.getOrPut("def|${kind.name}|$bw|$bh") {
                if (kind == Kind.LIB) Shapes.defaultBackground(bw, bh, radius)
                else vinylStyleBackground(null, bw, bh, radius)
            }
            rv.setImageViewBitmap(R.id.bg, bg)
            rv.setImageViewResource(R.id.cover, R.drawable.cover_placeholder)
        }

        // متن‌ها (رنگشون از کاور میاد)
        val title = when {
            !info.hasAccess -> "Tap to allow access"
            !info.hasMedia -> "Not playing"
            info.title.isEmpty() -> "Unknown"
            else -> info.title
        }
        rv.setTextViewText(R.id.title, title)
        rv.setTextViewText(R.id.artist, info.artist)
        rv.setTextColor(R.id.title, tint.primary)
        rv.setTextColor(R.id.artist, tint.secondary)

        // لمس هر جای ویجت → باز شدن پلیری که الان وصله
        val openApp = if (!info.hasAccess) {
            activity(ctx, Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS), 1)
        } else {
            info.openIntent ?: launchPlayer(ctx, info.pkg)
        }
        rv.setOnClickPendingIntent(android.R.id.background, openApp)
        rv.setOnClickPendingIntent(R.id.cover, openApp)
        rv.setOnClickPendingIntent(R.id.title, openApp)
        rv.setOnClickPendingIntent(R.id.artist, openApp)

        if (kind == Kind.FULL) {
            rv.setImageViewResource(R.id.btn_icon, if (info.playing) R.drawable.ic_pause else R.drawable.ic_play)
            rv.setTextViewText(R.id.btn_text, if (info.playing) "Pause" else "Play")
            rv.setTextColor(R.id.btn_text, tint.primary)
            rv.setInt(R.id.btn_icon, "setColorFilter", tint.primary)
            rv.setInt(R.id.cast, "setColorFilter", tint.primary)
            rv.setInt(R.id.output, "setColorFilter", tint.primary)

            val toggle = PendingIntent.getBroadcast(
                ctx, 3,
                Intent(ctx, Widget2x2Provider::class.java).setAction(BaseWidgetProvider.ACTION_TOGGLE),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            rv.setOnClickPendingIntent(R.id.btn_play, toggle)
            rv.setOnClickPendingIntent(R.id.cast, activity(ctx, volumeIntent(), 4))
            rv.setOnClickPendingIntent(R.id.output, activity(ctx, Intent(Settings.ACTION_BLUETOOTH_SETTINGS), 5))
        }

        if (kind == Kind.WIDE) {
            bindWide(ctx, rv, info, openApp)
        }
        if (kind == Kind.LIB) {
            bindLib(ctx, rv, d)
        }
        return rv
    }

    /** ویجت Library: لوگوی اسپاتیفای + ۵ کاشی‌ی آلبوم (لمس → باز شدن پلیر) */
    private fun bindLib(ctx: Context, rv: RemoteViews, d: Float) {
        rv.setInt(R.id.logo, "setColorFilter", tint.primary)
        val library = libraryIntent(ctx)
        val tilePx = (55f * d * 1.6f).toInt().coerceIn(96, 256)
        if (tileCache.size > 12) tileCache.clear()
        for (i in 0 until TileStore.COUNT) {
            val f = TileStore.file(ctx, i)
            var bmp: Bitmap? = null
            if (f.exists()) {
                val key = "$i|${f.lastModified()}|$tilePx"
                bmp = tileCache[key]
                if (bmp == null) {
                    val raw = BitmapFactory.decodeFile(f.absolutePath)
                    if (raw != null) {
                        val made = Shapes.cover(raw, tilePx, 0.18f)
                        tileCache[key] = made
                        bmp = made
                    }
                }
            }
            val shown = bmp
            if (shown != null) {
                rv.setImageViewBitmap(tileIds[i], shown)
            } else {
                rv.setImageViewResource(tileIds[i], R.drawable.tile_placeholder)
            }
            rv.setOnClickPendingIntent(tileIds[i], library)
        }
    }

    /** باز کردن خود پلیر (آخرین پلیری که آهنگ پخش کرده؛ اگه نبود، پلیر موزیک پیش‌فرض سیستم) */
    private fun libraryIntent(ctx: Context): PendingIntent {
        val pm = ctx.packageManager
        val pkg = AppPrefs.lastPlayer(ctx)
        val intent: Intent = (if (pkg.isNotEmpty()) pm.getLaunchIntentForPackage(pkg) else null)
            ?: Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_MUSIC)
        return activity(ctx, intent, 9)
    }

    /** بخش‌های مخصوص ویجت ۴×۲: آلبوم، زمان، نوار پیشرفت و دکمه‌ها */
    private fun bindWide(ctx: Context, rv: RemoteViews, info: MediaInfo, openApp: PendingIntent) {
        rv.setTextViewText(R.id.album, info.album)
        rv.setTextColor(R.id.album, tint.secondary)

        for (vid in intArrayOf(R.id.wave, R.id.star, R.id.prev, R.id.play, R.id.next, R.id.cast)) {
            rv.setInt(vid, "setColorFilter", tint.primary)
        }
        rv.setImageViewResource(R.id.play, if (info.playing) R.drawable.ic_pause else R.drawable.ic_play)

        // زمان: وقتی پخش میشه Chronometer خودش هر ثانیه می‌شمره؛ وقتی متوقفه متن ثابت
        val dur = info.durationMs
        val pos = if (dur > 0L) info.positionMs.coerceIn(0L, dur) else info.positionMs
        rv.setTextViewText(R.id.time_total, if (dur > 0L) DateUtils.formatElapsedTime(dur / 1000L) else "--:--")
        for (vid in intArrayOf(R.id.time_run, R.id.time_now, R.id.time_total)) {
            rv.setTextColor(vid, tint.primary)
        }
        rv.setChronometer(R.id.time_run, info.readAt - pos, null, info.playing)
        if (info.playing) {
            rv.setViewVisibility(R.id.time_run, View.VISIBLE)
            rv.setViewVisibility(R.id.time_now, View.GONE)
        } else {
            rv.setViewVisibility(R.id.time_run, View.GONE)
            rv.setViewVisibility(R.id.time_now, View.VISIBLE)
            rv.setTextViewText(R.id.time_now, DateUtils.formatElapsedTime(pos / 1000L))
        }

        val frac = if (dur > 0L) pos.toFloat() / dur else 0f
        rv.setImageViewBitmap(R.id.progress, Shapes.progress(PROGRESS_W, PROGRESS_H, frac, tint.primary))

        // دکمه‌ها
        rv.setOnClickPendingIntent(R.id.star, openApp)
        rv.setOnClickPendingIntent(R.id.prev, wideAction(ctx, BaseWidgetProvider.ACTION_PREV, 6))
        rv.setOnClickPendingIntent(R.id.play, wideAction(ctx, BaseWidgetProvider.ACTION_TOGGLE, 7))
        rv.setOnClickPendingIntent(R.id.next, wideAction(ctx, BaseWidgetProvider.ACTION_NEXT, 8))
        rv.setOnClickPendingIntent(R.id.cast, activity(ctx, volumeIntent(), 4))
    }

    internal fun wideAction(ctx: Context, action: String, code: Int): PendingIntent =
        PendingIntent.getBroadcast(
            ctx, code,
            Intent(ctx, Widget4x2Provider::class.java).setAction(action),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

    private fun volumeIntent(): Intent =
        if (Build.VERSION.SDK_INT >= 29) Intent(Settings.Panel.ACTION_VOLUME)
        else Intent(Settings.ACTION_SOUND_SETTINGS)

    internal fun launchPlayer(ctx: Context, pkg: String): PendingIntent {
        val pm = ctx.packageManager
        val intent = (if (pkg.isNotEmpty()) pm.getLaunchIntentForPackage(pkg) else null)
            ?: pm.getLaunchIntentForPackage(ctx.packageName)
            ?: Intent(Settings.ACTION_SOUND_SETTINGS)
        return activity(ctx, intent, 2)
    }

    internal fun activity(ctx: Context, intent: Intent, code: Int): PendingIntent =
        PendingIntent.getActivity(
            ctx, code, intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
}
