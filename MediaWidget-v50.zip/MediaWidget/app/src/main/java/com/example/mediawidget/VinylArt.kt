package com.example.mediawidget

import android.graphics.Bitmap
import android.graphics.BitmapShader
import android.graphics.Matrix
import android.graphics.BlurMaskFilter
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.CornerPathEffect
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * رسم قطعه‌های ثابت صفحه‌ی وینیل (با کد، بدون هیچ فایل تصویر).
 * همه‌ی مختصات روی بوم مرجع ۱۰۸۰×۲۳۴۰ هستن و با ضریب s به اندازه‌ی صفحه‌ی گوشی تبدیل میشن.
 * اندازه‌ها، رنگ‌ها و پروفایل نور دیسک از روی تصویرهای مرجع (دیسک، بازو، پایه) اندازه‌گیری شده.
 */
object VinylArt {

    const val REF_W = 1080f
    const val REF_H = 2340f

    // دیسک و برچسب (کاور)
    const val CX = 296f
    const val CY = 842.5f
    const val R = 654f
    const val LR = 294.5f

    // محور چرخش بازو و زاویه‌ها (درجه، ساعت‌گرد مثبت)
    const val PX = 875f
    const val PY = 338f
    const val ARM_REST = 0f
    const val ARM_OUTER = 14.3f
    const val ARM_INNER = 33.2f

    // محدوده‌ی بیت‌مپ بازو نسبت به محور
    const val ARM_OX = 100f
    const val ARM_OY = 150f
    const val ARM_W = 300f
    const val ARM_H = 1250f

    // نسبت اندازه‌ی تصویر مرجع بازو/پایه به بوم ما
    const val K = 0.722f

    // دکمه‌ها
    const val BTN_W = 206f
    const val BTN_H = 105f
    const val BTN_PAD = 30f

    /** مرز «جیب» پایه‌ی بازو (مختصات تصویر مرجع) */
    val POCKET = floatArrayOf(
        196f, 20f, 167f, 24f, 133f, 35f, 98f, 55f, 66f, 84f, 44f, 115f, 31f, 143f, 22f, 178f,
        20f, 220f, 24f, 245f, 85f, 315f, 131f, 379f, 172f, 392f, 218f, 395f, 252f, 390f,
        282f, 380f, 317f, 360f, 349f, 331f, 368f, 305f, 385f, 269f, 394f, 230f, 395f, 197f,
        390f, 163f, 380f, 133f, 360f, 98f, 331f, 66f, 300f, 44f, 269f, 30f, 230f, 21f
    )

    private fun interp(x: Float, xs: FloatArray, ys: FloatArray): Float {
        if (x <= xs[0]) return ys[0]
        for (i in 1 until xs.size) {
            if (x <= xs[i]) {
                val t = (x - xs[i - 1]) / (xs[i] - xs[i - 1])
                return ys[i - 1] + (ys[i] - ys[i - 1]) * t
            }
        }
        return ys[ys.size - 1]
    }

    private fun recordPixels(s: Float, noSheen: Boolean, sheen: ByteArray?): IntArray {
        val pad = 0.12f * R
        val size = ((2f * R + 2f * pad) * s).toInt()
        val rPx = R * s
        val mid = size / 2f
        val px = IntArray(size * size)

        val rs = floatArrayOf(0.557f, 0.62f, 0.66f, 0.72f, 0.78f, 0.82f, 0.86f, 0.90f, 0.95f, 0.985f)
        val ls = floatArrayOf(40f, 39f, 43f, 44f, 46f, 51f, 53f, 56.5f, 59.5f, 63f)
        val lut = FloatArray(1024)
        for (i in 0 until 1024) {
            lut[i] = interp(0.55f + 0.45f * i / 1023f, rs, ls)
        }
        val lines = floatArrayOf(0.650f, 0.686f, 0.713f, 0.771f, 0.801f)

        // بافت شیار: نویز شعاعی از چند بانده‌ی دوره‌ای (به پیکسل ref، ضرب در s)
        val nLen = (rPx * 1.06f).toInt() + 4
        val noise = FloatArray(nLen + 1)
        val periods = floatArrayOf(2.0f, 3.0f, 4.5f, 7.0f, 11.0f, 18.0f, 30.0f)
        val amps = floatArrayOf(1.4f, 2.2f, 3.0f, 2.8f, 2.4f, 2.8f, 1.8f)
        val rnd = java.util.Random(11)
        val piF = Math.PI.toFloat()
        for (k in periods.indices) {
            val pk = periods[k] * s
            val knots = FloatArray((nLen / pk).toInt() + 4) { rnd.nextFloat() * 2f - 1f }
            val gk = amps[k] / 0.496f
            for (i in 0..nLen) {
                val x = i / pk
                val i0 = x.toInt()
                val t = x - i0
                val sm = (1f - cos(piF * t)) * 0.5f
                noise[i] += (knots[i0] * (1f - sm) + knots[i0 + 1] * sm) * gk
            }
        }

        for (y in 0 until size) {
            val dy = y - mid
            for (x in 0 until size) {
                val dx = x - mid
                val rr = sqrt(dx * dx + dy * dy)
                if (rr < 1f) continue
                val r = rr / rPx
                if (r > 1.01f || r < 0.40f) continue

                val c = dx / rr
                val sn = dy / rr
                val c2 = 2f * c * c - 1f
                val s2 = 2f * sn * c
                val c4 = 2f * c2 * c2 - 1f
                val s4 = 2f * s2 * c2
                val cos4 = c4 * 0.848f - s4 * 0.530f
                var g = 0.67f + 0.30f * cos4 - 0.10f * sn
                if (g < 0.30f) g = 0.30f
                if (g > 1.0f) g = 1.0f
                val gU = if (noSheen) 1f else g

                // نویز شعاعی (درون‌یابی خطی) و دانه‌ی ریز
                val ni = rr.toInt().coerceIn(0, nLen - 1)
                val fr = rr - ni
                val nz = noise[ni] * (1f - fr) + noise[ni + 1] * fr
                val hsh = (x * 73856093) xor (y * 19349663)
                val grain = ((hsh and 1023) / 511.5f - 1f) * 1.3f

                var l: Float
                if (r < 0.555f) {
                    l = 21f * (0.8f + 0.2f * gU) + 0.3f * nz
                    if (abs(r - 0.50f) < 0.004f || abs(r - 0.534f) < 0.004f) l += 6f
                } else {
                    var idx = ((r - 0.55f) / 0.45f * 1023f).toInt()
                    if (idx < 0) idx = 0
                    if (idx > 1023) idx = 1023
                    l = lut[idx] * gU + nz + grain
                }
                for (ln in lines) {
                    if (abs(r - ln) < 0.003f) l *= 0.78f
                }
                if (r > 0.985f) l *= 0.62f

                var a = (1f - r) * rPx
                if (a <= 0f) continue
                if (a > 1f) a = 1f
                if (sheen != null) sheen[y * size + x] = ((1f - g) * a * 255f).toInt().coerceIn(0, 255).toByte()
                var v = l.toInt()
                if (v < 0) v = 0
                if (v > 255) v = 255
                px[y * size + x] = ((a * 255f).toInt() shl 24) or (v shl 16) or (v shl 8) or v
            }
        }

        return px
    }

    /** دیسک یک‌تکه (برای ویجت‌ها): سایه + بدنه + براقی */
    fun recordSize(s: Float): Int = ((2f * R + 2f * 0.12f * R) * s).toInt()

    fun recordBitmap(s: Float): Bitmap {
        val size = recordSize(s)
        val rPx = R * s
        val mid = size / 2f
        val px = recordPixels(s, false, null)
        val disc = Bitmap.createBitmap(px, size, size, Bitmap.Config.ARGB_8888)
        val out = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)

        // سایه‌ی نرم زیر دیسک روی پس‌زمینه
        p.color = Color.argb(100, 0, 0, 0)
        p.maskFilter = BlurMaskFilter(26f * s, BlurMaskFilter.Blur.NORMAL)
        c.drawCircle(mid, mid + 14f * s, rPx, p)
        p.maskFilter = null

        c.drawBitmap(disc, 0f, 0f, null)
        disc.recycle()
        return out
    }

    // پیکسل‌های دیسک شیشه‌ای (به اندازه‌ی دیسک) برای هر مقیاس فقط یک بار ساخته میشه
    private var glassS = -1f
    private var glassPx: IntArray? = null

    @Synchronized
    private fun glassPixels(glass: Bitmap, s: Float): IntArray {
        var px = glassPx
        if (px == null || glassS != s) {
            val d = (2f * R * s).toInt()
            val sc = Bitmap.createScaledBitmap(glass, d, d, true)
            val arr = IntArray(d * d)
            sc.getPixels(arr, 0, d, 0, 0, d, d)
            if (sc !== glass) sc.recycle()
            glassPx = arr
            glassS = s
            px = arr
        }
        return px
    }

    /**
     * دیسک رنگی/شفاف: بدنه همون تصویر دیسک شیشه‌ایه (شیار و بازتاب فایل theme.zip) با رنگ و شفافیت ویرایشگر،
     * و روش افکت (Splatter یا Marble) با دو رنگ.
     */
    fun styledRecordLayers(s: Float, st: DiscStyle, layers: List<Pair<Bitmap, Int>>, glass: Bitmap?): RecordLayers {
        val size = recordSize(s)
        val rPx = R * s
        val mid = size / 2f
        val d = (2f * rPx).toInt()
        val off = (size - d) / 2
        val body = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        if (glass != null) {
            val g = glassPixels(glass, s)
            val px = IntArray(size * size)
            val cr = Color.red(st.color)
            val cg = Color.green(st.color)
            val cb = Color.blue(st.color)
            val op = st.opacity / 100f
            for (y in 0 until d) {
                val row = (y + off) * size + off
                for (x in 0 until d) {
                    val v = g[y * d + x]
                    val a = v ushr 24
                    if (a == 0) continue
                    // روشنایی نسبی شیار/بازتاب فایل (حدود ۹۶ = سطح صاف)
                    val f = ((v and 0xFF) / 96f).coerceIn(0f, 1.8f)
                    val shade = 0.5f + 0.5f * f
                    val r = (cr * shade).toInt().coerceIn(0, 255)
                    val gg = (cg * shade).toInt().coerceIn(0, 255)
                    val bl = (cb * shade).toInt().coerceIn(0, 255)
                    // آلفای فایل (حداکثر ۱۱۹) = سطح کامل؛ شفافیت ویرایشگر روش ضرب میشه
                    val aa = (a / 119f * 255f * op).toInt().coerceIn(0, 255)
                    px[row + x] = (aa shl 24) or (r shl 16) or (gg shl 8) or bl
                }
            }
            body.setPixels(px, 0, size, 0, 0, size, size)
        }
        if (st.effect != DiscStyles.NONE && layers.isNotEmpty()) {
            val c = Canvas(body)
            c.save()
            val path = Path()
            path.addCircle(mid, mid, rPx - 1f, Path.Direction.CW)
            c.clipPath(path)
            val pt = Paint(Paint.FILTER_BITMAP_FLAG)
            for ((pat, color) in layers) {
                val col = DiscStyles.colorize(pat, color, st.effOpacity, d)
                c.drawBitmap(col, mid - d / 2f, mid - d / 2f, pt)
                col.recycle()
            }
            c.restore()
        }
        // بازتاب‌ها از خود تصویر دیسک میاد؛ لایه‌ی براقیِ جدا لازم نیست
        return RecordLayers(shadowBitmap(s, 0.35f + 0.65f * (st.opacity / 100f)), body, null)
    }

    /** سایه‌ی نرم زیر دیسک (ثابت؛ با دیسک نمی‌چرخه) */
    private val shadowCache = HashMap<String, Bitmap>()

    @Synchronized
    private fun shadowBitmap(s: Float, k: Float = 1f): Bitmap {
        val key = "$s:${(k * 20f).toInt()}"
        return shadowCache.getOrPut(key) { makeShadow(s, (k * 20f).toInt() / 20f) }
    }

    private fun makeShadow(s: Float, k: Float): Bitmap {
        val size = recordSize(s)
        val rPx = R * s
        val mid = size / 2f
        val out = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.color = Color.argb((100 * k).toInt(), 0, 0, 0)
        p.maskFilter = BlurMaskFilter(26f * s, BlurMaskFilter.Blur.NORMAL)
        c.drawCircle(mid, mid + 14f * s, rPx, p)
        return out
    }

    /** دیسک سه‌لایه: سایه‌ی ثابت، بدنه‌ی چرخان (شیار و الگو) و براقی ثابت؛ برای غلتیدن و چرخش واقعی */
    fun recordLayers(s: Float): RecordLayers {
        val size = recordSize(s)
        val bytes = ByteArray(size * size)
        val px = recordPixels(s, true, bytes)
        val body = Bitmap.createBitmap(px, size, size, Bitmap.Config.ARGB_8888)
        val sheen: Bitmap
        val tmp = Bitmap.createBitmap(size, size, Bitmap.Config.ALPHA_8)
        if (tmp.rowBytes == size) {
            tmp.copyPixelsFromBuffer(java.nio.ByteBuffer.wrap(bytes))
            sheen = tmp
        } else {
            tmp.recycle()
            val ints = IntArray(size * size)
            for (i in ints.indices) ints[i] = (bytes[i].toInt() and 0xFF) shl 24
            sheen = Bitmap.createBitmap(ints, size, size, Bitmap.Config.ARGB_8888)
        }
        return RecordLayers(shadowBitmap(s), body, sheen)
    }

    /** دیسک سفارشی از عکس، به‌صورت لایه (بدون براقی) */
    fun customRecordLayers(src: Bitmap, s: Float): RecordLayers {
        val size = recordSize(s)
        val rPx = R * s
        val mid = size / 2f
        val body = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(body)
        val d = (2f * rPx).toInt()
        val disc = circleCrop(src, d)
        c.drawBitmap(disc, mid - d / 2f, mid - d / 2f, Paint(Paint.FILTER_BITMAP_FLAG))
        disc.recycle()
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.style = Paint.Style.STROKE
        p.strokeWidth = 2f * s
        p.color = Color.argb(70, 0, 0, 0)
        c.drawCircle(mid, mid, rPx - s, p)
        return RecordLayers(shadowBitmap(s), body, null)
    }


    /** دایره‌ی وسط‌بُرش‌شده از عکس */
    fun circleCrop(src: Bitmap, d: Int): Bitmap {
        val out = Bitmap.createBitmap(d, d, Bitmap.Config.ARGB_8888)
        val side = min(src.width, src.height)
        val sx = (src.width - side) / 2
        val sy = (src.height - side) / 2
        val sc = d / side.toFloat()
        val m = Matrix()
        m.setScale(sc, sc)
        m.preTranslate(-sx.toFloat(), -sy.toFloat())
        val sh = BitmapShader(src, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP)
        sh.setLocalMatrix(m)
        val p = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
        p.shader = sh
        Canvas(out).drawCircle(d / 2f, d / 2f, d / 2f, p)
        return out
    }

    /** دیسک سفارشی از عکس کاربر: هم‌اندازه و با همون سایه‌ی دیسک اصلی (کاور آهنگ روش می‌چرخه) */
    fun customRecord(src: Bitmap, s: Float): Bitmap {
        val pad = 0.12f * R
        val size = ((2f * R + 2f * pad) * s).toInt()
        val rPx = R * s
        val mid = size / 2f
        val out = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.color = Color.argb(100, 0, 0, 0)
        p.maskFilter = BlurMaskFilter(26f * s, BlurMaskFilter.Blur.NORMAL)
        c.drawCircle(mid, mid + 14f * s, rPx, p)
        p.maskFilter = null
        val d = (2f * rPx).toInt()
        val disc = circleCrop(src, d)
        c.drawBitmap(disc, mid - d / 2f, mid - d / 2f, Paint(Paint.FILTER_BITMAP_FLAG))
        disc.recycle()
        p.style = Paint.Style.STROKE
        p.strokeWidth = 2f * s
        p.color = Color.argb(70, 0, 0, 0)
        c.drawCircle(mid, mid, rPx - s, p)
        return out
    }

    /** پس‌زمینه‌ی سفارشی از عکس: پر کردن صفحه (center-crop) + لایه‌ی تیره‌ی ملایم برای خوانایی متن */
    fun customBackground(src: Bitmap, w: Int, h: Int): Bitmap {
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        val sc = max(w / src.width.toFloat(), h / src.height.toFloat())
        val dw = src.width * sc
        val dh = src.height * sc
        val p = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
        c.drawBitmap(src, null, RectF((w - dw) / 2f, (h - dh) / 2f, (w + dw) / 2f, (h + dh) / 2f), p)
        val g = Paint()
        g.shader = LinearGradient(
            0f, 0f, 0f, h.toFloat(),
            intArrayOf(Color.argb(25, 0, 0, 0), Color.argb(45, 0, 0, 0), Color.argb(140, 0, 0, 0)),
            floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP
        )
        c.drawRect(0f, 0f, w.toFloat(), h.toFloat(), g)
        return out
    }

    /** بازوی سوزن در حالت عمودی (استراحت)؛ شکل و رنگ از تصویر مرجع. موقع نمایش حول PX,PY می‌چرخه */
    fun armBitmap(s: Float, style: Int = 0): Bitmap {
        val dark = style == 1
        val white = style == 2
        // تم سفید: بدنه و هد روشن؛ مقدارهای تیره‌ی اصلی (۲۸ تا ۵۴) برعکس میشن
        fun hv(v: Int): Int = if (white) (275 - v).coerceIn(0, 255) else v
        val bmp = Bitmap.createBitmap((ARM_W * s).toInt(), (ARM_H * s).toInt(), Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)

        fun mx(x: Float): Float = (848f + (x - 162f) * K - PX + ARM_OX) * s
        fun my(y: Float): Float = (288f + (y - 96f) * K - PY + ARM_OY) * s

        // هد: بالای هد داخل بست میره (هم‌پوشانی) تا از میله جدا نباشه
        val hull = floatArrayOf(414f, 1380f, 380f, 1581f, 297f, 1585f, 234f, 1547f, 234f, 1525f, 310f, 1380f)
        val rodProfile = intArrayOf(114, 111, 118, 137, 157, 183, 203, 211, 210, 202, 184, 167, 156, 147, 140)
        val rodColors = IntArray(rodProfile.size)
        val rodPos = FloatArray(rodProfile.size)
        for (i in rodProfile.indices) {
            // بازوی تیره (تم مشکی): همون براقی میله ولی خیلی تیره‌تر
            val rv = if (dark) (rodProfile[i] * 0.30f + 14f).toInt() else rodProfile[i]
            rodColors[i] = Color.rgb(rv, rv, rv)
            rodPos[i] = i / (rodProfile.size - 1f)
        }

        for (pass in 0..1) {
            val shadow = pass == 0
            val dx = if (shadow) 3f else 0f
            val dy = if (shadow) 8f else 0f
            p.shader = null
            p.pathEffect = null
            p.style = Paint.Style.FILL
            p.color = Color.BLACK
            p.maskFilter = if (shadow) BlurMaskFilter(16f * s, BlurMaskFilter.Blur.NORMAL) else null
            val shadowColor = Color.argb(88, 0, 0, 0)

            // مستطیل گرد با رنگ ثابت یا گرادیان عمودی (c1→c2)
            fun box(l: Float, t: Float, r: Float, b: Float, rad: Float, c1: Int, c2: Int) {
                val rect = RectF(mx(l) + dx * s, my(t) + dy * s, mx(r) + dx * s, my(b) + dy * s)
                p.shader = null
                p.color = Color.BLACK
                if (shadow) {
                    p.color = shadowColor
                } else if (c1 == c2) {
                    p.color = c1
                } else {
                    p.shader = LinearGradient(0f, rect.top, 0f, rect.bottom, c1, c2, Shader.TileMode.CLAMP)
                }
                c.drawRoundRect(rect, rad * K * s, rad * K * s, p)
                p.shader = null
            }

            box(178f, 42f, 293f, 96f, 10f, Color.rgb(hv(40), hv(40), hv(40)), Color.rgb(hv(40), hv(40), hv(40)))
            box(162f, 96f, 389f, 235f, 14f, Color.rgb(hv(35), hv(35), hv(35)), Color.rgb(hv(35), hv(35), hv(35)))
            if (!shadow) box(162f, 119f, 318f, 129f, 3f, Color.rgb(hv(49), hv(49), hv(49)), Color.rgb(hv(49), hv(49), hv(49)))
            box(326f, 235f, 377f, 338f, 8f, Color.rgb(hv(35), hv(35), hv(35)), Color.rgb(hv(47), hv(47), hv(47)))

            // میله‌ی نقره‌ای
            if (shadow) {
                p.color = shadowColor
                c.drawRect(RectF(mx(330f) + dx * s, my(332f) + dy * s, mx(373f) + dx * s, my(1255f) + dy * s), p)
            } else {
                p.color = Color.BLACK
                p.shader = LinearGradient(mx(330f), 0f, mx(373f), 0f, rodColors, rodPos, Shader.TileMode.CLAMP)
                c.drawRect(RectF(mx(330f), my(332f), mx(373f), my(1255f)), p)
                p.shader = null
            }

            box(326f, 1255f, 377f, 1318f, 6f, Color.rgb(hv(47), hv(47), hv(47)), Color.rgb(hv(54), hv(54), hv(54)))
            box(318f, 1312f, 385f, 1395f, 6f, Color.rgb(hv(46), hv(46), hv(46)), Color.rgb(hv(35), hv(35), hv(35)))

            // هد و سوزن
            val path = Path()
            path.moveTo(mx(hull[0]) + dx * s, my(hull[1]) + dy * s)
            var i = 2
            while (i < hull.size) {
                path.lineTo(mx(hull[i]) + dx * s, my(hull[i + 1]) + dy * s)
                i += 2
            }
            path.close()
            p.pathEffect = CornerPathEffect(12f * K * s)
            p.color = if (shadow) shadowColor else Color.rgb(hv(35), hv(35), hv(35))
            c.drawPath(path, p)
            p.pathEffect = null

            p.style = Paint.Style.STROKE
            p.strokeWidth = 14f * K * s
            p.strokeCap = Paint.Cap.ROUND
            p.color = if (shadow) shadowColor else Color.rgb(hv(28), hv(28), hv(28))
            c.drawLine(
                mx(330f) + dx * s, my(1548f) + dy * s,
                mx(383f) + dx * s, my(1588f) + dy * s, p
            )
            p.style = Paint.Style.FILL
        }
        p.maskFilter = null
        return bmp
    }

    /** دکمه‌ی قرصی (از روی اندازه‌گیری دکمه‌های MD): قرص تخت #252525، خط سیاه بالا، حلقه‌ی تیره و سایه */
    fun buttonBitmap(s: Float, face: Int = Color.rgb(37, 37, 37), edge: Int = Color.rgb(30, 30, 30), top: Int = Color.argb(235, 0, 0, 0), light: Boolean = false): Bitmap {
        val w = BTN_W
        val h = BTN_H
        val pad = BTN_PAD
        val bmp = Bitmap.createBitmap(((w + 2f * pad) * s).toInt(), ((h + 2f * pad) * s).toInt(), Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)

        // سایه‌ی زیر دکمه
        p.color = Color.argb(if (light) 52 else 115, 0, 0, 0)
        p.maskFilter = BlurMaskFilter(14f * s, BlurMaskFilter.Blur.NORMAL)
        c.drawRoundRect(RectF(pad * s, (pad + 12f) * s, (pad + w) * s, (pad + h + 12f) * s), h * s / 2f, h * s / 2f, p)
        p.maskFilter = null

        // حلقه‌ی بیرونی: بالا تیره‌تر (۲۰٪)، پایین کم‌رنگ‌تر (۱۰٪)
        val ring = RectF(pad * s, pad * s, (pad + w) * s, (pad + h) * s)
        p.color = Color.BLACK
        p.shader = LinearGradient(0f, ring.top, 0f, ring.bottom, Color.argb(if (light) 30 else 51, 0, 0, 0), Color.argb(if (light) 12 else 26, 0, 0, 0), Shader.TileMode.CLAMP)
        c.drawRoundRect(ring, h * s / 2f, h * s / 2f, p)
        p.shader = null

        // قرص داخلی تخت
        val i = 11f
        val rect = RectF((pad + i) * s, (pad + i) * s, (pad + w - i) * s, (pad + h - i) * s)
        p.style = Paint.Style.FILL
        p.color = face
        c.drawRoundRect(rect, rect.height() / 2f, rect.height() / 2f, p)

        // لبه: پایین کمی تیره، نیمه‌ی بالا سیاه
        p.style = Paint.Style.STROKE
        p.strokeWidth = 2.5f * s
        p.color = edge
        c.drawRoundRect(rect, rect.height() / 2f, rect.height() / 2f, p)
        c.save()
        c.clipRect(rect.left - 4f * s, rect.top - 4f * s, rect.right + 4f * s, rect.centerY())
        p.color = top
        c.drawRoundRect(rect, rect.height() / 2f, rect.height() / 2f, p)
        c.restore()
        return bmp
    }



    /** کاهش اندازه به صورت چندمرحله‌ای (برای اینکه موقع کوچک‌کردن زیاد، نویز نیاد) */
    private fun downscale(src: Bitmap, tw: Int, th: Int): Bitmap {
        var cur = src
        while (cur.width > tw * 2 || cur.height > th * 2) {
            val nw = (cur.width / 2).coerceAtLeast(tw)
            val nh = (cur.height / 2).coerceAtLeast(th)
            cur = Bitmap.createScaledBitmap(cur, nw, nh, true)
        }
        return Bitmap.createScaledBitmap(cur, tw, th, true)
    }

    /**
     * پس‌زمینه‌ی نرم از روی کاور، مثل MD Vinyl: کل کاور به اندازه‌ی صفحه کشیده میشه
     * (تا رنگ ناحیه‌های واقعی کاور بمونه)، خیلی بلر میشه و یه لایه‌ی تیره‌ی ملایم
     * (بالا ۱۵٪، پایین ۲۵٪) روش میاد. پارامترها از روی اسکرین‌شات مرجع برازش شده.
     */
    fun coverBackground(art: Bitmap, w: Int, h: Int): Bitmap {
        val bw = (w / 4).coerceAtLeast(8)
        val bh = (h / 4).coerceAtLeast(8)
        val sw = 30
        val sh = (sw * h / w.toFloat()).toInt().coerceAtLeast(8)
        val small = downscale(art, sw, sh)
        val blurred = Shapes.boxBlur(small, 8, 3)
        val big = Bitmap.createScaledBitmap(blurred, bw, bh, true)
        val out = big.copy(Bitmap.Config.ARGB_8888, true)
        val c = Canvas(out)
        val p = Paint()
        p.shader = LinearGradient(
            0f, 0f, 0f, bh.toFloat(),
            Color.argb(48, 0, 0, 0), Color.argb(74, 0, 0, 0), Shader.TileMode.CLAMP
        )
        c.drawRect(0f, 0f, bw.toFloat(), bh.toFloat(), p)
        return out
    }

    /** برچسب گرد از روی کاور آهنگ */
    fun labelFromCover(art: Bitmap, d: Int): Bitmap {
        val label = Shapes.cover(art, d, 0.5f)
        val c = Canvas(label)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.style = Paint.Style.STROKE
        p.strokeWidth = 0.012f * d
        p.color = Color.argb(110, 0, 0, 0)
        c.drawCircle(d / 2f, d / 2f, d / 2f - p.strokeWidth / 2f, p)
        return label
    }

    /** میانگین رنگ کاور (برای رنگ برچسب لندسکیپ) */
    fun labelColor(art: Bitmap): Int {
        val sm = Bitmap.createScaledBitmap(art, 20, 20, true)
        var r = 0L
        var g = 0L
        var b = 0L
        val px = IntArray(400)
        sm.getPixels(px, 0, 20, 0, 0, 20, 20)
        for (c in px) {
            r += Color.red(c)
            g += Color.green(c)
            b += Color.blue(c)
        }
        sm.recycle()
        return Color.rgb((r / 400).toInt(), (g / 400).toInt(), (b / 400).toInt())
    }

    /** کارت کاور برای لندسکیپ: مربع گوشه‌گرد با سایه‌ی نرم (pad دورش برای سایه) */
    fun coverCard(art: Bitmap, size: Int, pad: Int): Bitmap {
        val total = size + 2 * pad
        val out = Bitmap.createBitmap(total, total, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        val rad = size * 0.025f
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.color = Color.argb(95, 0, 0, 0)
        p.maskFilter = BlurMaskFilter(pad * 0.45f, BlurMaskFilter.Blur.NORMAL)
        val dy = size * 0.012f
        c.drawRoundRect(RectF(pad.toFloat(), pad + dy, (pad + size).toFloat(), pad + size + dy), rad, rad, p)
        p.maskFilter = null
        val card = Shapes.cover(art, size, 0.025f)
        c.drawBitmap(card, pad.toFloat(), pad.toFloat(), Paint(Paint.FILTER_BITMAP_FLAG))
        card.recycle()
        return out
    }

    /**
     * برچسب لندسکیپ: رنگ از روی کاور، اسم آهنگ و خواننده وسطش و چند متن دایره‌ای دورش.
     * (متن‌های دور برچسب مال خود این اپن)
     */
    fun landscapeLabel(d: Int, base: Int, title: String, artist: String, tf: Typeface?): Bitmap {
        val bmp = Bitmap.createBitmap(d, d, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val m = d / 2f
        val hsv = FloatArray(3)
        Color.colorToHSV(base, hsv)
        if (hsv[1] < 0.2f) {
            // کاور بی‌رنگ (سفید، خاکستری، سیاه): برچسب هم بی‌رنگ و هم‌روشنایی کاور
            hsv[1] = 0f
            hsv[2] = hsv[2].coerceIn(0.16f, 0.93f)
        } else {
            hsv[1] = hsv[1].coerceIn(0.30f, 0.85f)
            hsv[2] = hsv[2].coerceIn(0.34f, 0.80f)
        }
        val fill = Color.HSVToColor(hsv)
        val lum = (0.299f * Color.red(fill) + 0.587f * Color.green(fill) + 0.114f * Color.blue(fill)) / 255f
        // روی برچسب روشن متن و حلقه تیره، روی برچسب تیره سفید
        val fg = if (lum > 0.55f) Color.rgb(32, 32, 36) else Color.WHITE

        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.color = fill
        c.drawCircle(m, m, m, p)
        // حلقه‌ی سفید لبه
        p.style = Paint.Style.STROKE
        p.strokeWidth = 0.022f * d
        p.color = fg
        c.drawCircle(m, m, m - p.strokeWidth / 2f - 0.004f * d, p)

        val tp = Paint(Paint.ANTI_ALIAS_FLAG)
        if (tf != null) tp.typeface = tf
        tp.color = Color.argb(235, Color.red(fg), Color.green(fg), Color.blue(fg))

        // متن‌های دایره‌ای
        tp.textSize = 0.036f * d
        val rt = 0.80f * m
        val oval = RectF(m - rt, m - rt, m + rt, m + rt)
        fun arcText(text: String, centerDeg: Float) {
            val span = Math.toDegrees((tp.measureText(text) / rt).toDouble()).toFloat()
            val path = Path()
            path.addArc(oval, centerDeg - span / 2f, span)
            c.drawTextOnPath(text, path, 0f, 0f, tp)
        }
        arcText("MEDIA WIDGET RECORDS", 270f)
        arcText("\u00A9 2026 MEDIA WIDGET", 0f)
        arcText("MADE ON ANDROID", 90f)
        arcText("DESIGNED WITH LOVE", 180f)

        // اسم آهنگ بالا و خواننده پایین (وسط‌چین)
        tp.textAlign = Paint.Align.CENTER
        val maxW = 0.62f * d
        var tSize = 0.118f * d
        tp.textSize = tSize
        tp.isFakeBoldText = true
        while (tp.measureText(title) > maxW && tSize > 0.05f * d) {
            tSize *= 0.92f
            tp.textSize = tSize
        }
        var t = title
        while (tp.measureText(t) > maxW && t.length > 1) t = t.substring(0, t.length - 1)
        if (t.length < title.length) t = t.trimEnd() + "\u2026"
        c.drawText(t, m, m - 0.18f * d + 0.35f * tSize, tp)

        tp.isFakeBoldText = false
        var aSize = 0.082f * d
        tp.textSize = aSize
        while (tp.measureText(artist) > maxW && aSize > 0.04f * d) {
            aSize *= 0.92f
            tp.textSize = aSize
        }
        var a = artist
        while (tp.measureText(a) > maxW && a.length > 1) a = a.substring(0, a.length - 1)
        if (a.length < artist.length) a = a.trimEnd() + "\u2026"
        c.drawText(a, m, m + 0.20f * d + 0.35f * aSize, tp)

        // سوراخ وسط
        p.style = Paint.Style.FILL
        p.color = Color.argb(40, 0, 0, 0)
        c.drawCircle(m, m, 0.10f * d, p)
        p.color = Color.rgb(165, 165, 165)
        c.drawCircle(m, m, 0.036f * d, p)
        p.color = Color.rgb(60, 60, 60)
        c.drawCircle(m, m, 0.016f * d, p)
        return bmp
    }



    fun greyBackground(w: Int, h: Int): Bitmap {
        val bw = (w / 4).coerceAtLeast(8)
        val bh = (h / 4).coerceAtLeast(8)
        val bmp = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val p = Paint()
        p.shader = LinearGradient(
            0f, 0f, 0f, bh.toFloat(),
            intArrayOf(Color.rgb(62, 62, 66), Color.rgb(48, 48, 52), Color.rgb(36, 36, 39)),
            floatArrayOf(0f, 0.5f, 1f),
            Shader.TileMode.CLAMP
        )
        c.drawRect(0f, 0f, bw.toFloat(), bh.toFloat(), p)
        return bmp
    }

    /** نوشته‌ی دایره‌ای روی یک کمان */
    private fun arcTextOn(c: Canvas, text: String, oval: RectF, r: Float, centerDeg: Float, paint: Paint) {
        val span = Math.toDegrees((paint.measureText(text) / r).toDouble()).toFloat()
        val path = Path()
        path.addArc(oval, centerDeg - span / 2f, span)
        c.drawTextOnPath(text, path, 0f, 0f, paint)
    }

    /** برچسب مشکی وقتی آهنگی نیست: حلقه‌ی کنار با چند نوشته و اسم اپ و سرعت (طراحی خودمون) */
    fun blankLabel(d: Int, tf: Typeface?, style: Int = 0): Bitmap {
        val bmp = Bitmap.createBitmap(d, d, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val m = d / 2f
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        // رنگ‌ها: ۰ خاکستری تیره (پیش‌فرض و تم‌های خاکستری و مشکی)، ۱ نارنجی (تم زرد)، ۲ کرم روشن (تم سفید)
        val ringC = when (style) { 1 -> Color.rgb(247, 187, 85); 2 -> Color.rgb(228, 210, 184); else -> Color.rgb(58, 56, 52) }
        val faceC = when (style) { 1 -> Color.rgb(250, 156, 4); 2 -> Color.rgb(241, 238, 232); else -> Color.rgb(40, 40, 41) }
        val hubC = when (style) { 1 -> Color.rgb(247, 148, 4); 2 -> Color.rgb(236, 232, 225); else -> Color.rgb(32, 32, 33) }
        val holeC = when (style) { 1 -> Color.rgb(120, 118, 116); 2 -> Color.rgb(110, 108, 106); else -> Color.rgb(150, 150, 150) }
        p.color = ringC
        c.drawCircle(m, m, m, p)
        p.color = faceC
        c.drawCircle(m, m, m * 0.86f, p)

        val tan = when (style) { 1 -> Color.rgb(60, 36, 4); 2 -> Color.rgb(168, 98, 62); else -> Color.rgb(160, 146, 124) }
        val tp = Paint(Paint.ANTI_ALIAS_FLAG)
        if (tf != null) tp.typeface = tf
        tp.color = Color.argb(200, Color.red(tan), Color.green(tan), Color.blue(tan))
        tp.textSize = 0.040f * d
        val rt = m * 0.89f
        val oval = RectF(m - rt, m - rt, m + rt, m + rt)
        arcTextOn(c, "MEDIA WIDGET \u00B7 SIDE A", oval, rt, 270f, tp)
        arcTextOn(c, "OPEN A MUSIC APP", oval, rt, 0f, tp)
        arcTextOn(c, "PERSONAL PRESSING", oval, rt, 90f, tp)
        arcTextOn(c, "STEREO \u00B7 12 INCH", oval, rt, 180f, tp)

        p.color = hubC
        c.drawCircle(m, m, m * 0.16f, p)
        p.color = holeC
        c.drawCircle(m, m, m * 0.04f, p)

        val serif = Paint(Paint.ANTI_ALIAS_FLAG)
        serif.typeface = Typeface.create(Typeface.SERIF, Typeface.BOLD)
        serif.color = tan
        serif.textAlign = Paint.Align.CENTER
        serif.textSize = 0.088f * d
        c.drawText("MEDIA WIDGET", m, m - 0.15f * d, serif)
        serif.textSize = 0.068f * d
        c.drawText("33\u2153 RPM", m, m + 0.24f * d, serif)
        return bmp
    }

    /** کاور مربعی مشکی وقتی آهنگی نیست (طراحی خودمون): نور ملایم و یک نت توخالی */
    fun blankCoverCard(size: Int, pad: Int, style: Int = 0): Bitmap {
        val art = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(art)
        val sz = size.toFloat()
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        // رنگ‌ها: ۰ مشکی با گرد و غبار کم‌رنگ، ۱ هلویی با گرد و غبار نارنجی (تم زرد)، ۲ شنی با گرد و غبار کرم (تم سفید)
        when (style) {
            1 -> p.shader = LinearGradient(0f, 0f, 0f, sz, Color.rgb(253, 241, 222), Color.rgb(246, 224, 192), Shader.TileMode.CLAMP)
            2 -> p.shader = LinearGradient(0f, 0f, 0f, sz, Color.rgb(220, 201, 170), Color.rgb(216, 195, 163), Shader.TileMode.CLAMP)
            else -> p.color = Color.rgb(26, 26, 28)
        }
        c.drawRect(0f, 0f, sz, sz, p)
        p.shader = null
        if (style == 0) {
            p.shader = RadialGradient(
                sz * 0.5f, sz * 0.5f, sz * 0.46f,
                intArrayOf(Color.argb(95, 92, 82, 70), Color.argb(0, 92, 82, 70)),
                floatArrayOf(0f, 1f), Shader.TileMode.CLAMP
            )
            c.drawRect(0f, 0f, sz, sz, p)
            p.shader = null
        }
        // دایره‌ی گرد و غبار (نقطه‌نقطه): وسط کاور؛ تراکم از مرکز به لبه کم میشه
        val dust = when (style) { 1 -> Color.rgb(255, 170, 30); 2 -> Color.rgb(242, 233, 220); else -> Color.rgb(220, 205, 180) }
        val count = if (style == 0) 5200 else 42000
        val dotA = if (style == 0) 34 else 200
        val rad = sz * (if (style == 0) 0.40f else 0.43f)
        val pts = FloatArray(count * 2)
        var n = 0
        val rnd = java.util.Random(7)
        while (n < count) {
            val x = (rnd.nextFloat() * 2f - 1f)
            val y = (rnd.nextFloat() * 2f - 1f)
            val rr = x * x + y * y
            if (rr >= 1f) continue
            if (rnd.nextFloat() > 1f - rr * rr * 0.85f) continue
            pts[n * 2] = sz * 0.5f + x * rad
            pts[n * 2 + 1] = sz * 0.5f + y * rad
            n++
        }
        p.color = Color.argb(dotA, Color.red(dust), Color.green(dust), Color.blue(dust))
        p.strokeWidth = sz * (if (style == 0) 0.0032f else 0.0034f)
        p.strokeCap = Paint.Cap.SQUARE
        c.drawPoints(pts, p)
        val out = coverCard(art, size, pad)
        art.recycle()
        return out
    }

}

/** لایه‌های دیسک: shadow و sheen ثابتن و body (شیار و الگو) می‌چرخه */
class RecordLayers(val shadow: Bitmap, val body: Bitmap, val sheen: Bitmap?) {
    fun composite(): Bitmap {
        val out = Bitmap.createBitmap(body.width, body.height, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        c.drawBitmap(shadow, 0f, 0f, null)
        c.drawBitmap(body, 0f, 0f, null)
        sheen?.let {
            val p = Paint()
            p.color = Color.BLACK
            c.drawBitmap(it, 0f, 0f, p)
        }
        return out
    }
}
