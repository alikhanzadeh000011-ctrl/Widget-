package com.example.mediawidget

import android.graphics.Bitmap
import android.graphics.Color
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/** رنگ متن و آیکون‌ها: primary برای اسم آهنگ/آیکون‌ها، secondary (کم‌رنگ‌تر) برای خواننده */
class Tint(val primary: Int, val secondary: Int)

object Palette {

    private val NEUTRAL = Tint(Color.parseColor("#F2F2F2"), Color.argb(170, 242, 242, 242))

    private class Analysis(
        val hue: Float,
        val sat: Float,
        val value: Float,
        val avgSat: Float,
        val avgVal: Float,
        val grey: Boolean
    )

    fun neutral(): Tint = NEUTRAL

    /** رنگ غالب کاور (هیو، اشباع و روشنی) */
    private fun analyze(art: Bitmap): Analysis {
        val n = 32
        val small = Bitmap.createScaledBitmap(art, n, n, true)
        val hsv = FloatArray(3)
        val bins = 24
        val weight = DoubleArray(bins)
        val sx = DoubleArray(bins)
        val sy = DoubleArray(bins)
        val sS = DoubleArray(bins)
        val sV = DoubleArray(bins)
        var satSum = 0.0
        var valSum = 0.0

        for (y in 0 until n) {
            for (x in 0 until n) {
                Color.colorToHSV(small.getPixel(x, y), hsv)
                val s = hsv[1].toDouble()
                val v = hsv[2].toDouble()
                satSum += s
                valSum += v
                if (v < 0.15) continue
                val w = s * s * (0.4 + v)
                val bin = ((hsv[0] / 360f) * bins).toInt().coerceIn(0, bins - 1)
                val rad = Math.toRadians(hsv[0].toDouble())
                weight[bin] += w
                sx[bin] += w * cos(rad)
                sy[bin] += w * sin(rad)
                sS[bin] += w * s
                sV[bin] += w * v
            }
        }

        val avgSat = (satSum / (n * n)).toFloat()
        val avgVal = (valSum / (n * n)).toFloat()
        var best = 0
        var bestScore = -1.0
        for (i in 0 until bins) {
            val a = (i + bins - 1) % bins
            val b = (i + 1) % bins
            val score = weight[i] + 0.5 * (weight[a] + weight[b])
            if (score > bestScore) {
                bestScore = score
                best = i
            }
        }
        if (avgSat < 0.08f || bestScore <= 0.0) {
            return Analysis(0f, 0f, avgVal, avgSat, avgVal, true)
        }

        val a = (best + bins - 1) % bins
        val b = (best + 1) % bins
        val vx = sx[a] + sx[best] + sx[b]
        val vy = sy[a] + sy[best] + sy[b]
        var hue = Math.toDegrees(atan2(vy, vx)).toFloat()
        if (hue < 0f) hue += 360f
        val wsum = weight[a] + weight[best] + weight[b]
        val sat = ((sS[a] + sS[best] + sS[b]) / wsum).toFloat()
        val value = ((sV[a] + sV[best] + sV[b]) / wsum).toFloat()
        return Analysis(hue, sat, value, avgSat, avgVal, false)
    }

    /** از روی رنگ غالب کاور، یه سایه‌ی روشن و کم‌رنگ (پاستلی) از همون رنگ می‌سازه */
    fun tintFor(art: Bitmap?): Tint {
        if (art == null) return NEUTRAL
        val an = analyze(art)
        if (an.grey) return NEUTRAL
        // هرچی کاور رنگی‌تر، رنگ پاستلی پررنگ‌تر
        val sat = 0.12f + 0.15f * min(1f, an.avgSat / 0.3f)
        val primary = Color.HSVToColor(floatArrayOf(an.hue, sat, 0.97f))
        val secondary = Color.HSVToColor(170, floatArrayOf(an.hue, sat + 0.04f, 0.92f))
        return Tint(primary, secondary)
    }

    /** رنگ دیسک‌های آماده توی تم پیش‌فرض: رنگ غالب کاور، با روشنایی متوسط (کاورِ خاکستری → خاکستری) */
    fun discColorFor(art: Bitmap?): Int {
        if (art == null) return Color.rgb(112, 112, 120)
        val an = analyze(art)
        if (an.grey) return Color.HSVToColor(floatArrayOf(0f, 0f, an.avgVal.coerceIn(0.42f, 0.7f)))
        val s = (an.sat * 0.85f).coerceIn(0.30f, 0.75f)
        val v = (an.value * 0.9f).coerceIn(0.45f, 0.85f)
        return Color.HSVToColor(floatArrayOf(an.hue, s, v))
    }

    /** رنگ چراغ سوزن در حالت Auto: رنگ غالب کاور، پرنور؛ برای کاورِ خاکستری null (همون رنگ اصلی چراغ) */
    fun glowColorFor(art: Bitmap?): Int? {
        if (art == null) return null
        val an = analyze(art)
        if (an.grey) return null
        return Color.HSVToColor(floatArrayOf(an.hue, an.sat.coerceIn(0.65f, 1f), 1f))
    }

    /** رنگ تک‌رنگ پس‌زمینه (ویجت Library): رنگ غالب کاور، تیره‌تر */
    fun solidFor(art: Bitmap?): Int {
        if (art == null) return Color.parseColor("#3A4658")
        val an = analyze(art)
        if (an.grey) {
            return Color.HSVToColor(floatArrayOf(0f, 0f, an.avgVal.coerceIn(0.26f, 0.42f)))
        }
        val s = (an.sat * 0.9f).coerceIn(0.30f, 0.70f)
        val v = (an.value * 0.6f).coerceIn(0.30f, 0.52f)
        return Color.HSVToColor(floatArrayOf(an.hue, s, v))
    }
}
