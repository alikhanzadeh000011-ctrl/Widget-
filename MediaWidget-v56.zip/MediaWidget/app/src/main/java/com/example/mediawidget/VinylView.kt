package com.example.mediawidget

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.CornerPathEffect
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Typeface
import android.os.SystemClock
import android.text.TextPaint
import android.text.TextUtils
import android.view.GestureDetector
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.VelocityTracker
import android.view.View
import android.view.ViewConfiguration
import java.util.concurrent.Executors
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * صفحه‌ی اصلی اپ: دیسک وینیل (فقط کاور روی برچسب می‌چرخه)، بازوی سوزن، متن و سه دکمه.
 * همه‌چیز با Canvas کشیده میشه؛ مختصات‌ها از VinylArt (بوم مرجع ۱۰۸۰×۲۳۴۰) میان.
 */
class VinylView(ctx: Context) : View(ctx) {

    interface Listener {
        fun onPlayPause()
        fun onPrev()
        fun onNext()
        fun onNeedAccess()
        fun onSettings()
        fun onWidgets()
        fun onAlbums()
        fun onPlayer()
        fun onTheme()
        fun onRotate()
        fun onLock()
        fun onKeepAwake()
        /** دکمه‌ها نمایش داده شدن یا مخفی شدن (برای استاتوس‌بار) */
        fun onOverlay(show: Boolean)
        /** سوزن از روی دیسک برداشته شد: موزیک باید قطع بشه */
        fun onNeedleLift()
        /** سوزن روی دیسک گذاشته شد: از positionMs پخش کن (منفی یعنی بدون seek) */
        fun onNeedleDrop(positionMs: Long)
    }

    var listener: Listener? = null

    private class Assets(
        val rec: RecordLayers,
        var arm: Bitmap,
        var button: Bitmap,
        val greyBg: Bitmap,
        var blankLabel: Bitmap,
        var blankCover: Bitmap?
    )

    private class Visual(
        val key: String,
        val title: String,
        val artist: String,
        var label: Bitmap,
        val bg: Bitmap,
        val cover: Bitmap?,
        val tint: Int,          // رنگ دیسک‌های آماده از کاور
        val glow: Int?,         // رنگ چراغ سوزن در حالت Auto
        val dark: Boolean       // پس‌زمینه‌ی این آهنگ تیره‌ست؟ (برای نحوه‌ی کشیدن چراغ)
    )

    private val executor = Executors.newSingleThreadExecutor()
    private var assets: Assets? = null
    private var scale = 1f          // مقیاس هنر (دیسک و بازو): پیکسل به ازای هر واحد مرجع
    private var ui = 1f             // مقیاس دکمه‌ها و چیدمان
    private var landscape = false
    private var artOX = 0f          // جابه‌جایی هنر (دیسک، بازو) نسبت به مختصات مرجع پرتره
    private var artOY = 0f
    private var landOx = 0f         // فاصله‌ی چیدمان لندسکیپ از چپ
    private var locked = false
    private var awake = false
    private var coverOn = false     // کاور لندسکیپ روی دیسک نشسته؟
    private var coverT = 0f         // پیشرفت انیمیشن کاور (۰ تا ۱)
    private var longFired = false
    private val typeface: Typeface = loadFont()

    // اطلاعات پخش
    private var hasAccess = true
    private var hasMedia = false
    private var playing = false
    private var durationMs = 0L
    private var anchorPos = 0L
    private var anchorTime = 0L
    private var wantedInfo: MediaInfo? = null
    private var targetKey = ""
    private var visualRequestKey = ""
    private var buildGen = 0

    // آنچه الان نشون داده میشه
    private var shown: Visual? = null
    private var pending: Visual? = null
    private var prevBg: Bitmap? = null
    private var bgFade = 1f

    // انتقال بین آهنگ‌ها: 0 آرام، 1 خروج صفحه‌ی قبلی، 2 ورود صفحه‌ی جدید
    private var phase = 0
    private var phaseT = 0f
    private var recX = 0f
    private var textAlpha = 1f

    // حرکت
    private var armAngle = VinylArt.ARM_REST
    private var spinVel = 0f
    private var labelAngle = 0f
    private var lastNanos = 0L

    // لمس
    private var pressedBtn = -1
    private val slop = ViewConfiguration.get(ctx).scaledTouchSlop.toFloat()
    private var downX = 0f
    private var downY = 0f
    private var velocity: VelocityTracker? = null

    // درگ سوزن
    private var armGrab = false
    private var armDrag = false
    private var grabX = 0f
    private var grabY = 0f
    private var dragAngle = 0f
    private var overrideUntil = 0L   // تا این زمان، وضعیت پخش رو محلی نگه می‌داریم تا پلیر برسه

    // دکمه‌های روی صفحه (با یک تپ)
    private var overlayOn = false
    private var overlayAlpha = 0f
    private val hideRunnable = Runnable { setOverlay(false) }
    private var playerLogo: Bitmap? = null
    private var themeLogo: Bitmap? = null
    private var albumsLogo: Bitmap? = null
    private var hideText = false
    private val oPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val oStroke = Paint(Paint.ANTI_ALIAS_FLAG)
    private val oPath = Path()

    // تم سفارشی
    private var discWanted = false   // دیسک سفارشی انتخاب شده ولی شاید هنوز آماده نشده
    private var bgWanted = false
    private val themeExec = Executors.newSingleThreadExecutor()
    private var customBg: Bitmap? = null
    private var customRecord: RecordLayers? = null
    private var recPrev: RecordLayers? = null     // دیسک قبلی، موقع عوض شدن رنگ با هر آهنگ محو میشه
    private var recFade = 1f
    private var coverTint = Color.rgb(112, 112, 120)
    private var armHideLatch = false  // لندسکیپ: از وقتی سوایپ شروع میشه تا بازو دوباره برگرده، بازو زیر دیسک و کاور میره
    private var rollDeg = 0f           // غلتیدن دیسک موقع لغزیدن (متناسب با مسافت)
    private var realRot = false        // چرخش واقعی: کل دیسک با سرعت ۳۳⅓ دور در دقیقه
    private val sheenPaint = Paint(Paint.FILTER_BITMAP_FLAG).also { it.color = Color.BLACK }
    private var themeGen = 0
    private var preset: ScreenTheme.Preset = ScreenTheme.DEFAULT_P
    private var presetBg: Bitmap? = null
    private var presetBgId = ""
    private var glowBmp: Bitmap? = null
    private var glowOn = true
    private var glowScreen = true        // روی پس‌زمینه‌ی تیره با حالت Screen (درخشان)، روی روشن عادی
    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val screenMode = android.graphics.PorterDuffXfermode(android.graphics.PorterDuff.Mode.SCREEN)

    // سوایپ دیسک
    private var swipeCand = false
    private var swiping = false
    private var swipeX = 0f
    private var swipeDir = -1        // -1 بعدی (دیسک میره چپ)، +1 قبلی (دیسک میره راست)
    private var swipeExit = false
    private var exitStartX = 0f
    private var outDur = OUT_DUR
    private var waitT = 0f
    private var hintDir = -1
    private var hintTime = 0L
    private val btnCx = floatArrayOf(200f, 620f, 879f)

    private val bmpPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val titlePaint = TextPaint(Paint.ANTI_ALIAS_FLAG)
    private val artistPaint = TextPaint(Paint.ANTI_ALIAS_FLAG)
    private val smallPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val shapePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val dst = Rect()
    private val tmpRect = RectF()
    private val skipPath = Path()
    private val pocketPath = Path()
    private var pocketScale = 0f

    private val detector = GestureDetector(ctx, object : GestureDetector.SimpleOnGestureListener() {
        override fun onDown(e: MotionEvent): Boolean = true

        override fun onLongPress(e: MotionEvent) {
            if (pressedBtn == 14) {
                longFired = true
                performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                setOverlay(true)
                listener?.onLock()
            }
        }

        override fun onSingleTapUp(e: MotionEvent): Boolean {
            if (pressedBtn >= 0) return true
            if (!hasAccess) {
                listener?.onNeedAccess()
                return true
            }
            if (phase == 0) {
                val coverFirst = landscape && coverT > COVER_SWAP
                if (coverFirst && hitCover(e.x, e.y)) {
                    toggleCover()
                    return true
                }
                if (hasMedia && hitLabel(e.x, e.y)) {
                    performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                    listener?.onPlayPause()
                    return true
                }
                if (landscape && hitCover(e.x, e.y)) {
                    toggleCover()
                    return true
                }
            }
            setOverlay(!overlayOn)
            return true
        }
    })

    init {
        try {
            playerLogo = android.graphics.BitmapFactory.decodeResource(resources, R.drawable.ic_player_logo)
            themeLogo = android.graphics.BitmapFactory.decodeResource(resources, R.drawable.ic_theme_logo)
            albumsLogo = android.graphics.BitmapFactory.decodeResource(resources, R.drawable.ic_albums_logo)
        } catch (e: Exception) {
            // آیکن‌ها اختیاری‌ان
        }
        titlePaint.typeface = typeface
        artistPaint.typeface = typeface
        smallPaint.typeface = typeface
        smallPaint.textAlign = Paint.Align.CENTER
        oStroke.style = Paint.Style.STROKE
        oStroke.strokeCap = Paint.Cap.ROUND
        oStroke.strokeJoin = Paint.Join.ROUND
        oStroke.color = Color.WHITE
    }

    private fun loadFont(): Typeface {
        return try {
            resources.getFont(R.font.sf_pro_soft)
        } catch (e: Exception) {
            Typeface.DEFAULT
        }
    }

    // ------------------------------------------------------------------ داده

    fun update(info: MediaInfo) {
        hasAccess = info.hasAccess
        hasMedia = info.hasAccess && info.hasMedia
        durationMs = info.durationMs
        // وقتی سوزن رو با دست جابه‌جا کردیم، تا رسیدن جواب پلیر وضعیت محلی رو نگه می‌داریم
        if (SystemClock.elapsedRealtime() >= overrideUntil) {
            playing = hasMedia && info.playing
            anchorPos = info.positionMs
            anchorTime = info.readAt
        }
        wantedInfo = info
        targetKey = if (!info.hasAccess) "noaccess" else if (!info.hasMedia) "none" else info.key
        maybeBuildVisual()
        invalidate()
    }

    private fun currentPos(): Long {
        var p = anchorPos
        if (playing) p += SystemClock.elapsedRealtime() - anchorTime
        if (durationMs > 0L && p > durationMs) p = durationMs
        if (p < 0L) p = 0L
        return p
    }

    private fun progress(): Float {
        if (!hasMedia || durationMs <= 0L) return 0f
        return (currentPos().toFloat() / durationMs).coerceIn(0f, 1f)
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        if (w <= 0 || h <= 0) return
        landscape = w > h
        if (landscape) {
            val sl = h / 1080f
            ui = sl
            scale = LAND_K * sl
            landOx = (w - 2340f * sl) / 2f
            artOX = landOx + 1487f * sl - VinylArt.CX * scale
            artOY = 534.5f * sl - VinylArt.CY * scale
        } else {
            scale = w / VinylArt.REF_W
            ui = scale
            landOx = 0f
            artOX = 0f
            artOY = 0f
        }
        assets = null
        customBg = null
        customRecord = null
        val s = scale
        val tf = typeface
        val isLand = landscape
        val uiScale = ui
        reloadTheme()
        val pr0 = ScreenTheme.current(context)
        executor.execute {
            try {
                val labelPx = (2f * VinylArt.LR * s).toInt()
                val a = Assets(
                    VinylArt.recordLayers(s),
                    VinylArt.armBitmap(s, pr0.armStyle),
                    VinylArt.buttonBitmap(s, pr0.btnFace, pr0.btnEdge, pr0.btnTop, pr0.lightBtn),
                    VinylArt.greyBackground(w, h),
                    VinylArt.blankLabel(labelPx, tf, pr0.blank),
                    if (isLand) VinylArt.blankCoverCard((875f * uiScale).toInt(), (60f * uiScale).toInt(), pr0.blank) else null
                )
                post {
                    assets = a
                    visualRequestKey = ""
                    maybeBuildVisual()
                    invalidate()
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    /** برچسب و پس‌زمینه‌ی آهنگ جدید رو توی thread جدا می‌سازه */
    private fun maybeBuildVisual() {
        val a = assets ?: return
        val info = wantedInfo ?: return
        if (visualRequestKey == targetKey) return
        visualRequestKey = targetKey
        val key = targetKey
        val gen = ++buildGen
        val w = width
        val h = height
        val labelPx = (2f * VinylArt.LR * scale).toInt()
        val land = landscape
        val coverPx = (875f * ui).toInt()
        val coverPad = (60f * ui).toInt()
        val tf = typeface
        val title: String
        val artist: String
        when {
            !info.hasAccess -> {
                title = "Allow access"
                artist = "Tap to allow notification access"
            }
            !info.hasMedia -> {
                title = "Not Launched"
                artist = "Open a music app to start"
            }
            else -> {
                title = if (info.title.isEmpty()) "Unknown" else info.title
                artist = info.artist
            }
        }
        val art: Bitmap? = if (info.hasAccess && info.hasMedia) info.art else null
        executor.execute {
            try {
                val label = when {
                    art == null -> a.blankLabel
                    land -> VinylArt.landscapeLabel(labelPx, VinylArt.labelColor(art), title, artist, tf)
                    else -> VinylArt.labelFromCover(art, labelPx)
                }
                val bg = if (art != null) VinylArt.coverBackground(art, w, h) else a.greyBg
                val cover = if (art != null && land) VinylArt.coverCard(art, coverPx, coverPad) else null
                val tint = Palette.discColorFor(art)
                val glow = Palette.glowColorFor(art)
                val small = Bitmap.createScaledBitmap(bg, 8, 8, true)
                var lumSum = 0.0
                for (yy in 0 until 8) for (xx in 0 until 8) {
                    val pv = small.getPixel(xx, yy)
                    lumSum += (0.299 * Color.red(pv) + 0.587 * Color.green(pv) + 0.114 * Color.blue(pv)) / 255.0
                }
                val darkBg = lumSum / 64.0 < 0.5
                val v = Visual(key, title, artist, label, bg, cover, tint, glow, darkBg)
                post {
                    if (gen == buildGen) {
                        pending = v
                        invalidate()
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    private fun applyPending() {
        val p = pending ?: return
        prevBg = shown?.bg ?: assets?.greyBg
        shown = p
        pending = null
        bgFade = 0f
        // رنگ دیسک و چراغ سوزن با آهنگ تازه
        rebuildGlow()
        if (p.tint != coverTint) {
            coverTint = p.tint
            val ctx = context
            if (ThemeStore.selected(ctx, ThemeStore.DISC) == null && DiscStyles.isOn(ctx) &&
                DiscStyles.load(ctx).auto && ScreenTheme.current(ctx).id == ScreenTheme.DEFAULT
            ) reloadDisc(true)
        }
    }

    /** رنگ دیسک آماده‌ها: تم پیش‌فرض = رنگ کاور آهنگ؛ تم‌های دیگه = رنگ خود تم */
    fun discTint(): Int {
        val pr = ScreenTheme.current(context)
        return if (pr.id == ScreenTheme.DEFAULT) coverTint else pr.discTint
    }

    fun resolveStyle(st: DiscStyle): DiscStyle = DiscStyles.withTint(st, discTint())

    /** چراغ سوزن رو دوباره با رنگ فعلی (ثابت یا Auto از کاور) می‌سازه */
    fun rebuildGlow() {
        val ctx = context
        val dark = isDarkBg()
        glowScreen = dark
        var col: Int? = if (ScreenTheme.needleAuto(ctx)) shown?.glow else ScreenTheme.needleColor(ctx)
        // Auto بدون رنگ کاور (هنوز کاوری نیومده): نور ملایم به‌جای قرمز اصلی
        if (col == null && ScreenTheme.needleAuto(ctx)) col = if (dark) Color.rgb(255, 226, 190) else Color.rgb(255, 178, 120)
        glowBmp = ScreenTheme.needleBitmap(ctx, col, ScreenTheme.needleGain(ctx))
        invalidate()
    }

    /** پس‌زمینه‌ی الان تیره‌ست؟ تم‌های غیر پیش‌فرض از رنگ خود تم، تم پیش‌فرض از پس‌زمینه‌ی آهنگ */
    private fun isDarkBg(): Boolean {
        val pr = ScreenTheme.current(context)
        if (pr.id != ScreenTheme.DEFAULT) {
            val c = pr.bgBottom
            val l = (0.299 * Color.red(c) + 0.587 * Color.green(c) + 0.114 * Color.blue(c)) / 255.0
            return l < 0.5
        }
        return shown?.dark ?: true
    }

    // ------------------------------------------------------------------ حرکت

    private fun startExit(fromSwipe: Boolean) {
        phase = 1
        phaseT = 0f
        swipeExit = fromSwipe
        exitStartX = swipeX
        swipeX = 0f
        outDur = if (fromSwipe) SWIPE_OUT_DUR else OUT_DUR
    }

    /** یک قدم انیمیشن؛ اگه هنوز چیزی در حال حرکته true برمی‌گردونه */
    private fun step(dt: Float): Boolean {
        var anim = false
        val s = scale

        when (phase) {
            0 -> {
                val p = pending
                if (p != null) {
                    val cur = shown
                    if (cur == null || (cur.title == p.title && cur.artist == p.artist)) {
                        applyPending()
                    } else {
                        swipeDir = if (SystemClock.elapsedRealtime() - hintTime < 3000L) hintDir else -1
                        startExit(false)
                    }
                    anim = true
                }
            }
            1 -> {
                phaseT += dt / outDur
                if (phaseT >= 1f) {
                    if (pending != null) {
                        applyPending()
                        phase = 2
                        phaseT = 0f
                    } else if (swipeExit) {
                        phase = 3
                        waitT = 0f
                    } else {
                        phase = 2
                        phaseT = 0f
                    }
                }
            }
            3 -> {
                // دیسک بیرون از صفحه منتظر آهنگ جدیده؛ اگه نیومد همون دیسک برمی‌گرده
                waitT += dt
                if (pending != null) {
                    applyPending()
                    phase = 2
                    phaseT = 0f
                } else if (waitT > WAIT_MAX) {
                    phase = 2
                    phaseT = 0f
                }
            }
            2 -> {
                phaseT += dt / IN_DUR
                if (phaseT >= 1f) {
                    phase = 0
                    phaseT = 1f
                    swipeExit = false
                }
            }
        }

        if (phase == 0 && !swiping && swipeX != 0f) {
            swipeX *= exp(-dt / 0.10f)
            if (abs(swipeX) < 0.5f) swipeX = 0f
            anim = true
        }

        val exitL = artOX + (VinylArt.CX + VinylArt.R + 120f) * s
        val exitR = if (landscape) width - landOx - 230f * ui else width + 100f * s - artOX - (VinylArt.CX - VinylArt.R) * s
        val exitTarget = if (swipeDir < 0) -exitL else exitR
        recX = when (phase) {
            1 -> {
                val t = phaseT.coerceIn(0f, 1f)
                val e = if (swipeExit) 1f - (1f - t) * (1f - t) else t * t * t
                exitStartX + (exitTarget - exitStartX) * e
            }
            3 -> exitTarget
            2 -> {
                val q = 1f - phaseT.coerceIn(0f, 1f)
                q * q * q * (if (swipeDir < 0) exitR else -exitL)
            }
            else -> swipeX
        }
        textAlpha = when (phase) {
            1 -> 1f - phaseT.coerceIn(0f, 1f)
            2 -> phaseT.coerceIn(0f, 1f)
            3 -> 0f
            else -> 1f
        }
        if (phase != 0) anim = true
        // غلتیدن: دیسک مثل چرخ می‌غلته؛ سرعت لبه‌اش با سرعت لغزیدن (و کاور) یکیه
        rollDeg = if (landscape) Math.toDegrees((recX / (VinylArt.R * s)).toDouble()).toFloat() else 0f

        val coverTarget = if (coverOn) 1f else 0f
        if (coverT != coverTarget) {
            val dc = dt / COVER_DUR
            coverT = if (coverT < coverTarget) min(coverT + dc, 1f) else max(coverT - dc, 0f)
            anim = true
        }

        val ovTarget = if (overlayOn) 1f else 0f
        if (abs(ovTarget - overlayAlpha) > 0.01f) {
            overlayAlpha += (ovTarget - overlayAlpha) * (1f - exp(-dt / 0.08f))
            anim = true
        } else {
            overlayAlpha = ovTarget
        }

        // بازوی سوزن: با پیشرفت آهنگ از لبه به مرکز میره؛ موقع توقف یا تغییر آهنگ میره کنار
        val playArm = VinylArt.ARM_OUTER + (VinylArt.ARM_INNER - VinylArt.ARM_OUTER) * progress()
        // لندسکیپ: به‌محض شروع سوایپ، موزیک ادامه داره ولی بازو آروم به جای قبلیش برمی‌گرده
        val swipeRetreat = landscape && swiping
        if (landscape) {
            if (swiping) armHideLatch = true
            else if (armHideLatch && phase == 0 && pending == null && abs(recX) < 1f && armAngle <= 0.5f) armHideLatch = false
            else if (armHideLatch && armAngle >= VinylArt.ARM_OUTER - 0.1f) armHideLatch = false
        } else {
            armHideLatch = false
        }
        val armTarget = if (playing && phase == 0 && pending == null && shown != null && !swipeRetreat) playArm else VinylArt.ARM_REST
        if (armDrag) {
            armAngle = dragAngle
            anim = true
        } else {
            val armTau = if (armHideLatch && armTarget == VinylArt.ARM_REST && armAngle > 0.5f) 0.45f else 0.20f
            armAngle += (armTarget - armAngle) * (1f - exp(-dt / armTau))
            if (abs(armTarget - armAngle) > 0.05f) anim = true
        }

        // چرخش کاور: نرم شروع و نرم متوقف میشه
        // سرعت چرخش واقعی دقیقاً همون حالت دیفالته؛ فقط کل دیسک می‌چرخه نه فقط برچسب
        val spinTarget = if (playing && armAngle > 10f) SPIN_DPS else 0f
        spinVel += (spinTarget - spinVel) * (1f - exp(-dt / 0.7f))
        labelAngle = (labelAngle + spinVel * dt) % 360f
        if (spinTarget > 0f || spinVel > 0.3f) anim = true

        if (bgFade < 1f) {
            bgFade = min(1f, bgFade + dt / 0.6f)
            anim = true
        }
        if (recFade < 1f) {
            recFade = min(1f, recFade + dt / 0.5f)
            if (recFade >= 1f) recPrev = null
            anim = true
        }
        return anim
    }

    // ------------------------------------------------------------------ رسم

    private fun by(refY: Float): Float = height - (VinylArt.REF_H - refY) * scale

    override fun onDraw(canvas: Canvas) {
        val now = System.nanoTime()
        var dt = if (lastNanos == 0L) 0f else (now - lastNanos) / 1_000_000_000f
        if (dt > 0.05f) dt = 0.05f
        lastNanos = now

        canvas.drawColor(Color.BLACK)
        val a = assets ?: return
        val anim = step(dt)
        drawBackground(canvas, a)
        val front = landscape && coverT > COVER_SWAP
        // بازو: همیشه بالای دیسکه، به‌جز لندسکیپ وقتی سوایپ شروع شده: بازو آروم عقب میره و زیر دیسک و کاور قایم میشه
        // (با محو شدن نرم بین «بالا» و «زیر» تا جهش نداشته باشه)
        val overA = if (landscape && armHideLatch) ((armAngle - 6.5f) / (VinylArt.ARM_OUTER - 6.5f)).coerceIn(0f, 1f) else 1f
        canvas.save()
        canvas.translate(artOX + groupShift(), artOY)
        drawBase(canvas)
        if (overA < 1f) drawArm(canvas, a, 255)
        canvas.restore()
        if (landscape && !front) drawCover(canvas)
        canvas.save()
        canvas.translate(artOX + groupShift(), artOY)
        drawRecordGroup(canvas, a)
        if (overA > 0f) drawArm(canvas, a, (overA * 255f).toInt())
        canvas.restore()
        if (front) drawCover(canvas)
        if (!landscape) drawTexts(canvas)
        val pa = if (landscape) 0f else 1f - overlayAlpha
        if (pa > 0.01f) {
            if (pa < 0.99f) {
                canvas.saveLayerAlpha(0f, 0f, width.toFloat(), height.toFloat(), (pa * 255f).toInt())
                drawButtons(canvas, a)
                canvas.restore()
            } else {
                drawButtons(canvas, a)
            }
        }
        drawOverlay(canvas)
        if (anim) postInvalidateOnAnimation() else lastNanos = 0L
    }

    private fun drawBackground(c: Canvas, a: Assets) {
        dst.set(0, 0, width, height)
        val cb = customBg
        if (cb != null) {
            bmpPaint.alpha = 255
            c.drawBitmap(cb, null, dst, bmpPaint)
            return
        }
        if (bgWanted) {
            c.drawColor(Color.rgb(42, 43, 51))
            return
        }
        if (preset.id != ScreenTheme.DEFAULT) {
            val pb = presetBg
            if (pb != null && presetBgId == preset.id) c.drawBitmap(pb, null, dst, bmpPaint) else c.drawColor(preset.bgBottom)
            return
        }
        val cur = shown?.bg ?: a.greyBg
        val prev = prevBg
        if (bgFade < 1f && prev != null) {
            bmpPaint.alpha = 255
            c.drawBitmap(prev, null, dst, bmpPaint)
            bmpPaint.alpha = (bgFade * 255f).toInt().coerceIn(0, 255)
            c.drawBitmap(cur, null, dst, bmpPaint)
            bmpPaint.alpha = 255
        } else {
            c.drawBitmap(cur, null, dst, bmpPaint)
        }
    }

    /** وقتی کاور روی دیسک میشینه، دیسک و بازو این‌قدر به چپ میرن (لندسکیپ) */
    // مسیر دو مرحله‌ای کاور (مثل ویدیو): اول به چپ میره و صاف میشه و کامل از دیسک جدا میشه،
    // بعد (جلوی دیسک) میره روی دیسک. برگشت دقیقاً برعکسه، پس هیچ‌وقت از وسط دیسک رد نمیشه.
    private fun cEase1(): Float {
        val u = (coverT / COVER_SWAP).coerceIn(0f, 1f)
        val v = 1f - u
        return 1f - v * v * v
    }

    private fun cEase2(): Float {
        val u = ((coverT - COVER_SWAP) / (1f - COVER_SWAP)).coerceIn(0f, 1f)
        return u * u * (3f - 2f * u)
    }

    private fun coverTilt(): Float = COVER_TILT * (1f - cEase1())

    private fun groupShift(): Float = if (landscape) -COVER_SHIFT * ui * cEase2() else 0f

    private fun coverCx(): Float =
        landOx + (783f - COVER_OUT * cEase1() + (COVER_OUT + COVER_SHIFT) * cEase2()) * ui + recX

    private fun toggleCover() {
        coverOn = !coverOn
        performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
        invalidate()
    }

    /** آیا نقطه روی کاور مربعی (لندسکیپ) هست؟ */
    private fun hitCover(x: Float, y: Float): Boolean {
        if (!landscape) return false
        val cx = coverCx()
        val cy = 533.75f * ui
        val r = Math.toRadians((-coverTilt()).toDouble())
        val dx = x - cx
        val dy = y - cy
        val lx = dx * cos(r).toFloat() - dy * sin(r).toFloat()
        val ly = dx * sin(r).toFloat() + dy * cos(r).toFloat()
        val h = 437.5f * ui
        return abs(lx) <= h && abs(ly) <= h
    }

    /** آیا نقطه روی برچسب دایره‌ای وسط دیسک هست؟ */
    private fun hitLabel(x: Float, y: Float): Boolean {
        val cx = artOX + groupShift() + VinylArt.CX * scale + recX
        val cy = artOY + VinylArt.CY * scale
        return hypot(x - cx, y - cy) <= VinylArt.LR * scale * 1.05f
    }

    /** کاور مربعی لندسکیپ: پشت دیسک و کمی کج؛ با تپ صاف میشه و میاد روی دیسک (مثل عکس ۶) */
    private fun drawCover(c: Canvas) {
        val u = ui
        val cx = coverCx()
        val cy = 533.75f * u
        c.save()
        c.rotate(coverTilt(), cx, cy)
        val cv = shown?.cover ?: assets?.blankCover
        if (cv != null) {
            tmpRect.set(cx - cv.width / 2f, cy - cv.height / 2f, cx + cv.width / 2f, cy + cv.height / 2f)
            bmpPaint.alpha = 255
            c.drawBitmap(cv, null, tmpRect, bmpPaint)
        } else {
            val h = 437.5f * u
            tmpRect.set(cx - h, cy - h, cx + h, cy + h)
            shapePaint.style = Paint.Style.FILL
            shapePaint.color = Color.argb(90, 20, 20, 20)
            c.drawRoundRect(tmpRect, 22f * u, 22f * u, shapePaint)
        }
        c.restore()
    }

    private fun drawRec(c: Canvas, rec: RecordLayers, cx: Float, cy: Float, alpha: Int) {
        val oldB = bmpPaint.alpha
        val oldS = sheenPaint.alpha
        bmpPaint.alpha = alpha
        sheenPaint.alpha = alpha
        c.drawBitmap(rec.shadow, cx - rec.shadow.width / 2f, cy - rec.shadow.height / 2f, bmpPaint)
        // بدنه: غلتیدن + (اگه چرخش واقعی روشنه) چرخش دیسک؛ براقی ثابت می‌مونه
        c.save()
        c.rotate(rollDeg + (if (realRot) labelAngle else 0f), cx, cy)
        c.drawBitmap(rec.body, cx - rec.body.width / 2f, cy - rec.body.height / 2f, bmpPaint)
        c.restore()
        rec.sheen?.let { c.drawBitmap(it, cx - it.width / 2f, cy - it.height / 2f, sheenPaint) }
        bmpPaint.alpha = oldB
        sheenPaint.alpha = oldS
    }

    private fun drawRecordGroup(c: Canvas, a: Assets) {
        val s = scale
        val cx = VinylArt.CX * s
        val cy = VinylArt.CY * s
        c.save()
        c.translate(recX, 0f)
        val rec = customRecord ?: (if (discWanted) null else a.rec)
        val prevRec = recPrev
        val fading = prevRec != null && recFade < 1f
        if (fading && prevRec != null) drawRec(c, prevRec, cx, cy, 255)
        if (rec != null) drawRec(c, rec, cx, cy, if (fading) (recFade * 255f).toInt().coerceIn(0, 255) else 255)
        val label = shown?.label ?: a.blankLabel
        c.save()
        c.rotate(labelAngle + rollDeg, cx, cy)
        c.drawBitmap(label, cx - label.width / 2f, cy - label.height / 2f, bmpPaint)
        c.restore()
        c.restore()
    }

    /** پایه‌ی شفاف بازو (زیر دیسک): گولی با «جیب» که بازو توش می‌شینه، شکل از تصویر مرجع */
    private fun drawBase(c: Canvas) {
        val s = scale
        val k = VinylArt.K
        tmpRect.set(780f * s, 200f * s, (780f + 412f * k) * s, (200f + 604f * k) * s)
        val rad = 412f * k / 2f * s
        shapePaint.style = Paint.Style.FILL
        shapePaint.color = preset.baseFill
        c.drawRoundRect(tmpRect, rad, rad, shapePaint)
        shapePaint.style = Paint.Style.STROKE
        shapePaint.strokeWidth = 2f * s
        shapePaint.color = preset.baseStroke
        c.drawRoundRect(tmpRect, rad, rad, shapePaint)

        if (pocketScale != s) {
            pocketPath.reset()
            val pts = VinylArt.POCKET
            pocketPath.moveTo((780f + pts[0] * k) * s, (200f + pts[1] * k) * s)
            var i = 2
            while (i < pts.size) {
                pocketPath.lineTo((780f + pts[i] * k) * s, (200f + pts[i + 1] * k) * s)
                i += 2
            }
            pocketPath.close()
            pocketScale = s
        }
        shapePaint.pathEffect = CornerPathEffect(10f * s)
        shapePaint.style = Paint.Style.FILL
        shapePaint.color = preset.pocketFill
        c.drawPath(pocketPath, shapePaint)
        shapePaint.style = Paint.Style.STROKE
        shapePaint.strokeWidth = 1.5f * s
        shapePaint.color = Color.argb(30, 0, 0, 0)
        c.drawPath(pocketPath, shapePaint)
        shapePaint.pathEffect = null
    }

    private fun drawArm(c: Canvas, a: Assets, alpha: Int = 255) {
        val s = scale
        val old = bmpPaint.alpha
        bmpPaint.alpha = alpha
        c.save()
        c.translate(VinylArt.PX * s, VinylArt.PY * s)
        c.rotate(armAngle)
        // چراغ سوزن: زیر بازو و سر سوزن کشیده میشه (روی دیسک می‌مونه ولی بازو روش میفته)
        val g = glowBmp
        if (glowOn && g != null) {
            val ga = ((armAngle - 6f) / 8f).coerceIn(0f, 1f)
            if (ga > 0.01f) {
                glowPaint.alpha = (ga * alpha).toInt().coerceIn(0, 255)
                glowPaint.xfermode = if (glowScreen) screenMode else null
                val half = 285f * s
                val gx = 72f * s          // کمی زیر بدنه‌ی هد: فقط یه گوشه‌ی کوچیکِ نور بیرون می‌مونه
                val gy = 992f * s
                tmpRect.set(gx - half, gy - half, gx + half, gy + half)
                c.drawBitmap(g, null, tmpRect, glowPaint)
            }
        }
        c.drawBitmap(a.arm, -VinylArt.ARM_OX * s, -VinylArt.ARM_OY * s, bmpPaint)
        c.restore()
        bmpPaint.alpha = old
    }

    private fun drawTexts(c: Canvas) {
        if (hideText) return
        val v = shown ?: return
        val s = scale
        val maxW = (VinylArt.REF_W - 98f * 2f) * s

        titlePaint.textSize = 72f * s
        titlePaint.letterSpacing = TITLE_LETTER_SPACING
        titlePaint.color = preset.title
        titlePaint.alpha = (textAlpha * 255f).toInt().coerceIn(0, 255)
        val tGap = titlePaint.measureText(" ") * WORD_SPACE
        val t = fitSpaced(v.title, titlePaint, tGap, maxW)
        drawSpaced(c, t, 98f * s, by(1752f), titlePaint, tGap)

        artistPaint.textSize = 46.5f * s
        artistPaint.letterSpacing = ARTIST_LETTER_SPACING
        artistPaint.color = preset.artist
        artistPaint.alpha = (textAlpha * 235f).toInt().coerceIn(0, 255)
        val aGap = artistPaint.measureText(" ") * WORD_SPACE
        val ar = fitSpaced(v.artist, artistPaint, aGap, maxW)
        drawSpaced(c, ar, 98f * s, by(1840f), artistPaint, aGap)
    }

    // متن با فاصله‌ی کمتر بین کلمه‌ها (فاصله‌ی حروف دست‌نخورده می‌مونه)
    private fun measureSpaced(text: String, paint: Paint, gap: Float): Float {
        val words = text.split(' ')
        var w = 0f
        for (i in words.indices) {
            w += paint.measureText(words[i])
            if (i < words.size - 1) w += gap
        }
        return w
    }

    private fun fitSpaced(text: String, paint: Paint, gap: Float, maxW: Float): String {
        if (measureSpaced(text, paint, gap) <= maxW) return text
        var end = text.length
        while (end > 1) {
            end--
            val cand = text.substring(0, end).trimEnd() + "\u2026"
            if (measureSpaced(cand, paint, gap) <= maxW) return cand
        }
        return "\u2026"
    }

    private fun drawSpaced(c: Canvas, text: String, x: Float, y: Float, paint: Paint, gap: Float) {
        var cx = x
        val words = text.split(' ')
        for (i in words.indices) {
            c.drawText(words[i], cx, y, paint)
            cx += paint.measureText(words[i]) + gap
        }
    }

    private fun drawButtons(c: Canvas, a: Assets) {
        val s = scale
        val cy = by(2097f)
        for (i in 0..2) {
            val cx = btnCx[i] * s
            c.save()
            if (pressedBtn == i) c.scale(0.96f, 0.96f, cx, cy)
            c.drawBitmap(a.button, cx - a.button.width / 2f, cy - a.button.height / 2f, bmpPaint)
            c.restore()
        }

        smallPaint.color = preset.btnLabel
        smallPaint.textSize = 35f * s
        c.drawText("PLAY", btnCx[0] * s, by(2206f), smallPaint)

        drawSkip(c, btnCx[1] * s, by(2205f), s, true)
        drawSkip(c, btnCx[2] * s, by(2205f), s, false)
    }

    private fun drawSkip(c: Canvas, cx: Float, cy: Float, s: Float, left: Boolean) {
        shapePaint.style = Paint.Style.FILL
        shapePaint.color = preset.btnIcon
        skipPath.reset()
        if (left) {
            c.drawRect(cx - 22f * s, cy - 14f * s, cx - 16f * s, cy + 14f * s, shapePaint)
            skipPath.moveTo(cx + 22f * s, cy - 15f * s)
            skipPath.lineTo(cx + 22f * s, cy + 15f * s)
            skipPath.lineTo(cx - 12f * s, cy)
        } else {
            c.drawRect(cx + 16f * s, cy - 14f * s, cx + 22f * s, cy + 14f * s, shapePaint)
            skipPath.moveTo(cx - 22f * s, cy - 15f * s)
            skipPath.lineTo(cx - 22f * s, cy + 15f * s)
            skipPath.lineTo(cx + 12f * s, cy)
        }
        skipPath.close()
        c.drawPath(skipPath, shapePaint)
    }

    // ------------------------------------------------------------------ لمس

    private fun hitButton(x: Float, y: Float): Int {
        if (landscape) return -1
        val s = scale
        val cy = by(2097f)
        for (i in 0..2) {
            val cx = btnCx[i] * s
            if (abs(x - cx) <= 118f * s && y >= cy - 62f * s && y <= cy + 135f * s) return i
        }
        return -1
    }

    // ------------------------------------------------------------------ دکمه‌های روی صفحه

    private fun setOverlay(on: Boolean) {
        removeCallbacks(hideRunnable)
        if (overlayOn != on) {
            overlayOn = on
            listener?.onOverlay(on)
        }
        if (on) postDelayed(hideRunnable, OVERLAY_MS)
        invalidate()
    }

    // مرکز دکمه‌ها: 0 ویجت، 1 تنظیمات، 2 تم، 3 پلیر، 4 قفل چرخش (مختصات از عکس مرجع؛ در لندسکیپ هم همین فاصله‌ها از لبه‌ها)
    // ردیف پایین: تم، لامپ | آلبوم‌ها | پلیر، چرخش (همه هم‌ردیف). لندسکیپ: آلبوم‌ها بالا-چپ
    private fun ovX(i: Int): Float = when (i) {
        0, 3 -> width - 290f * ui
        1, 4 -> width - 130f * ui
        2 -> 130f * ui
        5 -> 290f * ui
        else -> if (landscape) 130f * ui else width / 2f
    }

    private fun ovY(i: Int): Float = when (i) {
        0, 1 -> 190f * ui
        6 -> if (landscape) 190f * ui else height - 255f * ui
        else -> height - 255f * ui
    }

    private fun hitOverlay(x: Float, y: Float): Int {
        val s = ui
        for (i in 0..6) {
            val dx = abs(x - ovX(i))
            val dy = abs(y - ovY(i))
            val r = 74f * s
            if (dx <= r && dy <= r) return i
        }
        return -1
    }

    fun setLocked(v: Boolean) {
        locked = v
        invalidate()
    }

    fun setHideText(v: Boolean) {
        hideText = v
        invalidate()
    }

    fun setAwake(v: Boolean) {
        awake = v
        invalidate()
    }

    private fun onOverlayButton(i: Int) {
        when (i) {
            0 -> {
                setOverlay(false)
                listener?.onWidgets()
            }
            1 -> {
                setOverlay(false)
                listener?.onSettings()
            }
            2 -> {
                setOverlay(false)
                listener?.onTheme()
            }
            3 -> {
                setOverlay(false)
                listener?.onPlayer()
            }
            4 -> {
                setOverlay(true)
                listener?.onRotate()
            }
            5 -> {
                setOverlay(true)
                listener?.onKeepAwake()
            }
            6 -> {
                setOverlay(false)
                listener?.onAlbums()
            }
            else -> setOverlay(true)   // دکمه‌ی ویجت فعلاً فقط ظاهریه
        }
    }

    private fun drawOverlay(c: Canvas) {
        val a = overlayAlpha
        if (a <= 0.01f) return
        val s = ui
        c.saveLayerAlpha(0f, 0f, width.toFloat(), height.toFloat(), (a * 255f).toInt().coerceIn(0, 255))
        for (i in 0..6) {
            val cx = ovX(i)
            val cy = ovY(i)
            c.save()
            if (pressedBtn == 10 + i) c.scale(0.93f, 0.93f, cx, cy)
            run {
                oPaint.style = Paint.Style.FILL
                oPaint.color = Color.argb(80, 0, 0, 0)
                c.drawCircle(cx, cy, 64f * s, oPaint)
                oStroke.strokeWidth = 8f * s
                oStroke.pathEffect = null
                when (i) {
                    0 -> {
                        c.drawCircle(cx - 20f * s, cy - 24f * s, 12f * s, oStroke)
                        c.drawCircle(cx + 20f * s, cy - 24f * s, 12f * s, oStroke)
                        tmpRect.set(cx - 38f * s, cy + 2f * s, cx + 38f * s, cy + 34f * s)
                        c.drawRoundRect(tmpRect, 16f * s, 16f * s, oStroke)
                    }
                    1 -> {
                        oPath.reset()
                        for (k in 0..5) {
                            val ang = Math.toRadians(-90.0 + 60.0 * k)
                            val px = cx + 36f * s * cos(ang).toFloat()
                            val py = cy + 36f * s * sin(ang).toFloat()
                            if (k == 0) oPath.moveTo(px, py) else oPath.lineTo(px, py)
                        }
                        oPath.close()
                        oStroke.pathEffect = CornerPathEffect(9f * s)
                        c.drawPath(oPath, oStroke)
                        oStroke.pathEffect = null
                        c.drawCircle(cx, cy, 12f * s, oStroke)
                    }
                    2 -> drawLogo(c, themeLogo, cx, cy, 34f * s)
                    3 -> drawPlayerIcon(c, cx, cy, s)
                    6 -> drawLogo(c, albumsLogo, cx, cy, 36f * s)
                    4 -> {
                        if (locked) {
                            // قفل: بدنه پررنگ و سفید، قلاب کم‌رنگ
                            val bodyTop = cy - 2f * s
                            oPath.reset()
                            oPath.moveTo(cx - 15f * s, bodyTop)
                            oPath.lineTo(cx - 15f * s, cy - 20f * s)
                            tmpRect.set(cx - 15f * s, cy - 35f * s, cx + 15f * s, cy - 5f * s)
                            oPath.arcTo(tmpRect, 180f, 180f)
                            oPath.lineTo(cx + 15f * s, bodyTop)
                            oStroke.color = Color.argb(120, 255, 255, 255)
                            c.drawPath(oPath, oStroke)
                            oStroke.color = Color.WHITE
                            oStroke.strokeWidth = 9.5f * s
                            tmpRect.set(cx - 26f * s, bodyTop, cx + 26f * s, cy + 34f * s)
                            c.drawRoundRect(tmpRect, 10f * s, 10f * s, oStroke)
                            oStroke.strokeWidth = 8f * s
                        } else {
                            // دو مستطیل: حالت فعلی (عمودی یا افقی) پررنگ و جلو، دیگری کم‌رنگ و پشت
                            val fr = if (landscape) RectF(cx - 32f * s, cy - 8f * s, cx + 32f * s, cy + 32f * s)
                            else RectF(cx - 35f * s, cy - 32f * s, cx + 5f * s, cy + 32f * s)
                            val br = if (landscape) RectF(cx - 32f * s, cy - 32f * s, cx + 8f * s, cy + 32f * s)
                            else RectF(cx - 5f * s, cy + 0f * s, cx + 35f * s, cy + 32f * s)
                            val fRad = 13f * s
                            val gap = 7f * s
                            c.save()
                            oPath.reset()
                            oPath.addRoundRect(RectF(fr.left - gap, fr.top - gap, fr.right + gap, fr.bottom + gap), fRad + gap, fRad + gap, Path.Direction.CW)
                            c.clipOutPath(oPath)
                            oStroke.color = Color.argb(120, 255, 255, 255)
                            c.drawRoundRect(br, 12f * s, 12f * s, oStroke)
                            c.restore()
                            oStroke.color = Color.WHITE
                            oStroke.strokeWidth = 9.5f * s
                            c.drawRoundRect(fr, fRad, fRad, oStroke)
                            oStroke.strokeWidth = 8f * s
                        }
                    }
                    5 -> {
                        val pnt = if (awake) oPaint else oStroke
                        if (awake) {
                            oPaint.style = Paint.Style.FILL
                            oPaint.color = Color.argb(240, 255, 255, 255)
                        } else {
                            oStroke.strokeWidth = 6f * s
                        }
                        c.drawCircle(cx, cy - 8f * s, 24f * s, pnt)
                        tmpRect.set(cx - 16f * s, cy + 19f * s, cx + 16f * s, cy + 27f * s)
                        c.drawRoundRect(tmpRect, 4f * s, 4f * s, pnt)
                        tmpRect.set(cx - 9f * s, cy + 30f * s - 9f * s, cx + 9f * s, cy + 30f * s + 9f * s)
                        c.drawArc(tmpRect, 0f, 180f, true, pnt)
                    }
                }
            }
            c.restore()
        }
        c.restore()
    }

    private fun drawPlayerIcon(c: Canvas, cx: Float, cy: Float, s: Float) {
        val lg = playerLogo
        if (lg != null) {
            val h = 38f * s
            val w = h * lg.width / lg.height
            tmpRect.set(cx - w, cy - h, cx + w, cy + h)
            c.drawBitmap(lg, null, tmpRect, bmpPaint)
            return
        }
        oPaint.style = Paint.Style.FILL
        oPaint.color = Color.WHITE
        c.drawCircle(cx - 10f * s, cy + 18f * s, 12f * s, oPaint)
        c.drawRect(cx + 1f * s, cy - 30f * s, cx + 8f * s, cy + 18f * s, oPaint)
        oPath.reset()
        oPath.moveTo(cx + 8f * s, cy - 30f * s)
        oPath.quadTo(cx + 30f * s, cy - 24f * s, cx + 26f * s, cy - 4f * s)
        oPath.quadTo(cx + 20f * s, cy - 14f * s, cx + 8f * s, cy - 12f * s)
        oPath.close()
        c.drawPath(oPath, oPaint)
    }

    private fun drawLogo(c: Canvas, lg: Bitmap?, cx: Float, cy: Float, h: Float) {
        if (lg == null) return
        val w = h * lg.width / lg.height
        tmpRect.set(cx - w, cy - h, cx + w, cy + h)
        c.drawBitmap(lg, null, tmpRect, bmpPaint)
    }

    // ------------------------------------------------------------------ تم سفارشی

    /** انتخاب فعلی (پس‌زمینه و دیسک) رو از حافظه می‌خونه و اعمال می‌کنه؛ null یعنی پیش‌فرض اپ */
    fun reloadTheme() {
        refreshSpinMode()
        if (width <= 0) return
        val ctx = context
        val bgFile = ThemeStore.selected(ctx, ThemeStore.BG)
        val discFile = ThemeStore.selected(ctx, ThemeStore.DISC)
        // تا آماده شدن دیسک و پس‌زمینه‌ی سفارشی، پیش‌فرض رو نشون نمیدیم (جلوگیری از پرش)
        discWanted = discFile != null
        bgWanted = bgFile != null
        val style: DiscStyle? = if (discFile == null && DiscStyles.isOn(ctx)) resolveStyle(DiscStyles.load(ctx)) else null
        if (!discWanted && style == null) customRecord = null
        if (!bgWanted) customBg = null
        val gen = ++themeGen
        val w = width
        val h = height
        val s = scale
        val pr = ScreenTheme.current(ctx)
        preset = pr
        val labelPxT = (2f * VinylArt.LR * s).toInt()
        val tfT = typeface
        val landT = landscape
        val uiT = ui
        glowOn = ScreenTheme.needleOn(ctx)
        rebuildGlow()
        themeExec.execute {
            try {
                val pbg: Bitmap? = if (pr.id != ScreenTheme.DEFAULT) ScreenTheme.background(pr, w, h) else null
                val newArm = VinylArt.armBitmap(s, pr.armStyle)
                val newBtn = VinylArt.buttonBitmap(s, pr.btnFace, pr.btnEdge, pr.btnTop, pr.lightBtn)
                val newLabel = VinylArt.blankLabel(labelPxT, tfT, pr.blank)
                val newCover: Bitmap? = if (landT) VinylArt.blankCoverCard((875f * uiT).toInt(), (60f * uiT).toInt(), pr.blank) else null
                var bg: Bitmap? = null
                if (bgFile != null) {
                    val src = ThemeStore.decodeFile(bgFile, 2000)
                    if (src != null) bg = VinylArt.customBackground(src, w, h)
                }
                var rec: RecordLayers? = null
                if (discFile != null) {
                    val src = ThemeStore.decodeFile(discFile, 1400)
                    if (src != null) rec = VinylArt.customRecordLayers(src, s)
                } else if (style != null) {
                    rec = VinylArt.styledRecordLayers(s, style, DiscStyles.layers(ctx, style), DiscStyles.glass(ctx))
                }
                post {
                    if (gen == themeGen) {
                        presetBg = pbg
                        presetBgId = pr.id
                        assets?.let {
                            it.arm = newArm
                            it.button = newBtn
                            it.blankLabel = newLabel
                            it.blankCover = newCover
                        }
                        // وقتی آهنگی نیست، لیبلی که الان روی دیسکه هم به رنگ تم تازه برمیگرده
                        for (vis in listOf(shown, pending)) {
                            if (vis != null && (vis.key == "none" || vis.key == "noaccess")) vis.label = newLabel
                        }
                        customBg = bg
                        customRecord = rec
                        if (bg == null) bgWanted = false
                        if (rec == null) discWanted = false
                        invalidate()
                    }
                }
            } catch (e: Throwable) {
                e.printStackTrace()
            }
        }
    }

    private var discGen = 0

    /** فقط دیسک رو از نو می‌سازه (برای ویرایشگر دیسک که پشت‌سرهم رنگ و شفافیت عوض میشه) */
    fun reloadDisc(fade: Boolean = false) {
        if (width <= 0) return
        val ctx = context
        val s = scale
        val gen = ++discGen
        val discFile = ThemeStore.selected(ctx, ThemeStore.DISC)
        val style: DiscStyle? = if (discFile == null && DiscStyles.isOn(ctx)) resolveStyle(DiscStyles.load(ctx)) else null
        themeExec.execute {
            try {
                var rec: RecordLayers? = null
                if (discFile != null) {
                    val src = ThemeStore.decodeFile(discFile, 1400)
                    if (src != null) rec = VinylArt.customRecordLayers(src, s)
                } else if (style != null) {
                    rec = VinylArt.styledRecordLayers(s, style, DiscStyles.layers(ctx, style), DiscStyles.glass(ctx))
                }
                post {
                    if (gen == discGen) {
                        refreshSpinMode()
                        if (fade && customRecord != null && rec != null) {
                            recPrev = customRecord
                            recFade = 0f
                        }
                        customRecord = rec
                        discWanted = false
                        invalidate()
                    }
                }
            } catch (e: Throwable) {
                e.printStackTrace()
            }
        }
    }

    /** حالت چرخش دیسکِ انتخاب‌شده رو از تنظیمات می‌خونه (چرخش واقعی روشن یا خاموش) */
    fun refreshSpinMode() {
        realRot = ThemeStore.realRotation(context, DiscStyles.rotationKey(context))
        invalidate()
    }

    /** بندانگشتی گزینه‌ی پیش‌فرض پس‌زمینه (همون پس‌زمینه‌ی نرم از روی کاور) */
    fun defaultBackgroundPreview(): Bitmap? = shown?.bg ?: assets?.greyBg

    /** بندانگشتی دیسک پیش‌فرض */
    fun defaultRecordPreview(): Bitmap? {
        val a = assets ?: return null
        val d = (2f * VinylArt.R * scale).toInt()
        val comp = a.rec.composite()
        val off = (comp.width - d) / 2
        if (d <= 0 || off < 0) return null
        return try {
            Bitmap.createScaledBitmap(Bitmap.createBitmap(comp, off, off, d, d), 200, 200, true)
        } catch (e: Exception) {
            null
        }
    }

    /** آیا نقطه روی بازوی سوزن (با زاویه‌ی فعلی) هست؟ نقطه‌ی گرفتن رو هم ذخیره می‌کنه */
    private fun hitArm(x: Float, y: Float): Boolean {
        val s = scale
        val tx = (x - artOX - groupShift()) / s - VinylArt.PX
        val ty = (y - artOY) / s - VinylArt.PY
        val r = Math.toRadians(armAngle.toDouble())
        val cs = cos(r).toFloat()
        val sn = sin(r).toFloat()
        val lx = tx * cs + ty * sn
        val ly = -tx * sn + ty * cs
        if (lx in ARM_HIT_X0..ARM_HIT_X1 && ly in ARM_HIT_Y0..ARM_HIT_Y1) {
            grabX = lx
            grabY = ly
            return true
        }
        return false
    }

    private fun moveArm(e: MotionEvent) {
        if (!armDrag) {
            if (hypot(e.x - downX, e.y - downY) < slop) return
            armDrag = true
            parent?.requestDisallowInterceptTouchEvent(true)
            performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
            overrideUntil = Long.MAX_VALUE
            if (playing) {
                anchorPos = currentPos()
                anchorTime = SystemClock.elapsedRealtime()
                playing = false
                listener?.onNeedleLift()
            }
        }
        val s = scale
        val fx = (e.x - artOX - groupShift()) / s - VinylArt.PX
        val fy = (e.y - artOY) / s - VinylArt.PY
        var a = Math.toDegrees((atan2(fy, fx) - atan2(grabY, grabX)).toDouble()).toFloat()
        while (a > 180f) a -= 360f
        while (a < -180f) a += 360f
        dragAngle = a.coerceIn(VinylArt.ARM_REST, VinylArt.ARM_INNER + 4f)
        invalidate()
    }

    /** رها کردن سوزن: روی دیسک = پخش از همون نقطه، بیرون دیسک = برگشت به جای خودش */
    private fun dropArm() {
        val a = dragAngle
        armDrag = false
        val now = SystemClock.elapsedRealtime()
        if (a >= DROP_MIN && hasMedia) {
            var p = ((a - VinylArt.ARM_OUTER) / (VinylArt.ARM_INNER - VinylArt.ARM_OUTER)).coerceIn(0f, 1f)
            if (p < 0.04f) p = 0f
            var pos = -1L
            if (durationMs > 0L) {
                pos = (p * durationMs).toLong()
                val last = max(0L, durationMs - 250L)
                if (pos > last) pos = last
            }
            anchorPos = if (pos >= 0L) pos else currentPos()
            anchorTime = now
            playing = true
            overrideUntil = now + 1500L
            performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
            listener?.onNeedleDrop(pos)
        } else {
            overrideUntil = now + 600L
        }
        invalidate()
    }

    private fun moveSwipe(e: MotionEvent) {
        val dx = e.x - downX
        val dy = e.y - downY
        if (!swiping) {
            if (hypot(dx, dy) < slop) return
            if (abs(dx) > abs(dy)) {
                swiping = true
                parent?.requestDisallowInterceptTouchEvent(true)
            } else {
                swipeCand = false
                return
            }
        }
        swipeX = dx
        invalidate()
    }

    private fun finishSwipe() {
        val vt = velocity
        vt?.computeCurrentVelocity(1000)
        val vx = vt?.xVelocity ?: 0f
        val dx = swipeX
        swiping = false
        if (phase != 0) {
            swipeX = 0f
            return
        }
        val thr = width * 0.22f
        val dir = when {
            dx < -thr || (vx < -FLING_V && dx < -slop) -> -1
            dx > thr || (vx > FLING_V && dx > slop) -> 1
            else -> 0
        }
        if (dir == 0) {
            invalidate()
            return
        }
        swipeDir = dir
        startExit(true)
        if (dir < 0) listener?.onNext() else listener?.onPrev()
        invalidate()
    }

    private fun endTouch() {
        armGrab = false
        armDrag = false
        swipeCand = false
        swiping = false
        velocity?.recycle()
        velocity = null
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        detector.onTouchEvent(event)
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = event.x
                downY = event.y
                longFired = false
                armGrab = false
                armDrag = false
                swipeCand = false
                swiping = false
                velocity?.recycle()
                velocity = VelocityTracker.obtain()
                velocity?.addMovement(event)
                val ov = if (overlayAlpha > 0.5f) hitOverlay(event.x, event.y) else -1
                pressedBtn = if (ov >= 0) 10 + ov else if (overlayAlpha < 0.5f) hitButton(event.x, event.y) else -1
                if (pressedBtn >= 0) {
                    performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                    invalidate()
                } else if (hasMedia && phase == 0) {
                    if (hitArm(event.x, event.y)) armGrab = true else swipeCand = true
                }
            }
            MotionEvent.ACTION_MOVE -> {
                velocity?.addMovement(event)
                if (armGrab) moveArm(event) else if (swipeCand) moveSwipe(event)
            }
            MotionEvent.ACTION_UP -> {
                velocity?.addMovement(event)
                val was = pressedBtn
                pressedBtn = -1
                if (was >= 10) {
                    if (!longFired && hitOverlay(event.x, event.y) == was - 10) onOverlayButton(was - 10)
                } else if (was >= 0 && hitButton(event.x, event.y) == was) {
                    when (was) {
                        0 -> listener?.onPlayPause()
                        1 -> {
                            hintDir = 1
                            hintTime = SystemClock.elapsedRealtime()
                            listener?.onPrev()
                        }
                        else -> {
                            hintDir = -1
                            hintTime = SystemClock.elapsedRealtime()
                            listener?.onNext()
                        }
                    }
                }
                if (armDrag) dropArm() else if (swiping) finishSwipe()
                endTouch()
                invalidate()
            }
            MotionEvent.ACTION_CANCEL -> {
                pressedBtn = -1
                if (armDrag) dropArm() else if (swiping) {
                    swiping = false
                }
                endTouch()
                invalidate()
            }
        }
        return true
    }

    companion object {
        private const val TITLE_LETTER_SPACING = 0f      // فاصله‌ی حروف عنوان (۰ = فاصله‌ی طبیعی فونت)
        private const val ARTIST_LETTER_SPACING = 0f     // فاصله‌ی حروف اسم خواننده
        private const val WORD_SPACE = 0.55f             // اندازه‌ی space بین کلمه‌ها نسبت به حالت عادی (کمتر = کلمه‌ها نزدیک‌تر)
        private const val ARM_HIT_X0 = 30f               // ناحیه‌ی گرفتن بازو (مختصات مرجع، نسبت به محور)
        private const val ARM_HIT_X1 = 175f
        private const val ARM_HIT_Y0 = -110f
        private const val ARM_HIT_Y1 = 1090f
        private const val DROP_MIN = VinylArt.ARM_OUTER - 1.5f   // کمتر از این یعنی سوزن روی دیسک نیست
        private const val FLING_V = 1200f
        private const val SWIPE_OUT_DUR = 0.28f
        private const val WAIT_MAX = 1.0f
        private const val OVERLAY_MS = 4000L
        private const val LAND_K = 421f / 654f     // اندازه‌ی هنر در لندسکیپ نسبت به پرتره
        private const val COVER_TILT = -3.9f
        private const val COVER_SWAP = 0.38f     // لحظه‌ای که کاور کامل از دیسک جدا شده و ترتیب لایه‌ها عوض میشه
        private const val COVER_OUT = 300f       // کاور تا این‌قدر به چپ میره
        private const val COVER_DUR = 0.64f      // مدت کل انیمیشن کاور (ثانیه)
        private const val COVER_SHIFT = 132f      // جابه‌جایی کاور (به راست) و دیسک و بازو (به چپ) وقتی کاور روی دیسک میشینه
        private const val OUT_DUR = 0.40f
        private const val IN_DUR = 0.55f
        private const val SPIN_DPS = 18f      // از روی ویدیوی MD Vinyl: حدود ۱۸ درجه بر ثانیه
    }
}
