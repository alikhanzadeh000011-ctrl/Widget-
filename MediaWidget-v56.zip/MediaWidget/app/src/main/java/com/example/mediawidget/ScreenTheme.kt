package com.example.mediawidget

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Shader
import android.graphics.Canvas
import java.util.Random

/**
 * تم‌های آماده‌ی صفحه‌ی وینیل (مثل MD): پیش‌فرض (پس‌زمینه‌ی نرم از روی کاور)، زرد، خاکستری و مشکی.
 * هر تم رنگ پس‌زمینه، متن، دکمه‌ها، بازو و پایه‌ی بازوی خودش رو داره.
 * چراغ سوزن (روشن/خاموش و رنگ) مستقل از تمه و تو تنظیمات «theme» ذخیره میشه.
 */
object ScreenTheme {

    const val DEFAULT = "default"
    const val YELLOW = "yellow"
    const val GRAY = "gray"
    const val BLACK = "black"
    const val WHITE = "white"

    class Preset(
        val id: String,
        val bgTop: Int,
        val bgBottom: Int,
        val grain: Int,          // شدت نویز پس‌زمینه (۰ = بدون نویز)
        val title: Int,
        val artist: Int,
        val btnFace: Int,        // رنگ قرص دکمه
        val btnEdge: Int,        // لبه‌ی قرص
        val btnTop: Int,         // خط بالای قرص
        val btnLabel: Int,       // نوشته‌ی PLAY
        val btnIcon: Int,        // آیکن‌های قبلی و بعدی
        val armStyle: Int,       // ۰ نقره‌ای با هد تیره، ۱ بازوی تیره، ۲ بازوی سفید
        val lightBtn: Boolean,   // سایه‌ی ملایم دکمه‌ها (تم روشن)
        val blank: Int,          // طرح کاور و لیبل وقتی آهنگی نیست: ۰ خاکستری، ۱ نارنجی، ۲ کرم
        val baseFill: Int,       // پایه‌ی بازو (زیر دیسک)
        val baseStroke: Int,
        val pocketFill: Int,
        val discTint: Int = Color.rgb(112, 112, 120)   // رنگ دیسک‌های آماده‌ی همین تم (تم‌های غیر پیش‌فرض)
    )

    val DEFAULT_P = Preset(
        DEFAULT, 0, 0, 0,
        Color.WHITE, Color.WHITE,
        Color.rgb(37, 37, 37), Color.rgb(30, 30, 30), Color.argb(235, 0, 0, 0),
        Color.argb(205, 255, 255, 255), Color.argb(235, 255, 255, 255),
        0, false, 0,
        Color.argb(10, 0, 0, 0), Color.argb(34, 255, 255, 255), Color.argb(34, 0, 0, 0)
    )

    val YELLOW_P = Preset(
        YELLOW, Color.rgb(255, 170, 28), Color.rgb(252, 160, 20), 7,
        Color.rgb(28, 28, 28), Color.rgb(28, 28, 28),
        Color.rgb(48, 48, 48), Color.rgb(36, 36, 36), Color.argb(235, 0, 0, 0),
        Color.argb(190, 70, 52, 20), Color.argb(225, 52, 40, 22),
        0, false, 1,
        Color.argb(22, 255, 210, 120), Color.argb(70, 160, 90, 0), Color.argb(40, 150, 80, 0),
        Color.rgb(255, 170, 28)
    )

    val GRAY_P = Preset(
        GRAY, Color.rgb(62, 62, 65), Color.rgb(50, 50, 53), 6,
        Color.WHITE, Color.WHITE,
        Color.rgb(58, 58, 62), Color.rgb(36, 36, 39), Color.argb(200, 0, 0, 0),
        Color.argb(205, 255, 255, 255), Color.argb(235, 255, 255, 255),
        0, false, 0,
        Color.argb(18, 255, 255, 255), Color.argb(34, 255, 255, 255), Color.argb(46, 0, 0, 0),
        Color.rgb(132, 132, 138)
    )

    val BLACK_P = Preset(
        BLACK, Color.rgb(11, 11, 11), Color.rgb(9, 9, 9), 0,
        Color.WHITE, Color.rgb(165, 165, 168),
        Color.rgb(15, 15, 16), Color.rgb(44, 44, 46), Color.argb(255, 8, 8, 8),
        Color.argb(235, 255, 255, 255), Color.argb(240, 255, 255, 255),
        1, false, 0,
        Color.argb(26, 255, 255, 255), Color.argb(22, 255, 255, 255), Color.argb(60, 0, 0, 0),
        Color.rgb(40, 40, 43)
    )

    val WHITE_P = Preset(
        WHITE, Color.rgb(246, 245, 242), Color.rgb(241, 239, 235), 3,
        Color.rgb(30, 30, 30), Color.rgb(112, 112, 112),
        Color.rgb(246, 245, 241), Color.rgb(196, 192, 184), Color.argb(150, 170, 165, 155),
        Color.argb(215, 40, 40, 40), Color.argb(235, 40, 40, 40),
        2, true, 2,
        Color.argb(70, 255, 255, 255), Color.argb(60, 150, 145, 135), Color.argb(34, 130, 125, 115),
        Color.rgb(238, 238, 240)
    )

    val ALL = listOf(DEFAULT_P, YELLOW_P, WHITE_P, GRAY_P, BLACK_P)

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("theme", Context.MODE_PRIVATE)

    fun byId(id: String?): Preset = ALL.firstOrNull { it.id == id } ?: DEFAULT_P

    fun current(ctx: Context): Preset = byId(prefs(ctx).getString("screen_preset", DEFAULT))

    fun select(ctx: Context, id: String) {
        prefs(ctx).edit().putString("screen_preset", id).apply()
    }

    // پیش‌فرض خاموش (کلید جدید تا تنظیم قدیمی روشن اثر نذاره)
    fun needleOn(ctx: Context): Boolean = prefs(ctx).getBoolean("needle_on2", false)

    fun setNeedleOn(ctx: Context, v: Boolean) {
        prefs(ctx).edit().putBoolean("needle_on2", v).apply()
    }

    /** حالت Auto: رنگ چراغ با هر آهنگ از کاور گرفته میشه */
    fun needleAuto(ctx: Context): Boolean = prefs(ctx).getBoolean("needle_auto", false)

    fun setNeedleAuto(ctx: Context, v: Boolean) {
        prefs(ctx).edit().putBoolean("needle_auto", v).apply()
    }

    /** رنگ چراغ سوزن؛ null یعنی همون رنگ اصلی تصویر */
    fun needleColor(ctx: Context): Int? {
        val p = prefs(ctx)
        return if (p.contains("needle_color")) p.getInt("needle_color", 0) else null
    }

    fun setNeedleColor(ctx: Context, c: Int?) {
        val e = prefs(ctx).edit()
        if (c == null) e.remove("needle_color") else e.putInt("needle_color", c)
        e.apply()
    }

    /** شدت چراغ سوزن: ۰.۶ تا ۲.۴ (پیش‌فرض ۱.۵) */
    fun needleGain(ctx: Context): Float = 1.5f

    /** تصویر چراغ سوزن با رنگ دلخواه (یا رنگ اصلی تصویر) و شدت gain؛ شکل و پخش نور همون تصویر فایله */
    fun needleBitmap(ctx: Context, color: Int?, gain: Float = 1.5f): Bitmap? {
        val src: Bitmap = (try {
            BitmapFactory.decodeResource(ctx.resources, R.drawable.ic_needle_light)
        } catch (e: Throwable) {
            null
        }) ?: return null
        val w = src.width
        val h = src.height
        val px = IntArray(w * h)
        src.getPixels(px, 0, w, 0, 0, w, h)
        for (i in px.indices) {
            val v = px[i]
            val a = Color.alpha(v)
            if (a == 0) continue
            var r = Color.red(v)
            var g = Color.green(v)
            var b = Color.blue(v)
            // هسته‌ی داغ چراغ: هرچی به مرکز نزدیک‌تر، روشن‌تر
            val core = (r / 255f)
            val k = ((core - 0.9f) * 1.5f).coerceIn(0f, 0.35f)
            if (color != null) {
                r = (Color.red(color) + (255 - Color.red(color)) * k).toInt()
                g = (Color.green(color) + (255 - Color.green(color)) * k).toInt()
                b = (Color.blue(color) + (255 - Color.blue(color)) * k).toInt()
            }
            // آلفا رو با شدت بالا میبریم؛ نزدیک مرکز سریع‌تر پر میشه تا هسته‌ی نور قوی‌تر دیده بشه
            val boost = 1f + (gain - 1f) * (0.6f + 0.8f * (a / 197f).coerceIn(0f, 1f))
            val na = (a * boost).toInt().coerceIn(0, 255)
            px[i] = Color.argb(na, r.coerceIn(0, 255), g.coerceIn(0, 255), b.coerceIn(0, 255))
        }
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        out.setPixels(px, 0, w, 0, 0, w, h)
        return out
    }

    /** پس‌زمینه‌ی تم (گرادیان ملایم + نویز ریز مثل کاغذ) */
    fun background(p: Preset, w: Int, h: Int): Bitmap {
        val bw = (w / 2).coerceAtLeast(8)
        val bh = (h / 2).coerceAtLeast(8)
        val bmp = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val pt = Paint()
        pt.shader = LinearGradient(0f, 0f, 0f, bh.toFloat(), p.bgTop, p.bgBottom, Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, bw.toFloat(), bh.toFloat(), pt)
        if (p.grain > 0) {
            val px = IntArray(bw * bh)
            bmp.getPixels(px, 0, bw, 0, 0, bw, bh)
            val rnd = Random(7)
            val g = p.grain
            for (i in px.indices) {
                val n = rnd.nextInt(g * 2 + 1) - g
                val col = px[i]
                val r = (Color.red(col) + n).coerceIn(0, 255)
                val gg = (Color.green(col) + n).coerceIn(0, 255)
                val b = (Color.blue(col) + n).coerceIn(0, 255)
                px[i] = Color.rgb(r, gg, b)
            }
            bmp.setPixels(px, 0, bw, 0, 0, bw, bh)
        }
        return bmp
    }

    /** بندانگشتی گرد/مربعی تم برای کشوی Theme */
    fun swatch(p: Preset, size: Int): Bitmap {
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val pt = Paint()
        pt.shader = LinearGradient(0f, 0f, 0f, size.toFloat(), p.bgTop, p.bgBottom, Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, size.toFloat(), size.toFloat(), pt)
        return bmp
    }
}
