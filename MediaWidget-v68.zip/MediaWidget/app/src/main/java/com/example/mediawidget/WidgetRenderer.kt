package com.example.mediawidget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.widget.RemoteViews
import java.util.concurrent.Executors

/** انواع ویجت‌ها. defW/defH ابعاد پیش‌فرض (dp) وقتی لانچر اندازه نمیده */
enum class Kind(val provider: Class<*>, val defW: Int, val defH: Int) {
    SMALL(WidgetVibeSmallProvider::class.java, 160, 170),
    MEDIUM(WidgetVibeMediumProvider::class.java, 340, 170),
    LARGE(WidgetVibeLargeProvider::class.java, 340, 385),
    VDISC(WidgetVDiscProvider::class.java, 160, 185),
    VHALF(WidgetVHalfProvider::class.java, 160, 185),
    VCTRL(WidgetVCtrlProvider::class.java, 160, 185),
    VWIDE(WidgetVWideProvider::class.java, 340, 170),
    VBIG(WidgetVBigProvider::class.java, 340, 385),
    NOW(WidgetNowProvider::class.java, 340, 170),
    NOWBIG(WidgetNowBigProvider::class.java, 340, 340);

    val pixel: Boolean get() = this == NOW || this == NOWBIG
    val vinyl: Boolean get() = this == VDISC || this == VHALF || this == VCTRL || this == VWIDE || this == VBIG
    val vibe: Boolean get() = this == SMALL || this == MEDIUM || this == LARGE
}

object WidgetRenderer {

    /**
     * ضریب کوچک‌کردن تصویرها: تا جایی که حافظه‌ی مجاز RemoteViews (حدود ۱.۵ برابر اندازه‌ی صفحه) اجازه میده
     * کیفیت کامل (۱.۰) نگه داشته میشه. bytesPerPx = مجموع بایت تصویرهای هم‌اندازه‌ی ویجت به‌ازای هر پیکسل
     */
    fun fitScale(ctx: Context, w: Float, h: Float, bytesPerPx: Float): Float {
        val dm = ctx.resources.displayMetrics
        val budget = dm.widthPixels.toFloat() * dm.heightPixels * 4f * 1.5f
        val need = w * h * bytesPerPx
        return if (need <= budget) 1f else Math.sqrt((budget / need).toDouble()).toFloat()
    }

    /** پس‌زمینه‌ی نرمِ بلر کاور با گوشه‌های گرد (بدون کاور: همون خاکستری تیره‌ی وینیل) */
    internal fun softBackground(art: Bitmap?, w: Int, h: Int, radius: Float): Bitmap {
        val src = if (art != null) VinylArt.coverBackground(art, w, h) else VinylArt.greyBackground(w, h)
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        val rect = RectF(0f, 0f, w.toFloat(), h.toFloat())
        val clip = Path()
        clip.addRoundRect(rect, radius, radius, Path.Direction.CW)
        c.clipPath(clip)
        c.drawBitmap(src, null, rect, Paint(Paint.FILTER_BITMAP_FLAG))
        return out
    }

    private val executor = Executors.newSingleThreadExecutor()

    // همه‌ی این‌ها فقط داخل executor استفاده میشن
    private var cacheKey: String? = null
    private var tint: Tint = Palette.neutral()

    fun updateAll(context: Context) {
        val app = context.applicationContext
        executor.execute {
            try {
                renderAll(app)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    /** رنگ‌ها رو برای آهنگ فعلی آماده می‌کنه (فقط داخل executor) */
    private fun prepare(info: MediaInfo) {
        if (info.key != cacheKey) {
            tint = Palette.tintFor(info.art)
            cacheKey = info.key
        }
    }

    /** ساخت ویجت از روی نوعش و تنظیمات اون (همه‌ی ویجت‌ها تنظیمات خودشون رو دارن) */
    private fun build(ctx: Context, mgr: AppWidgetManager?, id: Int, kind: Kind, info: MediaInfo, coverTint: Tint, set: VSettings.Data): RemoteViews =
        when {
            kind.pixel -> PixelWidgets.build(ctx, mgr, id, kind, info, set)
            kind.vibe -> VibeWidgets.build(ctx, mgr, id, kind, info, coverTint, set)
            else -> VinylWidgets.build(ctx, mgr, id, kind, info, coverTint, set)
        }

    /** پیش‌نمایش ویجت برای صفحه‌ی ویجت‌ها و تنظیمات (با اندازه‌ی پیش‌فرض)؛ جواب روی ترد اصلی میاد */
    fun preview(context: Context, kind: Kind, set: VSettings.Data? = null, onReady: (RemoteViews) -> Unit) {
        val app = context.applicationContext
        executor.execute {
            try {
                val info = MediaReader.read(app)
                prepare(info)
                val s = set ?: VSettings.defaults(kind)
                val i = if (s.players.isEmpty()) info else MediaReader.read(app, s.players)
                val rv = build(app, null, -1, kind, i, if (i === info) tint else Palette.tintFor(i.art), s)
                Handler(Looper.getMainLooper()).post { onReady(rv) }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    private fun renderAll(ctx: Context) {
        val mgr = AppWidgetManager.getInstance(ctx)
        val jobs = ArrayList<Pair<Kind, IntArray>>()
        for (k in Kind.values()) {
            val ids = mgr.getAppWidgetIds(ComponentName(ctx, k.provider))
            if (ids.isNotEmpty()) jobs.add(Pair(k, ids))
        }
        val info = MediaReader.read(ctx)
        // تاریخچه‌ی آخرین آهنگ‌ها برای ویجت Now Playing بزرگ (حتی اگه هنوز ویجتی اضافه نشده)
        RecentStore.record(ctx, info)
        if (jobs.isEmpty()) return
        prepare(info)
        if (info.pkg.isNotEmpty() && info.pkg != AppPrefs.lastPlayer(ctx)) {
            AppPrefs.setLastPlayer(ctx, info.pkg)
        }
        if (info.pkg.isNotEmpty()) AppPrefs.addSeen(ctx, info.pkg)
        // هر ویجت تنظیمات خودش رو داره (پلیرهای انتخابی، تم، سوییچ‌ها)
        val perSet = HashMap<Set<String>, Pair<MediaInfo, Tint>>()
        for ((kind, ids) in jobs) {
            for (id in ids) {
                val set = VSettings.load(ctx, id, kind)
                val pair = if (set.players.isEmpty()) Pair(info, tint) else perSet.getOrPut(set.players) {
                    val i = MediaReader.read(ctx, set.players)
                    if (i.pkg.isNotEmpty()) AppPrefs.addSeen(ctx, i.pkg)
                    Pair(i, Palette.tintFor(i.art))
                }
                mgr.updateAppWidget(id, build(ctx, mgr, id, kind, pair.first, pair.second, set))
            }
        }
    }

    /** دکمه‌های کنترل ویجت وینیل Wide (پخش، قبلی، بعدی) */
    internal fun wideAction(ctx: Context, action: String, code: Int): PendingIntent =
        PendingIntent.getBroadcast(
            ctx, code,
            Intent(ctx, WidgetVWideProvider::class.java).setAction(action),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

    internal fun launchPlayer(ctx: Context, pkg: String): PendingIntent {
        val pm = ctx.packageManager
        val intent = (if (pkg.isNotEmpty()) pm.getLaunchIntentForPackage(pkg) else null)
            ?: pm.getLaunchIntentForPackage(ctx.packageName)
            ?: Intent(Settings.ACTION_SOUND_SETTINGS)
        return activity(ctx, intent, 2)
    }

    internal fun activity(ctx: Context, intent: Intent, code: Int): PendingIntent =
        PendingIntent.getActivity(
            ctx, code, intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
}
