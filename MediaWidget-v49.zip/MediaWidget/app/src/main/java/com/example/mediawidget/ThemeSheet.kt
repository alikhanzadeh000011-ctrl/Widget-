package com.example.mediawidget

import android.app.AlertDialog
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.TextView
import java.io.File
import kotlin.math.min

/** بندانگشتی گرد یا چهارگوش (گزینه‌ی پیش‌فرض، عکس سفارشی یا دکمه‌ی +) */
class ThumbView(act: VinylActivity, private val circle: Boolean) : View(act) {
    var bmp: Bitmap? = null
    var plus = false
    var tune = false     // آیکن ویرایش (سه خط با دسته)
    var chosen = false

    private val d = resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val path = Path()
    private val src = Rect()
    private val box = RectF()

    override fun onDraw(c: Canvas) {
        val m = 5f * d
        box.set(m, m, width - m, height - m)
        path.reset()
        if (circle) path.addOval(box, Path.Direction.CW) else path.addRoundRect(box, 13f * d, 13f * d, Path.Direction.CW)
        c.save()
        c.clipPath(path)
        p.style = Paint.Style.FILL
        p.color = Color.rgb(44, 43, 48)
        c.drawRect(box, p)
        val b = bmp
        if (b != null) {
            val side = min(b.width, b.height)
            val sx = (b.width - side) / 2
            val sy = ((b.height - side) * 0.35f).toInt()
            src.set(sx, sy, sx + side, sy + side)
            c.drawBitmap(b, src, box, p)
        } else if (tune) {
            p.style = Paint.Style.STROKE
            p.strokeWidth = 2.2f * d
            p.strokeCap = Paint.Cap.ROUND
            p.color = Color.WHITE
            val cx = width / 2f
            val cy = height / 2f
            val l = 10f * d
            val knobs = floatArrayOf(-4f, 5f, -2f)
            for (i in 0 until 3) {
                val y = cy + (i - 1) * 8.5f * d
                c.drawLine(cx - l, y, cx + l, y, p)
                p.style = Paint.Style.FILL
                c.drawCircle(cx + knobs[i] * d, y, 3.2f * d, p)
                p.style = Paint.Style.STROKE
            }
        } else if (plus) {
            p.style = Paint.Style.STROKE
            p.strokeWidth = 2.4f * d
            p.strokeCap = Paint.Cap.ROUND
            p.color = Color.WHITE
            val cx = width / 2f
            val cy = height / 2f
            val l = 9f * d
            c.drawLine(cx - l, cy, cx + l, cy, p)
            c.drawLine(cx, cy - l, cx, cy + l, p)
        }
        c.restore()
        if (chosen) {
            p.style = Paint.Style.STROKE
            p.strokeWidth = 2.4f * d
            p.color = Color.WHITE
            box.inset(-3.5f * d, -3.5f * d)
            if (circle) c.drawOval(box, p) else c.drawRoundRect(box, 16.5f * d, 16.5f * d, p)
        }
    }
}

/** دایره‌ی رنگ برای چراغ سوزن (رنگ ساده یا حلقه‌ی رنگین‌کمان برای انتخابگر) */
class SwatchView(act: VinylActivity, private val color: Int, private val rainbow: Boolean) : View(act) {
    var chosen = false
    var dim = false
    private val d = resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onDraw(c: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val r = min(width, height) / 2f - 6f * d
        p.alpha = if (dim) 110 else 255
        p.style = Paint.Style.FILL
        if (rainbow) {
            val cols = IntArray(7) { Color.HSVToColor(floatArrayOf(it * 60f, 0.9f, 1f)) }
            p.shader = android.graphics.SweepGradient(cx, cy, cols, null)
            c.drawCircle(cx, cy, r, p)
            p.shader = null
            p.color = Color.rgb(28, 27, 32)
            c.drawCircle(cx, cy, r * 0.42f, p)
        } else {
            p.color = color
            c.drawCircle(cx, cy, r, p)
        }
        if (chosen) {
            p.style = Paint.Style.STROKE
            p.strokeWidth = 2.2f * d
            p.color = Color.WHITE
            c.drawCircle(cx, cy, r + 3.5f * d, p)
        }
    }
}

/** صفحه‌ی تم (کشوی پایین)، مثل عکس مرجع: ردیف Theme برای پس‌زمینه و ردیف Vinyl برای دیسک */
class ThemeSheet(private val act: VinylActivity, private val vinyl: VinylView) : FrameLayout(act) {

    var onDismissed: (() -> Unit)? = null

    private val d = resources.displayMetrics.density
    private val panel = LinearLayout(act)
    private val bgRow = LinearLayout(act)
    private val discRow = LinearLayout(act)
    private val needleRow = LinearLayout(act)
    private val tf: Typeface = try {
        resources.getFont(R.font.sf_pro_soft)
    } catch (e: Exception) {
        Typeface.DEFAULT
    }
    private val defBg: Bitmap? = vinyl.defaultBackgroundPreview()
    private val defDisc: Bitmap? = vinyl.defaultRecordPreview()
    private val thumbCache = HashMap<Int, Bitmap>()
    private var dismissing = false
    private var dragging = false
    private var dragStartY = 0f

    private fun dp(v: Float) = (v * d).toInt()

    // لندسکیپ (ارتفاع کم): همه‌چیز کمی فشرده‌تر تا کشو از صفحه بیرون نزنه
    private val compact = resources.displayMetrics.heightPixels < dp(520f)

    private fun title(label: String, topPad: Int): TextView {
        val t = TextView(act)
        t.text = label
        t.setTextColor(Color.WHITE)
        t.textSize = if (compact) 16f else 20f
        t.typeface = tf
        t.setPadding(dp(28f), if (compact) topPad / 2 else topPad, 0, if (compact) dp(4f) else dp(8f))
        return t
    }

    private fun scroller(row: LinearLayout): HorizontalScrollView {
        val sv = HorizontalScrollView(act)
        sv.isHorizontalScrollBarEnabled = false
        sv.overScrollMode = View.OVER_SCROLL_NEVER
        sv.setPadding(dp(23f), 0, dp(23f), 0)
        sv.clipToPadding = false
        row.orientation = LinearLayout.HORIZONTAL
        sv.addView(row, ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        return sv
    }

    init {
        isClickable = true
        setOnClickListener { dismiss() }

        panel.orientation = LinearLayout.VERTICAL
        val r = 30f * d
        val bgd = GradientDrawable()
        bgd.setColor(Color.rgb(28, 27, 32))
        bgd.cornerRadii = floatArrayOf(r, r, r, r, 0f, 0f, 0f, 0f)
        panel.background = bgd
        panel.isClickable = true
        panel.setPadding(0, 0, 0, if (compact) dp(14f) else dp(34f))

        val handle = View(act)
        val hd = GradientDrawable()
        hd.setColor(Color.rgb(142, 140, 147))
        hd.cornerRadius = 4f * d
        handle.background = hd
        val hlp = LinearLayout.LayoutParams(dp(36f), dp(4f))
        hlp.gravity = Gravity.CENTER_HORIZONTAL
        hlp.topMargin = if (compact) dp(8f) else dp(14f)
        hlp.bottomMargin = if (compact) dp(8f) else dp(20f)
        panel.addView(handle, hlp)

        panel.addView(title("Theme", 0))
        panel.addView(scroller(bgRow))
        panel.addView(title("Vinyl", dp(12f)))
        panel.addView(scroller(discRow))
        panel.addView(title("Needle light", dp(12f)))
        panel.addView(scroller(needleRow))

        panel.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    if (e.y < dp(56f)) {
                        dragging = true
                        dragStartY = e.rawY
                    }
                    dragging
                }
                MotionEvent.ACTION_MOVE -> {
                    if (dragging) panel.translationY = (e.rawY - dragStartY).coerceAtLeast(0f)
                    dragging
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    val was = dragging
                    dragging = false
                    if (was) {
                        if (panel.translationY > dp(90f)) dismiss()
                        else panel.animate().translationY(0f).setDuration(160).start()
                    }
                    was
                }
                else -> false
            }
        }

        addView(panel, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT, Gravity.BOTTOM))
        refresh()

        panel.alpha = 0f
        panel.post {
            panel.translationY = panel.height.toFloat()
            panel.alpha = 1f
            panel.animate().translationY(0f).setDuration(260).setInterpolator(DecelerateInterpolator()).start()
        }
    }

    fun dismiss(then: (() -> Unit)? = null) {
        if (dismissing) return
        dismissing = true
        panel.animate().translationY(panel.height.toFloat()).setDuration(200).withEndAction {
            (parent as? ViewGroup)?.removeView(this)
            onDismissed?.invoke()
            then?.invoke()
        }.start()
    }

    fun refresh() {
        fillTheme()
        fillDisc()
        fillNeedle()
    }

    /** ردیف Theme: تم‌های آماده (پیش‌فرض، زرد، خاکستری، مشکی) + پس‌زمینه‌های گالری + دکمه‌ی + */
    private fun fillTheme() {
        bgRow.removeAllViews()
        val selFile = ThemeStore.selected(act, ThemeStore.BG)
        val cur = ScreenTheme.current(act)
        for (pr in ScreenTheme.ALL) {
            val v = item(false)
            v.bmp = if (pr.id == ScreenTheme.DEFAULT) defBg else ScreenTheme.swatch(pr, 200)
            v.chosen = selFile == null && cur.id == pr.id
            v.setOnClickListener {
                ThemeStore.select(act, ThemeStore.BG, null)
                ScreenTheme.select(act, pr.id)
                vinyl.reloadTheme()
                refresh()
            }
            bgRow.addView(v)
        }
        for (f in ThemeStore.list(act, ThemeStore.BG)) {
            val v = item(false)
            v.bmp = ThemeStore.decodeFile(f, 200)
            v.chosen = selFile != null && selFile.name == f.name
            v.setOnClickListener {
                ThemeStore.select(act, ThemeStore.BG, f)
                vinyl.reloadTheme()
                refresh()
            }
            v.setOnLongClickListener {
                confirmDelete(ThemeStore.BG, f)
                true
            }
            bgRow.addView(v)
        }
        val add = item(false)
        add.plus = true
        add.setOnClickListener { act.pickImage(ThemeStore.BG) }
        bgRow.addView(add)
    }

    /** ردیف چراغ سوزن: کلید روشن/خاموش، چند رنگ آماده و انتخابگر رنگ */
    private fun fillNeedle() {
        needleRow.removeAllViews()
        val on = ScreenTheme.needleOn(act)
        val curColor = ScreenTheme.needleColor(act)

        val tog = TextView(act)
        tog.text = if (on) "On" else "Off"
        tog.setTextColor(Color.WHITE)
        tog.textSize = 16f
        tog.typeface = tf
        tog.gravity = Gravity.CENTER
        val g = GradientDrawable()
        g.cornerRadius = dp(22f).toFloat()
        g.setColor(if (on) Color.rgb(108, 70, 222) else Color.rgb(58, 59, 68))
        tog.background = g
        val tlp = LinearLayout.LayoutParams(dp(70f), dp(44f))
        tlp.marginEnd = dp(14f)
        tlp.topMargin = dp(2f)
        needleRow.addView(tog, tlp)
        tog.setOnClickListener {
            ScreenTheme.setNeedleOn(act, !on)
            vinyl.reloadTheme()
            refresh()
        }

        // رنگ اصلی تصویر + چند رنگ آماده
        val presets = listOf<Int?>(
            null,
            Color.rgb(255, 255, 255),
            Color.rgb(70, 160, 255),
            Color.rgb(60, 210, 120),
            Color.rgb(255, 205, 50),
            Color.rgb(200, 90, 255)
        )
        var matched = false
        for (c in presets) {
            val sw = SwatchView(act, c ?: Color.rgb(253, 103, 58), false)
            sw.dim = !on
            sw.chosen = if (c == null) curColor == null else curColor == c
            if (sw.chosen) matched = true
            val lp = LinearLayout.LayoutParams(dp(48f), dp(48f))
            lp.marginEnd = dp(8f)
            needleRow.addView(sw, lp)
            sw.setOnClickListener {
                ScreenTheme.setNeedleColor(act, c)
                ScreenTheme.setNeedleOn(act, true)
                vinyl.reloadTheme()
                refresh()
            }
        }
        val pick = SwatchView(act, Color.WHITE, true)
        pick.dim = !on
        pick.chosen = !matched && curColor != null
        needleRow.addView(pick, LinearLayout.LayoutParams(dp(48f), dp(48f)))
        pick.setOnClickListener {
            ColorPickerView.show(act, curColor ?: Color.rgb(253, 103, 58), "Needle light") { col ->
                ScreenTheme.setNeedleColor(act, col)
                ScreenTheme.setNeedleOn(act, true)
                vinyl.reloadTheme()
                refresh()
            }
        }
    }

    private fun item(circle: Boolean): ThumbView {
        val v = ThumbView(act, circle)
        val sz = if (compact) 50f else 62f
        val lp = LinearLayout.LayoutParams(dp(sz), dp(sz))
        lp.marginEnd = dp(14f)
        v.layoutParams = lp
        return v
    }

    private fun fill(row: LinearLayout, kind: String, circle: Boolean, defBmp: Bitmap?) {
        row.removeAllViews()
        val sel = ThemeStore.selected(act, kind)

        val def = item(circle)
        def.bmp = defBmp
        def.chosen = sel == null
        def.setOnClickListener {
            ThemeStore.select(act, kind, null)
            vinyl.reloadTheme()
            refresh()
        }
        if (kind == ThemeStore.DISC) {
            def.setOnLongClickListener {
                discMenu("default", null)
                true
            }
        }
        row.addView(def)

        for (f in ThemeStore.list(act, kind)) {
            val v = item(circle)
            v.bmp = ThemeStore.decodeFile(f, 200)
            v.chosen = sel != null && sel.name == f.name
            v.setOnClickListener {
                ThemeStore.select(act, kind, f)
                vinyl.reloadTheme()
                refresh()
            }
            v.setOnLongClickListener {
                if (kind == ThemeStore.DISC) discMenu(f.name, f) else confirmDelete(kind, f)
                true
            }
            row.addView(v)
        }

        val add = item(circle)
        add.plus = true
        add.setOnClickListener { act.pickImage(kind) }
        row.addView(add)
    }

    /** ردیف Vinyl: دیسک پیش‌فرض، سه دیسک آماده (Clear، Splatter، Marble)، دیسک‌های ساخته‌شده با ادیتور، دیسک‌های گالری و + */
    private fun fillDisc() {
        discRow.removeAllViews()
        val sel = ThemeStore.selected(act, ThemeStore.DISC)
        val styleOn = sel == null && DiscStyles.isOn(act)
        val cur = DiscStyles.load(act)
        val savedIdx = DiscStyles.savedIndex(act)

        val def = item(true)
        def.bmp = defDisc
        def.chosen = sel == null && !styleOn
        def.setOnClickListener {
            ThemeStore.select(act, ThemeStore.DISC, null)
            DiscStyles.setOn(act, false)
            vinyl.reloadTheme()
            refresh()
        }
        def.setOnLongClickListener {
            discMenu("default", null)
            true
        }
        discRow.addView(def)

        for (eff in listOf(DiscStyles.NONE, DiscStyles.SPLATTER, DiscStyles.MARBLE)) {
            val v = item(true)
            val pre = DiscStyles.preset(eff)
            v.bmp = thumbCache.getOrPut(eff) { DiscStyles.thumb(act, pre, 200) }
            v.chosen = styleOn && savedIdx < 0 && cur.effect == eff
            v.setOnClickListener {
                ThemeStore.select(act, ThemeStore.DISC, null)
                DiscStyles.save(act, if (styleOn && savedIdx < 0 && cur.effect == eff) cur else pre)
                DiscStyles.setSavedIndex(act, -1)
                DiscStyles.setOn(act, true)
                vinyl.reloadTheme()
                refresh()
            }
            v.setOnLongClickListener {
                discMenu("default", null)
                true
            }
            discRow.addView(v)
        }

        // دیسک‌هایی که کاربر با ادیتور ساخته (نگه داشتن: ویرایش یا حذف)
        for ((i, st) in DiscStyles.listSaved(act).withIndex()) {
            val v = item(true)
            v.bmp = DiscStyles.thumb(act, st, 200)
            v.chosen = styleOn && savedIdx == i
            v.setOnClickListener {
                ThemeStore.select(act, ThemeStore.DISC, null)
                DiscStyles.save(act, st)
                DiscStyles.setSavedIndex(act, i)
                DiscStyles.setOn(act, true)
                vinyl.reloadTheme()
                refresh()
            }
            v.setOnLongClickListener {
                savedMenu(i)
                true
            }
            discRow.addView(v)
        }

        for (f in ThemeStore.list(act, ThemeStore.DISC)) {
            val v = item(true)
            v.bmp = ThemeStore.decodeFile(f, 200)
            v.chosen = sel != null && sel.name == f.name
            v.setOnClickListener {
                ThemeStore.select(act, ThemeStore.DISC, f)
                DiscStyles.setOn(act, false)
                vinyl.reloadTheme()
                refresh()
            }
            v.setOnLongClickListener {
                discMenu(f.name, f)
                true
            }
            discRow.addView(v)
        }

        val add = item(true)
        add.plus = true
        add.setOnClickListener {
            MdDialog(act).title("Add vinyl")
                .primary("Disc editor") { dismiss { act.openDiscEditor(-1) } }
                .secondary("From gallery") { act.pickImage(ThemeStore.DISC) }
                .show()
        }
        discRow.addView(add)
    }

    /** منوی دیسک ساخته‌شده با ادیتور: ویرایش یا حذف */
    private fun savedMenu(i: Int) {
        MdDialog(act).title("Vinyl")
            .primary("Edit") { dismiss { act.openDiscEditor(i) } }
            .danger("Delete") {
                MdDialog.confirm(act, null, "Delete this vinyl?", "Delete", true) {
                    val wasActive = DiscStyles.isOn(act) && DiscStyles.savedIndex(act) == i
                    DiscStyles.deleteSaved(act, i)
                    if (wasActive) DiscStyles.setOn(act, false)
                    vinyl.reloadTheme()
                    refresh()
                }
            }
            .secondary("Close")
            .show()
    }

    /** نگه داشتن انگشت روی یه دیسک: چرخش واقعی (و حذف برای دیسک‌های شخصی) */
    private fun discMenu(key: String, file: File?) {
        val dlg = MdDialog(act).title("Vinyl")
        dlg.addView(
            MdDialog.toggleRow(act, "Real rotation", "The whole disc spins, not only the label", ThemeStore.realRotation(act, key)) { on ->
                ThemeStore.setRealRotation(act, key, on)
                vinyl.refreshSpinMode()
            }
        )
        if (file != null) dlg.danger("Delete") { confirmDelete(ThemeStore.DISC, file) }
        dlg.secondary("Close")
        dlg.show()
    }

    private fun confirmDelete(kind: String, f: File) {
        MdDialog.confirm(act, null, "Delete this image?", "Delete", true) {
            ThemeStore.delete(act, kind, f)
            vinyl.reloadTheme()
            refresh()
        }
    }
}
