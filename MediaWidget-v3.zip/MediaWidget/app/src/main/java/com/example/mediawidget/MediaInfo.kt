package com.example.mediawidget

import android.app.PendingIntent
import android.content.ComponentName
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.net.Uri

/** اطلاعات آهنگی که الان پخش میشه (از هر پلیری) */
data class MediaInfo(
    val hasAccess: Boolean = true,
    val hasMedia: Boolean = false,
    val title: String = "",
    val artist: String = "",
    val art: Bitmap? = null,
    val playing: Boolean = false,
    val openIntent: PendingIntent? = null,
    val pkg: String = ""
) {
    /** با عوض شدن آهنگ این کلید عوض میشه (برای کش بلر و رنگ‌ها) */
    val key: String
        get() {
            val a = art
            val sample = if (a != null) a.getPixel(a.width / 3, a.height / 3) else 0
            return "$title|$artist|${a?.width}x${a?.height}|$sample"
        }
}

object MediaReader {

    fun controllers(ctx: Context): List<MediaController>? {
        return try {
            val msm = ctx.getSystemService(MediaSessionManager::class.java)
            msm.getActiveSessions(ComponentName(ctx, MediaListenerService::class.java))
        } catch (e: SecurityException) {
            null
        }
    }

    fun pick(list: List<MediaController>): MediaController? =
        list.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING }
            ?: list.firstOrNull { it.metadata != null }

    fun read(ctx: Context): MediaInfo {
        val list = controllers(ctx) ?: return MediaInfo(hasAccess = false)
        val c = pick(list) ?: return MediaInfo()
        val md = c.metadata
        val raw = md?.getBitmap(MediaMetadata.METADATA_KEY_ART)
            ?: md?.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
            ?: loadUri(ctx, md?.getString(MediaMetadata.METADATA_KEY_ART_URI))
            ?: loadUri(ctx, md?.getString(MediaMetadata.METADATA_KEY_ALBUM_ART_URI))
        val art = raw?.copy(Bitmap.Config.ARGB_8888, false)
        return MediaInfo(
            hasMedia = md != null,
            title = md?.getString(MediaMetadata.METADATA_KEY_TITLE).orEmpty(),
            artist = (md?.getString(MediaMetadata.METADATA_KEY_ARTIST)
                ?: md?.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST)).orEmpty(),
            art = art,
            playing = c.playbackState?.state == PlaybackState.STATE_PLAYING,
            openIntent = c.sessionActivity,
            pkg = c.packageName
        )
    }

    private fun loadUri(ctx: Context, uri: String?): Bitmap? {
        if (uri.isNullOrEmpty()) return null
        val u = Uri.parse(uri)
        if (u.scheme != "content" && u.scheme != "file") return null
        return try {
            ctx.contentResolver.openInputStream(u)?.use { BitmapFactory.decodeStream(it) }
        } catch (e: Exception) {
            null
        }
    }
}
