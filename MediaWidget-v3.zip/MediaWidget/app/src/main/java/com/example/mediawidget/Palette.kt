package com.example.mediawidget

import android.graphics.Bitmap
import android.graphics.Color
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/** رنگ متن و آیکون‌ها: primary برای اسم آهنگ/آیکون‌ها، secondary (کم‌رنگ‌تر) برای خواننده */
class Tint(val primary: Int, val secondary: Int)

object Palette {

    private val NEUTRAL = Tint(Color.parseColor("#F2F2F2"), Color.argb(170, 242, 242, 242))

    fun neutral(): Tint = NEUTRAL

    /** از روی رنگ غالب کاور، یه سایه‌ی روشن و کم‌رنگ (پاستلی) از همون رنگ می‌سازه */
    fun tintFor(art: Bitmap?): Tint {
        if (art == null) return NEUTRAL
        val n = 32
        val small = Bitmap.createScaledBitmap(art, n, n, true)
        val hsv = FloatArray(3)
        val bins = 24
        val weight = DoubleArray(bins)
        val sx = DoubleArray(bins)
        val sy = DoubleArray(bins)
        var satSum = 0.0

        for (y in 0 until n) {
            for (x in 0 until n) {
                Color.colorToHSV(small.getPixel(x, y), hsv)
                val s = hsv[1].toDouble()
                val v = hsv[2].toDouble()
                satSum += s
                if (v < 0.15) continue
                val w = s * s * (0.4 + v)
                val bin = ((hsv[0] / 360f) * bins).toInt().coerceIn(0, bins - 1)
                val rad = Math.toRadians(hsv[0].toDouble())
                weight[bin] += w
                sx[bin] += w * cos(rad)
                sy[bin] += w * sin(rad)
            }
        }

        val avgSat = satSum / (n * n)
        var best = 0
        var bestScore = -1.0
        for (i in 0 until bins) {
            val a = (i + bins - 1) % bins
            val b = (i + 1) % bins
            val score = weight[i] + 0.5 * (weight[a] + weight[b])
            if (score > bestScore) {
                bestScore = score
                best = i
            }
        }
        if (avgSat < 0.08 || bestScore <= 0.0) return NEUTRAL

        val a = (best + bins - 1) % bins
        val b = (best + 1) % bins
        val vx = sx[a] + sx[best] + sx[b]
        val vy = sy[a] + sy[best] + sy[b]
        var hue = Math.toDegrees(atan2(vy, vx)).toFloat()
        if (hue < 0f) hue += 360f

        // هرچی کاور رنگی‌تر، رنگ پاستلی پررنگ‌تر
        val sat = 0.12f + 0.15f * min(1f, (avgSat / 0.3).toFloat())
        val primary = Color.HSVToColor(floatArrayOf(hue, sat, 0.97f))
        val secondary = Color.HSVToColor(170, floatArrayOf(hue, sat + 0.04f, 0.92f))
        return Tint(primary, secondary)
    }
}
