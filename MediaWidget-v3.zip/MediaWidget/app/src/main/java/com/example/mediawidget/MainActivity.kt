package com.example.mediawidget

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (24 * resources.displayMetrics.density).toInt()

        val message = TextView(this).apply {
            text = "1) Allow Notification access for Media Widget.\n" +
                "2) Home screen: long press > Widgets > Media Widget."
            textSize = 16f
            setPadding(0, 0, 0, pad)
        }
        val openButton = Button(this).apply {
            text = "Open access settings"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
            }
        }

        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(pad, pad, pad, pad)
            addView(message)
            addView(openButton)
        })
    }
}
