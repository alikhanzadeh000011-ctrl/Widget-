package com.example.mediawidget

import android.appwidget.AppWidgetManager
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.os.Bundle
import android.provider.Settings
import android.widget.RemoteViews
import kotlin.math.min

/**
 * ویجت‌های «NOW PLAYING» سبک MD: کارت شیشه‌ای رنگی با فونت پیکسلی، کاور، چند کلید (LIKE، PLAY، PREVIOUS، NEXT)
 * و (تو نسخه‌ی بزرگ) ردیف «RECENTLY PLAYED». کل ظاهر یه تصویر واحده؛ کلیدها فقط ناحیه‌ی لمس شفاف دارن.
 */
object PixelWidgets {

    private const val WHITE = 0xFFFFFFFF.toInt()

    fun build(ctx: Context, mgr: AppWidgetManager?, id: Int, kind: Kind, info: MediaInfo, set: VSettings.Data): RemoteViews {
        PixelFont.ensure(ctx)
        val rv = RemoteViews(ctx.packageName, R.layout.pixel_widget)
        val d = ctx.resources.displayMetrics.density
        val opts = if (mgr != null) mgr.getAppWidgetOptions(id) else Bundle()
        var wDp = opts.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 0)
        var hDp = opts.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT, 0)
        if (wDp < 50) wDp = kind.defW
        if (hDp < 40) hDp = kind.defH
        wDp = wDp.coerceAtMost(700)
        hDp = hDp.coerceAtMost(600)
        val w = wDp * d
        val h = hDp * d
        val sc = WidgetRenderer.fitScale(ctx, w, h, 5.5f)
        val bw = (w * sc).toInt().coerceAtLeast(2)
        val bh = (h * sc).toInt().coerceAtLeast(2)
        val bmp = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888)
        // شکل: مستطیل = کل ناحیه‌ی ویجت (بلر ممکنه)، مربع = کارت مربع وسط ویجت (بلر نه)
        val square = VSettings.hasShape(kind) && !set.rect
        val radio = set.theme == VSettings.RADIO
        val blur = !square && !radio && set.theme == VSettings.BLUR
        val cw = if (square) min(bw, bh).toFloat() else bw.toFloat()
        val ch = if (square) min(bw, bh).toFloat() else bh.toFloat()
        val ox = (bw - cw) / 2f
        val oy = (bh - ch) / 2f
        val cv = Canvas(bmp)
        cv.translate(ox, oy)
        if (kind == Kind.NOW22) drawSmall(ctx, cv, cw, ch, d * sc, info, blur, radio) else draw(ctx, cv, kind, cw, ch, d * sc, info, blur, radio)
        // بلر واقعی One UI: رنگ نیمه‌شفاف روی ویوی ریشه، بقیه (کارت، شیشه، کاور...) همون قبلی روش کشیده میشه
        rv.setInt(android.R.id.background, "setBackgroundColor", if (blur) Color.argb(VSettings.blurAlpha(set.blur), 0, 0, 0) else 0)
        rv.setImageViewBitmap(R.id.scene, bmp)

        // ناحیه‌ی لمس کلیدها دقیقاً روی کلیدهای کشیده‌شده
        val k = keysRect(kind, cw, ch)
        k.offset(ox, oy)
        rv.setViewPadding(
            R.id.keys_box,
            (k.left / sc).toInt(), (k.top / sc).toInt(),
            ((bw - k.right) / sc).toInt(), ((bh - k.bottom) / sc).toInt()
        )
        val base = 40 + kind.ordinal * 6
        if (kind == Kind.NOW22) {
            // 2x2: فقط نشانه‌ی پخش/توقف بالا-راست لمس میشه (پخش/توقف)؛ بقیه‌ی ویجت اپ رو باز می‌کنه
            val t = action(ctx, kind, BaseWidgetProvider.ACTION_TOGGLE, base + 1)
            rv.setOnClickPendingIntent(R.id.k_like, t)
            rv.setOnClickPendingIntent(R.id.k_play, t)
            rv.setOnClickPendingIntent(R.id.k_prev, t)
            rv.setOnClickPendingIntent(R.id.k_next, t)
        } else {
            rv.setOnClickPendingIntent(R.id.k_like, action(ctx, kind, BaseWidgetProvider.ACTION_LIKE, base))
            rv.setOnClickPendingIntent(R.id.k_play, action(ctx, kind, BaseWidgetProvider.ACTION_TOGGLE, base + 1))
            rv.setOnClickPendingIntent(R.id.k_prev, action(ctx, kind, BaseWidgetProvider.ACTION_PREV, base + 2))
            rv.setOnClickPendingIntent(R.id.k_next, action(ctx, kind, BaseWidgetProvider.ACTION_NEXT, base + 3))
        }
        val openApp = if (!info.hasAccess) {
            WidgetRenderer.activity(ctx, Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS), 1)
        } else {
            WidgetRenderer.launchPlayer(ctx, "")   // لمس ویجت: باز شدن خود اپ (نه پلیر)
        }
        rv.setOnClickPendingIntent(android.R.id.background, openApp)
        return rv
    }

    private fun action(ctx: Context, kind: Kind, action: String, code: Int) =
        android.app.PendingIntent.getBroadcast(
            ctx, code, Intent(ctx, kind.provider).setAction(action),
            android.app.PendingIntent.FLAG_IMMUTABLE or android.app.PendingIntent.FLAG_UPDATE_CURRENT
        )

    private fun big(kind: Kind) = kind == Kind.NOWBIG

    /** مستطیل ردیف کلیدها (به پیکسل تصویر) */
    private fun keysRect(kind: Kind, w: Float, h: Float): RectF =
        if (kind == Kind.NOW22) RectF(0.60f * w, 0.04f * h, 0.96f * w, 0.26f * h)
        else if (big(kind)) RectF(0.300f * w, 0.835f * h, 0.955f * w, 0.935f * h)
        else RectF(0.305f * w, 0.715f * h, 0.955f * w, 0.895f * h)

    private fun draw(ctx: Context, c: Canvas, kind: Kind, w: Float, h: Float, du: Float, info: MediaInfo, blur: Boolean, radio: Boolean = false) {
        val isBig = big(kind)
        val radius = if (isBig) 0.075f * w else 0.17f * h
        val art = info.art
        val playing = info.hasMedia && info.playing

        val card = RectF(0f, 0f, w, h)
        body(c, card, radius, du, art, blur, radio)

        val fill = Paint(Paint.ANTI_ALIAS_FLAG)
        val text = Paint(Paint.ANTI_ALIAS_FLAG)
        text.color = if (radio) RADIO_TEXT else Color.argb(235, 255, 255, 255)
        val dim = Paint(Paint.ANTI_ALIAS_FLAG)
        dim.color = if (radio) RADIO_DIM else Color.argb(120, 255, 255, 255)

        // پنل بالایی
        val panel = if (isBig) RectF(0.045f * w, 0.045f * h, 0.955f * w, 0.705f * h) else RectF(0.04f * w, 0.075f * h, 0.96f * w, 0.585f * h)
        fill.color = if (radio) Color.rgb(4, 6, 5) else Color.argb(16, 255, 255, 255)
        val pr = if (isBig) 0.05f * w else 0.09f * h
        c.drawRoundRect(panel, pr, pr, fill)
        if (radio) lcdEdge(c, panel, pr, du)

        // کاور فعلی
        val coverSize = if (isBig) 0.29f * w else 0.34f * h
        val cover = if (isBig) RectF(panel.left + 0.035f * w, panel.top + 0.035f * w, panel.left + 0.035f * w + coverSize, panel.top + 0.035f * w + coverSize)
        else RectF(panel.left + 0.033f * w, panel.centerY() - coverSize / 2f, panel.left + 0.033f * w + coverSize, panel.centerY() + coverSize / 2f)
        drawCover(c, art ?: (if (blur) null else WidgetRenderer.blankCover(ctx)), cover, 0.12f * coverSize)

        val textX = cover.right + (if (isBig) 0.04f * w else 0.03f * w)
        val maxW = panel.right - textX - (if (isBig) 0.04f * w else 0.03f * w)

        // NOW PLAYING + آیکن دیسک
        val pHead = if (isBig) 0.0033f * w else 0.0074f * h
        val headBase = cover.top + (if (isBig) 0.14f else 0.30f) * coverSize
        val iconR = 4.6f * pHead
        if (radio) {
            // رادیو: فقط متن وضعیت (بدون آیکن دیسک)، مثل صفحه‌ی LCD
            PixelFont.draw(c, if (playing) "NOW PLAYING" else "NOT PLAYING", textX, headBase, pHead, dim)
        } else {
            fill.color = Color.argb(235, 255, 255, 255)
            c.drawCircle(textX + iconR, headBase - 3.5f * pHead, iconR, fill)
            fill.color = Color.argb(90, 0, 0, 0)
            c.drawCircle(textX + iconR, headBase - 3.5f * pHead, iconR * 0.38f, fill)
            PixelFont.draw(c, "NOW PLAYING", textX + 2f * iconR + 2.2f * pHead, headBase, pHead, text)
        }

        // عنوان (و خواننده)
        val title = if (!info.hasMedia) "Not playing" else info.title
        val artist = if (!info.hasMedia) "Open a music player" else info.artist
        if (isBig) {
            drawLine(c, title, textX, cover.top + 0.72f * coverSize, 0.0036f * w, maxW, text, du)
            drawLine(c, artist, textX, cover.top + 0.96f * coverSize, 0.0033f * w, maxW, dim.also { it.color = if (radio) RADIO_ARTIST else Color.argb(170, 255, 255, 255) }, du)
        } else {
            val joined = if (artist.isNotEmpty() && info.hasMedia) "$title-$artist" else title
            drawLine(c, joined, textX, cover.top + 0.93f * coverSize, 0.0087f * h, maxW, text, du)
        }

        // RECENTLY PLAYED (فقط نسخه‌ی بزرگ)
        if (isBig) {
            dim.color = if (radio) RADIO_DIM else Color.argb(120, 255, 255, 255)
            PixelFont.draw(c, "RECENTLY PLAYED", panel.left + 0.035f * w, 0.455f * h, 0.0032f * w, dim)
            val recents = RecentStore.recent(ctx, RecentStore.keyOf(info), 4)
            val size = 0.19f * w
            val gap = (panel.width() - 0.07f * w - 4f * size) / 3f
            for (i in 0 until 4) {
                val x = panel.left + 0.035f * w + i * (size + gap)
                val r = RectF(x, 0.50f * h, x + size, 0.50f * h + size)
                val b = recents.getOrNull(i)?.second
                drawCover(c, b, r, 0.12f * size)
            }
        }

        // شیارهای بلندگو (چپ پایین)
        val gx0 = if (isBig) 0.045f * w else 0.045f * w
        val gx1 = if (isBig) 0.255f * w else 0.265f * w
        val gy0 = if (isBig) 0.805f * h else 0.665f * h
        val gy1 = if (isBig) 0.94f * h else 0.895f * h
        val lines = 7
        val lineH = (gy1 - gy0) / (lines * 1.9f)
        fill.color = if (radio) Color.argb(34, 255, 255, 255) else Color.argb(42, 255, 255, 255)
        for (i in 0 until lines) {
            val y = gy0 + i * ((gy1 - gy0 - lineH) / (lines - 1))
            val shrink = if (i == lines - 1) 0.15f * (gx1 - gx0) else if (i == 0) 0.02f * (gx1 - gx0) else 0f
            c.drawRoundRect(RectF(gx0 + shrink, y, gx1 - shrink, y + lineH), lineH / 2f, lineH / 2f, fill)
        }

        // کلیدها و برچسب‌ها
        val k = keysRect(kind, w, h)
        val gapK = 0.012f * k.width()
        val kw = (k.width() - 3f * gapK) / 4f
        val labels = arrayOf("LIKE", "PLAY", "PREVIOUS", "NEXT")
        val pLab = if (isBig) 0.0022f * w else 0.0047f * h
        dim.color = if (radio) Color.argb(125, 150, 150, 156) else Color.argb(105, 255, 255, 255)
        for (i in 0 until 4) {
            val x = k.left + i * (kw + gapK)
            val key = RectF(x, k.top, x + kw, k.bottom)
            // بدنه‌ی کلید
            if (radio) {
                radioKey(c, key, 0.06f * kw, du)
            } else {
                fill.color = Color.argb(28, 255, 255, 255)
                c.drawRoundRect(key, 0.06f * kw, 0.06f * kw, fill)
                val hl = Paint(Paint.ANTI_ALIAS_FLAG)
                hl.style = Paint.Style.STROKE
                hl.strokeWidth = 1f * du
                hl.color = Color.argb(22, 255, 255, 255)
                c.drawRoundRect(key, 0.06f * kw, 0.06f * kw, hl)
            }
            // برچسب بالای کلید (وسط‌چین)
            val lw = PixelFont.width(labels[i], pLab)
            val baseY = k.top - (if (isBig) 0.025f * h else 0.05f * h)
            val tx = key.centerX() - lw / 2f
            PixelFont.draw(c, labels[i], tx, baseY, pLab, dim)
            // LED: فقط سبز کنار PLAY وقتی پخش میشه
            val ledR = 3.4f * pLab
            if (i == 1) {
                fill.color = if (radio) (if (playing) Color.rgb(255, 70, 60) else Color.argb(150, 90, 25, 22)) else if (playing) Color.rgb(60, 220, 110) else Color.argb(110, 40, 40, 40)
                c.drawCircle(tx - ledR * 2.2f, baseY - 3.5f * pLab, ledR, fill)
                val ring = Paint(Paint.ANTI_ALIAS_FLAG)
                ring.style = Paint.Style.STROKE
                ring.strokeWidth = 1.2f * du
                ring.color = Color.argb(200, 10, 20, 10)
                c.drawCircle(tx - ledR * 2.2f, baseY - 3.5f * pLab, ledR + 0.6f * du, ring)
            }
        }
    }

    private val RADIO_TEXT = Color.argb(240, 150, 240, 175)
    private val RADIO_ARTIST = Color.argb(205, 120, 205, 150)
    private val RADIO_DIM = Color.argb(150, 105, 175, 128)

    /** بدنه‌ی کارت: شیشه‌ای (بلر کاور / بلر واقعی) یا بدنه‌ی مشکی رادیو */
    private fun body(c: Canvas, card: RectF, radius: Float, du: Float, art: Bitmap?, blur: Boolean, radio: Boolean) {
        val clip = Path()
        clip.addRoundRect(card, radius, radius, Path.Direction.CW)
        c.save()
        c.clipPath(clip)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        if (radio) {
            p.shader = LinearGradient(0f, card.top, 0f, card.bottom, Color.rgb(42, 42, 45), Color.rgb(20, 20, 22), Shader.TileMode.CLAMP)
            c.drawRect(card, p)
            p.shader = LinearGradient(0f, card.top, 0f, card.top + card.height() * 0.22f, Color.argb(34, 255, 255, 255), Color.argb(0, 255, 255, 255), Shader.TileMode.CLAMP)
            c.drawRect(card.left, card.top, card.right, card.top + card.height() * 0.22f, p)
        } else {
            val bgSrc = if (art != null) VinylArt.coverBackground(art, card.width().toInt(), card.height().toInt()) else VinylArt.greyBackground(card.width().toInt(), card.height().toInt())
            if (!blur) c.drawBitmap(bgSrc, null, card, Paint(Paint.FILTER_BITMAP_FLAG))
            // جلای شیشه‌ای بالا
            p.shader = LinearGradient(0f, 0f, 0f, card.height() * 0.35f, Color.argb(20, 255, 255, 255), Color.argb(0, 255, 255, 255), Shader.TileMode.CLAMP)
            c.drawRect(0f, 0f, card.width(), card.height() * 0.35f, p)
        }
        c.restore()
        val border = Paint(Paint.ANTI_ALIAS_FLAG)
        border.style = Paint.Style.STROKE
        border.strokeWidth = 1.6f * du
        border.color = if (radio) Color.argb(60, 255, 255, 255) else Color.argb(36, 255, 255, 255)
        c.drawRoundRect(RectF(card).also { it.inset(border.strokeWidth / 2f, border.strokeWidth / 2f) }, radius, radius, border)
    }

    /** لبه‌ی داخلی صفحه‌ی LCD رادیو: سایه‌ی تیره‌ی بالا و روشنایی کم پایین */
    private fun lcdEdge(c: Canvas, panel: RectF, pr: Float, du: Float) {
        val e = Paint(Paint.ANTI_ALIAS_FLAG)
        e.style = Paint.Style.STROKE
        e.strokeWidth = 2f * du
        e.color = Color.argb(150, 0, 0, 0)
        c.drawRoundRect(RectF(panel).also { it.inset(du, du) }, pr, pr, e)
        e.strokeWidth = 1f * du
        e.color = Color.argb(26, 255, 255, 255)
        c.drawRoundRect(RectF(panel).also { it.inset(-0.5f * du, -0.5f * du) }, pr, pr, e)
    }

    /** کلید برجسته‌ی رادیو */
    private fun radioKey(c: Canvas, key: RectF, r: Float, du: Float) {
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.color = Color.argb(150, 0, 0, 0)
        c.drawRoundRect(RectF(key.left, key.top + 1.5f * du, key.right, key.bottom + 1.5f * du), r, r, p)
        p.shader = LinearGradient(0f, key.top, 0f, key.bottom, Color.rgb(62, 62, 66), Color.rgb(36, 36, 39), Shader.TileMode.CLAMP)
        c.drawRoundRect(key, r, r, p)
        p.shader = null
        p.style = Paint.Style.STROKE
        p.strokeWidth = 1f * du
        p.color = Color.argb(46, 255, 255, 255)
        c.drawRoundRect(RectF(key).also { it.inset(0.5f * du, 0.5f * du) }, r, r, p)
    }

    /** Now Playing 2x2 («Radio» در MD): پنل بالا با کاور، نشانه‌ی پخش/توقف، عنوان و خواننده؛ پایین سه دسته شیار بلندگو */
    private fun drawSmall(ctx: Context, c: Canvas, w: Float, h: Float, du: Float, info: MediaInfo, blur: Boolean, radio: Boolean) {
        val u = minOf(w, h)
        val radius = 0.17f * u
        val art = info.art
        val playing = info.hasMedia && info.playing
        val card = RectF(0f, 0f, w, h)
        body(c, card, radius, du, art, blur, radio)

        val fill = Paint(Paint.ANTI_ALIAS_FLAG)
        val text = Paint(Paint.ANTI_ALIAS_FLAG)
        text.color = if (radio) RADIO_TEXT else Color.argb(235, 255, 255, 255)
        val sub = Paint(Paint.ANTI_ALIAS_FLAG)
        sub.color = if (radio) RADIO_ARTIST else Color.argb(170, 255, 255, 255)

        val panel = RectF(0.06f * w, 0.06f * h, 0.94f * w, 0.76f * h)
        val pr = 0.09f * u
        fill.color = if (radio) Color.rgb(4, 6, 5) else Color.argb(16, 255, 255, 255)
        c.drawRoundRect(panel, pr, pr, fill)
        if (radio) lcdEdge(c, panel, pr, du)

        // کاور بالا-چپ
        val cs = 0.30f * u
        val cover = RectF(panel.left + 0.05f * u, panel.top + 0.05f * u, panel.left + 0.05f * u + cs, panel.top + 0.05f * u + cs)
        drawCover(c, art ?: (if (blur) null else WidgetRenderer.blankCover(ctx)), cover, 0.12f * cs)

        // نشانه‌ی پخش (دو خط) یا توقف (مثلث) بالا-راست
        val ix = panel.right - 0.09f * u
        val iy = cover.top + 0.03f * u
        fill.color = text.color
        if (playing) {
            c.drawRect(ix, iy, ix + 0.022f * u, iy + 0.085f * u, fill)
            c.drawRect(ix + 0.05f * u, iy, ix + 0.072f * u, iy + 0.085f * u, fill)
        } else {
            val tri = Path()
            tri.moveTo(ix, iy)
            tri.lineTo(ix + 0.072f * u, iy + 0.0425f * u)
            tri.lineTo(ix, iy + 0.085f * u)
            tri.close()
            c.drawPath(tri, fill)
        }

        // عنوان و خواننده
        val title = if (!info.hasMedia) "Not playing" else info.title
        val artist = if (!info.hasMedia) "Open a music player" else info.artist
        val tx = panel.left + 0.05f * u
        val maxW = panel.width() - 0.10f * u
        drawLine(c, title, tx, cover.bottom + 0.17f * u, 0.0092f * u, maxW, text, du)
        drawLine(c, artist, tx, cover.bottom + 0.30f * u, 0.0078f * u, maxW, sub, du)

        // شیارهای بلندگو: سه دسته، هر دسته سه خط
        fill.color = if (radio) Color.argb(34, 255, 255, 255) else Color.argb(42, 255, 255, 255)
        val gw = 0.24f * w
        val lh = 0.011f * h
        for (g in 0 until 3) {
            val cx = (0.2f + 0.3f * g) * w
            for (i in 0 until 3) {
                val y = 0.815f * h + i * 0.033f * h
                c.drawRoundRect(RectF(cx - gw / 2f, y, cx + gw / 2f, y + lh), lh / 2f, lh / 2f, fill)
            }
        }
    }

    /** یه خط متن: پیکسلی برای ASCII و فونت معمولی برای بقیه (فارسی و...) */
    private fun drawLine(c: Canvas, s: String, x: Float, baseline: Float, p: Float, maxW: Float, paint: Paint, du: Float) {
        if (s.isEmpty()) return
        if (PixelFont.supports(s)) {
            var pp = p
            // اگه جا نشد اول کوچیک‌تر، بعد کوتاه
            while (pp > p * 0.6f && PixelFont.width(s, pp) > maxW) pp *= 0.94f
            PixelFont.draw(c, PixelFont.fit(s, pp, maxW), x, baseline, pp, paint)
        } else {
            val tp = Paint(paint)
            tp.typeface = Typeface.DEFAULT_BOLD
            tp.textSize = 9f * p
            var t = s
            while (t.length > 1 && tp.measureText(t) > maxW) t = t.dropLast(1)
            c.drawText(if (t.length < s.length) "$t…" else t, x, baseline, tp)
        }
    }

    private fun drawCover(c: Canvas, art: Bitmap?, r: RectF, radius: Float) {
        val path = Path()
        path.addRoundRect(r, radius, radius, Path.Direction.CW)
        c.save()
        c.clipPath(path)
        if (art != null) {
            val m = minOf(art.width, art.height)
            val src = android.graphics.Rect((art.width - m) / 2, (art.height - m) / 2, (art.width + m) / 2, (art.height + m) / 2)
            c.drawBitmap(art, src, r, Paint(Paint.FILTER_BITMAP_FLAG))
        } else {
            val p = Paint()
            p.color = Color.argb(70, 0, 0, 0)
            c.drawRect(r, p)
        }
        c.restore()
        val edge = Paint(Paint.ANTI_ALIAS_FLAG)
        edge.style = Paint.Style.STROKE
        edge.strokeWidth = 1.5f
        edge.color = Color.argb(60, 255, 255, 255)
        c.drawRoundRect(r, radius, radius, edge)
    }
}
